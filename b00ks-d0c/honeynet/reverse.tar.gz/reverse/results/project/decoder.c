/*
 * decoder.c
 * Job
 *
 *
 * This decoder is based on the code reversed from
 * the RC binary, nothing was done to clean the code up.
 *
 *
 * Options: decoder [-h] [-a] [-p] <filename>
 *
 *  -p: the <filename> is a pcap dump.
 *  -a: also print the ascii strings
 *  -h: the <filename> contains 1 packet with pcap header
 *
 *  option -h is braindead and buggy.
 *
 *  Tip for compiling: you need to figure out where your
 *  pcap includes and libs are (need -lpcap). On linux
 *  I used the includes from tcpdump.  
 *
 *  My compile line:
 *  gcc -I /usr/include/pcap -I ./linux-include/ -g decoder.c -o decoder -lpcap
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <getopt.h>
#include <pcap/pcap.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/if_ether.h>
#include <netinet/ip.h>
#include <netinet/ip_var.h>
#include <netinet/udp.h>
#include <netinet/udp_var.h>
#include <netinet/tcp.h>
#include <netinet/tcpip.h>

char outbuf[2048];

static pcap_t *pd;

extern int optind;
extern int opterr;
extern char *optarg;

int doheader = 0;
int doascii = 0;
int dopcap = 0;

/*
 * This is the reverse engineered decode routine from 'foo'.
 * Followed the register naming for readability with the disasm.
 */

decode(unsigned int len, unsigned char *inbuf, unsigned char *outbuf)
{
  int eax, ebx, ecx, edx, i, j;
  unsigned char *localbuf;

  printf("starting decode of packet size %d\n",len);

  for(eax=0;eax<16;eax++) printf("%02X ",inbuf[eax]);
  printf("\n");

  outbuf[0] = 0;

  ebx = len - 1;

  if (ebx<0) return(0);

  eax = (len+3)&0xFFFC;

  localbuf = malloc(eax);
  printf("local buf of size %d\n",eax);

  while(ebx>=0) {
     edx = ebx - 1;
     if (ebx>0) {
        eax = inbuf[ebx];
        edx = inbuf[edx]; 
        eax -= edx;
     } else
        eax = inbuf[0];

     ecx = eax - 23;

     while( ecx<0 ) ecx += 0x100;

     if (len>0) {
        for(edx=0;edx<len;edx++) localbuf[edx] = outbuf[edx];
     } 
     outbuf[0] = (ecx & 0xFF);

     if (len>1) {
        for(edx=1;edx<len;edx++) outbuf[edx] = localbuf[edx-1];
     }

     sprintf(outbuf,"%c%s",(ecx&0xFF),localbuf);

     ebx -= 1;
  }
 
  for(i=0;i<len;i+=16) {
    for(j=0;j<16;j++) printf("%02X ",(unsigned char)outbuf[i+j]);
    printf(" ");
    for(j=0;j<16;j++)
      if (isprint((unsigned char)outbuf[i+j]))
        printf("%c",(unsigned char)outbuf[i+j]);
      else
        printf(".");
    printf("\n");
  }

  if (doascii) {
    for(i=0;i<len;i++) 
      if (isascii((unsigned char)outbuf[i+j]))
        printf("%c",(unsigned char)outbuf[i]);
      else
        printf(".");
    printf("\n");
  }

  return(0);
}


void
printer(u_char *user, const struct pcap_pkthdr *h, unsigned char *p)
{
  unsigned int caplen =  h->caplen;
  struct ether_header *ep;
  struct ip *ip;
  unsigned short n;

  printf("reading packet....\n");

  ep = (struct ether_header *)p;
  p += sizeof(struct ether_header);
  caplen -= sizeof(struct ether_header);

  if (ntohs(ep->ether_type) != ETHERTYPE_IP) {
    printf("not an IP packet\n");
    return;
  }

  ip = (struct ip *)p;
  p += sizeof(struct ip);

  if (ip->ip_p != 11) {
    fprintf(stderr,"no protocol 11\n");
    return;
  }

  n = ntohs(ip->ip_len);
  printf("packet length %d. %x\n", n, ip->ip_len);

  printf("command %d.\n",*p);

  memset(outbuf,0,2038);
  decode(n-2, p+2, outbuf);

}

main(int argc, char *argv[])
{
  int fd, n, i, j;
  int op, cnt = -1;
  char inbuf[2048], ebuf[PCAP_ERRBUF_SIZE];
  unsigned char *pcap_userdata = NULL;

  opterr = 0;
  while ((op = getopt(argc, argv, "hap")) != EOF)
    switch (op) {
      case 'h':   ++doheader;
                  break;
      case 'a':   ++doascii;
                  break;
      case 'p':   ++dopcap;
                  break;
    }

  if (optind == argc) {
      printf("need a filename as argument\n");
      exit(1);
  }

  if (dopcap) {
      pd = pcap_open_offline(argv[optind], ebuf);
      if (pd == NULL) {
         perror(ebuf);
         exit(1);
      }
      if (pcap_loop(pd, cnt, (pcap_handler)printer, pcap_userdata) < 0) {
        (void)fprintf(stderr, "%s: pcap_loop: %s\n",
          argv[0], pcap_geterr(pd));
      exit(1);
    }
    pcap_close(pd);
    exit(0);
  }

  if ((fd=open(argv[optind], O_RDONLY))<0) {
    perror("open");
    exit(1);
  }

  if (doheader) {
    /* read tcpdump header */
    n = read(fd,inbuf, 0x30);

    /* read linklevel header */
    n = read(fd,inbuf, 14);

    /* read IP header */
    n = read(fd,inbuf, 20);

    if (n<0) {
      perror("read");
      exit(1);
    }

    if (inbuf[9]!=11) {
      fprintf(stderr,"no protocol 11\n");
      exit(1);
    }

  }

  n = read(fd,inbuf, sizeof(inbuf));
  memset(outbuf,0,2038);
  decode(n-2, inbuf+2, outbuf);

  return(0);
}

