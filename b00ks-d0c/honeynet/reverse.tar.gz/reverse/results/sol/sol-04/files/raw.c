/* the-binary client v. 0.1
   (C) Gijs Hollestelle     */

#include <stdio.h>
#include <sys/types.h>
#include <netinet/in_systm.h>  
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>

int main () {
  int sockd;
  int size,t;
  unsigned char v,d;
  char *buffer=malloc(1024);
  sockd = socket(PF_INET,SOCK_RAW,0xb);
  while (1) {
    v = 0;
    size = recv(sockd,buffer,1024,0);
    for (t=0;t<size && t<422;t++) {
      d = *(buffer+t);
      d = (d - v -0x17);
      v = *(buffer+t);
      *(buffer+t) = d;
      printf("%.2x",d);
    }
    printf("\n");
    fflush(0);
  }
  return 0;
}
