#!/usr/bin/perl
#
#Packet decoder
#
sub getstr {
  my ($w,$off) = @_;
  my $r = "";
  my $x,$v;
  for ($x=$off;$x<length($w);$x++) {
    $v = substr($w,$x,1);
    last if ($v eq "\x00");
    $r .= $v;
  }
  return $r;
}

sub getip {
  my ($w,$off) = @_;
  my $ip = substr($w,$off,4);
  $ip =~ s/(.)/ord($1)."."/eg;
  $ip =~ s/\.$//;
  return $ip;
}

$| = 1;
while (<>) {
  $msg = $_;
  $msg =~ s/(..)/chr(hex($1))/eg;
  $mode = ord(substr($msg,23,1)); 
  if ($mode == 1) {
    print "Ping packet\n";
  } elsif ($mode == 2) {
    $decoy = ord(substr($msg,24,1));
    $ip = getip($msg,25);
    print "Set master IP to $ip decoymode $decoy\n";
  } elsif ($mode == 3) {
    $cmd = getstr($msg,24);
    print "Exec '$cmd' and send results back.\n";
  } elsif ($mode == 4) {
    $target = getstr($msg,31);
    print "Start flooding $target using DNS floods\n";    
  } elsif ($mode == 5) {
    $src = getip($msg,30);
    $target = getstr($msg,35);
    print "Do a fragmented UDP flood on $target source address $src\n";
  } elsif ($mode == 6) {
    print "Bind a rootshell to port 23281\n";
  } elsif ($mode == 7) {
    $cmd = getstr($msg,24);
    print "Exec '$cmd'\n";
  } elsif ($mode == 8) {
    print "Stop all attacks\n";
  } elsif ($mode == 9) {
    $target = getstr($msg,32);
    print "Start flooding $target using DNS floods\n";
  } elsif ($mode == 10) {
    $src = getip($msg,31);
    $target = getstr($msg,36);
    print "Do a SYN flood on $target source address $src\n";
  } elsif ($mode == 11) {
    $src = getip($msg,32);
    $target = getstr($msg,37);
    print "Do a SYN flood on $target source address $src\n";
  } elsif ($mode == 12) {
    $src = getip($msg,32);
    $target = getstr($msg,37);
    print "Start flooding $target using DNS floods\n";
  } else {
    print "Unknown command $mode received\n";
  }
}
