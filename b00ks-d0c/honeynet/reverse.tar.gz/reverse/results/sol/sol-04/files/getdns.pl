#!/usr/bin/perl
# 
# Getdns.pl get all the dns servers from the-binary
# (C) 2002 Gijs Hollestelle

open BIN,"the-binary";
seek(BIN,148012,0);
while ($v++ < 11441) {
  $n = read(BIN,$buf,4);
  for($x=0;$x<$n;$x++) {
    print ord(substr($buf,$x,1));
    print "." if ($x<3);
  }
  print "\n";
}