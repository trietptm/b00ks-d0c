Encoder( int length_to_encode, char * plaintext, char * cipher ) {

	int count;

	*cipher = 0;
	sprintf( cipher, "%c", *plaintext + 0x17 );

	count = 1;
	if( count != length_to_encode ) {

		do {
			cipher[count] = cipher[ count - 1 ] + plaintext[ count ] + 0x17;
			count ++;
		} while( count != length_to_encode );
	}

	return;
}
