char null_char = 0;

void
decoder( int length, char * ciphertext, char plainbuf[] ) {

	char * buf_ptr;
	char pkt_buf[ (length + 3) & 0xfffffffc ]; // round up to multiple of 4
	int decoded_char;

	buf_ptr = pkt_buf;
	*plainbuf = seed;
	index = length - 1;
	if( length > 0 ) {

		do {

			if( index != 0 ) {

				decoded_char = ciphertext[ index ] - ciphertext[ index - 1 ];
			} else {

				decoded_char = *ciphertext;
			}

			decoded_char -= 0x17;
			while( decoded_char < 0 ) {

				decoded_char += 0x100;
			}

			memcpy( buf_ptr, plainbuf, length );
	
			*plainbuf = decoded_char & 0xff;

			memcpy( plainbuf + 1, buf_ptr, length - 1 );

			sprintf( plainbuf, "%c%s", decoded_char, buf_ptr );
			index --;
		} while( index >= 0 );
	}
	return;
}