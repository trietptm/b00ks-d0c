#include <libnet.h>

void usage(char *);
int
get_payload( char buf[], unsigned buf_len );

int
main(int argc, char **argv)
{
    int network, packet_size, c;
    u_long src_ip, dst_ip;
    u_char *packet;
    char payload[ 2000 ];
    int payload_len;

    src_ip  = 0;
    dst_ip  = 0;

    while((c = getopt(argc, argv, "d:s:")) != EOF)
    {      
        switch (c)
        {
            case 'd':
                if (!(dst_ip = libnet_name_resolve(optarg, 0)))
                {
                    libnet_error(LIBNET_ERR_FATAL, "Bad destination IP address: %s\n", optarg);
                }
                break;
            case 's':
                if (!(src_ip = libnet_name_resolve(optarg, 0)))
                {
                    libnet_error(LIBNET_ERR_FATAL, "Bad source IP address: %s\n", optarg);
                }
                break;
        }
    }
    if (!src_ip || !dst_ip )
    {
        usage(argv[0]);
        exit(EXIT_FAILURE);
    }
    payload_len = get_payload( payload, sizeof( payload ) );

    packet_size = LIBNET_IP_H + payload_len;

    libnet_init_packet(packet_size, &packet);
    if (packet == NULL)
    {
        libnet_error(LIBNET_ERR_FATAL, "libnet_init_packet failed\n");
    }

    network = libnet_open_raw_sock(IPPROTO_RAW);
    if (network == -1)
    {
        libnet_error(LIBNET_ERR_FATAL, "Can't open network.\n");
    }
    

    libnet_build_ip(payload_len,   /* size of the packet sans IP header */
            IPTOS_LOWDELAY,         /* IP tos */
            242,                    /* IP ID */
            0,                      /* frag stuff */
            48,                     /* TTL */
            11,            /* transport protocol */
            src_ip,                 /* source IP */
            dst_ip,                 /* destination IP */
            payload,                   /* payload (none) */
            payload_len,                      /* payload length */
            packet);                /* packet header memory */

    c = libnet_write_ip(network, packet, packet_size);
    if (c < packet_size)
    {
        libnet_error(LN_ERR_WARNING, "libnet_write_ip only wrote %d bytes\n", c);
    }
    else
    {
        printf("construction and injection completed, wrote all %d bytes\n", c);
    }

    /*
     *  Shut down the interface.
     */
    if (libnet_close_raw_sock(network) == -1)
    {
        libnet_error(LN_ERR_WARNING, "libnet_close_raw_sock couldn't close the interface");
    }


    /*
     *  Free packet memory.
     */
    libnet_destroy_packet(&packet);

    return (c == -1 ? EXIT_FAILURE : EXIT_SUCCESS);
}


void
usage(char *name)
{
    fprintf(stderr, "usage: %s -s s_ip.s_port -d d_ip.d_port\n", name);
}

int
get_payload( char buf[], unsigned buf_len ) {


	int c;
	int i = 0;
	while( ( c = fgetc( stdin ) ) != EOF && i < buf_len ) {

		buf[ i ] = c;
		i ++;
	}

	return i;
}


