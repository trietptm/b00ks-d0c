#include <stdio.h>

int
main( void ) {

	int prev_cipher;
	int curr_plaintext;
	int curr_cipher;

	prev_cipher = 0;
	putchar( 2 );
	putchar( 1 );
	while( (curr_plaintext = fgetc( stdin ) ) != EOF ) {

		curr_cipher = curr_plaintext + prev_cipher + 0x17;
		putchar( curr_cipher );
		prev_cipher = curr_cipher;
	}

	return 0;
}	
