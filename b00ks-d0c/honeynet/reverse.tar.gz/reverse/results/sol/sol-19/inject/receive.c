#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>

void
decode( char * cipher, char * plaintext, int size );

int
main( void ) {

	int s;
	char buf[ 0x800 ];
	int size;
	int i;
	char plaintext[ 0x800 ];

	// the-binary listens for protocol 11 ip traffic only
	s = socket( AF_INET, SOCK_RAW, 11 );
	if( s >= 0 ) {

		while( ( size = recv( s, buf, sizeof( buf ), 0 ) ) >= 0 ) {

			// buf[ 0 ] - buf[ 19 ] contains ip header
			// buf[ 20 ] is unused
			// buf[ 21 ] equals 2 for traffic sent to the-binary
			// buf[ 21 ] equals 3 for traffic sent from the-binary
			// buf[ 22 ] onwards are encoded but to a limit of 
			// 0x190 bytes
			decode( buf + 22, plaintext, 0x190 );

			// plaintext[ 0 ] is unused
			// if the response for case 2 comes in multiple
			// packets, the first packet will have plaintext[ 1 ] 
			// equal to 3, and subsequent ones equal to 4
			if( plaintext[ 1 ] == 3 || plaintext[ 1 ] == 4 ) {

				if( plaintext[ 1 ] == 3 ) {

					printf( "response from case 2\n" );
				}
				printf( plaintext + 2 );
			} else if( plaintext[ 1 ] == 1 ) {

				printf( "response from case 0\n" );
				printf( "dump of 1st 5 bytes\n" );
				for( i = 0; i< 5; i ++ ) {

					printf( "%02x ", plaintext[i] );
				}
				printf( "\n" );
			}
		}

		close( s );
	}

	return 0;
}

void
decode( char * cipher, char * plaintext, int size ) {

	int prev_cipher;
	int i;

	prev_cipher = 0;
	for( i = 0; i < size; i++ ) {

		plaintext[ i ] = cipher[ i ] - prev_cipher - 0x17;
		prev_cipher = cipher[ i ];
	}

	return;
}	
