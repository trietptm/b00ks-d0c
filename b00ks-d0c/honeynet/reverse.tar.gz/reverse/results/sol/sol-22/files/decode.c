/* (the-binary-)decode.c */
#include <stdio.h>

void main (){
  int s,c,i,l,o,t;
  c=getchar();
  c=getchar();
  l=getchar();
  s=getchar();
  c=getchar();
  o=c-72;
  putchar(o);
  t=c;
  while ((c=getchar()) != EOF){
    if (c-t == l) { /* */
      break;
    }
    if ( t <= 136 ){
      t+=256;
    }
    i=(c-(t+136))%256 - 143;
    putchar(i);
    t=c;
  }
}
