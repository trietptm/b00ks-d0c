#!/usr/bin/perl

$file = shift || die "no file";

open(FP,"tcpdump -x -r $file | ") || die "tcpdump err";

$n=1;

while(<FP>) {
	if (/^\d+:\d+:\d+/) {
		if ($out) {
			chop($out); chop($out); chop($out);
			print "$out\n};\n\n";			
			$n++;
		}
		$out = "\n/*\n\t\t$_*/\n\nunsigned char packet".$n."[] =\n{\n";
		next;
	}

	@nb = split();
	$out .= "\t";
	foreach $n (@nb) {
		($n1,$n2) = ($n =~ /(.{2})(.{2})/);
		if (!$n1) {
			($n1) = ($n =~ /(.{2})/);
			$out.= "0x$n1, ";
		} else {
			$out.= "0x$n1, 0x$n2, ";
		}
	}
	$out .= "\n";
}

if ($out) {
	chop($out); chop($out); chop($out);
	print "$out\n};\n";
}

close(FP);