#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include "packet.h"

#define PACKET packet1

#define QUICK_UNCRYPT 1
//#define PRINT_CHAR    1

void uncrypt(unsigned char * data, int size) {
	unsigned char b1[size], b2[size];
	int i,d;


#ifndef QUICK_UNCRYPT
	b1[0] = 0;

	for(i=size-1;i>=0;i--) {
		if (i > 0)
			d = data[i] - data[i-1];
		else
			d = data[i];

		d -= 23;
		while (d < 0) d+= 256;

		memcpy(b2,b1,size);

		b1[i] = (unsigned char)d;

		memcpy(b1+1,b2,size-1);

		sprintf(b1,"%c%s",d,b2);
	}
#else

	for(i=0;i<size;i++) {
		if (i > 0) 	d = data[i] - data[i-1];
		else 		d = data[i];

		d -= 23;
		while (d < 0) d+= 256;
		b1[i] = (unsigned char)d;
	}
#endif
	printf("Command : %d\n",b1[1]);

	d = 2;

	if (b1[1] == 2) {
		printf("Need Decoy : %s\n",b1[2] ? "YES":"NO");
		printf("Ip : %d.%d.%d.%d\n",b1[3],b1[4],b1[5],b1[6]);
		d = 7;
	}

        if (b1[1] == 3) {
                printf("Command Line : %s\n",b1+2);
		d = size;
	}

        if (b1[1] == 4) {
		printf("Exit Code ? : %d\n",b1[2]);		
                printf("Command Line : %s\n",b1+3);
		d = size;
	}

	for(i=d;i<size;i++) {
		d = b1[i];
#ifdef PRINT_CHAR
		if (isprint(d) || d == '\n') {
			printf("%c ",d);	
		} else {
			printf("%.2x ",d);
		}
#else
		printf("%.2x ",d);
#endif
	}

	
}

int main() {
	unsigned char * data = PACKET + 20;
	printf("Signature : 0x%.2x%.2x\n",data[0],data[1]);
	data += 2;

	uncrypt(data,sizeof(PACKET) - 22);

	return 0;
}

