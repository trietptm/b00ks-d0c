
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// has to be all caps ABCDEF
// convert in emacs with ctrl X ctrl U

#define PACKET_SIZE 5000
#define PACKET_FILE "/opt/snort_log/packet4nvp"
#define PACKET_OUT "/opt/snort_log/packet4nvp.bin"

// Prototypes
int hexdigit(char digit);
int hexbyte(char hidigit, char lowdigit);

int main(void)
{

// Examples of calls
// (Coment from an actual program)-> Get load address for this line

  char packet[PACKET_SIZE];
  unsigned char udp_data[PACKET_SIZE/2];

  int n,i,j;
  FILE *fp;
  int flag=1;

  if((fp = fopen(PACKET_FILE,"r")) == NULL)
    {
      printf("Error reading file \n");
      exit(1);
    }
  
  i=0;
  while(flag)
    {
      packet[i] = fgetc(fp);
      i++;
      if(feof(fp)!=0)
	{
	  flag=0;
          i=i-1;
	}

    }

  fclose(fp);

  printf("There are %d chars in this packet \n",i);

  j=0;
  for(n=0;n<i;n=n+3)
    {  
      
      printf("from hexbyte %d \n", hexbyte(packet[n], packet[n+1]));
      udp_data[j] = hexbyte(packet[n], packet[n+1]);
      printf("%c%c converted to %d  \n",packet[n],packet[n+1],udp_data[j]);
      j++;
      
    }
  
  printf("\n");
  printf("Actually wrote %d udp bytes \n",j);
  

  if((fp = fopen(PACKET_OUT,"wb")) == NULL)
    {
      printf("Error opening write file \n");
      exit(1);
    }
  
  if(fwrite(&udp_data,j,1,fp) !=1)
    {
      printf("Error writing file \n");
      exit(1);
    }

  fclose(fp);
}


// Functions
int hexbyte(char hidigit, char lowdigit) {
	// Return the value of two hex digits as the value they represent (0 - 255)
	int rc = -1;
	int low;
	int hi;

	low = hexdigit(lowdigit);
	hi  = hexdigit(hidigit);

	if ((low >= 0) && (hi >= 0)) {
		rc = low + (hi * 16);
	}

	return (rc);
}


int hexdigit(char digit) {
  int rc = -1;
	
  if ((digit >= '0') && (digit <='9'))
    { rc = digit - '0'; }
  else if ((digit >= 'A') && (digit <='F')) 
    { rc = (digit - 'A') + 10; }
  
  return (rc);
}

// End of functions
