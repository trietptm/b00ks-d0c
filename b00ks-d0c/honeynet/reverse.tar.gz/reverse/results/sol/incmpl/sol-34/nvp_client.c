/* Sample UDP client */

#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>

#define SEND_SIZE 402
#define PACKET_FILE "/opt/snort_log/packet4nvp.bin"

int main(int argc, char**argv)
{
  int sockfd,n;
  struct sockaddr_in servaddr,cliaddr;
  unsigned char sendline[SEND_SIZE];
  FILE *fp;
  
  int zult;
  if (argc != 2)
    {
      printf("usage:  udpcli <IP address>\n");
      exit(1);
    }
  
  if((fp = fopen(PACKET_FILE,"rb")) == NULL)
    {
      printf("Error reading file \n");
      exit(1);
    }
  
  if(fread(&sendline,SEND_SIZE,1,fp) !=1)
    {
      printf("Error: can't read data \n");
      exit(1);
    } 
  
  fclose(fp);
  
  printf("Read in the following bytes \n");
  for(n=0;n<SEND_SIZE;n++)
    {
      printf("%x \n",sendline[n]);
    }
 
  //  sockfd=socket(AF_INET,SOCK_DGRAM,0);
  sockfd=socket(AF_INET,SOCK_RAW,11);
  bzero(&servaddr,sizeof(servaddr));
  
  
  servaddr.sin_family = AF_INET;
  servaddr.sin_addr.s_addr=inet_addr(argv[1]);
  //  servaddr.sin_port=htons(5555);
  servaddr.sin_port=htons(11);

  zult = sendto(sockfd,sendline,SEND_SIZE,0,(struct sockaddr *)&servaddr,sizeof(servaddr));
  printf("returned %d when using fd of %d \n",zult,sockfd);
  
  
  
}
