#include <pcap.h>


void decrypt(int len, u_char *in, u_char *out)
{
    int i;

    if (len <= 0)
	return;

    for (i=len-1; i>0; i--)
	out[i] = (in[i]-in[i-1]-0x17)&0xff;
    out[0] = (in[0]-0x17)&0xff;
}


void print_command(u_char *data, int len)
{
    u_char result[1000];
    int numips = 1;
    int i;

    decrypt(len, data, result);

    printf("    Command %d ", result[1]);
    switch(result[1]) {
    case 2:
	printf("(set comm parameters): \n");
	if (result[2] == 0) {
	    printf("      Reply type 0 (reply to single IP address)\n");
	} else if (result[2] == 1) {
	    printf("      Reply type 1 (reply to IP address + 9 random)\n");
	} else if (result[2] == 2) {
	    printf("      Reply type 2 (reply to 10 IP address)\n");
	    numips = 10;
	} else {
	    printf("      Unknown parameter type (%d)\n", result[2]);
	}

	for (i=0; i<numips; i++) {
	    printf("      %d.%d.%d.%d\n", result[3+i*4], result[4+i*4], 
		   result[5+i*4], result[6+i*4]);
	}
	break;

    case 3:
	printf("(execute command): %s\n", result+2);
	break;

    default:
	printf(" -- no printer for this command yet\n");
    }
}

void print_reply(u_char *data, int len)
{
    u_char result[1000];
    int x;
    decrypt(len, data, result);

    switch (result[1]) {
    case 3:
    case 4:
	printf("    Reply to command 3 (execute command%s)\n",
	       (result[1]==3)?" first reply packet":" continuation");
	printf("%s\n", result+2);
	break;

    default:
	printf("    Reply type %d -- no printer for this yet\n", result[1]);
    }
}


int main()
{
    pcap_t *pcap;
    struct pcap_pkthdr hdr;
    u_char *packet;
    int i;

    if ((pcap=pcap_open_offline("-", NULL)) == NULL) {
	fprintf(stderr, "Couldn't open capture file.\n");
	exit(1);
    }

    i=0;
    while ((packet=pcap_next(pcap, &hdr)) != NULL) {
	if (packet[34] == 2) {
	    printf("Command packet:\n");
	    print_command(packet+36, hdr.len-36);
	} else if (packet[34] == 3) {
	    printf("Reply packet:\n");
	    print_reply(packet+36, hdr.len-36);
	}
    }

    return 0;
}

