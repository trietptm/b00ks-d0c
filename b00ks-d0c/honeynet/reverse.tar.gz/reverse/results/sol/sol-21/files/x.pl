#!/usr/bin/perl

$last="";
$line="";
$procnum=1;

while (<STDIN>) {
    $last = $line;
    $line = $_;
    if (/push *%ebp/) {
	open (OFILE, ">start/proc.$procnum") || die "Couldn't open startfile\n";
	/^\s*([^\s]+):/;
	print OFILE "$1\n";
	close(OFILE);

	open (OFILE, ">procs/proc.$procnum") || die "Couldn't open outfile\n";
	$procnum++;
	$line =~ /^\s*[^\s]+:\s*([^\s].*$)/;
	print OFILE "$1\n";
PROC:	while (<STDIN>) {
	    $line = $_;
	    if (/(^.*\tj[[:alpha:]]*)\s/) {
		$line = "$1\n";
	    }
	    last PROC if $line =~ /0x8[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]/;
	    $line =~ /^\s*[^\s]+:\s*([^\s].*$)/;
	    print OFILE "$1\n";
	    last PROC if /ret/;
	}
	close(OFILE);
    }
}

