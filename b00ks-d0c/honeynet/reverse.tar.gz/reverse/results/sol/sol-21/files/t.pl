#!/usr/bin/perl

$last="";
$line="";

while (<STDIN>) {
    $last = $line;
    $line = $_;
    if (/push *%ebp/ && $last =~ /<(.*)>/) {
	$fname = $1;
	open (OFILE, "> sigs/$fname.sig") || die "Couldn't open outfile\n";
	/^\s*[^:\s]+:\s*([^\s].*$)/;
	print OFILE "$1\n";
      PROC: while (<STDIN>) {
	  $last = $line;
	  $line = $_;
	  if (/(^.*\sj[a-z]*) /) {
	      $line = "$1\n";
	  } elsif (/</) {
	      last PROC;
	  }
	  $line =~ /^\s*[^:\s]+:\s*([^\s].*$)/;
         if (/R_386/) {
	     if ($last =~ /\t[[:alpha:]]/) {
	         print OFILE "R_386\n";
             } else {
                 print OFILE "S_386\n";
             }
	     last PROC;
         }				    
	  print OFILE "$1\n";
        }	
	close(OFILE);
    }
}

