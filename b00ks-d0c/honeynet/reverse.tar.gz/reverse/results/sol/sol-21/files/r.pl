#!/usr/bin/perl

%symtab = ();

open (FILE, "<symtab.txt") || die "No symtab?\n";

while (<FILE>) {
    /^([^\s]*)\s([^\s]*)$/;
    $symtab{$1} = $2;
}

close(FILE);

while (<STDIN>) {
    $line = $_;
    foreach $addr (keys %symtab) {
	if ($line =~ /^(.*$addr.*)$/) {
	    $line = "$1       ; $symtab{$addr}\n";
	}
    }

    print "$line";
}

