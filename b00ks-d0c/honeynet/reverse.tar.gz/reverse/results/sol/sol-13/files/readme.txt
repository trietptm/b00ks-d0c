Readme.txt
----------

The files contained within this directory are:

tld.pl - Our custom disassembler for elf binaries! Written by elliot specifically for the reverse challenge.
globals.txt - Notes on global functions and other locations within the binary.
disassembly.html - the-binary, converted into html disassembly with tld.pl
disassembler.html - brief on tld.pl
detect/detect.c - An example attack detector. This sends a 'set master' packet to the compromised system, then requests a status packet. If a response is detected, you are compromised.
encode.c - Code that implements the decode, encode routines in the-binary. decode is used for packets inbound into the-binary, encode is used for packets outbound.
