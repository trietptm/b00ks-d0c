#include <stdio.h>

void encode(int size, char *payload, char *output)
{
        int a;
        int b,c;
        int count;
        output[0] = 0;
        a = payload[0]+0x17;
        sprintf(output, "%c", a);
        count = 1;
        if (count != size)
        {
                do
                {
                        b = output[count-1];
                        c = payload[count];
                        c = b + c + 0x17;
                        output[count] = c;
                        count++;
                }
                while(count != size);
        }       
}

void decode(int size, char *payload, char *output)
{
        int cx,dx;
        int di = size;
        int bx = di - 1;
        char buf[size];
        int ax = 0;

        output[0] = 0;

        if (!(size < 0))
        {
                do
                {
                        dx = bx - 1;
                        if  (!(bx == 0))
                        {
                                ax = payload[bx];
                                dx = payload[dx];
                                ax = ax - dx;
                        }
                        else
                        {
                                ax = payload[0];
                        }
                        cx = ax - 23;

                        if (cx < 0)
                        {
                                while(cx < 0) cx = cx + 0x100;
                        }

                        dx = 0;

                        if(dx < di)
                        {
                                do
                                {
                                        ax = output[dx];
                                        buf[dx] = ax;
                                        dx++;
                                } while(dx<di);
                        }

                        sprintf(output,"%c%s",cx,buf);
                        bx = bx - 1;
                } while(bx >= 0);
        }
}

int main()
{
        int i,j;
        char a[8];
        char b[8];
        char *input = "testing";

        printf("input:            %s\n",input);
        encode(8,input, a);
        printf("encoded input:    ");
        for(i=0;i<sizeof(a);i++)
        {
                printf("%02X ",(unsigned char)a[i]);
        }
        printf("\n");
        decode(8,a, b);
        printf("decoded:          %s\n",b);

        return 0;
}
