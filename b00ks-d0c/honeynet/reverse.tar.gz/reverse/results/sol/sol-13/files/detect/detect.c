#include <stdio.h>
#include <libnet.h>
#include <pcap.h>
#include <sys/utsname.h>
#include <sys/socket.h>

/*
*
* Quick and nasty attack detector written for the honeynet reverse challenge
* It never exits unless it gets a response packet, so unless you
* get a response within a few seconds, you are probably not infected
* and may as well ctrl-c...
* tested on openbsd, may or may not compile anywhere else
* 
* sniph
* 
*/

int bComp;
u_long src,dst;

void encode(int size, unsigned char *payload, char *output)
{
        int a;
        int b,c;
        int count;
        output[0] = 0;
        a = payload[0]+0x17;
        sprintf(output, "%c", a);
        count = 1;
        if (count != size)
        {
                do
                {
                        b = output[count-1];
                        c = payload[count];
                        c = b + c + 0x17;
                        output[count] = c;
                        count++;
                }
                while(count != size);
        }       
}

void reply(u_char *data, const struct pcap_pkthdr *h, u_char *p)
{
	if(p[13] == 11 && (memcmp(&src,&(p[20]),4) == 0))
	{
		printf("Host is compromised!\n");
		exit(0);
	}
}

int main(int argc, char **argv)
{
	unsigned char payload[250];
	unsigned char *packet;
	char encpay[250];
	int i,s;
	u_char *data;
	struct in_addr si,di;
	pcap_t *p;
	char ebuf[PCAP_ERRBUF_SIZE];
	char filt[200];
	struct bpf_program fcode;
	struct hostent *he;
	struct utsname uts;

	pcap_if_t *t,*loop;
	pcap_addr_t *addr;
	struct sockaddr_in *sa;
	bpf_u_int32 net, mask;

        typedef void (*pcap_func_t)(u_char *, const struct pcap_pkthdr *, const
u_char *);

        bComp == 0;

	if(argc != 4)
	{
		printf("Usage: the-binary-detect <source interface> <source IP address> <IP address to test>\n");
		exit(1);
	}

	p = pcap_open_live(argv[1],50,1,20, ebuf);
	if(p == NULL)
	{
		printf("pcap_open_live: %s\n",ebuf);
		exit(1);
	}
	if(pcap_lookupnet(argv[1], &net, &mask, ebuf)<0)
	{
		printf("pcap_lookupnet: %s\n",ebuf);
		exit(1);
	}
	if(pcap_compile(p, &fcode, "", 0, mask)<0)
	{
		printf("pcap_compile: %s",pcap_geterr(p));
		exit(1);
	}
	if(pcap_setfilter(p, &fcode) <0)
	{
		printf("pcap_setfilter: %s", pcap_geterr(p));
		exit(1);
	}

	dst = inet_addr(argv[3]);
	src = inet_addr(argv[2]);
	if((s = libnet_open_raw_sock(11)) == -1)
	{
		printf("libnet_open_raw_sock failed.\n");
		exit(0);
	}
	payload[3] = 0x2;	// Command
	payload[4] = 0x0;	// No decoy hosts

	memcpy(&(payload[5]),&src,4);

	encode(250,payload,encpay);
	encpay[0] = 0x2;
	if((libnet_init_packet(0,&packet)) == -1)
	{
		printf("libnet_init_packet failed.\n");
		exit(0);
	}

	printf("Testing for compromise: source = %s, dest = %s\n",argv[2],argv[3]);
	if((libnet_build_ip(250,0,100,0,250,11,src,dst,encpay,250,packet)) == -1)
	{
		printf("libnet_build_ip failed.\n");
		exit(0);
	}
	libnet_do_checksum(packet,IPPROTO_IP,IP_H+250);
	if((libnet_write_ip(s,packet,IP_H+250)) == -1)
	{
		printf("libnet_write_ip failed.\n");
		exit(0);
	}
	printf("Set master to %s\n",argv[2]);
	payload[3] = 0x1;
        encode(250,payload,encpay);
	encpay[0] = 0x2;
	if((libnet_build_ip(250,0,100,0,250,11,src,dst,encpay,250,packet)) == -1
)
	{ 
		printf("libnet_build_ip failed.\n");
		exit(0);
	}
	libnet_do_checksum(packet,IPPROTO_IP,IP_H+250);
	if((libnet_write_ip(s,packet,IP_H+250)) == -1)
	{
		printf("libnet_write_ip failed.\n");
		exit(0);
	}
	printf("Send status request\n");
	if(pcap_loop(p, -1, (pcap_func_t) reply, data) < 0)
	{
		printf("pcap_loop failed\n");
		exit(0);
	}
	printf("bComp == %d\n",bComp);
	if(bComp == 0)
	{
		printf("Host not responding - probably not compromised\n");
	}
	else
	{
		printf("Host %s is compromised\n",argv[2]);
	}
	pcap_close(p);
	exit(1);
}
