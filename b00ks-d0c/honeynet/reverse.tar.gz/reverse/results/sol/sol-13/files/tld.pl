#!/usr/bin/perl 
use strict;
####################################################
##    ...The Little Disassembler that could...    ##
##              By Elliot and sniph              ##
####################################################

unless (@ARGV>=2) {
        print "Not enough arguments\n";
        usage();
        }

my $binary=$ARGV[0];
my $html=$ARGV[1];
my $object_dir=$ARGV[2];
my $tempdisasm = ".".$binary.".obj";

my ($number_lines,$current_pos,$rodata_start,$objectdir);
my ($sys,$line_len,$current_line,$key,$size,$offset,$rodata,$symbol);
my ($fblue,$end);
my (@hash_value);
my (%sections,%sym_table);

# Disassemble the binary
# The output gets put in a temp file for now
print "Disassembling $binary\n";
$sys = system("objdump -d -x $binary > $tempdisasm 2> /dev/null");
unless ($sys == 0) { 
        print "\n";
        usage();
        }

open(DISASS, "$tempdisasm");


$current_line=<DISASS>;

unless ($current_line =~ /^Sections:/){ 
        $current_line=<DISASS>;
        }

%sections=get_sections(*DISASS);

seek(DISASS,-1,1);
$current_pos=tell(DISASS);

foreach $key (keys(%sections)){
        @hash_value = split(/ /,$sections{$key});
        seek(DISASS,$current_pos,0);
        push (@hash_value,find_index(*DISASS,$key));
        $sections{$key}=join(" ",@hash_value);
        }

# Get some data direct from the 
# binary file. The method used here was 
# first used in the perl disassembler
# hdasm.pl, so the authors of that program
# deserve the credit for this bit of the code.

undef(@hash_value);
@hash_value=split(/ /,$sections{".rodata"});
$size=hex($hash_value[0]);
$offset=hex($hash_value[2]);
$rodata_start=hex($hash_value[1]);

open(BINARY,"$binary") || die "Can't read from $binary: $!\n";
seek(BINARY,$offset,0);
read(BINARY,$rodata,$size);
close(BINARY);

if (@ARGV==3) {
 print "Reconstructing symbol table\n";
        %sym_table=res_functions(*DISASS,$object_dir);
        }

# Start processing the disassembled output



undef(@hash_value);
@hash_value=split(/ /,$sections{".init"});
$current_pos=pop(@hash_value);
seek(DISASS,$current_pos,0);

open(HTML,">$html");
html_start(*HTML);
select(HTML);

$fblue="<font color='#0000f0'>";
$end="</font>";

OUTPUT: while($current_line=<DISASS>){
        $current_line =~ s/^ //g;
        $current_line =~ s/</&lt\;/g;
        $current_line =~ s/>/&gt\;/g; 
        my @parts = split(/\s+/,$current_line);
        chomp(@parts);
        chop ($parts[0]);
        my $link = shift(@parts);
 	my $aname = "<a name='$link'>";
 	if ($current_line =~ /Dis/) {
                print "\n";
  		next OUTPUT;
  		}
 	if (($current_line =~ /call/) && !($parts[0] eq "ff")) {
  		my ($instr,$addr) = split(/\s+/,substr($current_line,-17));
  		$addr =~ s/^0x//g;
   		splice (@parts,-2);
  		if ($sym_table{$addr}){
   			$current_line="\t@parts\t\t$instr\t<a href='#$addr'>0x$addr</a>$fblue &lt\;$sym_table{$addr}&gt\;$end\n";
   			print "$aname$link:$current_line";
   			next OUTPUT;
   			} else {
   			$current_line="\t@parts\t\t$instr\t<a href='#$addr'>0x$addr</a>\n";
   			print "$aname$link:$current_line";
   			next OUTPUT;
   			}
		}
 	if ($current_line =~ /j/){
  		my $jump = pop(@parts);
  		$jump =~ s/^0x//;
  		my $instr = pop(@parts);
  		if (@parts < 3){
   			$current_line="\t@parts\t\t\t$instr\t<a href='#$jump'>0x$jump</a>\n";
   			} elsif (@parts < 6) {
   			$current_line="\t@parts\t\t$instr\t<a href='#$jump'>0x$jump</a>\n";
   			} else { 
   			$current_line="\t@parts\t$instr\t<a href='#$jump'>0x$jump</a>\n";
   			}
  		print "$aname$link:$current_line";
  		next OUTPUT;
  		}
	if (($current_line =~ /push/) && ($current_line =~ /\$/)){
		my @mem = split(/\$/, $current_line);
		my $mem = pop(@mem);
		chomp ($mem);
		my $offset = hex($mem);
		if (($offset <= ($size + $rodata_start)) && ($offset >= $rodata_start)){
			$mem = substr($rodata,($offset-$rodata_start));
			my $length = index($mem,pack("x"));
			$mem = substr($mem,0,$length);
			$mem =~ s/\n//g;
			chomp($current_line);
			$current_line = "$aname$current_line$fblue"."\t\"$mem\"$end\n";
			print "$current_line";
			next OUTPUT;
			}
		}
 	if ($sym_table{$link}){
  		print "$aname$fblue&lt\;$sym_table{$link}&gt\;$end\n$current_line";
  		} else {
  		print "$aname$current_line";
  		}
 	}

print "</body>\n</html>\n";
close (HTML);
select (STDOUT);
print "Finished\n";

# Delete the temp files
# and close the filehandles

unlink($tempdisasm);
close(DISASS);

sub usage {
print "\nThe Little Disassembler that could...\n";
print "Usage:\n";
print "tld <binary file> <html file> [libdir]\n";
print "Options:\n";
print "[libdir] path to object files\n\n";
exit(0);
}

sub get_sections {

local(*D) = @_;
my ($line,@sections,%out);
seek(D,-1,1);
$line=<D>;
until($line =~ /^Dis/){
        if ($line =~ /\./){
                chomp($line);
                @sections=split(/\s+/,$line);
                $line = join(" ",$sections[3],$sections[4],$sections[6]);
                $out{$sections[2]} = $line;
                }
        $line=<D>;
        }
return(%out);
}

sub find_index {

local (*D) = $_[0];
my $name = $_[1];
my ($index,$line,$pos);
$line=<D>;
until (!(defined($line)) || ($line =~ /$name/)){
        $line=<D>;
        }
unless ($line) {
        return("NA");
        }
if ($line =~ /^Dis/){
        seek(D,2,1);
        $line=<D>;
        }
$pos=tell(D);
$index = $pos - length($line);
return($index);
}

sub html_start {
local (*H) = @_;
select(H);
print "<html>\n\n";
print "<head><title>Disassembly of $binary</title>\n";
print "</head>\n\n";
print "<body link='#f00000' vlink='#b00000'>\n\n";
print "<blockquote><pre>\n\n";
print "<a name='top'><center><h3>Disassembly of $binary</h3></center>\n";
}


sub res_functions {
local (*D) = $_[0];
my ($libdir,$objfile,%sym_table,@objfiles,@objdump);
my ($line,$foundname,@temp,@temp1,$value);
my (%search,%search1);
$libdir = $_[1];
$libdir =~ s/\/$//g;
@objfiles=<$libdir/*.o>;
foreach $objfile (@objfiles) {
        @objdump = split(/\n/,`objdump -d $objfile 2> /dev/null`);
        print "Disassembling $objfile\n";
        foreach $line (@objdump) {
		split (/:\s+/,$line);
                if ($_[0] =~ /</) {
                        $foundname++;
                        $search{$foundname}=get_func_name($_[0]);
                        } else {
                        unless (($_[1] =~ /^file/) || ($_[1] =~ /^\s+/) || (!$foundname)){
                                @temp = split(/\s+/, $_[1],3);
                                if (($temp[0] eq "e8") || ($temp[0] eq "90")){
                                        $search{$foundname} .= ":$temp[0]";
                                        } elsif (!($temp[1] =~ /[a-f0-9][a-f0-9]/)){
					$search{$foundname} .= ":$temp[0]";
     					} elsif ($temp[1] eq "db"){
     					$search{$foundname} .= ":$temp[0]";
     					} else {
                                        $search{$foundname} .=":$temp[0] $temp[1]";
                                        }
                                }
                        }
                }
        }
foreach $value (values(%search)) {
        my ($funcname,$string);
        @temp1=split(/:/,$value);
        $funcname = shift(@temp1);
        foreach $string (@temp1) {
                $search1{$funcname} .= "$string:";
                }
        undef(@temp1);
        }
%sym_table=search_bin(%search1);
return(%sym_table);
}

sub get_func_name {
my $out;
my $in  = $_[0]; 
split (/\s+/,$in);
my $a = $_[1];
chop ($out = substr($a,1));
chop ($out);
return($out);
}

sub search_bin {
my %search = @_;
my ($hexaddr,$i,$match,@match,%match,@pos,$seek_pos,@codes,$line,$key);
my (@address,%result,%seen,$numcodes,$a,$b);
@pos = split(/\s+/,$sections{".text"});
$seek_pos=pop(@pos);
SEARCH: foreach $key (keys(%search)) {
 	seek(DISASS,$seek_pos,0);
 	$line = <DISASS>;
 	@codes=split(/:/,$search{$key});
 	if ($key =~ /\./){
  		next SEARCH;
  		}
 	print "Searching for $key\n";
 	$numcodes=@codes;
 	$i=0;
MATCH:  foreach $line (<DISASS>){
		if ((substr($line,10))=~/$codes[$i]/){
                 	$i++;
                 	push (@match,$line);
                 	} else {
                 	undef(@match);
                 	$i=0;
                 	}
         	if ($i == $numcodes) {
			($a,$b)=split(/:/,$match[0],2);
                 	$b = substr($a,1);
			$match{$b}=$key;
			next MATCH;
                 	}
         	}


 	unless (%match){
         	print "$key not found\n\n";
		undef(@match);
		undef(%match);
	  	next SEARCH;
         	}
 	$match++;
	foreach $hexaddr (keys(%match)){
 		if (!defined($seen{$hexaddr})){
         		$result{$hexaddr}="$key";
         		} else {
         		$result{$hexaddr}.=" $key";
         		}
 		$seen{$hexaddr}++;
		undef(@match);
		undef(%match);
 		printf("%s found at address %08x\n\n",$key,hex($hexaddr)); 
 		}
	}
print "$match functions in $binary matched library functions\n";
my $dup = keys(%result);
$dup = ($match - $dup);
print "$dup of them matched more than one library function\n";
return(%result);
}


