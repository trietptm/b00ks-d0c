#include <pcap.h>
#include <stdlib.h>


char errbuf[PCAP_ERRBUF_SIZE];
int packetnum;


void process_packet(const u_char *packet, struct pcap_pkthdr *header)
{
	int i;

	if (header->caplen < (0x190 + 40  ))
		printf("BAD PACKET!!\n");
	else {

		printf("---------Paket %d------------\n",packetnum);
		packetnum++;
	
		for (i=65 ; i <= (0x190 + 65 - 2 ) ; i++ ){
			printf("%c", packet[i]-packet[i-1]-0x17);		
		}
	printf("\n\n");
	}

}

int main(int argc, char **argv)
{
	pcap_t *handle;
	struct pcap_pkthdr header;
	const u_char *packet;

	packetnum = 0;

	if (argc < 2) { 
		printf( "Use; %s <tcpdump_file>\n\n",argv[0]); 
		exit(1);
	}

	handle = pcap_open_offline(argv[1], errbuf);

	packet = pcap_next(handle, &header);
	while ( packet != NULL ) {
		process_packet(packet,&header);
		packet = pcap_next(handle, &header);
	}

	pcap_close(handle);
	return(0);	
}
