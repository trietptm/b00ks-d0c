#include <unistd.h>
#include <stdlib.h>

char    header[0x17]={1,2,3,4,5,6,7,8,9,0xb,11,12,13,14,15,16,
                      17,18,19,20,0x2,22,00}; //includes 1st data byte

int main(int argc, char** argv)
{
        char    ch,prev;
        char    command;

        command = atoi(argv[1]);

        //Write header
        write(1,header,sizeof(header));

        //Write "encoded" Command
        ch = command + 0x17;
        write(1,&ch,1);
        prev = ch;

        //Write encoded data
        while (read(0,&ch,1)) 
                {
                ch = prev + ch + 0x17;
                write(1,&ch,1);
                prev = ch;
                }
        return(0);
}
