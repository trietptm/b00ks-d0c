#!/usr/bin/perl

@libs = @ARGV;
$binary = shift @libs;

if (($binary eq '') || ($#libs < 0)) {
	die("Syntax: libstrings.pl binary libraries\n");
}

foreach $lib (@libs) {
	open(AR, '-|', "ar xv $lib") || die("Can't run ar xv $lib\n");
	while (<AR>) {
		if (!/^x - (\S*)$/) {
			die("Problem with ar\n");
		}
		$o = $1;
		open(FILE, '-|', "strings $o") || die("Can't run strings $o\n");
		while (<FILE>) {
			chomp;
			$strings{"$_"}{$o} = 1;
		}
		close(FILE);
		system("rm $o");
	}
	close(AR);
}

open(FILE, '-|', "strings $binary") || die("Can't run strings $binary\n");
while(<FILE>) {
	chomp;
	$files = '';
	foreach $key (keys %{ $strings{"$_"} }) {
		$files .= "$key ";
	}
	if ($files ne '') {
		$files .= ": ";
	}
	printf("%-20s%s\n", $files, $_);
}
close(FILE);
