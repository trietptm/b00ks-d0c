#include <netinet/in.h>
#include <stdio.h>


#include <stdio.h>
#include <stdlib.h>


void encode(int len, char *data, char *dest)
{
  char* temp;
  char ch;
  char ch2;
  int i=1;
  int j=0;

  ch = 2; //(char)&data[len];
  temp = malloc(len+2 * sizeof(char));
  temp[0] = ch;

  for (i=len, j=1; i > 0; i--, j++)
    {
      fprintf(stdout, "i = %d\n", i);
      ch2 = (int)(data[i-1] + 23 + (int)ch); // first part of encoding.
      temp[j] = (char)ch2;
      ch = (int)data[i-1];
    }

  strncpy(dest, &temp[0], len);
}


int main(int argc, char **argv)
{
  int sock = -1; /* sock fd */
  int conn = -1; /* connection id */
  const char* host = "127.0.0.1";
  int i=0;
  int loop = 1;
  char str[2048];
  char rect[2048];
  char *host_in;
  struct sockaddr_in sin;
  struct in_addr ina;
  char buf[2048];
  char buf2[2048];
  char *p = &buf[0];
  char *p1 = &str[1];
  int len = 0;
	

 strcpy(p, "A fscking long string into this buffer for a very long string of characters, there has to be lots of data for some reason,,,");

  len = strlen(p);
  str[0] = 2;
  //  str[len - 1] = (char)(9 + 1) & 255;
  encode(len-1, p + 1, p1+1);
	//addr.sin_port = 11;
	if ((inet_aton(host, &ina)) == 0 )
	{	
		fprintf(stderr, "Error converting address to in_addr\n");
		return 1;
	}
	else
	{
		fprintf(stdout, "Got socket %d\n", ina.s_addr);
		host_in = (char *)inet_ntoa(ina);	
		fprintf(stdout, "Got reverse address %s\n", host_in);
	}
	
	if ((sock = socket(PF_INET, SOCK_RAW, 0xb)) == -1)
	{
		fprintf(stderr, "Failed to create socket\n");
		return 1;
	}
	else
	{
	  	bzero ((char *)&sin, sizeof(sin));
	      	sin.sin_family = AF_INET;
	        sin.sin_port = 11;
		sin.sin_addr = ina;
			    
		if ((conn = connect(sock, &sin, sizeof(sin))) == -1)
		{
			fprintf(stderr, "Unable to  connect to socket\n");
			return 1;
		}
		
		while (loop == 1)
		{
//			for (i=0; i < 210; i++)


			//			fprintf(stdout, "Input string to send (ENTER to quit) :");
			
			//fgets(str, 2048, stdin);
			/*
			 * if (str[0] == 10)
			{
				fprintf(stdout, "Fred doesn;t like u\n");
				loop = 0;
				break;
			}
			*/

			fprintf(stdout, "Attempting to send %s to server %s\n", str, host_in);
			send(sock, str, 210, MSG_DONTWAIT);
			//i=-1;	
			//bzero ((char *)&rect, 2048);
			//i = recv(sock, (void *)&rect, 2048, MSG_DONTWAIT);
			//fprintf(stdout, "Recieved %d bytes from %s\n", i, host_in);
			//fprintf(stdout, "Response: %s (length %d)\n", rect, strlen(rect));
			loop = 0;
		}
		return 0;
	}

	return 0;

}

  
