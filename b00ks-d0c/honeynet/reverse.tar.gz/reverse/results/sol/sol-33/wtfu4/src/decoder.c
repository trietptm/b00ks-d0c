
#include <stdio.h>
#include <stdlib.h>


void encode(int len, char *data, char *dest)

{  char* temp;
  char ch;
  char ch2;
  int i=1;
  int j=0;

  dest[0] = '\002';
  for (i=0; i<len; i++)
    {
      dest[i+1] = (char)((int)dest[i] + 23 + (int)data[i]);
    }

  /*
  ch = 2; 
  temp = malloc(len+2 * sizeof(char));
  temp[0] = ch;

  for (i=len, j=1; i > 0; i--, j++)
    {
      fprintf(stdout, "i = %d\n", i);
      ch2 = (int)(data[i-1] + 23 + (int)ch); // first part of encoding.
      sprintf(temp, "%c%s", ch2, temp);
      ch = (int)data[i-1];
    }
  */

  //strncpy(dest, &temp[0], len);
}

void orig_encode(int len, char *data, char *dest)
{
  char temp[2048];
  int ch;
  int ch2;
  int i=1;
  int j=0;
  int k=0;
  int count = len-1;
  
  //bzero((char *)&str2[0], 20);   // zero new buffer
  ch = (int)2;
  
  
  do
  {
	
    for (i=0, j=len; i < len; i++, j--)
      {
	//	fprintf(stdout, "i = %d\n", i);
	ch2 = (int)(data[i] + 23 + ch); // first part of encoding.
	//while (ch2 > 256)
	//   ch2 -= 256;
	
	temp[j++] = (char)ch2;
	ch = (int)data[i];
      }
    
    k=1;
    while (k<len)
      {
	temp[k-1] = dest[k];
	k++;
      }
 	
    k=0;
    while(k<len)
      {
	dest[k] = temp[k];
	k++;
      }

    for (i=0, j=len; i < len; i++, j--)
      {
	//fprintf(stdout, "i = %d\n", i);
	ch2 = (int)(data[i] + 23 + ch); // first part of encoding.
	//while (ch2 > 256)
	//   ch2 -= 256;
	
	temp[j++] = (char)ch2;
	ch = (int)data[i];
      }
    
    //fprintf(stdout, "'%s' becomes '%s'\n", data, temp);
  } while (count--);
  
  strncpy(dest, &temp[0], len);

}

void decode(int len, char *data, char *dest)
{
	char *p;
	int count = len -1;
	int diff = 0;
	int int2 = 0;
	int j,k;
	char tempBuf[2048];
	int copied;

	do
	{
		k = count - 1;
		if (count == 0)
			diff = (char)data[0];
		else
		{
			p = data;
			diff = (char)(p[count] - p[k]);
		}

		int2 = diff -23;
		while (int2 < 0)
			int2 += 256;
	
		k=0;
		while (k<len)
		{
			tempBuf[k] = dest[k];
			k++;
		}
		
		dest[0] = (char)diff;
		k=1;
		while(k<len)
		{
			dest[k] = tempBuf[k-1];
			k++;
		}
		
		copied = sprintf(dest, "%c%s", int2, tempBuf);

	} while (count--);
}

void prettyDump(int len, char *p)
{
  int count = 0;

  while (count < len)
    {
      
      //if (count == 0 || count == 1)
      //fprintf(stdout, "%d", p[count]);
      //else
      //{
	  if (p[1] == 0x2)
	    fprintf(stdout, "'%d'", p[count], (char)p[count]);
	  else
	    fprintf(stdout, "'%c'", p[count], (char)p[count]);
	  
	  //}
      count ++;
    }
  fprintf(stdout, "\n");

}


int main(int argc, char **argv)
{
  char buf[2048];
  char buf2[2048];
  char buf3[2048];
  char *p = &buf[0];
  char *p1 = &buf2[0];
  char *p2 = &buf3[0];
  int len = 0;
  int start = 0, j=0, i=0;
  FILE *file;
  char buf4[256];
  char *filename = &buf4[0];
  size_t filelen;
  int offset = 0;

  j = 7;
  //  strcpy(p, "A fscking long string into this buffer for a very long string of characters, there has to be lots of data for some reason,,,");
  //for (i=0; i<255; i++)
  //  {
  //    len = 255 -i;
  //    p[i] = (char)(len + 1);
  //  }
  file = NULL;

  if (argc < 2)
    {
      fprintf(stderr, "Failed to find a single thing on the commandline - Quitting\n");
      exit(1);
    }
  else
    {
      strncpy(filename, argv[1], 255);
    }

  file = fopen(filename, "r");
  if (file == NULL)
    {
      fprintf(stderr, "Failed to open file\n");
      exit(1);
    }

  len = 0;
  i=0;

  while (!feof(file))
    {
      i = (int)fread(p++, (size_t)1, (size_t)(1), file);
      len++;
    }
  p = &buf[0];
  
  //len = strlen(p2);
  //255;

  //buf[0] = 2;

  //fprintf(stdout, "the buffer is %d bytes long\n", len);
  
  //encode(len, p, p1);
  
  //fprintf(stdout, "Encoded '%s' to '%s'\n", p, p1);

  if (p[0] == 0x2)
    {
      // single pass decoder starting at offset 2
      fprintf(stdout, "Got incoming packet, will decode in single pass\n");
      j=2;
      decode(402 - j, p+j, p2);
      fprintf(stdout, "Decoded buffer = ");
      prettyDump(len, p2);
    }
  else if (p[0] == 0x3)
    {
      // offset is 7 for initial pass, and 17 for second pass. Need 2 bufers
      fprintf(stdout, "Got outgoing packet, will decode in double pass.\n");
      j = 2;
      decode(401 - j, p+j, p1);
      //offset = 14;
      //p += offset;
      // clear memory out just to be sure.
      //bzero(p2, 2048);
      //decode(402, p1, p2);
      
      fprintf(stdout, "Decoded 1st buffer = ");
      prettyDump(402, p1);
      
      //fprintf(stdout, "\nDecoded 2nd buffer = ");
      //prettyDump(402 - offset, p2);
    }
      
}

