/* 
 * dnsrip.c
 *
 * Written by RuSKoV for the HoneyNet Reverse Challenge.
 *
 * ./dnsrip the-binary > dnsips
 *
 * I'm sure the dns servers used in this binary are already abused enough from
 * the blackhat(s) who use this binary, please do NOT abuse any generated list.
 *
 * This program will ONLY work on the HoneyNet supplied binary since it uses
 * a static file offset.  There are more than likely several versions of this
 * binary in distribution, using an offset  of (.data +4) would probably work
 * on most.  To obtain the .data offset for another binary:
 *   objdump --all-headers the-binary
 * and use the File Off value for the DATAOFFSET define below.
 *
 * Tested under Linux, and FreeBSD 4.2.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>

#define DATAOFFSET 0x24228

int main (int argc, char **argv) {
  FILE *binaryFile;
  int lastIP = 0, amtRead;
  unsigned long *IPPtr;
  unsigned char readBuf[5];

  if (argc != 2) {
    printf("dnsrip.c - DNS server ripper\n");
    printf("Written for the HoneyNet Reverse Challenge\n\n");
    printf("  Usage: %s <binary-file>\n", argv[0]);
    exit(1);
  }
  
  if ((binaryFile = fopen(argv[1], "rb")) == NULL) {
    printf("Error opening \"%s\"", argv[1]);
    exit(1);
  }
  
  fseek(binaryFile,DATAOFFSET+4,SEEK_SET);
  IPPtr = (unsigned long *) readBuf;
  while (!feof(binaryFile) && !lastIP) {
    fread(readBuf, sizeof(unsigned long), 1, binaryFile); 
    if (*IPPtr != 0)
      printf("%s\n", inet_ntoa(*IPPtr));
    else
      lastIP = 1;
  }
  
  if (!lastIP)
    printf("Premature end of file! - this is not the HoneyNet binary.\n");
  fclose(binaryFile);
}
