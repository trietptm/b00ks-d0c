/* 
 * covert_decode.c
 *
 * Written by RuSKoV for the HoneyNet Reverse Challenge.
 *
 * Due to the use of a pcap-based dump file format, pcap was used.
 * i.e. you need pcap installed to use this.
 *
 *   gcc covert_decode.c -o covert_decode -lpcap
 *
 * NOTE:  A capture of at LEAST 200 bytes (starting at IP layer) is required.
 *        "the-binary" will NOT listen to anything less than 200 bytes, and
 *        as such, neither will we.
 *
 * All details that have gone into this decoder were obtained by analysis
 * presented in the analysis report that should be in the same package as
 * this file.
 *
 * Further depth can easily be placed into this decoder.  For incident
 * management however, it is believed that only the victim of the denial of
 * service attacks is needed to be known.
 *
 * Placing further depth in a public program allows "kids" to hack together
 * clients for what are, potentially very destructive attacks.
 * (At least this way the 'skill' bar is just under the assembly line for any
 * potential abuse of the published binary)
 *
 *
 * Possible bugs: The victim IP addresses/ports may not be byte ordered
 *                properly, thus MAY be displayed wrong. (effort++)
 *
 * Tested under Linux, and FreeBSD 4.2.
 *
 */

#define __BSD_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <pcap.h>

int DDOSDecode(unsigned char *, unsigned char *, int);

int DDOSDecode(unsigned char *inBuffer, unsigned char *outBuffer, int amount) {
/* 
   The decode process is incredibly simple, yet the author made it so damn
   complex?  Anyway, this function was initially going to be an asm adaptation
   of the asm in Data_Manipulation_Function_A.  If one has looked at the asm of
   Data_Manipulation_Function_A, it is quite complex.  The amazing thing is
   however, that the actual algorithm involved is INCREDIBLY simple!
   It makes one wonder if the author:
     a) Had a bad day.
     b) Made the whole binary by scavaging pieces together.
     c) Deliberately tried to obfuscate the coding.
   Compared to the rest of the binary, the encoding section is really, really,
   REALLY poor.  That is ofcourse, unless c) was the reason behind it - in
   which case they still did a poor job ;)

   Anyway, to the code.  We load:
       %esi with inBuffer 
       %edi with outBuffer
       %ecx with amount 
 */
  __asm__ __volatile__("
      leal    0xffffffff(%%ecx),%%ecx
      0:
              testl  %%ecx,%%ecx
              jl     4f

              testl  %%ecx,%%ecx
              je     1f

              movzbl (%%ecx,%%esi,1),%%eax
              movzbl 0xffffffff(%%ecx,%%esi,1),%%edx
              subl   %%edx,%%eax
              leal   0xffffffe9(%%eax),%%eax
              jmp 2f
      1:
              movzbl (%%ecx,%%esi,1),%%eax
              leal   0xffffffe9(%%eax),%%eax
      2:
              cmpl   $0x0, %%eax
              jge    3f
              addl   $0x100, %%eax
              jmp    2b
      3:
              movb   %%al,(%%ecx,%%edi,1)
              decl   %%ecx
              jmp 0b
      4:
    "
    :
    :"c"(amount),"S"(inBuffer),"D"(outBuffer)
  );

}

int main (int argc, char **argv) {
  const unsigned char *inBuf;
  unsigned char       outBuf[2048];
  pcap_t              *pcap_packet = 0;
  struct pcap_pkthdr  pcap_header;
  char                errbuf[PCAP_ERRBUF_SIZE];
  bpf_u_int32         linkType;
  struct ip           *ipPtr;
  unsigned char       *packetData;
  struct in_addr      convert;
  int                 captureSize, dataSize;
  int                 i, verbose = 0;

  if ((argc < 2) || (argc > 3)) {
    printf("covert_decode.c - DDOS decoder by RuSKoV\n");
    printf("Written for the HoneyNet Reverse Challenge\n\n");
    printf("  Usage: cat pcap_dump_file | %s -s\n", argv[0]);
    printf("     OR: %s -f pcap_dump_file\n", argv[0]);
    exit(1);
  }
  
  strncpy(errbuf, "No such file or directory", PCAP_ERRBUF_SIZE);
  if (strncmp(argv[1], "-s", 2)==0)
    pcap_packet = pcap_open_offline("-", errbuf);
  else
    if (argc == 3) {
      if (strncmp(argv[1], "-f", 2)==0) {
        pcap_packet = pcap_open_offline(argv[2], errbuf);
      }
    }
  if (pcap_packet == 0) {
     printf("Problem reading from pcap file: %s\n", errbuf);
     exit(1);
  }
  
  linkType = pcap_datalink(pcap_packet);
  while (inBuf = pcap_next(pcap_packet, &pcap_header)) {
    captureSize = pcap_header.caplen;
    if (linkType == DLT_EN10MB) {
      ipPtr = (struct ip *) (((unsigned long) inBuf) + 14);
    } else {
      if ((linkType == DLT_RAW) || (linkType == DLT_PPP)) {
        ipPtr = (struct ip *) ((unsigned long) inBuf);
      } else {
        if (linkType == DLT_NULL) {
          ipPtr = (struct ip *) (((unsigned long) inBuf) + 4);
        } else {
          /* Dont know the linktype :( */
          continue;
        }
      }
    }
    dataSize = captureSize-(((unsigned long) ipPtr)-((unsigned long) inBuf));
    if (dataSize <= 200)
      continue;
    /* "the-binary" seems to always expect a 20 byte IP header, 
       so we will too! */
    packetData = (unsigned char *) (((unsigned long) ipPtr) + 20);
    if (ipPtr->ip_v == 4) {
      if (ipPtr->ip_p == 11) { /* Good enough */
        printf("Blackhat DDOS Packet:\n");fflush(0);
        convert.s_addr = ipPtr->ip_src.s_addr; 
        printf("%s -> ", inet_ntoa(convert));
        convert.s_addr = ipPtr->ip_dst.s_addr;
        printf("%s\n", inet_ntoa(convert));
        if (packetData[0] == 2) { /* Blackhat DDOS destined packet */

          printf("CONTROL PACKET:\n");
          DDOSDecode(packetData+2, outBuf, dataSize);

          switch(outBuf[1]) {
            /* Similar to the jump %eax styles used in the-binary :) */
            case 1:
              printf("[Status Enquiry]\n");
              break;
            case 2:
              printf("[Blackhat Source");
              /* Now depending on packetData[1], we'll see if we can get
                 more details from the packet! */
              switch(outBuf[2]) {
                case 0: /* Blackhat setting a single covert destination! */
                  printf(" - \"%d.%d.%d.%d\"]\n", outBuf[3], outBuf[4], 
                                                 outBuf[5], outBuf[6]);
                  break;
                case 1: /* Blackhat sending only 1 IP, but the binary will
                           generate 9 more random IPs - sneaky */
                  printf(" - \"%d.%d.%d.%d\"]\n", outBuf[3], outBuf[4],
                                                 outBuf[5], outBuf[6]);
                  break;
                case 2: /* Blackhat sends 10 IP, any of which may potentially
                           be his/her client's address */
                  if (!verbose) {
                    printf(" - 10 addresses sent\n");
                  } else {
                    printf(" -");
                    for (i=3; i < 43; i++)
                      printf(" \"%d.%d.%d.%d\"",outBuf[i++], outBuf[i++],
                                                outBuf[i++], outBuf[i++]);
                    printf("]\n");
                  }
                  break;
                default: /* We dont know... */
                  printf(" - Unknown]\n");
                  break;
              } 
              break;
            case 3:
              printf("[Covert Shell Command - ");
              outBuf[2043] = '\0';
              printf("\"%s\"]\n", outBuf+2);
              break;
            case 4:
              printf("[DNS Amplification Attack -");
              printf(" Victim = \"%d.%d.%d.%d\"]\n", outBuf[2], outBuf[3],
                                                     outBuf[4], outBuf[5]);
              break;
            case 5:
              printf("[Corrupt Packet Attack");
              if (outBuf[3])
                printf(":(UDP)");
              else
                printf(":(ICMP)");
              printf(" - Victim = \"%d.%d.%d.%d\"]\n", outBuf[4], outBuf[5],
                                                       outBuf[6], outBuf[7]);
              break;
            case 6:
              printf("[Activate Bind Shell]]\n");
              break;
            case 7:
              printf("[Execute Command - ");
              outBuf[2043] = '\0';
              printf("\"%s\"]\n", outBuf+2);
              break;
            case 8:
              printf("[Kill any running bind shells or floods]\n");
              break;
            case 9:
              printf("[DNS Amplification Attack -");
              printf(" Victim = \"%d.%d.%d.%d\"]\n", outBuf[2], outBuf[3],
                                                    outBuf[4], outBuf[5]);
             break;
            case 10:
              printf("[SYN Attack -");
              printf(" Victim = \"%d.%d.%d.%d:%d\"]\n", outBuf[2], outBuf[3],
                                                    outBuf[4], outBuf[5],
                                                    outBuf[6]*256+outBuf[7]);
              break;
            case 11:
              printf("[SYN Attack -");
              printf(" Victim = \"%d.%d.%d.%d:%d\"]\n", outBuf[2], outBuf[3],
                                                    outBuf[4], outBuf[5],
                                                    outBuf[6]*256+outBuf[7]);
              break;
            case 12:
              printf("[DNS Request Attack -");
              printf(" Victim = \"%d.%d.%d.%d\"]\n", outBuf[2], outBuf[3],
                                                    outBuf[4], outBuf[5]);
              break;
            default:
              printf("[Unknown Packet!]\n");
              break;  
          }
        } else {
          if (packetData[0] == 3) {
            printf("REPLY PACKET:\n");
            /* This all comes from case section decoding */
            DDOSDecode(packetData+2, outBuf, dataSize);
            if (outBuf[1] == 1) { /* Looks like we just worked out what
                                     that second byte is for! *Goes and
                                     adds it to analysis* */
              printf("[Status Reply - [ID/VERSION: %d]\n", packetData[2]);
              /* This next byte indicates whether something it running */
              if (outBuf[3] == 0) {
                printf("[Nothing is running]\n");
              } else {
                if (outBuf[3] == 1) {
                  printf("[Current Action: ");
                  switch (packetData[4]) {
                    case 4:
                      printf("DNS Amplification Attack]\n");
                      break;
                    case 5:
                      printf("Corrupt Packet Attack]\n");
                      break;
                    case 6:
                      printf("Bind Shell Active]\n");
                      break;
                    case 9:
                      printf("DNS Amplification Attack]\n");
                      break;
                    case 10:
                      printf("SYN Attack]\n");
                      break;
                    case 11:
                      printf("SYN Attack]\n");
                      break;
                    case 12:
                      printf("DNS Request Flood Attack]\n");
                      break;
                    default:
                      printf("Unknown]\n");
                  }
                }
              }
            }
            if (outBuf[1] == 3) { /* See code analysis of 0x08048590 */
               printf("[Covert Shell Output - First 0x18e bytes]\n");
            } else {
              if (outBuf[1] == 4)
                printf("[Covert Shell Output - Extra bytes]\n");
            }
          }
        }
        printf("==========================================================\n");
      }
    }
  };
  pcap_close(pcap_packet);
}

