#include <stdio.h>
/* #include <sys/types.h> */
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

int main() {
    int sock;
    char msg[5000];
    char packet[5000];
    struct sockaddr_in to;
    struct iphdr *ip;
    int total_len;

    /* open a socket for protocol 0xb */
    sock = socket(PF_INET, SOCK_RAW, 0xff );
    if (sock < 0) {
	perror("socket");
	exit(1);
    }
    printf("socket = %d\n", sock);

    /* create a message to send */
    sprintf(msg, "testi2g");

    total_len = sizeof(struct iphdr) + 2 + strlen(msg);
    packet[sizeof(struct iphdr)] = 0;
    packet[sizeof(struct iphdr)+1] = 3;
    memcpy(&packet[sizeof(struct iphdr) + 2], msg, strlen(msg));

    to.sin_family = AF_INET;
    /* normally, you should also do the following:
	to.sin_port = 0xb;	// must be set to protocol, for RAW
	to.sin_addr.s_addr = inet_addr("127.0.0.1");
     */

    printf("sizeof(sockaddr_in) == %d\n", sizeof(struct sockaddr_in));
    printf("\tto.sin_family = %d\n", (int) to.sin_family);

    ip = (struct iphdr *) packet;
    ip->saddr = 0x0200007f;	/* 127.0.0.2 */
    ip->daddr = 0x0100007f;	/* 127.0.0.1 */

    ip->version = 4;
    ip->ihl = 5;
    ip->ttl = 250;
    ip->protocol = 11;
    ip->tot_len = htonl(total_len);
    ip->tos = 0;

    ip->id = htonl(1);
    /* Linux will create an ID for you, whether you like it or not. */

    ip->frag_off = 0;

    ip->check = 0;
    /* Linux will calculate the checksum for you, if you leave it blank. */

    /* and send the message */
    sendto(sock, packet, total_len,
		0, (struct sockaddr *)&to, sizeof(struct sockaddr));

    /* close the socket */
    close(sock);

    return 0;
}

