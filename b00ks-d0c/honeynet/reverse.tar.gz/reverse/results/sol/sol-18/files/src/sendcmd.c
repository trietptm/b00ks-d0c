#include <stdio.h>
/* #include <sys/types.h> */
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

void encode(unsigned char *msg, int len, unsigned char *newbuf) {
    int i;
    unsigned char lastdecoded;

    newbuf[0] = msg[0] + 23;
    for (i = 1; i < len; i++) {
	newbuf[i] = msg[i] + newbuf[i-1] + 23;
    }
}

int main(int argc, char *argv[]) {
    int sock;
    unsigned char msg[5000];
    unsigned char encrypted[5000];
    struct sockaddr_in to;
    int total_len;
    int cmd_num;
    int sent;

    if (argc < 3) {
	fprintf(stderr, "usage: sendcmd <cmd#> <ip#>\n");
	exit(-1);
    }

    sscanf(argv[1], "%d", &cmd_num);

    printf("Creating a packet of cmd#%d\n", cmd_num);

    /* open a socket for protocol 0xb */
    sock = socket(PF_INET, SOCK_RAW, 0xb );
    if (sock < 0) {
	perror("socket");
	exit(1);
    }

    *((unsigned short *)msg) = 2;		/* to pass test in server */

    msg[2] = 0;			/* this value seems to never be used
				 * by the-binary. */
    msg[3] = cmd_num;		/* set the command number */

    encode(msg+2, 200, encrypted+2);
    *((unsigned short *)encrypted) = 2;		/* to pass test in server */
					/* this short is not encrypted */

    to.sin_family = AF_INET;
    to.sin_port = 0xb;			/* must be set to protocol, for RAW */
    to.sin_addr.s_addr = inet_addr(argv[2]);

    /* and send the message */
    sent = sendto(sock, encrypted, 201,
		0, (struct sockaddr *)&to, sizeof(struct sockaddr));
    if (sent < 0) {
	perror("sendto");
	exit(1);
    }

    /* close the socket */
    close(sock);

    return 0;
}



