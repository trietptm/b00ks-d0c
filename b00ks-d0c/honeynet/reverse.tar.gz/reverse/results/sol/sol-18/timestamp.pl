#!/usr/bin/perl

use Digest::MD5;
use File::Find;
use Mail::Sendmail;
use Sys::Hostname;
use Error qw(:try);

my $mode = shift @ARGV;

print "$0: mode = $mode\n";

&$mode;

exit(0);

sub stamp {
    my $user = (getpwuid($<))[0];
    my $hostname = hostname;

    my $msg = "X-Stamper-To: $user\@$hostname\n";
    foreach my $file (@ARGV) {
	# skip "timestamp.html", since that will change
	# because of the results of stamping
	next if $file eq 'timestamp.html';
	print "\tdigesting $file...\n";
	my $md5 = Digest::MD5->new;
	open(INPUT, $file) || die "open($file): $!";
	$md5->addfile(*INPUT);
	close(INPUT);
	my $digest = $md5->hexdigest;
	$msg .= "$digest\t$file\n";
    }
    my %mail = (
	From	=> "$user\@$hostname",
	To	=> 'post@stamper.itconsult.co.uk',
	Message => $msg,
	Subject => 'Timestamp request',
	);
    print "\tsending email to Stamper...\n";
    sendmail(%mail) || die "sendmail error: ".$Mail::Sendmail::error;
    print "NOTE: When you receive a response back from Stamper,\n";
    print "      please save it in the current directory as 'stamper.msg'.\n";
}


# validate - read through timestamp.html and check all
# the MD5 signatures included there.  Report errors.
sub validate {
    my (%listed, $line);
    open(INPUT, "timestamp.html") || die "\topen(timestamp.html): $!";
    while (defined($line = <INPUT>)) {
	if ($line =~ m/^[0-9a-f]{32}\t/) {
	    chomp($line);
	    my ($reported_digest, $file) = split(' ', $line);
	    $listed{$file} = 1;
	    try {
		open(CHK, $file) || die "\topen($file): $!";
		my $md5 = Digest::MD5->new;
		$md5->addfile(*CHK);
		close(CHK);
		my $current_digest = $md5->hexdigest;
		die "\terror: mismatched md5 for $file\n"
			if $current_digest ne $reported_digest;
	    } otherwise {
		my $E = shift;
		# We don't actually want to die, just warn the user.
		warn $E;
	    };
	}
    }
    close(INPUT);

    # All the reported files have been checked.  Now look for new ones
    find( { wanted => sub {
		    my $file = $File::Find::name;
		    return if -d $file;
		    $file =~ s#./##;	# strip leading path
		    return if $file eq 'timestamp.html';	# special case
		    warn "\terror: no md5 listed for $file\n"
			if !exists $listed{$file};
		},
	}, '.');
    print "\tValidation complete.\n";
}


# include - to include the results from the Stamper service
# (saved in "stamper.msg") in the file "timestamp.html".
# The location to insert the message is marked by a line
# with the text '#REPLACE#'.
sub include {
    open(INPUT, "stamper.msg") || die "open(stamper.msg): $!";
    my @stamp = <INPUT>;
    close(INPUT);
    shift @stamp while $stamp[0] !~ m/^-----BEGIN PGP /;
    my $stamp = join('', @stamp);
    undef @stamp;
    open(INPUT, "timestamp.html") || die "open(timestamp.html): $!";
    open(OUTPUT, ">timestamp.bak") || die "open(timestamp.bak): $!";
    my ($line);
    while (defined ($line = <INPUT>)) {
	$line =~ s/#REPLACE#/$stamp/;
	print OUTPUT $line;
    }
    close(INPUT);
    close(OUTPUT);

    rename("timestamp.bak", "timestamp.html") || die "rename: $!";
}


