/* decode function */
/* reads IP packet with IP header from stdin and put result to stdout */

#include <linux/ip.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void decode (char *dst, char *src, int len) {
  int i = len;
  int j = i;
  int b;
  
  while(i >= 0) {
    if (i == 0) {
      b = src[i] - 0x17;
    } else {
      b = (src[i] - src[i-1]) - 0x17;
    }
    while (b < 0) { 
      b = b + 0x100;
    }
    dst[j] = b;
    i--;
    j--;
  }
}
	      
main(int argc, char **argv) {
  unsigned char buf[1024];
  unsigned char buf2[1024];
  
  int fd = 0;
  int len;
  int i = 0;
  int j,k;
  
  len = read(fd, buf, 1024);
  
  printf("Version : 0x%x\n",buf[0]);
  printf("TOS     : %i\n",buf[1]);
  printf("tot_len : %i\n",buf[2]*0x100+buf[3]);
  printf("id      : %i\n",buf[4]*0x100+buf[5]);
  printf("frag_off: %i\n",buf[6]*0x100+buf[7]);
  printf("TTL     : %i\n",buf[8]);
  printf("PROTO   : %i\n",buf[9]);
  printf("CHKSUM  : %i\n",buf[0xa]*0x100+buf[0xb]);
  printf("ip src  : %i.%i.%i.%i\n",buf[0xc],buf[0xd],buf[0xe],buf[0xf]);
  printf("ip dst  : %i.%i.%i.%i\n",buf[0x10],buf[0x11],buf[0x12],buf[0x13]);
  printf("options : %i\n\n\n",buf[0x15]);

  decode(buf2,&buf[0x16],len-0x16);
  while(i < len-0x16) {
    printf("%c",buf2[i]);
    i++;
  }

  close(fd);

}
