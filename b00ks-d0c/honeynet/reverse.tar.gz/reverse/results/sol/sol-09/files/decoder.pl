#!/usr/bin/perl
# Proof of concept decoder for project honeynet
# 
my $TCPDUMP='/usr/sbin/tcpdump';
my $filename=$ARGV[0];

open DUMP, "$TCPDUMP -n -x -s 1024 -r $filename|" || die "$!";
while(<DUMP>) {
	my $line=$_;
	if($line=~/(\S*) (\S*) > (\S*):(\s*)ip-proto-11 (\d*)/) {
		$src=$2;
		$dst=$3;
		$size=$5;
		if($pkt) {
			decode_pkt($pkt);
			$pkt="";
		}
	} elsif($line=~/(\s*)(\w*) (\w*) (\w*) (\w*) (\w*) (\w*) (\w*) (\w*)/) {
		$pkt.="$2$3$4$5$6$7$8$9";
	}
}
close DUMP;

sub decode_pkt {
   my $pkt = shift;
   my $count;
   my $char;
   my $key;
   my $keycount=3;
   my $plaintext;
   my $newchar;
   my $page=0;
   print "$src->$dst ($size)\n"; 
   for($count=44;$count < $size; $count+=2,$keycount++) {
	$key=$keycount * 23;
	$page=int($key/256);
	$char=substr($pkt,$count,2);
	$plaintext=sprintf("%x", (($key-hex $char)-(256*$page)));
	$newchar=pack("H2",$plaintext);
	sprintf($newchar, "%c", pack("H2",$plaintext));
	print "pkt[$count] CHAR: $char - 7x$keycount($key) = $plaintext($newchar)\n";
   }
   
}
