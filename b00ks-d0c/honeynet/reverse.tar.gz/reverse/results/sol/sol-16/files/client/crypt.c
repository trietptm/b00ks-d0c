#include <stdlib.h>
#include <stdio.h>

#include "crypt.h"


#define BACKDOOR_ENCRYPT_CONST 23


void backdoor_decrypt(char *destination, const char *source, int size) {
 char *tmp;
 int i;
 unsigned int substraction_result;

 tmp = calloc((size+3) & 0xFFFFFFFC, 1); /* rounded to dword */
 destination[0] = 0;
 if (size-1 == 0) return;

 for (i = size-1; i >= 0; i--) { /* loop for all chars */
  /* compute substraction */
  if (i != 0)
   substraction_result = source[i] - source[i-1];
  else
   substraction_result = source[0];

  /* adjust substraction */
  substraction_result -= BACKDOOR_ENCRYPT_CONST;
  if (substraction_result != 0) {
   do {
    substraction_result += 256;
   } while (substraction_result & 0x80000000); /* is signed */
  }

  /* copy current string to p_temp */
  if (size != 0) memcpy(tmp, destination, size);

  /* update first byte of the current string */
  destination[0] = substraction_result;

  /* concat other bytes to current string */
  if (size != 1) memcpy(destination+1, tmp, size-1);

  /* unusefull ? (exactly like previous operations) */
  sprintf(destination, "%c%s", substraction_result, tmp);
 }
}


void backdoor_encrypt(char *destination, const char *source, int size) {
 int i;

 for (i = 0; i < size; i++) {
  if (i == 0)
   destination[0] = source[0] + BACKDOOR_ENCRYPT_CONST;
  else
   destination[i] = source[i] + destination[i-1] + BACKDOOR_ENCRYPT_CONST;
 }
}
