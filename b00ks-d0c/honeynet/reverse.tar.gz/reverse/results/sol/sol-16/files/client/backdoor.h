#ifndef __BACKDOOR_H__
#define __BAKDOOR_H__

#define BACKDOOR_IP_PROTOCOL                11

#define BACKDOOR_IP_PAYLOAD_SIZE            181 /* minimum size of the backdoor's IP payload */
#define BACKDOOR_ENCRYPTED_SIZE             BACKDOOR_IP_PAYLOAD_SIZE - 2
#define BACKDOOR_ARGUMENT_SIZE              BACKDOOR_ENCRYPTED_SIZE - 2

#define BACKDOOR_DIRECTION_CLIENT_TO_SERVER 2
#define BACKDOOR_DIRECTION_SERVER_TO_CLIENT 3

#define BACKDOOR_OUTPUT_SIZE                397
#endif
