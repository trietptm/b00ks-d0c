#ifndef __CRYPT_H__
#define __CRYPT_H__

void backdoor_decrypt(char *destination, const char *source, int size);
void backdoor_encrypt(char *destination, const char *source, int size);

#endif
