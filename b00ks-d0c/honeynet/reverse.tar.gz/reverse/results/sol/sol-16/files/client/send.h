#ifndef __SEND_H__
#define __SEND_H__

char *get_ip_address(char *interface);

int backdoor_client_send(char *source, char *destination, int command, const char *argument, int argument_size);

#endif
