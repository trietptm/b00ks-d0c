#include <stdlib.h>
#include <stdio.h>

#include "crypt.h"
#include "debug.h"


int main(int argc, char **argv) {
 #define SIZE 1024
 char original[SIZE], encrypted[SIZE], decrypted[SIZE];
 int size, use_std;

 if (argc != 1 && argc != 2) {
  fprintf(stderr, "%s (will use stdin and stdout, size must be <= %d)\n", argv[0],SIZE);
  fprintf(stderr, "%s \"string to encrypt\"\n", argv[0]);
  exit(1);
 }

 if (argc == 1) {
  fgets(original, SIZE, stdin);
  size = strlen(original);
  use_std = 1;
 }
 else {
  size = strlen(argv[1]) + 1;
  if (size >= SIZE) exit(0);
  memset(original, 0, size);
  strncpy(original, argv[1], SIZE);
  use_std = 0;
 }

 backdoor_encrypt(encrypted, original, SIZE);
 backdoor_decrypt(decrypted, encrypted, SIZE);

 if (use_std) {
  encrypted[size] = 0;
  fputs(encrypted, stdout);
  fclose(stdout);
 }
 else {
  puts("original:");
  dump(original, size);

  puts("encrypted:");
  dump(encrypted, size);

  puts("decrypted:");
  dump(decrypted, size);

  /* sanity checks */
  printf("strcmp(\"%s\", \"%s\") ? %s\n", original, decrypted, strcmp(original,decrypted) ? "no" : "yes");
  printf("memcmp(\"%s\", \"%s\") ? %s\n", original, decrypted, memcmp(original,decrypted, SIZE) ? "no" : "yes");
 }

 exit(0);
}
