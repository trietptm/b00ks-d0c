#ifndef __DEBUG_H__
#define __DEBUG_H__


#define ERROR(message,return_code) \
 {                                 \
  backdoor_set_error(message);     \
  return return_code;              \
 }


void backdoor_set_error(const char *message);
void backdoor_perror(const char *format, int return_code);
void dump(const char *data, int size);

#endif
