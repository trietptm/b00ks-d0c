#ifndef __RECV_H__
#define __RECV_H__

int wait_recv(int msec);

int backdoor_client_recv_init(char *interface, char *destination);
int backdoor_client_recv(char *source, char *destination, int *direction, char *decrypted);
void backdoor_client_recv_terminate();

#endif
