#include <stdio.h>

#include "debug.h"


#define BACKDOOR_ERROR_MESSAGE "BACKDOOR ERROR: %s\n"


const char *backdoor_error = NULL;


void backdoor_set_error(const char *message) {
 backdoor_error = message;
}


void backdoor_perror(const char *format, int return_code) {
 if (backdoor_error) {
  if (!format) format = BACKDOOR_ERROR_MESSAGE;
  printf(format, backdoor_error);
  exit(return_code);
 } 
}


void dump(const char *data, int size) {
 char line[81];
 unsigned char b;
 char hex[3];
 int i,j;
 j = 0;
 for (i = 0; i < size; i++) {
  if (j == 0) { /* initialize line */
   memset(line, ' ', sizeof(line));
   line[sizeof(line)-2] = '\n';
   line[sizeof(line)-1] = 0;
  }
  b = data[i];
  /* print hex value */
  snprintf(hex, sizeof(hex), "%02X", b);
  memcpy(&line[((j <= 7) ? 0:1)+3*j], hex, 2);
  /* print ASCII value */
  if (b < 32) b = '.';
  line[16*3+2+j] = b;
  /* next byte */
  j++;
  if (j >= 16) { /* end of line */
   printf("%s", line);
   j = 0;
  }
 }
 if (j != 0) printf("%s", line);
}
