#define POLYNOMIAL 0x8408

// Code borrowed and adapted..
unsigned short crc16(int *data_p, size_t len)
{
	unsigned char i;
	unsigned int data;
	unsigned int crc = 0xffff;

	if(len == 0)
		return (~crc);

	do
	{
		while(*data_p == SIGNATURE_SKIP_BYTE) {
			if(len < 4)
				goto done;
			len -= 4;
			data_p += 4;
		}
		data = (unsigned int)0xff & *data_p++;

		for(i = 0; i < 8; i++, data >>= 1) 
		{
			if((crc & 0x0001) ^ (data & 0x0001))
				crc = (crc >> 1) ^ POLYNOMIAL;
			else
				crc >>= 1;
		}	
	} while(--len);
done:
	crc = ~crc;
	data = crc;
	crc = (crc << 8) | (data >> 8 & 0xff);

	return (crc);
}

