#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "elf_util.h"

char *elf_last_error = NULL;
extern int debug_level;

elf_handle *
elf_open(const char *filename){

	int fd;
	elf_handle *e;

	if( (fd = open(filename, O_RDONLY)) < 0) 
		return NULL;

	e = (elf_handle *)malloc(sizeof(elf_handle));
	if(!e) {
		elf_last_error = "Out of memory";
		return NULL;
	}

	e->fd = fd;
	if(read(fd, &e->hdr, sizeof(Elf32_Ehdr)) != sizeof(Elf32_Ehdr)) {
		elf_last_error = "Error reading ELF header";
		free(e);
		return NULL;
	}
	if(e->hdr.e_ident[0] != ELFMAG0 || e->hdr.e_ident[1] != 'E' || e->hdr.e_ident[2] != 'L' || e->hdr.e_ident[3] != 'F') {
		elf_last_error = "File not in ELF format";
		free(e);
		return NULL;
	}

	e->sections = NULL;
	e->section_name_strings = NULL;

	return e;
}

int
elf_close(elf_handle *e)
{
	int ret;
	free(e->sections);
	ret = close(e->fd);
	free(e);
	return ret;
}

int
elf_load_sections(elf_handle *e)
{
    if(e->hdr.e_shentsize != sizeof(Elf32_Shdr)) {
	    elf_last_error = "e_shentsize not consistent with size of Elf32_Shdr";
	    return -1;
    }

    if(e->hdr.e_shoff == 0) {
	    elf_last_error = "No section table";
	    return -1;
    }

    if(lseek(e->fd, e->hdr.e_shoff, SEEK_SET) < 0) {
	    elf_last_error = "Could not seek to section table offset";
	    return -1;
    }


    e->sections = (Elf32_Shdr *)malloc(e->hdr.e_shnum * e->hdr.e_shentsize);
    if(!e->sections) {
	    elf_last_error = "Out of memory";
	    return -1;
    }
    if(read(e->fd, e->sections, e->hdr.e_shnum * e->hdr.e_shentsize) != (e->hdr.e_shnum * e->hdr.e_shentsize)) {
	    elf_last_error = "Error reading section table";
	    return -1;
    }
    return 0;
}

ssize_t
elf_read_section_data(elf_handle *e, int index, off_t offset, char *buffer, size_t len)
{
	Elf32_Shdr *sec;
	Elf32_Word size_to_read;

	if(index >= e->hdr.e_shnum || index == 0) {
		elf_last_error = "Illegal index value";
		return -1;
	}

	sec = &e->sections[index];
	if(len > sec->sh_size)
		size_to_read = sec->sh_size;
	else
		size_to_read = len;

	if(lseek(e->fd, sec->sh_offset + offset, SEEK_SET) != (sec->sh_offset + offset)) {
		elf_last_error = "Seek to section data failed";
		return -1;
	}


	if(read(e->fd, buffer, size_to_read) != size_to_read) {
		elf_last_error = "Read section data failed";
		return -1;
	}

	return size_to_read;


}

int
elf_section_name_to_index(elf_handle *e, const char *section_name)
{
	int i;

	if(!section_name || !section_name[0]) /* Null name, Null section */
		return 0;

	if(e->section_name_strings == NULL && load_section_name_strings(e) == -1) {
		elf_last_error = "Cannot access section name strings";
		return -1;
	}
	for(i = 0; i < e->hdr.e_shnum; i++) {
		if(e->sections[i].sh_name == 0)
			continue;
		if(debug_level > 2) printf("Trying to match string: [%s]\n", e->section_name_strings + e->sections[i].sh_name);
		if(strcmp(e->section_name_strings + e->sections[i].sh_name, section_name) == 0) 
			return i;
	}

	elf_last_error = "No match";
	return -1;

	
}

char *
elf_lasterror(void)
{
	if(!elf_last_error)
		return "Operation completed successfully";
	return elf_last_error;
}

static int
load_section_name_strings(elf_handle *e)
{
	Elf32_Shdr *sec;

	if(e->sections == NULL)
		return -1;

	sec = &e->sections[e->hdr.e_shstrndx];
	e->section_name_strings = (char *)malloc(sec->sh_size);
	if(!e->section_name_strings)
		return -1;

	if(lseek(e->fd, sec->sh_offset, SEEK_SET) != sec->sh_offset) 
		return -1;

	if(read(e->fd, e->section_name_strings, sec->sh_size) != sec->sh_size) 
		return -1;

	return 0;
	
}
