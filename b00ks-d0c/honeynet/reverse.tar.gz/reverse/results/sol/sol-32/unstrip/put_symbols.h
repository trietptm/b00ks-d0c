#ifndef _PUT_SYMBOLS_H
#define _PUT_SYMBOLS_H

#define SIGNATURE_BYTES  	32	
#define SIGNATURE_SKIP_BYTE 	-1
#include <sys/types.h>

typedef struct found_struct {
	char *name;
	off_t offset;
	size_t size;
	struct found_struct *next;
} foundnode;

typedef struct symbol_list {
	Elf32_Sym sym;
	char *str_name;
	struct symbol_list *next;
} symbolnode;

char *open_target(const char *filename, size_t *len);
int search_signature(char *program_bytes, size_t program_len, int *signature, int signature_len);
ssize_t get_signature_bytes(elf_handle *e, int t_index, int *sig_bytes, size_t sig_len);
int process_relocations(elf_handle *e, int r_index, int *sig_bytes, int len);
int hexdump(int *bytes, int len);
void add_found_object(char *name, off_t offset, size_t textsize);
void process_symbols(elf_handle *e, off_t offset);
void add_symbol(char *name, off_t value, size_t size, int info);
void build_strsym_section();
void build_symbol_section(int text_index);

void dump_found();
void write_final_file(char *target_name);
#endif
