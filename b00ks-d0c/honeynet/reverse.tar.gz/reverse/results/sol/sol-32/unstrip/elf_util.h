#ifndef _ELF_UTIL_H
#define _ELF_UTIL_H
#include <linux/elf.h>

typedef struct  {
	int fd;
	Elf32_Ehdr hdr;
	Elf32_Shdr *sections;

	char *section_name_strings;

} elf_handle;

elf_handle *elf_open(const char *filename);
int elf_close(elf_handle *e);
int elf_load_sections(elf_handle *e);
ssize_t elf_read_section_data(elf_handle *e, int index, off_t offset, char *buffer, size_t len);
int elf_section_name_to_index(elf_handle *e, const char *section_name);
char *elf_lasterror(void);

static int load_section_name_strings(elf_handle *e);
#endif
