
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <assert.h>
#include "elf_util.h"
#include "put_symbols.h"


int debug_level = 0;
foundnode *foundlist = NULL;
symbolnode *symbollist = NULL;

unsigned char *g_symbol_table;
unsigned char *g_symbol_strings;

size_t g_symbol_table_len;
size_t g_symbol_strings_len;

void
usage(const char *filename)
{
	fprintf(stderr, "Usage: %s input_file object_files\n", filename);
	exit(EXIT_FAILURE);
}
int
main(int argc, char **argv)
{
	elf_handle *input_file, *target_elf;
	int text_index, text_reloc_index, target_text_index;
	Elf32_Rel *text_relocations;
	int num_relocations;
	int signature[SIGNATURE_BYTES];
	int siglen;
	char *program_bytes;
	char *target;
	int program_len;
	off_t offset;
	int n;


	if(argc <= 2)
		usage(argv[0]);

	target = argv[1];
	if( (target_elf = elf_open(target)) == NULL) {
		/* XXX */
		fprintf(stderr, "Failed opening target file");
		exit(EXIT_FAILURE);
	}
	if(elf_load_sections(target_elf) < 0) {
		fprintf(stderr, "failed loading section data: %s\n", elf_lasterror());
		exit(EXIT_FAILURE);
	}
	if( (target_text_index = elf_section_name_to_index(target_elf, ".text")) < 0) {
		fprintf(stderr, "Could not find .text section: %s\n", elf_lasterror());
		exit(EXIT_FAILURE);
	}



	for(n = 2; n < argc; n++) {
	

		if((input_file = elf_open(argv[n])) == NULL) {
			fprintf(stderr, "Failed opening input file '%s': %s\n", argv[1], elf_lasterror());
			exit(EXIT_FAILURE);
		}

		if(elf_load_sections(input_file) < 0) {
			fprintf(stderr, "Failed loading section data: %s\n", elf_lasterror());
			exit(EXIT_FAILURE);
		}

		if(debug_level) printf("%d sections loaded\n", input_file->hdr.e_shnum);

		if( (text_index = elf_section_name_to_index(input_file, ".text")) < 0) {
			fprintf(stderr, "Could not find .text section: %s\n", elf_lasterror());
			exit(EXIT_FAILURE);
		}

		if( (text_reloc_index = elf_section_name_to_index(input_file, ".rel.text")) < 0) 
			text_reloc_index = 0;

		if(debug_level > 0) printf("Text section located at index %d\n", text_index);
		if(debug_level > 0) printf("Text relocations located at index %d\n", text_reloc_index);

		siglen = get_signature_bytes(input_file, text_index, signature, SIGNATURE_BYTES);
		if(siglen < 4) {
			elf_close(input_file);
			continue;
		}

		if(text_reloc_index)
			process_relocations(input_file, text_reloc_index, signature, siglen);

		program_bytes = open_target(target, &program_len);

		if(offset = search_signature(program_bytes, program_len, signature, siglen)) {
			int textsize;
			textsize = input_file->sections[text_index].sh_size;
			printf("Found %s at offset %d - %d\n", argv[n], offset, offset + textsize);
			add_found_object(argv[n], offset, textsize);
			/*
			 * Nice, lets load some symbols...
			 */
			process_symbols(input_file, offset + target_elf->sections[target_text_index].sh_addr - target_elf->sections[target_text_index].sh_offset);


		}
		

		elf_close(input_file);
	}

	dump_found();
	build_strsym_section();

	/* XXX XXX XXX 2 is cheating XXX XXX XXX */
	build_symbol_section(2);

	write_final_file(target);
	printf("Ok.\n");


	return 0;
}


void
write_final_file(char *target_name) {
	elf_handle *e;
	unsigned char *program_bytes, *p, *new_name;
	size_t program_length, write_len;
	off_t strtab_offset, symtab_offset;
	int section_string_index;
	int strtab_string_index, symtab_string_index; /* indices into the section string table */
	int fd;
	Elf32_Shdr symtab_section, strtab_section;
	Elf32_Ehdr new_elf_header;

	e = elf_open(target_name);
	elf_load_sections(e);

	/*
	 * Let's make sure the sections we're going to add don't already exist.
	 */
	if(elf_section_name_to_index(e, ".strtab") != -1) {
		fprintf(stderr, ".strtab section already exists in target\n");
		exit(EXIT_FAILURE);
	}
	if(elf_section_name_to_index(e, ".symtab") != -1) {
		fprintf(stderr, ".symtab section already exists in target\n");
		exit(EXIT_FAILURE);
	}



	p = program_bytes = open_target(target_name, &program_length);

	/*
	 * Make a copy of the elf header and update it with new section header count and offset
	 */
	memcpy(&new_elf_header, p, sizeof(Elf32_Ehdr));
	new_elf_header.e_shnum += 2;
	new_elf_header.e_shoff +=  (16 + g_symbol_table_len + g_symbol_strings_len);


	new_name = (char *)malloc(strlen(target_name) + sizeof(".unstripped"));
	strcpy(new_name, target_name);
	strcat(new_name, ".unstripped");

	if( (fd = open(new_name, O_WRONLY | O_CREAT , 0755)) < 0) {
		fprintf(stderr, "Could not open output file '%s'\n", new_name);
		exit(EXIT_FAILURE);
	}
	free(new_name);

	if(write(fd, &new_elf_header, sizeof(Elf32_Ehdr)) != sizeof(Elf32_Ehdr)) {
		fprintf(stderr, "Error writing to final output file\n");
		exit(EXIT_FAILURE);
	}
	p += sizeof(Elf32_Ehdr);

	write_len = e->hdr.e_shoff - sizeof(Elf32_Ehdr);
	if(write(fd, p, write_len) != write_len) {
		fprintf(stderr, "Error writing to final output file\n");
		exit(EXIT_FAILURE);
	}
	p += write_len; /* p is pointing to section header table */

	/*
	 * Ok, we're now entering scary hack territory, we're going to assume that
	 * the section name string table is the last section, [1] verify this assumption
	 * (bail if we're wrong), [2] just append to it since the file pointer should be
	 * located at the end of it right now, then [3] update the section length before
	 * we write out the section table.  Are you following me here??
	 */
	if( (section_string_index = elf_section_name_to_index(e, ".shstrtab")) == -1) {
		fprintf(stderr, "Could not find section string table in target\n");
		exit(EXIT_FAILURE);
	}	

	/* [1] */
	if(e->hdr.e_shnum != (section_string_index + 1)) {
		fprintf(stderr, "section string table is not the last section in target!\n");
		exit(EXIT_FAILURE);
	}

	/* [2] */
	if((write(fd, ".strtab", 8) != 8) || (write(fd, ".symtab", 8) != 8)) {
		fprintf(stderr, "Write to output file failed\n");
		exit(EXIT_FAILURE);
	}
	/* [3] */
	strtab_section.sh_name = 9;
	symtab_section.sh_name = 1;

	e->sections[section_string_index].sh_size += 16;


	/*
	 * Write out new sections: symbol table and symbol string table
	 */
	symtab_offset = lseek(fd, 0, SEEK_CUR);
	if(write(fd, g_symbol_table, g_symbol_table_len) != g_symbol_table_len) {
		fprintf(stderr, "Write to output file failed\n");
		exit(EXIT_FAILURE);
	}
	strtab_offset = lseek(fd, 0, SEEK_CUR);

	if(write(fd, g_symbol_strings, g_symbol_strings_len) != g_symbol_strings_len) {
		fprintf(stderr, "Write to output file failed\n");
		exit(EXIT_FAILURE);
	}

	/*
	 * write the section structures from the target file, followed by the new section structures
	 * for the symbol table and string table
	 */
	write_len = e->hdr.e_shnum * e->hdr.e_shentsize;
	if(write(fd, e->sections, write_len) != write_len) {
		fprintf(stderr, "Write to output file failed\n");
		exit(EXIT_FAILURE);
	}


	symtab_section.sh_type = SHT_SYMTAB;
	symtab_section.sh_flags = 0;
	symtab_section.sh_addr = 0;
	symtab_section.sh_offset = symtab_offset;
	symtab_section.sh_size = g_symbol_table_len;
	symtab_section.sh_link = section_string_index + 2;
	symtab_section.sh_info = 1; /* no local symbols right? */
	symtab_section.sh_addralign = 4;
	symtab_section.sh_entsize = 16;

	if(write(fd, &symtab_section, sizeof(symtab_section)) != sizeof(symtab_section)) {
		fprintf(stderr, "write to target file failed\n");
		exit(EXIT_FAILURE);
	}


	strtab_section.sh_type = SHT_STRTAB;
	strtab_section.sh_flags = 0;
	strtab_section.sh_addr = 0;
	strtab_section.sh_offset = strtab_offset;
	strtab_section.sh_size = g_symbol_strings_len;
	strtab_section.sh_link = 0;
	strtab_section.sh_info = 0;
	strtab_section.sh_addralign = 0;
	strtab_section.sh_entsize = 0;
	if(write(fd, &strtab_section, sizeof(strtab_section)) != sizeof(strtab_section)) {
		fprintf(stderr, "write to target file failed\n");
		exit(EXIT_FAILURE);
	}


	

	close(fd);




}
void
process_symbols(elf_handle *e, off_t offset)
{
	int symbol_index, strtab_index, text_index, symbol_count;
	Elf32_Word symbol_table_size, string_table_size;
	Elf32_Sym *symtab, *p_sym;
	unsigned char *symbol_strings;
	int i;


	if( (symbol_index = elf_section_name_to_index(e, ".symtab")) < 0) {
		fprintf(stderr, "could not find symbol table\n");
		exit(EXIT_FAILURE);
	}
	if( (strtab_index = elf_section_name_to_index(e, ".strtab")) < 0) {
		fprintf(stderr, "Could not find symbol strings\n");
		exit(EXIT_FAILURE);
	}
	if( (text_index = elf_section_name_to_index(e, ".text")) < 0) {
		fprintf(stderr, "Could not find text section\n");
		exit(EXIT_FAILURE);
	}

	




	symbol_table_size = e->sections[symbol_index].sh_size;
	string_table_size = e->sections[strtab_index].sh_size;

	if(symbol_table_size % sizeof(Elf32_Sym)) {
		fprintf(stderr, "Symbol section size is not a multiple of sizeof(Elf32_Sym)\n");
		exit(EXIT_FAILURE);
	}
	symbol_count = symbol_table_size / sizeof(Elf32_Sym);



	symtab = (Elf32_Sym *)malloc(symbol_table_size);
	symbol_strings = (unsigned char *)malloc(string_table_size);

	if(!(symtab && symbol_strings)) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}

	if(elf_read_section_data(e, symbol_index, 0, (char *)symtab, symbol_table_size) != symbol_table_size) {
		fprintf(stderr, "Read incorrect number of bytes into symbol table\n");
		exit(EXIT_FAILURE);
	}

	if(elf_read_section_data(e, strtab_index, 0, symbol_strings, string_table_size) != string_table_size) {
		fprintf(stderr, "Read incorrect number of bytes into string table\n");
		exit(EXIT_FAILURE);
	}


	for(i = 0, p_sym = symtab; i < symbol_count; i++, p_sym++) {
		if( (ELF32_ST_TYPE(p_sym->st_info) == STT_FUNC) && (p_sym->st_shndx == text_index)  && (p_sym->st_name) ) {
			add_symbol(symbol_strings + p_sym->st_name, p_sym->st_value + offset, p_sym->st_size, p_sym->st_info); 
		}
	}
	free(symtab);
	free(symbol_strings);

}



void
add_symbol(char *name, off_t value, size_t size, int info)
{
	symbolnode *p_sym, *new_node;

	printf("adding symbol '%s'\n", name);
	if(!symbollist) {
		symbollist = malloc(sizeof(symbolnode));
		if(!symbollist) {
			fprintf(stderr, "Out of memory\n");
			exit(EXIT_FAILURE);
		}
		symbollist->next = NULL;
	}
	new_node = (symbolnode *)malloc(sizeof(symbolnode));

	if(!new_node) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}
	new_node->next = NULL;
	new_node->str_name = strdup(name);
	new_node->sym.st_name = 0;
	new_node->sym.st_value = value;
	new_node->sym.st_size = size;
	new_node->sym.st_info = info;
	new_node->sym.st_other = 0;
	new_node->sym.st_shndx = 0;


	p_sym = symbollist;

	for(p_sym = symbollist; p_sym; p_sym = p_sym->next) 
		if(!p_sym->next) {
			p_sym->next = new_node;
			break;
		}

}

/*
 * This function walks the list of symbol structures and constructs the body of a .strtab
 * section.  It also inserts the correct offset for each symbol into the st_name field of 
 * each symbol.
 *
 * Results are stored in global variables: g_symbol_strings and g_symbol_strings_len
 */
void
build_strsym_section()
{
	symbolnode *p_sym = symbollist;
	unsigned char *p;

	if(!p_sym || !p_sym->next) {
		fprintf(stderr, "No symbols on symbol list\n");
		exit(EXIT_FAILURE);
	}

	g_symbol_strings_len = 1; /* at least one character for the null label */
	while(p_sym = p_sym->next) {
		g_symbol_strings_len += strlen(p_sym->str_name);
		g_symbol_strings_len++; /* null character */
	}
	p = g_symbol_strings = (unsigned char *)malloc(g_symbol_strings_len);
	if(!g_symbol_strings) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}
	*p++ = 0; /* null label */

	p_sym = symbollist;
	while(p_sym = p_sym->next) {
		p_sym->sym.st_name = p - g_symbol_strings;
		memcpy(p, p_sym->str_name, strlen(p_sym->str_name) + 1);
		p += (strlen(p_sym->str_name) + 1);
	}
	assert(p - g_symbol_strings == g_symbol_strings_len);
}

/*
 * Creates the body of the symbol section from the list of symbol structures.  The st_shndx field
 * of each symbol is filled in from the 'text_index' parameter.  
 * 
 * Results are stored in global variables: g_symbol_table and g_symbol_table_len
 */
void
build_symbol_section(int text_index)
{
	int symbol_count = 0;
	symbolnode *p_sym;
	unsigned char *symbol_table, *p;

	p_sym = symbollist;

	if(!p_sym || !p_sym->next) {
		fprintf(stderr, "No symbols in symbol list\n");
		exit(EXIT_FAILURE);
	}

	while(p_sym = p_sym->next)
		symbol_count++;


	g_symbol_table_len = symbol_count * sizeof(Elf32_Sym);
	p = g_symbol_table = (unsigned char *)malloc(g_symbol_table_len);
	if(!g_symbol_table) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}

	p_sym = symbollist;
	while(p_sym = p_sym->next) {
		p_sym->sym.st_shndx = text_index;
		memcpy(p, &p_sym->sym, sizeof(Elf32_Sym));
		p += sizeof(Elf32_Sym);
	}

}


void
add_found_object(char *name, off_t offset, size_t textsize)
{
	foundnode *p, *node = NULL;

	if(!foundlist) {
		foundlist = malloc(sizeof(foundnode));
		foundlist->name = "";
		foundlist->offset = 0;
		foundlist->size = 0;
		foundlist->next = NULL;
	}

	node = malloc(sizeof(foundnode));
	node->name = name;
	node->offset = offset;
	node->size = textsize;
	node->next = NULL;

	p = foundlist;
	do {
		if(!p->next) {
			printf("appending %s\n", name);
			p->next = node;
			return;
		}
		if(p->next->offset > offset) {
			printf("inserting %s\n", name);
			node->next = p->next;
			p->next = node;
			return;
		}
	} while(p = p->next);

	/* not reached */
	fprintf(stderr, "AHHHHH!\n");
	return;
}



char *
open_target(const char *filename, size_t *len)
{
	int fd;
	off_t file_len;
	char *p;

	if( (fd = open(filename, O_RDONLY)) < 0) 
  		return NULL;

	if( (*len = lseek(fd, 0, SEEK_END)) < 0)
		return NULL;


	p = (char *)mmap(0, *len, PROT_READ, MAP_SHARED, fd, 0);
	if(p == MAP_FAILED)
		return NULL;

	close(fd);
	return p;
		
}

int
search_signature(char *program_bytes, size_t program_len, int *signature, int signature_len)
{
	int i;
	int *psig, len;

	psig = signature;
	len = signature_len;
	/*
	 * If signature doesn't contain any valid bytes this might blow up
	 * Hmm, oh well..
	 */
	while(*psig == SIGNATURE_SKIP_BYTE) { psig++; len--; }

	if(len <= 0) {
		fprintf(stderr, "bogus signature! len = %d\n", signature_len);
		hexdump(signature, signature_len);
		return 0;
	}

	if(debug_level > 2) printf("Searching %d bytes of target...\n", program_len);

	for(i = 0; i < (program_len - 3); i += 4) {
		if(*psig == (int)program_bytes[i])
			if(signature_match(program_bytes + i, psig, len)) {
				if(debug_level > 1) printf("DING DING DING, match found at offset %d\n" ,i - (psig - signature));
				return (i - (psig - signature));
			}
	}
	if(debug_level) printf("No match found :-(\n");
	return 0;

}

int signature_match(char *bytes, int *sig, int sig_len)
{
	int i;

	for(i = 0; i < sig_len; i++) {
		if(sig[i] == SIGNATURE_SKIP_BYTE)
			continue;
		if(bytes[i] != (char)sig[i])
			return 0;
	}
	return 1;
}

ssize_t
get_signature_bytes(elf_handle *e, int t_index, int *sig_bytes, size_t sig_len) 
{
	unsigned char *buffer;
	size_t bytes_read;
	int i;

	buffer = (char *)malloc(sig_len);
	if(!buffer) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}

	bytes_read = elf_read_section_data(e, t_index, 0, buffer, sig_len);
	for(i = 0; i < sig_len; i++) 
		if(i < bytes_read)
			sig_bytes[i] = buffer[i];
		else
			sig_bytes[i] = SIGNATURE_SKIP_BYTE;

	free(buffer);
	return bytes_read;
}

int
process_relocations(elf_handle *e, int r_index, int *sig_bytes, int len)
{
	Elf32_Rel *relocations, *r;
	Elf32_Word size;
	int num_relocations, i, j;

	size = e->sections[r_index].sh_size;
	num_relocations = size / sizeof(Elf32_Rel);

	relocations = (Elf32_Rel *)malloc(size);
	if(!relocations) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}

	if(elf_read_section_data(e, r_index, 0, (char *)relocations, size) != size) {
		fprintf(stderr, "Failed reading relocation section: %s\n", elf_lasterror());
		exit(EXIT_FAILURE);	
	}

	/*
	 * Loop over relocations and for each relocation that falls within the first
	 * 'len' bytes replace the relocation field with the value SIGNATURE_SKIP_BYTE
	 */
	r = relocations;
	for(i = 0; i < num_relocations; i++,r++) {
		/*
		 * This relocation is within our signature byte range but we have to be 
		 * careful not to write off the end of the signature array flagging the
		 * bytes
		 */
		if(r->r_offset < len)
			for(j = 0; j < 4; j++) {
				if( (r->r_offset + j) == len)
					break;
				sig_bytes[r->r_offset + j] = SIGNATURE_SKIP_BYTE;
			}
	}

		
	free(relocations);	
	return 0;
}

void
dump_found()
{
	foundnode *p = foundlist;
	int i = 0;
	int total_bytes = 0;

	printf("Results:\n\n");
	while(p = p->next) { 
		printf("%s\t\t\t\t\t%d -- %d\t%d\n", p->name, p->offset, p->offset + p->size, p->size);
		i++;
		total_bytes += p->size;
	}
	printf("\n\n%d matches\n", i);
	printf("total bytes: %d\n", total_bytes);
	
}
int
hexdump(int *bytes, int len)
{
	char hex[] = "0123456789ABCDEF";
	int i;

	for(i = 0; i < len; i++) {
		if(bytes[i] == -1) {
			putchar('X'); putchar('X'); putchar(' ');
		}
		else {
			putchar(hex[bytes[i] >> 4]);
			putchar(hex[bytes[i] & 0xF]);
			putchar(' ');
		}
	}
}

