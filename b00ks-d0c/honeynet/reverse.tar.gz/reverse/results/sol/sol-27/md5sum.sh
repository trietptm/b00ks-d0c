#!/bin/sh
#tar cvfz files.tar files
md5sum `find . -type f` |grep -v md5> md5.txt
scp md5.txt mat@monkey.org:

