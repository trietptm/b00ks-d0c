#!/usr/bin/perl

my @syscall;

open FP, "</usr/include/asm/unistd.h";
while(<FP>)
{
	if(/\#define __NR_([^\s]+)\s*([0-9]+)/)
	{
		$syscall[$2] = $1;
	}
}
close FP;

$eax = 0;
$eaxage = 0;

while(<>)
{
	my $line = $_;
	$line =~ s/\015//g;
	if(/eax = 0x([0-9]+)\;/)
	{
		$eax = hex($1);
		$eaxage = 1;
	}
	if((/asm\(\"int 0x80\"\)/) && ($eaxage < 5))
	{
		chomp $line;
		print "$line // syscall ".$syscall[$eax]."\n";
	}
	else
	{
		print $line;
	}
	$eaxage++;
}
