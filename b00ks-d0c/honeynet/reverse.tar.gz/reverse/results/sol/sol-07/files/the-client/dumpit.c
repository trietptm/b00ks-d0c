#include <stdio.h>
#include <string.h>
#include <pcap.h>

#define MAXPACKET 1600

void decrypt(u_char *data, unsigned int len)
{
	unsigned int pos;
	for(pos=len;pos>0;pos--)
		data[pos] -= data[pos-1] + 0x17;
	data[0] -= 0x17;
}

void dump_packet(u_char *arg, const struct pcap_pkthdr *hdr, const u_char *data)
{
	bpf_u_int32 pos;
	bpf_u_int32 packetlen, dir, cmd;
	bpf_u_int32 srcip, dstip, proto, ttl;
	u_char dirstring[20];
	u_char cmdstring[20];

	u_char unencrypted_data[MAXPACKET];
	unsigned int unencrypted_data_len = 0;

	if((hdr->len - 0x24) > 0)
	{
		unencrypted_data_len = hdr->len - 0x24;
		memcpy(unencrypted_data, &data[0x24], unencrypted_data_len);
		decrypt(unencrypted_data, unencrypted_data_len);
	}

	packetlen = (data[0x10] << 8) + data[0x11];
	srcip     = (data[0x1a] << 24) + (data[0x1b] << 16) + (data[0x1c] << 8) + (data[0x1d]);
	dstip     = (data[0x1e] << 24) + (data[0x1f] << 16) + (data[0x20] << 8) + (data[0x21]);

	ttl       = data[0x16];
	proto     = data[0x17];

	dir       = (data[0x23] << 8) + data[0x22];

	cmd       = (unencrypted_data[0x00] << 8) + unencrypted_data[0x01];

	switch(cmd & 0xFF)
	{
	case 1: strcpy(cmdstring, "status"); break;
	case 2: strcpy(cmdstring, "configure"); break;
	case 3: strcpy(cmdstring, "exec"); break;
	case 4: strcpy(cmdstring, "dns_flood"); break;
	case 7: strcpy(cmdstring, "exec_silent"); break;
	case 8: strcpy(cmdstring, "kill_child"); break;
	default: strcpy(cmdstring, "unknown");
	}

	switch(dir & 0xFF)
	{
	case 2: strcpy(dirstring, "request"); break;
	case 3: strcpy(dirstring, "reply"); break;
	default: strcpy(dirstring, "unknown");
	}

	printf("%d.%d.%d.%d -> %d.%d.%d.%d proto %02x ttl %d\n    ",
		(srcip >> 24) & 0xFF,
		(srcip >> 16) & 0xFF,
		(srcip >>  8) & 0xFF,
		(srcip      ) & 0xFF,
		(dstip >> 24) & 0xFF,
		(dstip >> 16) & 0xFF,
		(dstip >>  8) & 0xFF,
		(dstip      ) & 0xFF,
		proto, ttl);

	if((proto == 11) && unencrypted_data_len)
	{
 		printf("%04x (%s) %04x (%s)  %d data bytes:\n    ", dir, dirstring, cmd, cmdstring, unencrypted_data_len);
		pos=0x0;
		while(pos < unencrypted_data_len)
		{
			printf("%02X ", unencrypted_data[pos]);
			if((pos%16) == 15)
			{
				pos -= 15;
				while((pos%16) != 15)
				{
					printf("%c", isprint(unencrypted_data[pos])?unencrypted_data[pos]:'.');
					pos++;
				}
				printf("%c", isprint(unencrypted_data[pos])?unencrypted_data[pos]:'.');
				printf("\n    ");
			}
			pos++;
		}
		printf("\n");
		printf("\n");
	}
}

int main(int argc, char *argv[])
{
	char *device;
	char errbuff[PCAP_ERRBUF_SIZE];
	pcap_t *pc;
	struct bpf_program pc_filter;
	bpf_u_int32 mynetwork;
	bpf_u_int32 mynetmask;

	if(argc != 2)
	{
		fprintf(stderr, "usage: %s <device>\n", argv[0]);
		return(1);
	}

	device = strdup(argv[1]);

	pc = pcap_open_live(device, 1500, 0, 5, errbuff);
	if(pc == NULL)
	{
		fprintf(stderr, "Failed to open %s: %s\n", device, errbuff);
		return(1);
	}
	if((pcap_lookupnet(device, &mynetwork, &mynetmask, errbuff) == -1) ||
	   (pcap_compile(pc, &pc_filter, "ip proto 11", 1, mynetmask) == -1) ||
	   (pcap_setfilter(pc, &pc_filter) == -1))
	{
		fprintf(stderr, "Failed to configure interface %s: %s\n",
			device, pcap_geterr(pc));
		return(1);
	}

	pcap_loop(pc, -1, dump_packet, NULL);

	pcap_close(pc);
	pcap_freecode(&pc_filter);

	return(0);
}
