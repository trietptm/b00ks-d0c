#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <netdb.h>
#include <signal.h>


#define LEANA 213

int main (int argc , char *argv[]) {

 int fut ,  function;
 int fct;
 int k=0;
 unsigned char buf[1000];
 unsigned char my_got[2000];
 
 struct sockaddr_in skaTo;
 int intSkaLen = sizeof(skaTo);
 int sockd;
 int n , i=1;
   struct sockaddr_in sin;
   struct hostent *hp;
  int thesock;
 unsigned char  *buffer ;
 bzero ((char *) buf, 900);
 bzero ((char *) my_got, 2000);

 buf[0] = 69 ;
 buf[1] = 0 ; 
 buf[2] = 0 ;
 buf[3] = 60 ;
 buf[4] = 192 ;
 buf[5] = 161 ;
 buf[6] = 0;
 buf[7] = 0 ;
 buf[8] = 32;
 buf[9] = 11;         // Protocol check in the_binary 0x80482d5
 buf[10] = 88; 
 buf[11] = 199; 
 buf[12] = 192;
 buf[13] = 168;
 buf[14] = 1;
 buf[15] = 1;
 buf[16] = 192;
 buf[17] = 168;
 buf[18] = 1;
 buf[19] = 2;
 buf[20] = 2;	     // a new check in that binary at 0x80482e5
 buf[21] = 0;
/*
 buf[22] = 71;
 buf[23] = 92;
 buf[24] = 1;
 buf[25] = 0; 
 buf[26] = 5;
 buf[27] = 0; 
 buf[28] = 97; buf[29] = 98; buf[30] = 99;  buf[31] = 100;
 buf[32] = 101; buf[33] = 102;buf[34] = 103;buf[35] = 104;buf[36] = 105; buf[37] = 106 ;buf[38] = 107;buf[39] = 108;buf[40] = 109;buf[41] = 110;
 buf[42] = 111;buf[43] = 112; buf[44] = 113;buf[45] = 114;buf[46] = 115;buf[47] = 116;buf[48] = 117;buf[49] = 118;buf[50] = 119;
 buf[51] = 97;buf[52] = 98 ;buf[53] = 99;buf[54] = 100;buf[55] = 101;buf[56] = 102;buf[57] = 103;buf[58] = 104;buf[59] = 105;
*/

buffer = buf + 22;
for ( n = 21 ; n < 950 ; n ++) 
 buf[n] = 0 ;//'A';

// #define FUNCTION 3
//  spawn shell 

//strcpy(buffer,"uouch /test.txt");
//buffer[0]=0x17; // fix 23 ce frumos
//buffer[1]=0x2e + FUNCTION; // asta e functie + 0x00-0xd2 = 0x2e + functie
//buffer[2]='i'+0x48;
//buffer[3]=(unsigned char)('d') + (unsigned char)(0xc8);
//buffer[4]=0x43;
if (argc < 2){
    printf("Usage: control file <function> <command>\n");
    exit(0);
    }
{
FILE *fp;

fp = fopen( argv[1] , "rb");
fread(buffer,LEANA,1,fp);
fclose(fp);
}
//function = atoi(argv[1]);
//strcpy(buffer+2,argv[2]);
//  buffer[0] = 0x17;

// 1 -->  0x0 --> 0xd2 
//  buffer[1] =  0x100 - (0xe9 - buffer[0]) + function ;
//  buffer[1] = 0;  
// 14  

//for (fut = 2 ; fut < 256 ; fut ++)
// {
//  int j ; 
//  j = (buf[fut] -  buffer[fut-1]) + fut * 0x17 + fut-1 ;
// 0x48 + 0xe9 - i * 23 - i * 3  = 100
// 0xc8 - 0xe9 + 0x100 
//    j =  0x100 + i * 23 - i * 3 -  0xe9 ;
//  if ( j > 0x100 ) 
//    j -=  0x100;
//  
//  buffer[fut] = 0;// j; // buffer[i] + 23  ;
// }

//for (fut = 256 ; fut > 0 ; fut --)
// {
//int j;

//j = buffer[fut] + 23 ;


//buffer[0]=0xbb;
//buffer[1]=0xd8;
//buffer[2]=0x00;

//buffer[255]='t'+23+1;
//buf[254+22]='A';
//buf[253+22]='A'+23;
//buf[252+22]='A'+23+0x03;
//buf[251+22]='A'+23+0x03;
//buf[250+22]='A'+23+0x03;

 bzero ((char *) &skaTo, sizeof (skaTo));

 sockd = socket(PF_INET,SOCK_RAW,11 );
 //sockd = socket(PF_INET,SOCK_RAW,255 );

 if (sockd==-1)
 {
 printf("Could not open Socket");
 }

	 
 hp = gethostbyname("192.168.1.2");
 if (hp==NULL) {
  printf("pulaaaaaaa\n");
  exit(0);
    }
// bzero((char*) &sin, sizeof(sin));
 bcopy(hp->h_addr, (char *) &skaTo.sin_addr, hp->h_length);
 skaTo.sin_family = hp->h_addrtype;
 skaTo.sin_port = htons(1234);
// thesock = socket(AF_INET, SOCK_DGRAM, 0);
//  connect(thesock,(struct sockaddr *) &sin, sizeof(sin));
// return thesock;
					     


 n= setsockopt (sockd, IPPROTO_IP, IP_HDRINCL, (char *) &i,sizeof (i));
 printf("Set Socket = %d\n",i);
 n = sendto(sockd,buf,LEANA+22,0,(struct sockaddr*)&skaTo,intSkaLen);
 printf("sendto = %d\n",n);

// if (errno ==EINVAL )
// printf("einval\n");
 close(sockd);
 return 0;
 };

