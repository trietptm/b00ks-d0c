#include <stdio.h>
#include <sys/types.h>

// received = buffer address without header . that means actual_receved_buffer - 22 
// len = received len - 22 
int pack_decode(unsigned char *result, unsigned char *received , int len)
{
unsigned char temp_buf[5000];
int i , j ;
int calculus; 

i = len - 1 ;
temp_buf[0]= 0;
while ( i >= 0 )
 {
    if ( i != 0 )
     calculus = received[i] - received[i - 1];
    else
     calculus = received[0];

    calculus = calculus - 23;
    while ( calculus < 0 ) calculus += 0x100;

    for ( j = 0 ; j < len ; j ++)
      result[j] = temp_buf[j] ;

    temp_buf[0] = calculus ;

    for ( j = 1 ; j < len ; j ++)
      temp_buf[j] = result[j - 1];

    sprintf(temp_buf,"%c%s",calculus,result);
    i-- ;
 }
// here in temp_buf we have an good old plain text mode + command
}


// received = buffer address without header . that means actual_receved_buffer - 22 
// len = received len - 22 
int pack_encode(unsigned char *result, unsigned char *received , int len)
{
unsigned char temp_buf[5000];
int i , j ;
int calculus; 

i = len - 1 ;
//temp_buf[0]= 0;

//calculus = received[0] + 23 ;
//while ( calculus >= 0x100 ) calculus -= 0x100;
result[0] = 0x17;
//calculus;

for ( i = 1 ; i < len ; i ++ )
 {
    calculus = received[i-1] - received[i];
    calculus = calculus + 23;
    
    while ( calculus > 0x100 ) calculus -= 0x100;
    
    result[i] = calculus;
 }
// here in temp_buf we have an good old plain text mode + command
}

#define LEANA 213
int main(int argc,char * argv[])
{
unsigned char result[5000];
unsigned char received[5000];
FILE *fp;
FILE *fq;
fp = fopen(argv[1],"rb");
fq = fopen(argv[2],"wb");
fread(received,LEANA,1,fp);
pack_decode(result,received,LEANA);
//pack_encode(result,received,LEANA);

fwrite(result,LEANA,1,fq);
fclose(fp);
fclose(fq);

}
