#!/usr/bin/perl

while (<>) {
  ($a,$b,$c,$d)=m/(\w\w)(\w\w)(\w\w)(\w\w)/;
  print int("0x$a"),".",int("0x$b"),".",int("0x$c"),".",int("0x$d"),"\n";
}
