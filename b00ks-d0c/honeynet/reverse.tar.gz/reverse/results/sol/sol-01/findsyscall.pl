#!/usr/bin/perl

open FILE,"/usr/include/asm/unistd.h" || die;
while (<FILE>) {
  if (/#define __NR_(\w*)	* *(\d*)/) {
    $tab{$2} = $1;
  }
}
close FILE;
open FILE,"/usr/include/linux/net.h" || die;
while (<FILE>) {
  if (/#define SYS_(\w*)	* *(\d*)	*/) {
    $socktab{$2} = $1;
  }
}
close FILE;

while (<>) {
  chomp;
  if (/push   \%ebp/) {
    $laststart=$_;
    $syscall=-1; $sockcall=-1; $lasteax=""; $lastedx="";
  }
  if (/,\%eax *$/) {
    $lasteax=$_;
    if (/mov *\$(0x[0-9a-f]*),\%eax/) {
      $syscall=sprintf("%d",$1);
    } else {
      $syscall=-1;
    }
  }
  if (/,\%edx *$/) {
    $lastedx=$_;
    if (/mov *\$(0x[0-9a-f]*),\%edx/) {
      $sockcall=sprintf("%d",$1);
    } else {
      $sockcall=-1;
    }
  }
  if (/int    \$0x80/) {
    $laststart =~ s/^ *(\w+):.*/$1/;
    print "$laststart: ";
    if ($tab{$syscall} eq "socketcall") {
      print "Syscall: $syscall - $sockcall (",$socktab{$sockcall},")\n";
    } else {
      print "Syscall: $syscall (",$tab{$syscall},")\n";
    }
#    print "$_\n";
#    print "last eax:\n  $lasteax\n";
#    print "\n";
  }
}
