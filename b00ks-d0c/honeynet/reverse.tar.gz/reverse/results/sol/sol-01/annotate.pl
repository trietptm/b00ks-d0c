#!/usr/bin/perl

open FILE,"syscalls.txt" || die;
while (<FILE>) {
  chomp;
  ($addr,$name) = m/^([0-9a-f]+): *(.*)$/;
  if ($addr ne "") {
    $foo = sprintf("%08x",int("0x$addr"));
    $tab{$foo}=$name;
#    print "$addr: tab[$foo]=$name\n";
  } else {
    ($addr,$name) = m/^(\w+\/0x[0-9a-f]+): *(.*)$/;
    if ($addr ne "") {
      $locals{$addr}=$name;
    }
  }
}
close FILE;

while (<>) {
  chomp;
  ($addr,$codes,$opcode) = (m/^ ([0-9a-f]+):\t*([\w ]+)\t(.*)/);
  s/lea    0x0\(%esi\),%esi/nop; nop; nop;/;
  s/lea    \(%esi\),%esi/nop; nop;/;
  s/lea    0x0\(%esi,1\),%esi/nop; nop; nop; nop; nop; nop; nop;/;
  if ($opcode ne "") {
    $addr = sprintf("%08x",int("0x$addr"));
    if (exists $tab{$addr}) {
      $cur=$tab{$addr};
      if ($cur =~ m/^(\w+)\(/) {
	$curfunc=$1;
	print STDERR "found function $curfunc\n";
	print "\n$curfunc:\t\t/* $cur */\n";
      } else {
	print "\t\t\t[* -> $cur <- *]\n";
      }
      $flag=1;
    }
    if ($opcode =~ m/^call +(\w+)/) {
      $foo = sprintf("%08x",int($1));
      if (exists $tab{$foo}) {
        $callee=$tab{$foo};
	if ($callee =~ m/^(\w+)\(/) {
	  $name = $1;
	  s/call +(.*)/call   $name/;
	  print "$_\t/* $callee */\n";
	} else {
	  print "$_\t/* ",$tab{$foo}," */\n";
	}
      } else {
	print "$_\t/* ??? */\n";
      }
    } elsif ($flag==0 && $opcode =~ m/push   \%ebp$/) {
      $cur="???"; $curfunc="???";
      print "$_\n";
    } elsif ($opcode =~ m/(0x8\w{3,7})/) {
      $foo = sprintf("%08x",int($1));
      if (exists $tab{$foo}) {
	print "$_\t/* $1 == ",$tab{$foo}," */\n";
      } else {
	if ($opcode =~ m/^j/) {
	  print "$_\n";	# don't ???-annotate conditional jumps
	} else {
	  print "$_\t/* $1 == ??? */\n";
	}
      }
    } elsif ($opcode =~ m/(0x[0-9a-f]{1,8})\((\%e\w\w)?,?\%ebp(,%e\w\w)?(,[1248])?\)/) {
      if (exists $locals{"$curfunc/$1"}) {
	print "$_\t/* $1(\%ebp) == ",$locals{"$curfunc/$1"}," */\n";
      } else {
	print "$_\n";
      }
    } else {
      print "$_\n";
    }
  } else {
    print "$_\n";
  }
  $flag=0;
}
