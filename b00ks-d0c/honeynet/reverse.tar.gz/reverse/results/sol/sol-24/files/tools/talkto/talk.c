/******************************************************************************\
* File:
*   talk.c
*
* Description:
*   Tool to talk to "the-binary" of The Reverse Challenge.
*
* Author:
*   Jorge Ortiz-Fuentes
*
* Revisions:
*   2002-05-08. First version.
*
\******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

/* exit values */
#define EXIT_NO_ROOT 1
#define EXIT_NO_SOCK 1

/* default values */
#define SERVER_PROT 0xb
#define BUFF_SIZE 1024

void help (char *, char *);
int talk(char *, int);

/*
Function:
  main
Description:
  Parses the command line.
*/
int
main (int argc, char * argv[])
{
  char * version = "0.0.1";
  char * server_name = "localhost";
  int server_prot = SERVER_PROT;
  int buff_size = BUFF_SIZE;
  char buffer[BUFF_SIZE];
  char * pbuffer = buffer;
  int sock;
  int c;
  opterr = 0;

  while ((c = getopt (argc, argv, "hs:p:")) != -1)
    switch (c)
      {
      case 'h':
	help(argv[0], version);
	exit(0);
	break;
      case 'p':
	server_prot = atoi(optarg);
	break;
      case 's':
	server_name = (char *)malloc(strlen(optarg));
	strcpy(server_name, optarg);
	break;
      case '?':
	if (isprint (optopt))
	  fprintf (stderr, "Option `-%c' IGNORED.\n", optopt);
	else
	  fprintf (stderr,
		   "Option character `\\x%x' IGNORED.\n",
		   optopt);
      }

  if (geteuid() != 0)
    {
      fprintf(stderr, "Only root can use this program!.Sorry.\n");
      help(argv[0], version);
      exit(EXIT_NO_ROOT);
    }
  if ((sock = talk(server_name, server_prot)) < 0)
    {
      fprintf(stderr, "Error while creating the socket.\n");
      exit(EXIT_NO_SOCK);
    }
  /* according to the IRIX TCP/IP programming guide,
     connectionless sockets  should be used with sendto instead of
     write */
  while(getline(&pbuffer, &buff_size, stdin) != -1)
    {
      write(sock, buffer, buff_size);
      buff_size = BUFF_SIZE;
    }
  close(sock);

  return 0;
}

/*
Function:
  help
Description:
  prints a help message for the user (obtained with the -h option)
*/
void
help (char * name, char * version)
{
  fprintf(stderr, "USAGE:\n\t%s v%s [-options] [servername]\n\n", name, version);
  fprintf(stderr, "Servername is by default localhost.\n");
  fprintf(stderr, "Options:\n");
  fprintf(stderr, "\t-b #\tblock size for transmision\n");
  fprintf(stderr, "\t-h\tprint this help\n");
  fprintf(stderr, "\t-p #\tset port number\n");
}

/*
Function:
  talk
Description:
  Creates a socket to the dessired port.
Returns:
  A file descriptor for the socket (positive value) if successful.
*/
int
talk(char * server_name, int protocol)
{
  struct hostent * host;
  struct in_addr addr;
  int sock, connected;
  struct sockaddr_in address;

  /* resolve hostname */
  if (inet_aton(server_name, &addr) == 0)
    {
      host = (struct hostent *)gethostbyname(server_name);
      if (host != NULL)
	memcpy(&addr, host->h_addr_list[0], sizeof(struct in_addr));
      else
	return -1;
    }

  /* set address to connect to */
  memset((char *) &address, 0, sizeof(address));
  address.sin_family = AF_INET;
  /*  address.sin_port = (port);*/
  address.sin_addr.s_addr = addr.s_addr;

  /* create the socket */
  sock = socket(AF_INET, SOCK_RAW, protocol);

  /* "connect" it to set destination address */
  connect(sock, (struct sockaddr *) &address, 
		      sizeof(address));
  if (connected < 0) {
    perror("connect");
    return -2;
  }


  return sock;
}
