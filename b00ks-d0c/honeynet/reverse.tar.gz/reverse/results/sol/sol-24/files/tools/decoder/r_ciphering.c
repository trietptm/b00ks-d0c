/*
 * File: 
 *   r_ciphering.c
 *    
 * Description: 
 *   These file provides the two functions that perform
 *   the ciphering/deciphering of messages the way "the_binary"
 *   of the Reverse Challenge likes it.
 *    
 * Author:
 *   David Perez
 *
 * Revisions:
 *   2002-05-19. First version.
 */


/*
 * Function: 
 *   int r_cipher (int size, char *ciphertext, char *cleartext)
 *
 * Description: 
 *   Ciphers the contents of 'cleartext' into 'ciphertext'.
 *   Parameter size is the length of both arrays.
 */

int r_cipher (int size, char *ciphertext, char *cleartext)
{

  int i;
  int temp;

  /* The ciphering formula goes like this:
   *    ciphertext[i]=cleartext[i]+ciphertext[i-1]+23-(256*N)
   * where:
   *    i goes from 0 to size-1, being size the number of bytes of each array
   *    ciphertext[i-1] is assumed to be 0 for i=0
   *    N is the smaller factor among 0 and 1 such that ciphertext[i]<=255
   */
  
  for (i=0; i<=size-1; i++) {

    /* First we sum the 2 elements of the arrays and the constant 23*/
    if (i==0) {
      temp = (int) cleartext[i] + 23 ;
    }
    else {
      temp = (int) cleartext[i] + (int) ciphertext[i-1] + 23 ;
    }

    /* Second, we make temp less than 256  by substracting N times 256 */
    while ( temp > 255 ) {
      temp = temp-256;
    }

    /* Finally we save temp as a character in the ciphertext array */
    ciphertext[i] = (char) temp;

  } /* end of for */

  return (0);
}



/*
 * Function:
 *   int r_decipher (int size, char *ciphertext, char *cleartext)
 *
 * Description: 
 *   Deciphers the contents of 'ciphertext' into 'cleartext'.
 *   'size' is the length of both arrays.
 */

int r_decipher (int size, char *ciphertext, char *cleartext)
{

  int i;
  int temp;

  /* The deciphering formula goes like this:
   *    cleartext[i]=ciphertext[i]-ciphertext[i-1]-23+(256*N)
   * where:
   *    i goes from 0 to size-1, being size the number of bytes of each array
   *    ciphertext[i-1] is assumed to be 0 for i=0
   *    N is the smaller factor among 0, 1 and 2 such that cleartext[i]>=0
   */
  
  for (i=size-1; i>=0; i--) {

    /* First we substract the 2 elements of the array and the constant 23*/
    if (i==0) {
      temp = (int) ciphertext[i] - 23 ;
    }
    else {
      temp = (int) ciphertext[i] - (int) ciphertext [i-1] - 23 ;
    }

    /* Second, we make temp positive by adding N times 256 */
    while ( temp < 0 ) {
      temp = temp+256;
    }

    /* Finally we save temp as a character in the cleartext array */
    cleartext[i] = (char) temp;

  } /* end of for */

  return (0);
}
