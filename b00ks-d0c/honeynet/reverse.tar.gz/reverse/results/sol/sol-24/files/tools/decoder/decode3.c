#include <stdio.h>

#define MAX_BYTES 1024

void decode(int num_bytes, char *data, char *dest)
{
char var4[MAX_BYTES];
int i;

if (num_bytes<2) return;

for (i=num_bytes-1;i>=0;i--)
   {
	memcpy(var4,dest,num_bytes-1);
	sprintf(dest,"%c%s",i?(data[i]-data[i-1]-0x17):(data[0]-0x17),var4);
   }
}

main()
{
	char	destination[MAX_BYTES];

	decode(23,"olaPepe99ABCDEFGHIJABCD",destination);
	fprintf(stdout,"%s\n",destination);
}
