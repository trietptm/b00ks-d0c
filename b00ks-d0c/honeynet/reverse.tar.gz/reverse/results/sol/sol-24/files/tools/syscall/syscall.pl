#!/usr/bin/perl

# File:
#   syscall.pl
#
# Description:
#   Add comments to the output of objdump about the system calls.
#
# Author:
#   Jorge D. Ortiz-Fuentes
#
# Revisions:
#   2002-05-15. First version.
#

my @line;
my @aux;
my %syscall;
my $i;
my $j;

if (@ARGV < 1) {
    print STDERR "USAGE:\n";
    print STDERR "$0 <objdump_file>\n";
    exit 0;
}

# Load system calls names and numbers
open(SYSCALLS, "/usr/include/asm/unistd.h") || die "Couldn't open unistd.h\n";
@line = <SYSCALLS>;
close(SYSCALLS);
foreach $i (@line) {
    chop($i);
    if ($i =~ /\#define __NR_\w+/) {
	@aux = split(/\s+/, $i);
	$aux[1] =~ s/__NR_//;
	$syscall{$aux[2]} = $aux[1];
    }
}
#foreach $i (sort keys %syscall){
#    print "$i: $syscall{$i}\n";
#}
open(FILE,$ARGV[0]) || die "Couldn't open file $ARGV[0]\n";
@line = <FILE>;
close(FILE);

for($i = 0;  $i < @line; $i++) {
    if ($line[$i] =~ /int\s+\$0x80$/) {
	chop($line[$i]);
	# Look for a previous line (only 10) to set %eax
	$j = 1;
	while (($j < 10) && ($line[$i-$j] !~ /mov\s+.+,\%eax/)) {
	    $j++;
	}
	if ($line[$i-$j] != /mov\s+.+\%eax/) {
	    @aux = split(/\s+/, $line[$i-$j]);
	    $sysnum = pop(@aux);
	    $sysnum =~ s/,\%eax//;
	    $sysnum =~ s/^\$0x//;
	    $sysnum = hex($sysnum);

	}
	print "$line[$i] \# $syscall{$sysnum}()\n";
    } else {
	print $line[$i];
    }
}
