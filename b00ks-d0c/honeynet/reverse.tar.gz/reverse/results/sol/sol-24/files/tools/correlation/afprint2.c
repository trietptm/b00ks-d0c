/*

*/

#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <bfd.h>
//#include <libiberty.h>

#define SIGNATSIZE 100

unsigned char buf[SIGNATSIZE+4];

#define CODESEG (((unsigned int)buf) >> 24)

unsigned int result[4];

int main(int argc,char* argv[]) {
  int f,summ=0;
  asymbol** syms;
  int size,symcnt,i,off;
  bfd* b;
  char tagme=0;
  int ret;
  int num;

        bzero(buf,sizeof(buf));
	for (num=0;num<SIGNATSIZE;num++) {
		scanf("%2x",&ret);
		buf[num]=ret;
	}

        for (f=2;f<SIGNATSIZE;f++) {
          // This ain't no stinkin' code!
          if ((buf[f-2]==0x90) && (buf[f-1]==0x90) && (buf[f] == 0x90)) {
            buf[f-2]=0; buf[f-1]=0;
            tagme=1;
          }
          if (tagme) buf[f]=0;
        }

        // For sanity.
        for (f=0;f<SIGNATSIZE;f++)
         if (buf[f]==CODESEG) bzero(&buf[f-3],4);

        for (f=0;f<SIGNATSIZE;f++)
         if (buf[f]==0xe8) bzero(&buf[f+1],4);

        for (f=0;f<SIGNATSIZE;f++) printf("%02X ",buf[f]);
        printf("\n");



  return 0;

}
