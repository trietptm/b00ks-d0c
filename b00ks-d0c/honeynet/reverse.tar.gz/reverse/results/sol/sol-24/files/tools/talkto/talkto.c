/******************************************************************************\
* File:
*   talkto.c
*
* Description:
*   Tool to talk to "the-binary" of The Reverse Challenge.
*
* Authors:
*   Jorge Ortiz-Fuentes
*   Raul Siles
*
* Revisions:
*   2002-05-08. First version. 
*   2002-05-14. Payload adapted to talk �to the-binary�.
*	First version derived from "talk.c":
*	- Force first byte of the payload to be "0x02".
*	- Option for selecting number of bytes inside the packet. Default is 1500 bytes.
* 	  It should be at least 201 bytes: the minimum expected by "the-binary": 
*	  201 bytes = 20 IP header + 181 payload.
*
\******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

/* exit values */
#define EXIT_NO_ROOT 1
#define EXIT_NO_SOCK 1

/* default values */
#define SERVER_PROT 0xb
#define BUFF_SIZE 1480 /* Ethernet MTU: 1500 - IP header: 20 */

void help (char *, char *);
int talk(char *, int);

/*
Function:
  main
Description:
  Parses the command line.
*/
int
main (int argc, char * argv[])
{
  char * version = "1.0.0";
  char * server_name = "localhost";
  int server_prot = SERVER_PROT;
  int buff_size = BUFF_SIZE;
  char buffer[BUFF_SIZE];
  char * pbuffer = buffer;
  int sock;
  int c;
  int i = 0;
  int size = buff_size;
  /* By default it sends 1500 bytes packets = Ethernet MTU */

  opterr = 0;

  /* Initializing buffer */
  bzero(buffer,BUFF_SIZE);

  while ((c = getopt (argc, argv, "hp:s:b:")) != -1)
    switch (c)
      {
      case 'h':
	help(argv[0], version);
	exit(0);
	break;
      case 'p':
	server_prot = atoi(optarg);
	break;
      case 's':
	server_name = (char *)malloc(strlen(optarg));
	strcpy(server_name, optarg);
	break;
      case 'b':
	size = atoi(optarg);
	if (size > buff_size) {
	  fprintf (stderr, "Option `-%c': size (bytes) must be less than %d.\n", optopt,
			buff_size);
	  exit(-1);
	}
	break;
      case '?':
	if (isprint (optopt))
	  fprintf (stderr, "Option `-%c' IGNORED.\n", optopt);
	else
	  fprintf (stderr,
		   "Option character `\\x%x' IGNORED.\n",
		   optopt);
      }

  if (geteuid() != 0)
    {
      fprintf(stderr, "Only root can use this program!.Sorry.\n");
      help(argv[0], version);
      exit(EXIT_NO_ROOT);
    }
  if ((sock = talk(server_name, server_prot)) < 0)
    {
      fprintf(stderr, "Error while creating the socket.\n");
      exit(EXIT_NO_SOCK);
    }
  /* according to the IRIX TCP/IP programming guide,
     connectionless sockets  should be used with sendto instead of
     write */

  buff_size = BUFF_SIZE-1;
  pbuffer++;

  /* We get the user input and copy it to the buffer from the second byte to the end */
  while( (i=getline(&pbuffer, &buff_size, stdin)) != -1)
    {

	  /* Set first packet byte to 0x02 as "the-binary" expects */
	  *buffer=0x02;
	  buff_size = BUFF_SIZE;

	  printf("(0x%d)%s\n",*buffer,buffer);

	  /* Number of bytes to write:
		 - if option "-b" was not used, it will write 1480 bytes payload.
		 - if option "-b" was used:
			- if "size" is less or equal to "i+1" (characters read plus the 0x02)
			  then we write only the first "size" characters.
			  We set an ENTER (0x0a) at the end of the packet.
			- if "size" is greater than the read characters, "i+1", 
			  then we write all the read characters.
	  */

	  /* Payload allways has the characters and an end 0x0a */
	  if (size <= i) {
		buffer[size-1]=0x0a;
	  }
	  else {
		/* Nothing to do: we send all the read chars + zero aditional chars */
	  }

	  /* We only write the number of bytes selected (size) from the buffer */
      write(sock, buffer, size);

      /* Re-Initializing buffer */
  	  bzero(buffer,BUFF_SIZE);

      buff_size = BUFF_SIZE-1;
    }
  close(sock);

  return 0;
}



/*
Function:
  help
Description:
  prints a help message for the user (obtained with the -h option)
*/
void
help (char * name, char * version)
{
  fprintf(stderr, "USAGE:\n\t%s v%s [-options] \n\n", name, version);
  fprintf(stderr, "Servername is by default localhost.\n");
  fprintf(stderr, "Options:\n");
  fprintf(stderr, "\t-h #\tprint this help\n");
  fprintf(stderr, "\t-p #\tset protocol number (default is 0x0b)\n");
  fprintf(stderr, "\t-s #\tset server name (default is localhost)\n");
  fprintf(stderr, "\t-b #\tpayload block size for transmision (IP header includes 20 bytes)\n");
  fprintf(stderr, "\nExample.-\n");
  fprintf(stderr, "\t%s -shostname -p80 -b128 \n", name);
}



/*
Function:
  talk
Description:
  Creates a socket to the dessired server and protocol.
Returns:
  A file descriptor for the socket (positive value) if successful.
*/
int
talk(char * server_name, int protocol)
{
  struct hostent * host;
  struct in_addr addr;
  int sock, connected;
  struct sockaddr_in address;

  /* resolve hostname */
  if (inet_aton(server_name, &addr) == 0)
    {
      host = (struct hostent *)gethostbyname(server_name);
      if (host != NULL)
	memcpy(&addr, host->h_addr_list[0], sizeof(struct in_addr));
      else
	return -1;
    }

  /* set address to connect to */
  memset((char *) &address, 0, sizeof(address));
  address.sin_family = AF_INET;
  /*  address.sin_port = (port);*/
  address.sin_addr.s_addr = addr.s_addr;

  /* create the socket */
  sock = socket(AF_INET, SOCK_RAW, protocol);

  /* "connect" it to set destination address */
  connected = connect(sock, (struct sockaddr *) &address, 
		      sizeof(address));
  if (connected < 0) {
    perror("connect");
    return -2;
  }

  return sock;
}

