#include <pcap/pcap.h>
#include <netinet/ether.h>
#include <netinet/ip.h>


#define INPUTFILE   snort.log.ciphered
#define OUTPUTFILE  snort.log.cleartext


void process_packet(u_char *f,
                    struct pcap_pkthdr *pcapheader,
                    u_char *packet)
{
  /*
   * This function will be called by pcap_loop after each packet is read
   *
   * f  is the output filename
   * pcapheader is the pcap packet header
   * packet  is the packet itself
   *
   */

  int  size_payload;
  u_char *tmpbuff;

  /* These types from netinet/*.h */
  const struct ether_header *etherheader; /* The ethernet header */
  const struct iphdr        *ipheader;    /* The IP header */
  u_char              *payload;     /* Packet payload */

  /*
   * For readability, we'll make variables for the sizes of 
   * each of the structures
   */
  int size_ethernet = sizeof(struct ether_header);
  int size_ip = sizeof(struct iphdr);

  /* Print its length */
  printf("Read a packet with length of [%d]\n", pcapheader->len);

  /* And now we do our magical typecasting */
  etherheader  = (struct ether_header*)(packet);
  ipheader     = (struct iphdr*)(packet + size_ethernet);
  payload      = (u_char *)(packet + size_ethernet + size_ip);
  size_payload = ntohs(ipheader->tot_len)-size_ip;

  /* Print the length of the IP payload */
  printf("IP payload length: [%u] bytes.\n", size_payload);


  /* Let's try to decipher */
  tmpbuff = (u_char *) malloc (size_payload-2);
  bzero (tmpbuff, size_payload-2);
  r_decipher (size_payload-2, payload+2, tmpbuff);
  printf("tmpbuff: %s\n", tmpbuff+1);

  /* Replace ciphertext by cleartext */
  memcpy (payload+2, tmpbuff, size_payload-2);

  /* Put the packet in the output file */
  pcap_dump(f, pcapheader, packet);


} /* End of process_packet() */




int main()
{

  pcap_t        *cfin ;  /* cfin  stands for input  capture file */
  pcap_dumper_t *cfout;  /* cfout stands for output capture file */
  char *fnamein  = "./snort.log.ciphered";
  char *fnameout = "./snort.log.cleartext";
  int n; /* Number of packets read */


  /* These types from pcap/pcap.h */
  char errbuf[PCAP_ERRBUF_SIZE];   /* The error string */



  /* Here starts the action */


  /* Open the input trace file */
  cfin  = pcap_open_offline (fnamein, errbuf);
  if (cfin == NULL)  { printf("Error opening %s: %s\n", fnamein,  errbuf); };
  /* Open the output trace file */
  cfout = pcap_dump_open (cfin, fnameout);
  if (cfout == NULL) { printf("Error opening %s\n", fnameout); };

  /* Grab a packet and process it. Repeat until EOF */
  n = pcap_loop(cfin, 0, (pcap_handler) process_packet, (u_char *)cfout);

  /* Print statistics */
  printf ("Total number of packets processed: [%d]\n", n);

  /* Close the input trace file */
  pcap_close (cfin);

  /* Close the output trace file */
  pcap_dump_close (cfout);

  return(0);

/* Some code borrowed from:
---
Programming with pcap
Tim Carstens
timcarst at yahoo dot com
The latest version of this document can be found at
http://broker.dhs.org/pcap.html
This document is Copyright 2002 Tim Carstens.  All rights reserved.
Redistribution and use, with or without modification, are permitted provided
that the following conditions are met:  1. Redistribution must retain the
above copyright notice and this list of conditions.  2. The name of Tim
Carstens may not be used to endorse or promote products derived from this
document without specific prior written permission.
---
*/

} /* End of main() */

