#!/usr/bin/perl

#
# File:
#   identify.pl
#
# Description:
#   Identify functions ala fenris.
#
# Author:
#   German Martin
#   Modified by Jorge D. Ortiz-Fuentes
#
# Revisions:
#   2002-05-20. First version (shell script) by German Martin.
#   2002-02-27. Modified (perl version) by Jorge D. Ortiz-Fuentes.
#

use Digest::MD5 "md5";
use strict;

my %recog;
my @line;
my $line;
my @aux;
my $aux;
my @func;
my $addr;
my @bytes;
my $bytes;
my $found;
my $md5;
my @signat;
my $signature;
my $reset;
my $i;
my $j;

# check command line
if (@ARGV < 2) {
    die "Usage: $0 <binary_file> <signature_file>\n";
}

# load signatures
#print "Loading signatures...";
open(SIGN, $ARGV[1]) ||
    die "ERR: Couldn't open signature file $ARGV[1]: $!";
while ($aux = <SIGN>) {
    chop($aux);
    @aux = split(/\s/, $aux);
    $recog{$aux[2]} = $aux[1];
}
close(SIGN);
#print "done\n";

# this assumes that the objdump results fit in memory
open(OBJDUMP, "objdump -d $ARGV[0] 2>/dev/null|") ||
    die "ERR: Failed when using objdump: $!";
@line = <OBJDUMP>;
chop(@line);
close(OBJDUMP);

# get the addresses called in @aux
foreach $line (@line) {
    if ($line =~ /call\s+0x/) {
	$aux = (split(/\t+/, $line))[2];
	$aux =~ s/call\s+0x//;
	push(@aux, $aux);
    }
}
#sort them 
@aux=sort(@aux);

#eliminate duplicates
unshift(@func, shift(@aux));
foreach $line (@aux) {
    push(@func,$line) if ($func[$#func] ne $line);
}

# get the n first bytes after a call
foreach $addr (@func) {
    $i = 0;
    $found = 0;
    while (($i < @line) && ($found == 0)) {
	if ($line[$i] =~ /^ $addr/) {
	    # get the bytes for the signature
	    $j = $i;
	    $found = 1;
	    $bytes = 0;
	    @bytes = ();
	    # continue with the next lines till there are 24 bytes
	    while ($bytes < 24) {
		@aux = split(/\s+/, (split(/\t/, $line[$j]))[1]);
		$bytes += @aux;
		push(@bytes, @aux);
		$j++;
	    }
	    while (@bytes > 24) {
		pop(@bytes);
	    }
	    # sanity checks
	    $reset = 0;
	    for($j = 0; $j < 24; $j++) {
		if (($bytes[$j] eq "90") && ($bytes[$j] eq "90") &&
		    ($bytes[$j+2] eq "90")) {
		    $reset = 1;
		}
		$bytes[$j] = 0 if ($reset == 1);
		# remove addresses
		if ($bytes[$j] eq "08") {
		    $bytes[$j-3] = $bytes[$j-2] = $bytes[$j-1] =
			$bytes[$j] = 0;
		}
		if ($bytes[$j] eq "e8") {
		    $bytes[$j+1] = $bytes[$j+2] = $bytes[$j+3] =
			$bytes[$j+4] = 0;
		}		    
	    }


#	    print "$addr => @bytes\n";
	    for($j = 0; $j < 24; $j++) {
		$bytes[$j] = hex($bytes[$j]);
	    }
	    $signature = pack("C*", @bytes);
	    $md5 = md5($signature);
	    @signat = unpack("IIII",$md5);
#	    $aux = sprintf("%08X %08X %08X %08X", $signat[0],
#			   $signat[1], $signat[2], $signat[3]);
	    $signat[0] ^= $signat[2];
	    $signat[1] ^= $signat[3];
	    $signature = sprintf("%08X", $signat[0] ^ $signat[1]);

#	    print "$addr => ($aux) $signature $recog{$signature}\n";
	    if ($recog{$signature}) {
		$line[$i] .= "\t$recog{$signature}";
		# replace the calls also
		for($j = 0; $j < @line; $j++) {
		    if ($line[$j] =~ /call\s+0x$addr/) {
			$line[$j] .= "\t$recog{$signature}";
		    }
		}
	    }
	}
	$i++;
    }
    if ($found == 0) {
	print "$addr called but not found.\n";
    }
}

# print the edited objdump file
foreach $line (@line) {
    print "$line\n";
}
