#include <stdio.h>

#define MAX_BYTES 1024

void decode(int num_bytes, char *data, char *dest)
{
char var4[MAX_BYTES];
int i;
char tmp;

if (num_bytes<2) return;

for (i=num_bytes-1;i>=0;i--)
   {
	if (i==0)
		tmp=data[0];
	else
		tmp=data[i]-data[i-1];

	//if (tmp<0) tmp=256+tmp;
	memcpy(var4,dest,num_bytes-1);
	dest[0]=tmp-0x17;
	//memcpy(dest+1,var4,num_bytes-1);
	sprintf(dest,"%c%s",tmp-0x17,var4);
   }
}

main()
{
	char	destination[MAX_BYTES];

	decode(23,"olaPepe99ABCDEFGHIJABCD",destination);
	fprintf(stdout,"%s\n",destination);
}
