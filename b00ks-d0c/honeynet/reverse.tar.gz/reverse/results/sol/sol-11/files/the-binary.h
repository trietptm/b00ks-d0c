#ifndef THE_BINARY_H
#define THE_BINARY_H

#define CMD_RELAY_COMMAND               1
#define CMD_RELAY_SETUP                 2
#define CMD_SHELL_OUTPUT                3
#define CMD_DNSFLOOD_REFLECT            4
#define CMD_UDPORICMPFLOOD              5
#define CMD_SHELL                       6
#define CMD_SHELL_COMMAND               7
#define CMD_KILL_FLOOD                  8
#define CMD_DNSFLOOD_REFLECT_STEPPED    9
#define CMD_SYNFLOOD                    10
#define CMD_SYNFLOOD_STEPPED            11
#define CMD_DNSFLOOD_DIRECT             12

struct icmphdr
{
    unsigned char   type;
    unsigned char   code;
    unsigned short  checksum;
    union
    {
        struct
        {
            unsigned short  id;
            unsigned short  sequence;
        } echo;
        unsigned long   gateway;
        struct
        {
            unsigned short  __unused;
            unsigned short  mtu;
        } frag;
    } un;
};

struct iphdr
{
    unsigned char   version;
    unsigned char   tos;
    unsigned short  tot_len;
    unsigned short  id;
    unsigned short  frag_off;
    unsigned char   ttl;
    unsigned char   protocol;
    unsigned short  check;
    unsigned long   saddr;
    unsigned long   daddr;
};

struct tcphdr
{
    unsigned short  source;
    unsigned short  dest;
    unsigned long   seq;
    unsigned long   ack_seq;
    unsigned char   doff;
    unsigned char   flags;
    unsigned short  window;
    unsigned short  check;
    unsigned short  urg_ptr;
};

struct udphdr
{
    unsigned short  source;
    unsigned short  dest;
    unsigned short  len;
    unsigned short  check;
};

struct datahdr
{
    struct iphdr    iphdr;
    unsigned char   unknown[2];
};

#endif
