#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <pcap.h>

void decrypt(const unsigned char *src,unsigned char *dst, const int len)
{
  int i;
  for(i=len-1;i>0;i--)
    dst[i]=src[i]-src[i-1]-0x17;
  dst[0]=src[0]-0x17;
}

void decode(const unsigned char *buff,const int lu)
{
  unsigned char data[2048];
  if((buff[9]!=0xb) || (lu<200))
    return ;
  printf(" ======== Packet size=%d\n",lu);
  printf("%d.%d.%d.%d->%d.%d.%d.%d\n",buff[0xc],buff[0xd],buff[0xe],buff[0xf],
      buff[0x10],buff[0x11],buff[0x12],buff[0x13]);
 
  decrypt(&buff[22],data,lu-22);
  switch(buff[20])
  {
    case 2:
      {
	printf("client->server\n");
	data[lu-22]=0;
	switch(data[1])
	{
	  case 1:
	    printf("ask status\n");
	    break;
	  case 2:
	    printf("set hacker address %d.%d.%d.%d\n",data[3],data[4],data[5],data[6]);
	    printf("use fake address %d\n",data[2]);
	    break;
	  case 3:
	    printf("cmd=%s\n",&data[2]);
	    break;
	  case 4:
	    if(data[8]==0)
	      printf("send_dns from %d.%d.%d.%d",data[2],data[3],data[4],data[5]);
	    else
	      printf("send_dns from %s",&data[9]);
	    printf(":%d\n",data[6]<<8|data[7]);
	    break;
	  case 5:
	    printf("%s flood from %d.%d.%d.%d to ",
		data[2]==0?"ICMP":"UDP",
		data[4],data[5],data[6],data[7]);
	    if(data[12]==0)
	      printf("%d.%d.%d.%d",data[8],data[9],data[10],data[11]);
	    else
	      printf("%s",&data[13]);
	    if(data[2])
	      printf(":%d",data[3]);
	    printf("\n");
	    break;
	  case 6:
	    printf("remote shell\n");
	    break;
	  case 7:
	    printf("blind cmd=%s\n",&data[2]);
	    break;
	  case 8:
	    printf("kill\n");
	    break;
	  case 9:
	    if(data[9]==0)
	      printf("send_dns from %d.%d.%d.%d",data[2],data[3],data[4],data[5]);
	    else
	      printf("send_dns from %s",&data[10]);
	    printf(":%d nbr=%d\n",data[7]<<8|data[8],data[6]);
	    break;
	  case 10:
	    printf("TCP Syn flood from ");
	    if(data[8])
	      printf("%d.%d.%d.%d",data[9],data[10],data[11],data[12]);
	    else
	      printf("random IP");
	    if(data[13])
	      printf(" to %s",&data[14]);
	    else
	      printf(" to %d.%d.%d.%d",data[2],data[3],data[4],data[5]);
	    printf(":%u\n",data[6]<<8|data[7]);
	    break;
	  case 11:
	    printf("TCP Syn flood from ");
	    if(data[8])
	      printf("%d.%d.%d.%d",data[9],data[10],data[11],data[12]);
	    else
	      printf("random IP");
	    if(data[14])
	      printf(" to %s",&data[15]);
	    else
	      printf(" to %d.%d.%d.%d",data[2],data[3],data[4],data[5]);
	    printf(":%u foo=%d\n",data[6]<<8|data[7],data[13]);
	    break;
	  case 12:
	    if(data[13]==0)
	      printf("send_dns from %d.%d.%d.%d", data[6],data[7],data[8],data[9]);
	    else
	      printf("send_dns from %s",&data[14]);
	    printf(":%d to %d.%d.%d.%d foo=%d\n",
		data[11]<<8|data[12],
		data[2],data[3],data[4],data[5],
		data[10]);
	    break;
	  default:
	    printf("cmd=%d %s\n",data[1],&data[2]);
	    break;
	}
      }
      break;
    case 3:
      {
	printf("client<-server\n");
	data[lu-22]=0;
	data[0x190]=0;
	switch(data[1])
	{
	  case 1:
	    printf("status response\n");
	    if(data[3])
	      printf("working cmd=%d\n",data[4]);
	    else
	      printf("non working\n");
	    break;
	  default:
	    printf("cmd=%d %d %s\n",data[1],strlen(&data[2]),&data[2]);
	    break;
	}
      }
      break;
  }
}

int datalinkoffset(int type)
{
  switch (type)
  {
    case DLT_EN10MB:        return 14;
    case DLT_PPP:           return 4;
    case DLT_PPP_BSDOS:     return 24;
    case DLT_SLIP:          return 16;
    case DLT_SLIP_BSDOS:    return 24;
    case DLT_FDDI:          return 21;
    case DLT_IEEE802:       return 22;
    case DLT_RAW:           return 0;
    case DLT_LINUX_SLL:	    return 16;
    default:
			    printf("type=%d(0x%x)",type,type);
			    return -1;
  }
}

struct singleton {
  struct pcap_pkthdr *hdr;
  const u_char *pkt;
};

static void pcap_oneshot(u_char *userData, const struct pcap_pkthdr *h, const u_char *pkt)
{
  struct singleton *sp = (struct singleton *)userData;
  *sp->hdr = *h;
  sp->pkt = pkt;
}

int main()
{
  pcap_t *handle;                        /* Session handle */
  char *dev="any";                                /* The device to sniff on */
  char errbuf[PCAP_ERRBUF_SIZE]; /* Error string */
  struct pcap_pkthdr header;          /* The header that pcap gives us */
  const u_char *packet;                 /* The actual packet */
  int datalink;
  int offset;
  struct singleton s;
  /* Define the device */
  printf("device %s\n",dev);
  /* Open the session in promiscuous mode */
  handle = pcap_open_live(dev, BUFSIZ, 1, 0, errbuf);
  if(!handle)
  {
    perror("pcap_open_live failed ");
    return 1;
  }
/*
  datalink = pcap_datalink(handle);
  offset = datalinkoffset(datalink);
  if(offset < 0)
  { 
    printf("Unknown media\n");
    return 1;
  }
  */
  /* Grab a packet */
  datalink = pcap_datalink(handle);
  offset = datalinkoffset(datalink);


  while(1)
  { 
    /*
    int ret;
    s.hdr = &header;
    ret=pcap_dispatch(handle, 1, pcap_oneshot, (u_char*)&s);
    if(ret <= 0)
      printf("ret=%d, %s\n",ret,pcap_geterr(handle));
    else
    {
      packet=s.pkt;
      if(datalink!=DLT_LINUX_SLL || (packet[0xe]==8 && packet[0xf]==0))
	decode(packet+offset,header.caplen-offset);
    }
    */
    if((packet = pcap_next(handle, &header)))
    {
      if(datalink!=DLT_LINUX_SLL || (packet[0xe]==8 && packet[0xf]==0))
	decode(packet+offset,header.caplen-offset);
    }

  }
  /* And close the session */
  printf("pcap_close\n");
  pcap_close(handle);
  return(0);
}
