/*
    killer.c - Scans a class C network for the Honeynet project's
                "the-binary" DoS agent.
    Copyright (c) 2002 Chris Eagle

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>

#include <getopt.h>

#define BUF_SIZE 202
#define STATUS_BYTE 25
#define STATE_BYTE 26

int nvpSocket = 0;

void sub23decode(unsigned char *buf, int len) {
   int i;
   unsigned char offset = 23, prev = 0;
   for (i = 0; i < len; i++, offset += 23) {
       prev += buf[i] = buf[i] - prev - offset;
   }
}

void plus23encode(unsigned char *buf, int len) {
   int i;
   unsigned char prev = 0;
   for (i = 0; i < len; i++) {
       prev = buf[i] = buf[i] + prev + 23;
   }
}

int txPacket(int fd, struct in_addr *dest, unsigned char *packet, int len) {
   struct sockaddr_in to;
   int result = -1;
   unsigned char txpacket[182];
   if (fd != -1) {
      to.sin_addr = *dest;
      to.sin_port = 0;
      to.sin_family = AF_INET;
      txpacket[0] = 2;
      memcpy(txpacket + 2, packet, len);
      plus23encode(txpacket + 2, len);
      result = sendto(fd, txpacket, 182, 0, (struct sockaddr*) &to, sizeof(to));
   }
   return result == -1;
}

void reader() {
   int len;
   fd_set r, w, e;
   unsigned char buf[800];
   struct ip *ipHdr = (struct ip *) buf;
   while (1) {
      struct timeval tv = {4, 0};
      FD_ZERO(&r);
      FD_ZERO(&w);
      FD_ZERO(&e);
      FD_SET(nvpSocket, &r);
      if (!select(nvpSocket + 1, &r, &w, &e, &tv)) break;
      len = recv(nvpSocket, buf, 800, 0);
      if (len > 0) {
         if (len < 400 || buf[20] != 3) continue;
         sub23decode(buf + 22, len - 22);
         if (buf[23] == 1 && buf[24] == 7) {
            fprintf(stdout, "Found an agent at: %s, status is ", inet_ntoa(ipHdr->ip_src));
            if (buf[STATUS_BYTE]) {
               fprintf(stdout, "active, state = %d\n", buf[STATE_BYTE]);
            }
            else {
               fprintf(stdout, "idle\n");
            }
         }
      }
      else {
         break;
      }
   }
   close(nvpSocket);
}

void usage(char *cmd) {
    fprintf(stdout, "Usage: %s -i <ownip> -n <network>\n", cmd);
    fprintf(stdout, "   -i: the ip of the machine you are running this on\n");
    fprintf(stdout, "       sorry, but I am too lame to figure it out reliably.\n");
    fprintf(stdout, "   -n: the network you wish to scan as w.x.y.z, all integers, nothing fancy\n");
    exit(1);
}

int main(int argc, char **argv) {

   struct in_addr net;
   struct in_addr self;
   pthread_t readThread;
   int result, r, haveOwnIP = 0, haveNet = 0;
   void *tResult;
   unsigned char buf[10];
   unsigned char *byte4 = (unsigned char*)&net.s_addr;
   byte4 += 3;

   while (1) {
      r = getopt(argc, argv, "i:n:");
      if (r < 0) break;
      switch (r) {
      case 'i':
         inet_aton(optarg, &self);
         haveOwnIP = 1;
         break;
      case 'n':
         inet_aton(optarg, &net);
         haveNet = 1;
         break;
      default:
         usage(argv[0]);
      }
   }    

   if (!haveOwnIP || !haveNet) {
      usage(argv[0]);
   }    

   nvpSocket = socket(AF_INET, SOCK_RAW, 11);   
   if (nvpSocket > 0) {
      if (fork()) {
         reader();
      }
      else {
         for (r = 0; r < 256; r++) {
            *byte4 = r;
            buf[1] = 2;
            buf[2] = 0;
            memcpy(buf + 3, &self.s_addr, 4);
            txPacket(nvpSocket, &net, buf, 10);
            buf[1] = 1;
            txPacket(nvpSocket, &net, buf, 10);
         }
      }
   }
}
