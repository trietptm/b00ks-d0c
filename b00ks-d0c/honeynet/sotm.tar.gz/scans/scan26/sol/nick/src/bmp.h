/*
*  bmp.h definitions
*	Stripped from various sources.
*/

#define	BMAGIC 0x4d42

typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned long dword;


typedef struct {
	word		biType;
	dword		biFileSize;
	word		biReserved1;
	word		biReserved2;
	dword		biDataOffset;
	dword		biInfoSize;
	dword		biWidth;
	dword		biHeight;
	word		biPlanes;
	word		biBitCount;
	dword		biCompression;
	dword		biSizeImage;
	dword		biXPelsPerMeter;
	dword		biYPelsPerMeter;
	dword		biClrUsed;
	dword		biClrImportant;
} bmpinfo;


