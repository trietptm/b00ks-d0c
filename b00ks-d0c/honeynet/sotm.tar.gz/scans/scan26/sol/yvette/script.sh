##!/bin/sh
for i in `seq 1 140000`
         do
                 echo -n "offset $i :"
                (
                   dd if=scan26orig of=ntani skip=$i 2>/dev/null | \
                   file ntani | \
                   grep -v empty
                 )
         done

