
#include <stdio.h>
#include <fcntl.h>

int main(int argc, char **argv) {
   char buf[54];
   char ch = 0;
   int count = 0;
   int size = 0, osize = 0;
   int fd, ofd;
   char *dest;
   if (argc != 2) {
      printf("usage: extract <bmpfile>\n");
      return 1;
   }
   dest = (char*) malloc(strlen(argv[1]) + 5);
   strcpy(dest, argv[1]);
   strcat(dest, ".lsb");
   fd = open(argv[1], O_RDONLY);
   ofd = open(dest, O_WRONLY | O_CREAT, 0644);
   free(dest);
   read(fd, buf, 54);
   
   while (read(fd, buf, 1) == 1) {
      size++;
      ch += ch + (*buf & 1);
      count++;
      if (count == 8) {
         write(ofd, &ch, 1);
         osize++;
         count = 0;
      }
   }
   close(fd);
   close(ofd);
   printf("read %d bytes, wrote %d bytes\n", size, osize);
}
