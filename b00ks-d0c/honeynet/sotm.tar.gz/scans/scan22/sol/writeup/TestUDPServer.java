import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.net.SocketException;
import java.io.IOException;

/**
*  TestUDPServer implements the reverse engineered network protocol
*  of the foo/ttserve binary in the Aug. 2002 Honeypot Scan of the Month Challenge.
*
*  @author Brendan A. McLean
*  @version 08/2002
*
*/

public class TestUDPServer {

//socket info
protected static int listenPort = 53413;
protected static String listenAddr = "192.168.103.2";
protected static int defaultBufferSize = 65507;

//protocol responses
protected static String duResponse = "DU";
protected static String dieResponse = "DIE\n";
protected static String gotResponse = "GOT\n";

//start uin
protected static int uinCount = 9207000;

//request count
protected static int requestCount = 0;

/**
* Responds to each command of the protocol at least once. 
* After foo/ttserve has requested two 100 length blocks of UIN's, send the DIE command.
*
* @param ds This server's socket. 
* @param dp This request packet coming from foo/ttserve.
*/

public static void respond(DatagramSocket ds, DatagramPacket dp) {

	DatagramPacket outgoing;	
	byte[] req = dp.getData(); 
	String req_string = new String(req);
	String response = null;

	if (req_string.startsWith("GU")) {
		if (requestCount < 2) {
			requestCount += 1;
			uinCount += 100;
			response = duResponse + uinCount + "\n";
		}else{
			response = dieResponse;
		}
	}else if (req_string.startsWith("SE")) {
		response = gotResponse;
	}

	byte[] data = response.getBytes(); 

	try {
		outgoing = new DatagramPacket(data, data.length, dp.getAddress(), dp.getPort() );
		ds.send(outgoing);
	}
	catch (IOException e) {
		System.err.println(e);
	}
}

public static void main(String[] argv) {

	DatagramPacket incoming = null;
	
	try {
		DatagramSocket ds = new DatagramSocket(listenPort,InetAddress.getByName(listenAddr));
		byte[] inputBuffer = new byte[defaultBufferSize];

		while (true) {
			incoming = new DatagramPacket(inputBuffer, inputBuffer.length);
			try {
				ds.receive(incoming);
				respond(ds,incoming);
			}
			catch (IOException e) {
				System.err.println(e);
			}
		}
	}
	catch (SocketException e) {
		System.err.println(e);
	}
	catch (UnknownHostException e) {
		//Ignore, we know the IP won't resolve...
	}
}//end main

}//end class
