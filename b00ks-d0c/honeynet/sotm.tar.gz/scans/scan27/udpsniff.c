#include <stdio.h>
#include <string.h>
#include <pcap.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <net/ethernet.h>
#include <stdlib.h>

int main(int argc,char **argv)
{
	pcap_t *pcap_pkt;
	char ebuf[PCAP_ERRBUF_SIZE];
	struct pcap_pkthdr pcap_h;
	unsigned char       *pkt;
	const struct ip     *pip;
	const struct udphdr *pudp;
	u_char ip_hlen;
	u_int  ip_len;
	u_int  udp_len;
	struct bpf_program filter;
	int ok;
	int i;

	pcap_pkt = pcap_open_offline(argv[1],ebuf);

	ok = pcap_compile(pcap_pkt, &filter, argv[2], 0, 0);
	if (ok == -1)
	{
	    printf("\n%s\n", pcap_geterr(pcap_pkt));
	    exit(1);
	}
	
	ok = pcap_setfilter(pcap_pkt, &filter);
	if (ok == -1)
	{
	    printf("\n%s\n", pcap_geterr(pcap_pkt));
	    exit(1);
	}
	
	while ( (pkt=(u_char *)pcap_next(pcap_pkt,&pcap_h)) != NULL )
	{
	    pip = (struct ip*) (pkt + sizeof(struct ether_header));
	    ip_hlen = 4*pip->ip_hl;
	    ip_len  = ntohs(pip->ip_len);
	    udp_len = ip_len - ip_hlen;

	    pudp = (struct udphdr*) (((char *)(pip)) + ip_hlen);
	    printf("%s ", inet_ntoa(pip->ip_src.s_addr));
	    for (i=8; i < udp_len; i++)
	    {
	        printf("%02x-", *((unsigned char*)(pudp) + i));	
	    }
	    printf("\n");
	}
	pcap_close(pcap_pkt);
	return 0;
}
