#!/bin/bash
# These were the commands used to retrive "Jimmy Jungle.doc", "cover page.jpgc",
# and "Scheduled Visits.exe" from the dd image 
# the output files were named as such so I could keep track of where I got them 

SECTOR_SIZE="512"			#bytes per sector in FAT12
IMAGE="image"

JIMMY_OFFSET="33"			#file data is located in sectors 33-72
JIMMY_SIZE=`echo "(73-33)"|bc`
dd \
if=$IMAGE \
of="Jimmy Jungle-$JIMMY_OFFSET+$JIMMY_SIZE.doc" \
bs=$SECTOR_SIZE \
count=$JIMMY_SIZE \
skip=$JIMMY_OFFSET


COVER_OFFSET="73"			#file data is located in sectors 73-103
COVER_SIZE=`echo "(104-73)"|bc`
dd \
if=$IMAGE \
of="cover page-$COVER_OFFSET+$COVER_SIZE.jpg" \
bs=$SECTOR_SIZE \
count=$COVER_SIZE \
skip=$COVER_OFFSET


VISITS_OFFSET="104"			#this offset starts the sector after 
					#the "cover page.jpgc" data ends
VISITS_SIZE=`echo "(109-104)"|bc`	#this is 5 sectors
dd \
if=$IMAGE \
of="Scheduled Visits-$VISITS_OFFSET+$VISITS_SIZE.zip" \
bs=$SECTOR_SIZE \
count=$VISITS_SIZE \
skip=$VISITS_OFFSET

md5sum *.doc *.jpg *.zip
