#include <stdio.h>

int main(int argc, char* argv[])
{
	char* pcPatchFile = NULL;
	char* pcTarget = NULL;

	FILE* fpPatch = NULL;
	FILE* fpTarget = NULL;

	int iOffset = 0;
	
	int iOldByte = 0;
	int iNewByte = 0;

	char cOldByte = '\0';
	char cNewByte = '\0';


	if(argc != 3)
	{
		printf("Usage: cmppatch patchfile target\n");
		return -1;
	}

	// quick and dirty argument handling
	pcPatchFile = argv[1];
	pcTarget = argv[2];

	// quick and dirty file handling
	if((fpPatch = fopen(pcPatchFile, "r")) == NULL)
	{
		fprintf(stderr, "Could not open file: %s for read.\n", pcPatchFile);
		return -1;
	}

	// quick and dirty file handling
	if((fpTarget = fopen(pcTarget, "r+")) == NULL)
	{
		fprintf(stderr, "Could not open file: %s for read/write.\n", pcTarget);
		fclose(fpPatch);
		return -1;
	}

	
	while(fscanf(fpPatch, "%x %x %x", &iOffset, &iOldByte, &iNewByte) != EOF)
	{
		fseek(fpTarget, iOffset, SEEK_SET);
		fscanf(fpTarget, "%c", &cOldByte);

		if(cOldByte != (char) iOldByte)
		{
			fprintf(stderr, "Byte mismatch: %x %x %x\n", iOffset, (int) cOldByte, iOldByte);
			break;
		}
		else
		{
			//fprintf(stderr, "Patching: %x %x %x\n", iOffset, iOldByte, iNewByte);

			fseek(fpTarget, iOffset, SEEK_SET);
			fprintf(fpTarget, "%c", (char) iNewByte);
		}
	}
	
	fclose(fpPatch);
	fclose(fpTarget);

	return 0;
}
