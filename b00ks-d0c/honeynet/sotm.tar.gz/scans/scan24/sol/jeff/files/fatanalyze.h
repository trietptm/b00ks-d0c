#ifndef _FATANALYZE_H_
#define _FATANALYZE_H_

struct FAT_sb {
  char jumpb[3];
  char OEM[8];
  unsigned short bytesPerSector;
  unsigned char sectorsPerCluster;
  unsigned short numReserved;
  unsigned char FATCopies;
  unsigned short numRDirEntries;
  unsigned short numSectors;
  unsigned char mediaDescriptor;
  unsigned short sectorsPerFAT;
  unsigned short sectorsPerTrack;
  unsigned short numHeads;
  unsigned short numHiddenSectors;
};

struct FAT_dir_entry {
  char filename[11];
  char attributes;
  char reserved[10];
  unsigned short time;
  unsigned short date;
  unsigned short start;
  int size;
  struct FAT_dir_entry *next;
};
  
struct FAT_directory {
  struct FAT_dir_entry *head;
};  
struct FAT_sb *readSuperblock (int fd);
struct FAT_dir_entry *readDirectory (int fd);
void bomb (const char *error);
void printSuperblock(struct FAT_sb *sb);
void printDirectory(struct FAT_dir_entry *d);
#endif

