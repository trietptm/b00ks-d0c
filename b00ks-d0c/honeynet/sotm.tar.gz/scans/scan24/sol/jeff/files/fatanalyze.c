/**
 * FATAnalzye
 *  Performs simple analysis on images that are FAT filesystems
 *
 * Jeff Craig <craig@cs.montana.edu>
 **/
#include "fatanalyze.h"
#include <stdio.h>
#include <malloc.h> 
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main (int argc, char **argv)
{
  struct FAT_sb *superblock;
  struct FAT_dir_entry *dir;
  int fd,calc;

  if (argc < 2) {
    bomb("Not enough arguments");
  }

  fd = open(argv[1],O_RDONLY);
  if (fd == -1) {
    bomb("Error Opening File");
  }

  superblock = readSuperblock(fd);
  
  printSuperblock(superblock);
  //calc = 512 + (superblock->bytesPerSector)*(superblock->sectorsPerFAT)* (superblock->FATCopies) + 64;
  calc = 9792;
  lseek (fd, calc, SEEK_SET);
  
  dir = readDirectory(fd);
  printDirectory(dir);
  
  close(fd);
  return 1;
}

struct FAT_sb *readSuperblock (int fd)
{
  int e;
  struct FAT_sb *sb;
  sb = (struct FAT_sb *)malloc(sizeof(struct FAT_sb));
 

  e = read(fd, &sb->jumpb,3);
  if (e == -1) {
    bomb("Error Reading sb->jumpb");
  }
  
  e = read(fd, &sb->OEM,8);
  if (e == -1) {
    bomb("Error Reading sb->OEM");
  }

  e = read(fd, &sb->bytesPerSector, 2);
  if (e == -1) {
    bomb("Error Reading sb->bytesPerSector");
  }

  e = read(fd, &sb->sectorsPerCluster, 1);
  if (e == -1) {
    bomb("Error Reading sb->sectorsPerCluster");
  }

  e = read(fd, &sb->numReserved, 2);
  if (e == -1) {
    bomb("Error Reading sb->numReserved");
  }

  e = read(fd, &sb->FATCopies, 1);
  if (e == -1) {
    bomb("Error Reading sb->FATCopies");
  }

  e = read(fd, &sb->numRDirEntries, 2);
  if (e == -1) {
    bomb("Error Reading sb->numRDirEntries");
  }

  e = read(fd, &sb->numSectors,2);
  if (e == -1) {
    bomb("Error Reading sb->numSectors");
  }
  
  e = read(fd, &sb->mediaDescriptor,1);
  if (e == -1) {
    bomb("Error Reading sb->mediaDescriptor");
  }

  e = read(fd, &sb->sectorsPerFAT, 2);
  if (e == -1) {
    bomb("Error Reading sb->sectorsPerFAT");
  }

  e = read(fd, &sb->sectorsPerTrack, 2);
  if (e == -1) {
    bomb("Error Reading sb->sectorsPerTrack");
  }

  e = read(fd, &sb->numHeads, 2);
  if (e == -1) {
    bomb("Error Reading sb->numHeads");
  }

  e = read(fd, &sb->numHiddenSectors, 2);
  if (e == -1) {
    bomb("Error Reading sb->numHidden");
  }

  return sb;
}

void printSuperblock(struct FAT_sb *sb)
{
  printf("OEM String: %s\n",sb->OEM);
  printf("Number of Bytes/Sector: %i\n",sb->bytesPerSector);
  printf("Number of Sectors/Cluster: %i\n",sb->sectorsPerCluster);
  printf("Number of Reserved sectors: %i\n",sb->numReserved);
  printf("Number of FAT Copies: %i\n",sb->FATCopies);
  printf("Number of Root Directory Entries: %i\n",sb->numRDirEntries);
  printf("Total number of sectors in the filesystem: %i\n",sb->numSectors);
  printf("Number of Sectors per FAT: %i\n",sb->sectorsPerFAT);
  printf("Number of Sectors per Track: %i\n",sb->sectorsPerTrack);
  printf("Number of heads: %i\n",sb->numHeads);
  printf("Number of Hidden Sectors: %i\n",sb->numHiddenSectors);
}

struct FAT_dir_entry *readDirectory (int fd)
{
  int e, i=0;
  char c;
  struct FAT_dir_entry *dir, *current;
  dir = (struct FAT_dir_entry *)malloc(sizeof(struct FAT_dir_entry));
  current = dir;
 
  while (i != 9) {
    if (i != 0 && i != 3 && i != 6) {
      lseek(fd, 32, SEEK_CUR);
    }
    else {
      current->next = (struct FAT_dir_entry *)malloc(sizeof
						     (struct FAT_dir_entry));
      if (current->next == NULL) {
	bomb("malloc() error");
      }
      current = current->next;
      e = read(fd, current->filename,11);
      if (e == -1) {
	bomb ("Read Error: dir->filename");
      }
      
      e = read(fd, &current->attributes, 1);
      if (e == -1) {
	bomb ("Read Error: dir->attributes");
      }
      
      e = read(fd, &current->reserved, 10);
      if (e == -1) {
	bomb ("Read Error: dir->reserved");
      }
      
      e = read(fd, &current->time, 2);
      if (e == -1) {
	bomb ("Read Error: dir->time");
      }
      
      e = read(fd, &current->date, 2);
      if (e == -1) {
	bomb ("Read Error: dir->date");
      }
      
      e = read(fd, &current->start, 2);
      if (e == -1) {
	bomb ("Read Error: dir->start");
      }
      
      e = read(fd, &current->size, 4);
      if (e == -1) {
	bomb ("Read Error: dir->size");
      }
    }
    i++;
  }
  return dir;
}

void printDirectory(struct FAT_dir_entry *d)
{
  int i = 1;
  struct FAT_dir_entry *current = d;

  do {
    printf("File Number: %i\n", i);
    printf("File Name: %s\n",current->filename);
    printf("Start Sector: %i\n",current->start);
    printf("File Size: %i\n",current->size);

    current = current->next;
    i++;
  } while(current != NULL);
}
void 
bomb (const char *error)
{
  printf("%s",error);
  exit(-1);
}
